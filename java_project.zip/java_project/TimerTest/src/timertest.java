import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.Timer;
import java.util.TimerTask;
public class timertest {
    public static void main(String[] args) {
    	/* 
        final ScheduledExecutorService ses = Executors.newSingleThreadScheduledExecutor();
        ses.scheduleWithFixedDelay(new Runnable() {
            @Override
            public void run() {
                System.out.println(new Date());
            }
        }, 0, 1, TimeUnit.SECONDS);
        */

        final ScheduledExecutorService ses = Executors.newSingleThreadScheduledExecutor();
        ses.schedule(new Runnable() {
        	 @Override
             public void run() {
                 System.out.println(new Date());
             }
        }, 1, TimeUnit.SECONDS);

     //   Timer timer;
    //    timer = new Timer();
        //timer.
     /*   
        TimerTask timerTask = new TimerTask()
        {
            @Override
            public void run()
            {
            	System.out.println(new Date());
            }
        };*/
    }
}