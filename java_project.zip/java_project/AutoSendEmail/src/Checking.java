import java.awt.Font;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.JTextPane;

public class Checking {
	
	public static void main(String[] args) throws Exception{
		ArrayList<String> checkinglist = new ArrayList<String>();
		ArrayList<String> fileList = new ArrayList<String>();
		ArrayList<String> fileName = new ArrayList<String>();
	    SimpleDateFormat sdfDate = new SimpleDateFormat("yyyyMMdd");//dd/MM/yyyy
	    Date now = new Date();
	    String strDate = sdfDate.format(now);
	    System.out.println(strDate);
	    String sourceFolder="D:\\autoSendEmail\\testing";
	    String targetFolder="D:\\autoSendEmail\\target";
	    File folderPath = new File(sourceFolder);
	    File targetPath = new File(targetFolder);
        File listDir[] = folderPath.listFiles();
        for (int i = 0; i < listDir.length; i++) {
            if (listDir[i].toString().contains(strDate)) {
            	System.out.println(listDir[i].toString());
            	fileList.add(listDir[i].toString());
            	fileName.add(listDir[i].getName());
            }
        }
//        for (int i = 0; i < fileList.size(); i++) {
//        	Path source= Paths.get(fileList.get(i).toString());
//        	String changePath =fileList.get(i).toString();
//        	Path target= Paths.get(targetFolder+"\\"+fileName.get(i).toString());
//        	System.out.println(target);
//        	Files.copy(source, target, StandardCopyOption.REPLACE_EXISTING);
//        }
//		String checkingInfo =args[0];
        for (int i = 0; i < fileList.size(); i++) {
			try {
				BufferedReader fileReader = new BufferedReader(new FileReader(fileList.get(i).toString()));
				String line=null;
				int count =0;
			    try {
					while ((line = fileReader.readLine()) != null)
					{	

						if(count!=0) {
							checkinglist.add(line);
							System.out.println(line);
						}
						count++;
					}
					fileReader.close();
				} 
			    catch (IOException e1) {
					e1.printStackTrace();
				}
			} 
			catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
        }
	}
}