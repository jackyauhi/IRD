import java.awt.Font;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JTextPane;

public class SendEmail {
	
	public static void main(String[] args) throws Exception{
		ArrayList<String> datalist = new ArrayList<String>();
		ArrayList<String> contentlist = new ArrayList<String>();
		ArrayList<String> attachmentslist = new ArrayList<String>();
		ArrayList<String> powershellList = new ArrayList<String>();
		String dataFileName=args[0];
		String sendEmailLocation = "D:\\autoSendEmail\\email\\";


		File file = new File(sendEmailLocation);
		if(!file.exists()) 
			file.mkdirs();
		
		File dataFile = new File(dataFileName);

		try {
			BufferedReader fileReader = new BufferedReader(new FileReader(dataFile));
			String line=null;
			int count =0;
		    try {
				while ((line = fileReader.readLine()) != null)
				{	
					if(count!=0) {
						datalist.add(line);
					}
					count++;
				}
				fileReader.close();
			} 
		    catch (IOException e1) {
				e1.printStackTrace();
			}
		} 
		catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
		try {
			BufferedReader fileReader = new BufferedReader(new FileReader(args[1]));
			String line=null;
		    try {
				while ((line = fileReader.readLine()) != null)
				{					
					contentlist.add(line);	
				}
				fileReader.close();
			} 
		    catch (IOException e1) {
				e1.printStackTrace();
			}
		} 
		catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
		try {
			BufferedReader fileReader = new BufferedReader(new FileReader(args[2]));
			String line=null;
		    try {
				while ((line = fileReader.readLine()) != null)
				{					
					attachmentslist.add(line);	
				}
				fileReader.close();
			} 
		    catch (IOException e1) {
				e1.printStackTrace();
			}
		} 
		catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}

		for(int i = 0; i <datalist.size(); i++){
			String[] dataSplit = datalist.get(i).toString().split(",");
			String emailFrom="\""+dataSplit[0]+"\"";
			String emailTo="\""+dataSplit[1]+"\"";
			String subject=dataSplit[2];
			String dearPerson=dataSplit[3];
			
		String mailName="AutoSendEmail"+i;
		String sMTPServer="\"10.31.22.92\"";
		
		
		file = new File(sendEmailLocation + mailName + ".ps1");
		powershellList.add(file.getAbsolutePath());
//		if(file.exists()) 
//			file.delete();
		StringBuffer body = new StringBuffer();
		body.append("\"");
		body.append("Dear "+dearPerson+","+ "`n");
		body.append("`n");
		for(int j = 0; j <contentlist.size(); j++){
			body.append(contentlist.get(j).toString());
		}
		body.append("\"");
		StringBuffer attachmentsSource = new StringBuffer();
		for(int j = 0; j <attachmentslist.size(); j++){
			if(j==0) {
				attachmentsSource.append(" -Attachments ");
				attachmentsSource.append("\"");
			}
			attachmentsSource.append(attachmentslist.get(j).toString());
			if(j==attachmentslist.size()) {
				attachmentsSource.append("\"");
			}
		}
		BufferedWriter bw = new BufferedWriter(new FileWriter(file));  
		
	    StringBuffer buf=new StringBuffer();
	    
	    buf.append("send-mailmessage -Encoding ([System.Text.Encoding]::UTF8) -from ");
	    buf.append(emailFrom);
	    buf.append(" -to ");
	    buf.append(emailTo);
	    buf.append(" -subject ");
	    buf.append("\"");
	    buf.append(subject);
	    buf.append("\"");
	    buf.append(" -body ");
	    buf.append(body);
	    buf.append(attachmentsSource);
//	    buf.append("\"");
//	    buf.append("D:\\autoSendEmail\\testing\\no_output_20210818_batch_morning.txt");
//	    buf.append("\"");
	    buf.append(" -dno onSuccess, onFailure -smtpServer ");
	    buf.append(sMTPServer);
	    buf.append(";");
	    bw.write(buf.toString());
	    bw.flush();
	    bw.close();
	    String command = "powershell.exe -executionpolicy bypass -file " + file.toString();
	    Process powerShellProcess = Runtime.getRuntime().exec(command);
	    powerShellProcess.getOutputStream().close();
	    System.out.println("Email done");
		}
		//powershell -file "D:\autoSendEmail\email\AutoSendEmail*.ps1"
		try {
			FileWriter fileWriter = new FileWriter(sendEmailLocation+"powershell.bat");
			for (int i = 0; i < powershellList.size(); i++) {
				fileWriter.write("powershell -file "+'"'+powershellList.get(i).toString()+'"' + System.lineSeparator());
			}
			fileWriter.close();
		} catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data in outputPathList");
		}
//		String command = "powershell.exe -executionpolicy bypass -file " + file.toString();
		  // Executing the command
		
//		Process powerShellProcess = Runtime.getRuntime().exec(command);
		
		//System.out.println("Here is the standard output of the command:\n");
		//BufferedReader stdInput = new BufferedReader(new InputStreamReader(powerShellProcess.getInputStream()));
		//BufferedReader stdError = new BufferedReader(new InputStreamReader(powerShellProcess.getErrorStream()));
//		String s = null;
//		while ((s = stdInput.readLine()) != null) {
//		    System.out.println(s);
//		}
//
//		// read any errors from the attempted command
//		System.out.println("Here is the standard error of the command (if any):\n");
//		while ((s = stdError.readLine()) != null) {
//		    System.out.println(s);
//		    
//		}
//		stdInput.close();
//		stdError.close();
//		powerShellProcess.waitFor();
		
//		powerShellProcess.getOutputStream().close();
		
		
		//file.delete();
//		System.out.println("Email done");

		
	}
}