import java.awt.Font;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JTextPane;

public class SendEmail {
	
	public static void main(String[] args) throws Exception{
		ArrayList<String> datalist = new ArrayList<String>();
		String emailFrom="\""+args[0]+"@ird.gov.hk"+"\"";
		String subject=new String();
		String dataFileName=args[1];
		String typeOfEmail=args[2];

		

		File file = new File("D:\\SendEmail\\email\\");
		if(!file.exists()) 
			file.mkdirs();
		
		File dataFile = new File(dataFileName);

		try {
			BufferedReader fileReader = new BufferedReader(new FileReader(dataFile));
			String line=null;
		    try {
				while ((line = fileReader.readLine()) != null)
				{	
					
					datalist.add(line);
					
					
				}
				fileReader.close();
			} 
		    catch (IOException e1) {
				e1.printStackTrace();
			}
		} 
   	catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
		

		for(int i = 0; i <datalist.size(); i++){
			String[] dataSplit = datalist.get(i).toString().split(",");

		String emailTo="\""+dataSplit[0]+"\"";

		String dearPerson=dataSplit[1];
		
		String accountPassword=new String();
		
		
		accountPassword=dataSplit[2];
		
		String mailName="SendEmail"+i;
		String sMTPServer="\"10.31.22.92\"";
		
		
		file = new File("D:\\SendEmail\\email\\" + mailName + ".ps1");

		StringBuffer body = new StringBuffer();

		body.append("\"");
		body.append("Dear "+dearPerson+","+ "`n");
		body.append("`n");
		if(typeOfEmail.equals("1")){
			subject="*Restricted: Your initial password of the new OnDemand system";
			body.append("Your are invited to join the pilot test of the new OnDemand system on 19 Dec 2019 (Thursday) from 10:00 a.m. To 11:00 a.m."
					+ "  During the pilot test, you will"+"`n");
			body.append("(a)	enter your initial password;"+"`n");
			body.append("(b)	change your password; and,"+"`n");
			body.append("(c)	open the reports that are relevant to your official duties (from 10:30 a.m. to 11:00 a.m.)."+"`n");
			body.append("`n");
			body.append("The pilot test aims to: -"+"`n");
			body.append("(a)	ascertain whether the new OnDemand system is ready to handle a large number of simultaneous log-ons; and,"+"`n");
			body.append("(b)	provide an opportunity to pilot users getting familiar to the new OnDemand system."+"`n");
			body.append("`n");
			body.append("Please use this initial password to log on your account."
					+ "  You will be prompted to change the password upon the first log-on."+"`n");
			body.append("`n");
			body.append("OnDemand Account: LXXXXX (XXXXX = Badge Number)"+ "`n");
			body.append("OnDemand password: "+accountPassword+ "`n");
			body.append("`n");
			body.append("This email deliberately does not show your account name and the password at the same time to protect the computer security."+"`n");
			body.append("`n");
			body.append("Please notice the new OnDemand system implements the IRD password complexity policy and the password of your OnDemand account must: -"+"`n"); 
			body.append("(a)	contain at least eight characters, including at least one uppercase letter (A through Z), at least one lowercase letter (a through z), at least one digit (0 through 9)"+"`n");
			body.append("(b)	not contain the user name (i.e. Badge Number)"+"`n");
			body.append("(c)	not contain part of your full name"+"`n");
			body.append("`n");
			body.append("If you have enquiries in these aspects, please contact me."
					+ "  I will refer your enquiries to the colleagues, who will answer your enquiries."+"`n");
			body.append("(a)	You cannot log on the new OnDemand system, or"+"`n");
			body.append("(b)	You cannot view the reports you are authorised to do so."+"`n");
			body.append("`n");
		}
		else if(typeOfEmail.equals("2")){
			subject="*Restricted: Your initial password of the new OnDemand system";
			body.append("The new OnDemand would be implemented on 23 December 2019."
					+ "  To start, please use the below initial password to log on your account."
					+ "  You will be prompted to change the password upon the first log-on."+"`n");
			body.append("`n");
			body.append("OnDemand Account: LXXXXX (XXXXX = Badge Number)"+ "`n");
			body.append("OnDemand password: "+accountPassword+ "`n");
			body.append("`n");
			body.append("This email deliberately does not show your account name and the password at the same time to protect the computer security."+"`n");
			body.append("`n");
			body.append("Please notice the new OnDemand system implements the IRD password complexity policy and the password of your OnDemand account must: -"+"`n"); 
			body.append("(a)	contain at least eight characters, including at least one uppercase letter (A through Z), at least one lowercase letter (a through z), at least one digit (0 through 9)"+"`n");
			body.append("(b)	not contain the user name (i.e. Badge Number)"+"`n");
			body.append("(c)	not contain part of your full name"+"`n");
			body.append("`n");
		}
		body.append("Best Regards,"+"`n");
		body.append("`n");
		body.append("CHEUNG Lui"+"`n");
		body.append("A(Computer)1"+"`n");
		body.append("Tel 2594 5087"+"`n");
		body.append("\"");

		BufferedWriter bw = new BufferedWriter(new FileWriter(file));  
		
	    StringBuffer buf=new StringBuffer();
	    
	    buf.append("send-mailmessage -Encoding ([System.Text.Encoding]::UTF8) -from ");
	    buf.append(emailFrom);
	    buf.append(" -to ");
	    buf.append(emailTo);
	    buf.append(" -subject ");
	    buf.append("\"");
	    buf.append(subject);
	    buf.append("\"");
	    buf.append(" -body ");
	    buf.append(body);

	    buf.append(" -dno onSuccess, onFailure -smtpServer ");
	    buf.append(sMTPServer);
	    buf.append(";");
	    bw.write(buf.toString());
	    bw.flush();
	    bw.close();
	    String command = "powershell.exe -executionpolicy bypass -file " + file.toString();
	    Process powerShellProcess = Runtime.getRuntime().exec(command);
	    powerShellProcess.getOutputStream().close();
	    System.out.println("Email done");
		}		
//		String command = "powershell.exe -executionpolicy bypass -file " + file.toString();
		  // Executing the command
		
//		Process powerShellProcess = Runtime.getRuntime().exec(command);
		
		//System.out.println("Here is the standard output of the command:\n");
		//BufferedReader stdInput = new BufferedReader(new InputStreamReader(powerShellProcess.getInputStream()));
		//BufferedReader stdError = new BufferedReader(new InputStreamReader(powerShellProcess.getErrorStream()));
//		String s = null;
//		while ((s = stdInput.readLine()) != null) {
//		    System.out.println(s);
//		}
//
//		// read any errors from the attempted command
//		System.out.println("Here is the standard error of the command (if any):\n");
//		while ((s = stdError.readLine()) != null) {
//		    System.out.println(s);
//		    
//		}
//		stdInput.close();
//		stdError.close();
//		powerShellProcess.waitFor();
		
//		powerShellProcess.getOutputStream().close();
		
		
		//file.delete();
//		System.out.println("Email done");

		
	}
}