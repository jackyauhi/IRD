package layout.simple;

import java.awt.Dimension;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JScrollPane;

import utils.Field;

public abstract class SimpleHandler {
	
	protected Properties properties;
	
	protected SimpleRecord record;
	
	protected void loadProperties() {
		properties = new Properties();
		
     	File resourceFolder = new File("./resources");
     	try {
		    for (File nextFile : resourceFolder.listFiles()) {
		    	
		    	if (!nextFile.getName().endsWith(".properties"))
		    		continue;
		    	
		    	Properties singleProperties = new Properties();
		    	singleProperties.load(new FileReader(nextFile));
		    	properties.putAll(singleProperties);
		    }
 		}catch(Exception ex) {ex.printStackTrace();}
	}
	
	@SuppressWarnings({ "rawtypes"})
	public abstract List afterScan(List dataList);
	
	public abstract Dimension getPreferredSize();

	public abstract Object[][] parseToDisplayRecord(List<?> records);
	public abstract Object[] getDisplayHeader();
	
	public abstract List<Field> getReportColumns();
	
	public abstract List<String> getCustomizeReportTitle(List<SimpleRecord> dataList, Map<String, String> headerValues);
	
	public abstract SimpleRecord scanFromSTring(String string, Map<String, String> headerValues);
	
	public abstract String getFileName();
	public abstract String getFilePath(List<SimpleRecord> dataList, Map<String, String> headerValues);
	public abstract String getOldFilePath(List<SimpleRecord> dataList, Map<String, String> headerValues);
	public abstract String getUploadFilePath(List<SimpleRecord> dataList, Map<String, String> headerValues);
	public abstract String getCSVName();
	public abstract String getOldFileName();
	public abstract String getCopyFileName();
	public abstract void uploadData();
	
	public abstract JScrollPane prepareContentPanel(List<SimpleRecord> dataList, Map<String, String> headerValues, JButton btnPrint, JButton btnBack);

	@SuppressWarnings({ "rawtypes"})
	public abstract List loadFromFile(File file) throws IOException;
	
	public abstract Boolean shouldSaveExistingBeforeNew();
	
	public abstract SimpleRecord parseFromString(String string);
	public abstract List<Field> getHeaderFields();
	public abstract List<Field> getContentFields();
	public abstract Integer getScanRecordLength();
	
	public abstract void validateHeader(List<JComponent> fields) throws Exception;
	public abstract Boolean validateContent(List<Field> fields);

	public abstract Boolean canNewIfRecordExists();
	public abstract Boolean canBackIfRecordExists();
	public abstract Boolean hasSaveButtonInVerifyWindow();
}
