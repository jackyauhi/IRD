package layout.simple;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;

import utils.Field;

public class SimpleOptionNew extends JPanel {

	private static final long serialVersionUID = 2L;

	// public static String passTextFieldValue[] = new String[100];
	// JFrame f;
	private String selectedOnlineFunctionId;

	public SimpleOptionMenu SimpleOptionMenu;
//	public OptionOpen optionOpen;
//	public OptionNew optionNew;
//	private JTextField tfBrowseUri;

	private JFrame jFrame;
	private List<SimpleRecord> dataList;
	private String selectedSystem;
	private SimpleHandler simpleHandler;
	private JComponent[] jcHeaderValues;
	
	private Map<String, List<Integer>> componentMap;
	private Map<String, ButtonGroup> componentGroup;

	public SimpleOptionNew(JFrame jFrame, String selectedSystem, String selectedOnlineFunctionId,
			List<SimpleRecord> dataList, SimpleHandler simpleHandler) {
		this.selectedSystem = selectedSystem;
		this.jFrame = jFrame;
		this.dataList = dataList;
		this.selectedOnlineFunctionId = selectedOnlineFunctionId;
		this.simpleHandler = simpleHandler;
		componentMap = new HashMap<>();
		componentGroup = new HashMap<>();
	}

	public void draw() {
		// get the value to define different button click action

		JLabel topic = new JLabel(selectedSystem + " Menu", SwingConstants.CENTER);
		Border border = BorderFactory.createLineBorder(Color.BLACK, 3);
		JLabel header = new JLabel(selectedOnlineFunctionId, SwingConstants.CENTER);
		Border headerborder = BorderFactory.createLineBorder(Color.BLACK, 2);
		
		header.setBounds(150, 70, 400, 30);
		header.setFont(new Font("Serif", Font.PLAIN, 15));
		header.setBorder(headerborder);
		topic.setBounds(90, 20, 500, 40);
		topic.setFont(new Font("Serif", Font.PLAIN, 30));
		topic.setBorder(border);
		JButton back = new JButton("Back");
		JButton startToScan = new JButton("Start to Scan");
		add(header);
		add(topic);
		setBounds(700, 200, 700, 700);
		setLayout(null);
		setVisible(true);
		add(back);
		add(startToScan);
		startToScan.setBounds(250, 450, 180, 30);
		back.setBounds(250, 500, 180, 30);
		
		List<Field> headerFields = simpleHandler.getHeaderFields();
		JLabel[] headerLabels = new JLabel[headerFields.size()];
		jcHeaderValues = new JComponent[headerFields.size()];
		
		boolean isFirstRadio = true;
		
		for (int headerIdx = 0 ; headerIdx < headerLabels.length; headerIdx++) {
			Field headerField = headerFields.get(headerIdx);
			
			switch(headerField.getType()) {
				case RADIO:
					headerLabels[headerIdx] = new JLabel(headerField.getName());
					headerLabels[headerIdx].setBounds(230,(130 + headerIdx*30),250,21);
					headerLabels[headerIdx].setText(headerField.getName());
					
					JRadioButton rbtnHeaderField = new JRadioButton();
					rbtnHeaderField.setName(headerField.getName());
					rbtnHeaderField.setBounds(200, (130+ headerIdx*30), 25, 25);
					if (isFirstRadio) {
						rbtnHeaderField.setSelected(true);
						isFirstRadio = false;
					}
					
					jcHeaderValues[headerIdx] = rbtnHeaderField;
					
					if (headerField.getGroupId() != null) {
						if (componentMap.get(headerField.getGroupId()) == null) {
							componentGroup.put(headerField.getGroupId(), new ButtonGroup());
							componentMap.put(headerField.getGroupId(), new ArrayList<Integer>());
						}
						componentMap.get(headerField.getGroupId()).add(headerIdx);
						componentGroup.get(headerField.getGroupId()).add((JRadioButton)jcHeaderValues[headerIdx]);;
					}
					
					break;
				default:
					headerLabels[headerIdx] = new JLabel(headerField.getName());
					headerLabels[headerIdx].setBounds(200,(130 + headerIdx*30),96,21);
					headerLabels[headerIdx].setText(headerField.getName()+":");
					
					JTextField tfHeaderField = new JTextField();
					tfHeaderField.setName(headerField.getName());
					tfHeaderField.setBounds(350, (130+ headerIdx*30), 96, 21);
					tfHeaderField.setText(dataList.size() == 0 ? SimpleBatchHeaderUtils.prepareDefaultValue(headerField.getType(), dataList) : dataList.get(0).getValue(headerField.getName()));
					jcHeaderValues[headerIdx] = tfHeaderField;
			}

			add(headerLabels[headerIdx]);
			add(jcHeaderValues[headerIdx]);
		}

		// set action
		back.addActionListener(new BackButtonActionListener());
		
		startToScan.addActionListener(new StartToScanActionListener());
	}
		
	class BackButtonActionListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			jFrame.setVisible(false);
			jFrame.getContentPane().removeAll();

			SimpleOptionMenu simpleOptionMenu = new SimpleOptionMenu(jFrame, selectedSystem, selectedOnlineFunctionId, dataList, simpleHandler, false);
			simpleOptionMenu.draw();
			
			jFrame.setContentPane(simpleOptionMenu);
			Dimension preferredSize = new Dimension(700, 700);
			jFrame.setPreferredSize(preferredSize);
			jFrame.setBounds(700, 200, 700, 700);
			jFrame.setLocationRelativeTo(null);
			SwingUtilities.updateComponentTreeUI(jFrame);
			jFrame.pack();
			jFrame.setVisible(true);
			jFrame.invalidate();
			jFrame.validate();
			jFrame.repaint();
		}
	}
	
	class StartToScanActionListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			// check JTextField input value null or not
			boolean isAllRequiredFieldFilled = true;
			List<Field> headers = simpleHandler.getHeaderFields();
			for(Field header: headers) {
				if (!isAllRequiredFieldFilled)
					break;
				for (JComponent tfHeaderValue : jcHeaderValues) {
					if (!tfHeaderValue.getName().equals(header.getName())) {
						continue;
					}
					switch(header.getType()) {
						case RADIO:
							break;
						default:
							JTextField headerField = (JTextField)tfHeaderValue;
							if (headerField.getText().trim().length() == 0 && header.getPadding() == null
							) {
								isAllRequiredFieldFilled = false;
								break;
							}
					}
				}
			}
			
			if (!isAllRequiredFieldFilled) {
				JOptionPane optionPane2 = new JOptionPane("Please fill all the information in the blank",
						JOptionPane.ERROR_MESSAGE);
				JDialog dialog2 = optionPane2.createDialog("Failure");
				dialog2.setAlwaysOnTop(true);
				dialog2.setVisible(true);
				return;
			} 

			try {
				simpleHandler.validateHeader(Arrays.asList(jcHeaderValues));
			}catch(Exception exception) {
				JOptionPane optionPane2 = new JOptionPane(exception.getMessage(), JOptionPane.ERROR_MESSAGE);
				JDialog dialog2 = optionPane2.createDialog("Failure");
				dialog2.setAlwaysOnTop(true);
				dialog2.setVisible(true);
				return;
			}
			
			Map<String, String> headerValues = new HashMap<>();
			List<Field> headerFields = simpleHandler.getHeaderFields();
			Map<String, Field> headerFieldMap = new HashMap<>();
			for (Field headerField: headerFields) {
				headerFieldMap.put(headerField.getName(), headerField);
			}
			for (JComponent jcHeaderValue: jcHeaderValues) {
				Field headerField = headerFieldMap.get(jcHeaderValue.getName());
				if (headerField == null)
					continue;
			
				switch(headerField.getType()) {
					case RADIO:
						headerValues.put(((JRadioButton)jcHeaderValue).getName(), ((JRadioButton)jcHeaderValue).isSelected() ? "1" : "0");
						break;
					default:
						headerValues.put(((JTextField)jcHeaderValue).getName(), ((JTextField)jcHeaderValue).getText().toUpperCase());
				}
			}
			
			// open another window
			jFrame.setVisible(false);
			jFrame.getContentPane().removeAll();
			SimpleOptionScan sc = new SimpleOptionScan(jFrame, selectedSystem, selectedOnlineFunctionId, dataList, simpleHandler, headerValues);
			sc.draw();
			jFrame.setContentPane(sc);
			Dimension preferredSize = new Dimension(700, 700);
			jFrame.setPreferredSize(preferredSize);
			jFrame.setBounds(700, 200, 700, 700);
			jFrame.setLocationRelativeTo(null);
			SwingUtilities.updateComponentTreeUI(jFrame);
			jFrame.pack();
			jFrame.setVisible(true);
			jFrame.invalidate();
			jFrame.validate();
			jFrame.repaint();

		}
	}
}
