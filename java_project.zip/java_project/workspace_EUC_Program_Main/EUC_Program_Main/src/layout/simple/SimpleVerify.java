package layout.simple;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;
import javax.swing.event.TableModelEvent;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

import layout.RadioButtonCellEditorRenderer;
import layout.SystemMenu;
import layout.listener.SaveButtonActionListener;
import utils.Field;

@SuppressWarnings("serial")
public class SimpleVerify extends JPanel {

	private JFrame jFrame;

	private String selectedSystem;
	private List<SimpleRecord> dataList;
	private String selectedOnlineFunctionId;
	private SimpleHandler simpleHandler;
	private DefaultTableModel dtm;
	private ButtonGroup bg;
	private JTable table;
	private Map<String, String> headerValues;
	
	private JLabel lbNumOfRecords;

	/**
	 * Create the frame.
	 */
	public SimpleVerify(JFrame jFrame, String selectedSystem, String selectedOnlineFunctionId,
			List<SimpleRecord> dataList, SimpleHandler simpleHandler, Map<String, String> headerValues) {
		this.selectedSystem = selectedSystem;
		this.jFrame = jFrame;
		this.dataList = dataList;
		this.selectedOnlineFunctionId = selectedOnlineFunctionId;
		this.simpleHandler = simpleHandler;
		this.headerValues = headerValues;
	}

	/**
	 * Launch the application.
	 */
	public void draw() {

		JLabel topic = new JLabel(selectedSystem + " Menu", SwingConstants.CENTER);
		Border topicBorder = BorderFactory.createCompoundBorder(
		BorderFactory.createEmptyBorder(20, 20, 20, 20),
		BorderFactory.createMatteBorder(3, 3, 3, 3, Color.BLACK));
		topic.setFont(new Font("Serif", Font.PLAIN, 30));
		topic.setBorder(topicBorder);

		JLabel header = new JLabel(selectedOnlineFunctionId, SwingConstants.CENTER);
		Border headerBorder = BorderFactory.createCompoundBorder(
		BorderFactory.createEmptyBorder(0, 70, 10, 70),
		BorderFactory.createMatteBorder(3, 3, 3, 3, Color.BLACK));
		header.setBounds(150, 70, 400, 30);
		header.setFont(new Font("Serif", Font.PLAIN, 15));
		header.setBorder(headerBorder);

		List<Field> contentFields = simpleHandler.getReportColumns();

		// get the value to define different button click action
		// set layout and button group
		JPanel middlePanel = new JPanel();
		middlePanel.setLayout(new BorderLayout());
		middlePanel.setPreferredSize(new Dimension(contentFields.size() * 250, (dataList.size() + 1) * 23));

		lbNumOfRecords = new JLabel("Total No. of Records:                           " + Integer.toString(dataList.size()),SwingConstants.CENTER);

		JPanel headerPane = new JPanel(new BorderLayout());
		JPanel contentPane = new JPanel(new BorderLayout());
		JPanel bottomPanel = new JPanel(new BorderLayout());
		JPanel buttonPanel = new JPanel();
		JLabel tmplabel = new JLabel(" ", SwingConstants.LEFT);
		JLabel tmplabel2 = new JLabel(" ", SwingConstants.LEFT);
		JLabel tmplabel3 = new JLabel(" ", SwingConstants.LEFT);
		GridBagLayout layout = new GridBagLayout();
		buttonPanel.setLayout(layout);
		GridBagConstraints s = new GridBagConstraints();
		s.fill = GridBagConstraints.NONE;
		s.gridwidth = 2;
		s.gridheight = 2;
		s.weightx = 5;
		s.weighty = 20;
		JButton back = new JButton("Back");
		JButton btnDelete = new JButton("Delete");
		JButton report = new JButton("Report");
		JButton newheader = new JButton("Newheader");
		headerPane.setPreferredSize(new Dimension(600, 150));
		headerPane.add(BorderLayout.NORTH, topic);
		headerPane.add(BorderLayout.CENTER, header);
		buttonPanel.add(btnDelete);
		buttonPanel.add(report);
		buttonPanel.add(tmplabel);
		buttonPanel.add(back);
		buttonPanel.add(tmplabel2);
		JButton btnSave = new JButton("Save");
		buttonPanel.add(tmplabel3);
		if (simpleHandler.hasSaveButtonInVerifyWindow())
			buttonPanel.add(btnSave);

		layout.setConstraints(btnDelete, s);
		s.gridwidth = 0;
		s.weightx = 5;
		s.weighty = 20;
		layout.setConstraints(report, s);
		layout.setConstraints(tmplabel, s);
		layout.setConstraints(back, s);
		layout.setConstraints(tmplabel2, s);
		layout.setConstraints(newheader, s);
		layout.setConstraints(tmplabel3, s);
		if (simpleHandler.hasSaveButtonInVerifyWindow())
			layout.setConstraints(btnSave, s);

		bottomPanel.add(BorderLayout.NORTH, lbNumOfRecords);
		bottomPanel.add(BorderLayout.CENTER, buttonPanel);

		SystemMenu.SaveTinChangeToPrnData = new ArrayList<String>();

		Object[] tableHeaders = simpleHandler.getDisplayHeader();
		Object[] tableHeadersWithBtn = new Object[tableHeaders.length+1];
		tableHeadersWithBtn[0] = "";
		for (int hIdx = 0; hIdx < tableHeaders.length; hIdx++) {
			tableHeadersWithBtn[hIdx+1] = tableHeaders[hIdx];
		}
		
		dtm = new DefaultTableModel();
		dtm.setDataVector(simpleHandler.parseToDisplayRecord(dataList), tableHeadersWithBtn);

		table = new JTable(dtm) {
			public void tableChanged(TableModelEvent tme) {
				super.tableChanged(tme);
				repaint();
			}
		};
		
		table.getColumnModel().getColumn(0).setCellRenderer(new RadioButtonRenderer());
		table.getColumnModel().getColumn(0).setCellEditor(new RadioButtonEditor(new JCheckBox()));

		bg = new ButtonGroup();
		for (int rIdx = 0; rIdx < dataList.size(); rIdx++) {
			bg.add((JRadioButton) dtm.getValueAt(rIdx, 0));
		}

		table.setRowHeight(20);
		table.getTableHeader().setReorderingAllowed(false);
		table.getTableHeader().setResizingAllowed(false);
		TableColumn column = table.getColumnModel().getColumn(0);
		column.setCellEditor(new RadioButtonCellEditorRenderer());
		column.setCellRenderer(new RadioButtonCellEditorRenderer());
		
		JScrollPane scroll = new JScrollPane(table);
		scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
		scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scroll.setPreferredSize(new Dimension(400, 300));
		contentPane.add(BorderLayout.NORTH, headerPane);
		contentPane.add(BorderLayout.CENTER, scroll);
		contentPane.add(BorderLayout.SOUTH, bottomPanel);
		add(contentPane);

		btnDelete.addActionListener(new DeleteButtonActionListener());
		
		// set action
		back.addActionListener(new BackButtonActionListener());
		
		report.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// create window layout

				new SimplePrintableReport(dataList, simpleHandler, selectedSystem, selectedOnlineFunctionId, headerValues);
			}
		});

		btnSave.addActionListener(new SaveButtonActionListener(simpleHandler, dataList, headerValues, false));

	}
	
	class DeleteButtonActionListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			int rowCount = dtm.getRowCount();
			for(int i = rowCount-1; i >= 0; i--) {
				boolean shouldRemove = false;
				if (dtm.getValueAt(i, 0) instanceof Boolean) {
					if ((Boolean)dtm.getValueAt(i, 0)) {
						shouldRemove = true;
					}
				}
				if (dtm.getValueAt(i, 0) instanceof JRadioButton) {
					if(((JRadioButton)dtm.getValueAt(i, 0)).isSelected()) {
						shouldRemove = true;
					}
				}
				if (!shouldRemove)
					continue;
				
				int confirmDialoginput = JOptionPane.showConfirmDialog(null, "Do you want to delete this record?","Select an Option...", JOptionPane.YES_NO_OPTION);
				if (confirmDialoginput != 0)
					continue;
				
				dtm.removeRow(i);
				dataList.remove(i);
				lbNumOfRecords.setText("Total No. of Records:                           " + Integer.toString(dataList.size()));
				
				break;
			}
		}
	}
	
	class BackButtonActionListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			// create window layout
			boolean shouldBackToMenu = false;
			if (dataList.size() == 0) {
				int ConfirmDialoginput = JOptionPane.showConfirmDialog(null,
						"All the record empty already. It will let you come back to Option Menu. Do you want to go?",
						"Select an Option...", JOptionPane.YES_NO_OPTION);
				if (ConfirmDialoginput == 0) {
					shouldBackToMenu = true;
				}
				
				if (!shouldBackToMenu)
					return;
			
				SimpleOptionMenu SimpleOptionMenu = new SimpleOptionMenu(jFrame, selectedSystem, selectedOnlineFunctionId, dataList, simpleHandler, false);	        	
				SimpleOptionMenu.setDataList(dataList);
				SimpleOptionMenu.setHeaderValues(headerValues);
				SimpleOptionMenu.draw();		        	
				
				jFrame.setVisible(false);
				jFrame.getContentPane().removeAll();
			 	
				jFrame.setContentPane(SimpleOptionMenu);
		    	
		    	Dimension preferredSize = new Dimension(700,700);
		    	jFrame.setPreferredSize(preferredSize);	        	
		    	jFrame.setBounds(700,200,700,700);
		    	jFrame.setLocationRelativeTo(null);
		    	SwingUtilities.updateComponentTreeUI(jFrame);
		    	
		    	jFrame.pack();
		    	jFrame.setVisible(true);
		    	jFrame.invalidate();
		    	jFrame.validate();
		    	jFrame.repaint();
			} else {		
				// open another window
				jFrame.setVisible(false);
				jFrame.getContentPane().removeAll();
				SimpleOptionScan sc = new SimpleOptionScan(jFrame, selectedSystem, selectedOnlineFunctionId, dataList, simpleHandler, headerValues);
				sc.draw();
				jFrame.setContentPane(sc);
				Dimension preferredSize = new Dimension(700, 700);
				jFrame.setPreferredSize(preferredSize);
				jFrame.setBounds(700, 200, 700, 700);
				jFrame.setLocationRelativeTo(null);
				SwingUtilities.updateComponentTreeUI(jFrame);
				jFrame.pack();
				jFrame.setVisible(true);
				jFrame.invalidate();
				jFrame.validate();
				jFrame.repaint();
		    }
			
			
		}
	}

	class RadioButtonRenderer implements TableCellRenderer {
		public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
				int row, int column) {
			if (value == null)
				return null;
			return (Component) value;
		}
	}

	class RadioButtonEditor extends DefaultCellEditor implements ItemListener {
		private JRadioButton button;

		public RadioButtonEditor(JCheckBox checkBox) {
			super(checkBox);
		}

		public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
			if (value == null)
				return null;
			button = (JRadioButton) value;
			button.addItemListener(this);
			return (Component) value;
		}

		public Object getCellEditorValue() {
			button.removeItemListener(this);
			return button;
		}
		@Override
		public void itemStateChanged(ItemEvent e) {
			super.fireEditingStopped();
		}
	}
}
