package layout.simple;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.Map;
import java.util.Timer;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;

@SuppressWarnings("serial")
public class SimpleOptionScan extends JPanel {
	Timer timer = new Timer();

	// public static String passTextFieldValue[] = new String[100];
	// JFrame f;
	private String selectedOnlineFunctionId;
	private String watchFieldText;

	public SimpleOptionMenu SimpleOptionMenu;
	// public OptionOpen optionOpen;
	// public OptionNew optionNew;
	// private JTextField tfBrowseUri;

	private JFrame jFrame;
	private List<SimpleRecord> dataList;
	private String selectedSystem;
	private SimpleHandler simpleHandler;
	private JTextField tfScanField;
	private Map<String, String> headerValues;
	private JLabel lbLastScannedValue;
	private JLabel lbNumOfRecords;

	public SimpleOptionScan(JFrame jFrame, String selectedSystem, String selectedOnlineFunctionId,
			List<SimpleRecord> dataList, SimpleHandler simpleHandler, Map<String, String> headerValues) {
		this.selectedSystem = selectedSystem;
		this.jFrame = jFrame;
		this.headerValues = headerValues;
		this.dataList = dataList;
		this.selectedOnlineFunctionId = selectedOnlineFunctionId;
		this.simpleHandler = simpleHandler;
	}

	public void draw() {
		// get the value to define different button click action

		JLabel topic = new JLabel(selectedSystem + " Menu", SwingConstants.CENTER);
		Border border = BorderFactory.createLineBorder(Color.BLACK, 3);
		JLabel header = new JLabel(selectedOnlineFunctionId, SwingConstants.CENTER);
		Border headerborder = BorderFactory.createLineBorder(Color.BLACK, 2);

		header.setBounds(150, 70, 400, 30);
		header.setFont(new Font("Serif", Font.PLAIN, 15));
		header.setBorder(headerborder);
		topic.setBounds(90, 20, 500, 40);
		topic.setFont(new Font("Serif", Font.PLAIN, 30));
		topic.setBorder(border);
		JLabel count = new JLabel("Total No. of Records:", SwingConstants.CENTER);
		count.setBounds(140, 180, 126, 21);
		lbNumOfRecords = new JLabel(String.valueOf(dataList.size()), SwingConstants.CENTER);
		lbNumOfRecords.setBounds(320, 180, 96, 21);
		JButton back = new JButton("Back");
		JButton verify = new JButton("Verify");

		add(header);
		add(topic);
		add(count);
		add(lbNumOfRecords);
		setBounds(700, 200, 700, 700);
		setLayout(null);
		setVisible(true);
		add(back);
		add(verify);

		setBounds(700, 200, 700, 700);
		back.setBounds(250, 500, 180, 30);
		verify.setBounds(250, 450, 180, 30);

		JLabel scan = new JLabel("Scan:", SwingConstants.CENTER);

		scan.setBounds(170, 130, 96, 21);
		add(scan);
		tfScanField = new JTextField();
		tfScanField.setBounds(270, 130, 200, 21);
		tfScanField.setText("");
		add(tfScanField);

		lbLastScannedValue = new JLabel(watchFieldText, SwingConstants.CENTER);
		lbLastScannedValue.setBounds(270, 230, 200, 21);
		lbLastScannedValue.setText(headerValues.get("_lastScan") == null ? "" : headerValues.get("_lastScan"));
		add(lbLastScannedValue);
		JLabel fieldTextLabel = new JLabel("Field Text:", SwingConstants.CENTER);
		fieldTextLabel.setBounds(170, 230, 96, 21);
		add(fieldTextLabel);

		tfScanField.addKeyListener(new ScanFieldKeyAdapter());

		// set action
		back.addActionListener(new BackButtonActionListener());
		verify.addActionListener(new VerifyButtonActionListener());

	}

	class ScanFieldKeyAdapter extends KeyAdapter {
		@SuppressWarnings("unchecked")
		public void keyPressed(KeyEvent e) {
			int key = e.getKeyCode();
			if (key != KeyEvent.VK_ENTER) {
				return;
			}
			
			String scannedValue = tfScanField.getText();
			tfScanField.setText("");
			
			int expectedScanLength = simpleHandler.getScanRecordLength();
			if (scannedValue.length() < expectedScanLength) {
				JOptionPane.showMessageDialog(null,"Too short! Please input again");
				return;
			}else if(scannedValue.length() > expectedScanLength) {
				JOptionPane.showMessageDialog(null,"Too long! Please input again");
				return;
			}

			try {
				headerValues.put("_lastScan", scannedValue);
				SimpleRecord simpleRecord = simpleHandler.scanFromSTring(scannedValue, headerValues);
				dataList.add(simpleRecord);
				dataList = simpleHandler.afterScan(dataList);
				lbLastScannedValue.setText(scannedValue);
				lbNumOfRecords.setText(String.valueOf(dataList.size()));
			} catch (Exception exception) {
				JOptionPane.showMessageDialog(null,exception.getMessage());
			}
		}
	}

	class BackButtonActionListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			jFrame.setVisible(false);
			jFrame.getContentPane().removeAll();
			SimpleOptionNew son = new SimpleOptionNew(jFrame, selectedSystem, selectedOnlineFunctionId, dataList, simpleHandler);
			son.draw();
			jFrame.setContentPane(son);
			Dimension preferredSize = new Dimension(700, 700);
			jFrame.setPreferredSize(preferredSize);
			jFrame.setBounds(700, 200, 700, 700);
			jFrame.setLocationRelativeTo(null);
			SwingUtilities.updateComponentTreeUI(jFrame);
			jFrame.pack();
			jFrame.setVisible(true);
			jFrame.invalidate();
			jFrame.validate();
			jFrame.repaint();
		}
	}

	class VerifyButtonActionListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			// create another window
			jFrame.setVisible(false);
			jFrame.getContentPane().removeAll();

			SimpleVerify simpleOptionVerify = new SimpleVerify(jFrame, selectedSystem, selectedOnlineFunctionId, dataList, simpleHandler, headerValues);
			simpleOptionVerify.draw();
			
			jFrame.setContentPane(simpleOptionVerify);
			Dimension preferredSize = new Dimension(700, 700);
			jFrame.setPreferredSize(preferredSize);
			jFrame.setBounds(700, 200, 700, 700);
			jFrame.setLocationRelativeTo(null);
			SwingUtilities.updateComponentTreeUI(jFrame);
			jFrame.pack();
			jFrame.setVisible(true);
			jFrame.invalidate();
			jFrame.validate();
			jFrame.repaint();

		}
	}

}
