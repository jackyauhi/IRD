package layout;

import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Properties;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;

public class OptionMenu extends JPanel {

	// pass the class action command value to other class
	public static String passHeaderValue;

	public JFrame f;

	String onlineFctID;
	String getTopicValue;
	public OptionMenu optionMenu;
	public OptionNew optionNew;
	public OptionOpen optionOpen;
	public JFrame jframe;

	List<String> timerScanData;
	String passOptionNewTextFieldValue[][];
	int marks[];
	String getPropertiesValue;
	String buttonNum;
	int ButtonNumber;
	int headerno;
	String num;
	String status;
	int numOfButton;
	Properties prop;
	
	JLabel[] OutputLabel;
	JLabel[] OutputDataLabel;
	String OutputData[];
	int OutputDataInt[];
	String splitTimerScanData[];
	String storeSplitTimerScanData[];


	public OptionMenu(JFrame jframe, String onlineFctID, List timerScanData,
			String passOptionNewTextFieldValue[][], int headerno, int marks[],
			String status) {

		// get the value from the class action command
		this.onlineFctID = onlineFctID;
		this.jframe = jframe;
		optionMenu = this;
		this.timerScanData = timerScanData;
		this.passOptionNewTextFieldValue = passOptionNewTextFieldValue;
		this.headerno = headerno;
		this.marks = marks;
		this.status = status;
		// get the value from class String
		getTopicValue = SystemMenu.passTopicValue;

	}

	public void draw() {
		if(timerScanData.size()<SystemMenu.Recordlimited){
		System.out.println("timerScanData value = " + timerScanData);
		}
		// store the value
		passHeaderValue = onlineFctID;
		// get the value to define different button click action
		getPropertiesValue = getTopicValue.replaceAll("\\s", "")
				+ onlineFctID.replaceAll("\\s", "");

		
		String filePath = "resources/allOptionJava.properties";
		prop = new Properties();
		try (InputStream inputStream = MainMenu.class.getClassLoader()
				.getResourceAsStream(filePath)) {

			// Loading the properties.
			prop.load(inputStream);
			
			
			//SystemMenu.checkLogData.add("Click in "+ getPropertiesValue +" (OptionMenu) button");
			
			
			// get properties value
			buttonNum = prop.getProperty(getPropertiesValue + ".NUM");
			ButtonNumber = Integer.parseInt(buttonNum);
			num = prop.getProperty(getPropertiesValue + ".DetailRecordNUM");
			numOfButton = Integer.parseInt(num);

			// set layout and button group
			f = jframe;
			JLabel topic = new JLabel(getTopicValue + " Menu",
					SwingConstants.CENTER);
			Border border = BorderFactory.createLineBorder(Color.BLACK, 3);
			JLabel header = new JLabel(onlineFctID, SwingConstants.CENTER);
			Border headerborder = BorderFactory
					.createLineBorder(Color.BLACK, 2);
			header.setBounds(150, 70, 400, 30);
			header.setFont(new Font("Serif", Font.PLAIN, 15));
			header.setBorder(headerborder);
			topic.setBounds(90, 20, 500, 40);
			topic.setFont(new Font("Serif", Font.PLAIN, 30));
			topic.setBorder(border);
			JButton back = new JButton("Back");
			JButton newbutton = new JButton("New");
			JButton open = new JButton("Open");
			JButton save = new JButton("Save");
			add(header);
			add(topic);
			setBounds(700, 200, 700, 700);
			setLayout(null);
			setVisible(true);
			add(back);
			add(newbutton);
			add(open);
			add(save);

			back.setBounds(290, 500, 95, 30);
			newbutton.setBounds(200, 150, 95, 30);
			open.setBounds(380, 150, 95, 30);
			save.setBounds(290, 250, 95, 30);
		  	OutputLabel = new JLabel[numOfButton];
			OutputDataLabel = new JLabel[numOfButton];
			OutputData = new String[numOfButton + 1];
			OutputDataInt = new int[numOfButton + 1];
			splitTimerScanData = new String[timerScanData.size()];
			storeSplitTimerScanData= new String[timerScanData.size()];
			
			// get properties value
						for (int i = 0; i < numOfButton; i++) {
							OutputLabel[i] = new JLabel(prop.getProperty(getPropertiesValue
									+ ".DetailRecordLabel" + (i + 1)));
						}
						for (int i = 0; i <= numOfButton; i++) {
							OutputData[i] = new String(prop.getProperty(getPropertiesValue
									+ ".DetailRecordData" + i));
							OutputDataInt[i] = Integer.parseInt(OutputData[i]);
						}
							



			// set action
			back.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(timerScanData.size()<SystemMenu.Recordlimited){
					SystemMenu.checkLogData.add("Click in "+ getPropertiesValue +" (OptionMenu) (Back) button");
					}
					if (SystemMenu.checkSaveStatus == "false") {
						int ConfirmDialoginput = JOptionPane
								.showConfirmDialog(
										null,
										"You still have records do not save. Do you want to leave this page?",
										"Select an Option...",
										JOptionPane.YES_NO_OPTION);
						// 0=yes, 1=no, 2=cancel
						if (ConfirmDialoginput == 0) {
							f.dispose();
							try {
								new SystemMenu(getTopicValue);

							} catch (IOException e1) {

								System.out.println("Problem occurs when get Action Command!");
								e1.printStackTrace();

							}
						}
					} else {
						f.dispose();
						try {

							new SystemMenu(getTopicValue);

						} catch (IOException e1) {

							System.out.println("Problem occurs when get Action Command!");
							e1.printStackTrace();

						}
					}
				}
			});

			newbutton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(timerScanData.size()<SystemMenu.Recordlimited){
					SystemMenu.checkLogData.add("Click in "+ getPropertiesValue +" (OptionMenu) (New) button");
					}
					// open another window
					setVisible(false);
					removeAll();
					if (optionNew == null) {
						optionNew = new OptionNew(f, optionMenu, timerScanData,
								passOptionNewTextFieldValue, headerno, marks,
								status);
					}
					optionNew.draw();
					f.setContentPane(optionNew);
					Dimension preferredSize = new Dimension(700, 700);
					f.setPreferredSize(preferredSize);
					f.setBounds(700, 200, 700, 700);
					f.setLocationRelativeTo(null);
					SwingUtilities.updateComponentTreeUI(f);
					f.pack();
					f.setVisible(true);
					f.invalidate();
					f.validate();
					f.repaint();

				}
			});
			open.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(timerScanData.size()<SystemMenu.Recordlimited){
					SystemMenu.checkLogData.add("Click in "+ getPropertiesValue +" (OptionMenu) (Open) button");
					}
					f.setVisible(false);
					f.getContentPane().removeAll();
					if (optionOpen == null) {
						optionOpen = new OptionOpen(f, optionMenu,
								timerScanData, passOptionNewTextFieldValue,
								headerno, marks);
					}
					optionOpen.draw();
					f.setContentPane(optionOpen);
					Dimension preferredSize = new Dimension(700, 700);
					f.setPreferredSize(preferredSize);
					f.setBounds(700, 200, 700, 700);
					f.setLocationRelativeTo(null);
					SwingUtilities.updateComponentTreeUI(f);
					f.pack();
					f.setVisible(true);
					f.invalidate();
					f.validate();
					f.repaint();

				}
			});

			save.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(timerScanData.size()<SystemMenu.Recordlimited){
					SystemMenu.checkLogData.add("Click in "+ getPropertiesValue +" (OptionMenu) (Save) button");
					SystemMenu.checkLogData.add("timerScanData value = " + timerScanData);
					}
					String HeaderRecordSaveNextline[] = new String[ButtonNumber];
					String DialoginputContent;
					String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss")
							.format(Calendar.getInstance().getTime());
					String fileName = new String(prop
							.getProperty(getPropertiesValue + ".FileName"));
					String csvName = new String(prop
							.getProperty(getPropertiesValue + ".CSVName"));
					String logName = new String(prop
							.getProperty(getPropertiesValue + ".LogName"));
					String fileNameCopy = new String(prop
							.getProperty(getPropertiesValue + ".FileNameCopy"));
					String filePath = new String(prop
							.getProperty(getPropertiesValue + ".FilePath"));
					File newTextFile = new File(filePath + fileName);
					File csvFile = new File(filePath + csvName);
					File logFile = new File(filePath + logName);
					File oldFilecopy = new File(filePath + fileNameCopy);
					File FileToSave = new File(filePath);

					int countSpace = 0;
					String savingSpaceInFile = new String();
					String headerRecordAddSpace[] = new String[ButtonNumber];
					int headerRecordAddSpaceInt[] = new int[ButtonNumber];
					String DetailRecordAddSpace = new String();
					int DetailRecordAddSpaceInt = 0;
					for (int i = 0; i < ButtonNumber; i++) {
						headerRecordAddSpace[i] = new String(prop
								.getProperty(getPropertiesValue
										+ ".HeaderRecordAddSpace" + (i + 1)));
						headerRecordAddSpaceInt[i] = Integer
								.parseInt(headerRecordAddSpace[i]);
					}

					if (newTextFile.exists()) {
						DialoginputContent = "   You have existing file already.";
					} else {
						DialoginputContent = "";
					}
					if (marks[0]==0){
		        		JOptionPane optionPane2 = new JOptionPane("There are not any records can save", JOptionPane.ERROR_MESSAGE);    
		        		JDialog dialog2 = optionPane2.createDialog("Failure");
		        		dialog2.setAlwaysOnTop(true);
		        		dialog2.setVisible(true); 
					}
					else{
					int ConfirmDialoginput = JOptionPane.showConfirmDialog(
							null, "Do you want to save these records?"
									+ DialoginputContent,
							"Select an Option...", JOptionPane.YES_NO_OPTION);
					// 0=yes, 1=no, 2=cancel
					if (ConfirmDialoginput == 0) {

						if (FileToSave.exists()) {

						} else {
							FileToSave.mkdirs();
						}

						if (newTextFile.exists()) {
							try {
								Files.copy(newTextFile.toPath(),
										oldFilecopy.toPath());
							} catch (IOException e1) {
								e1.printStackTrace();
							}
							oldFilecopy.renameTo(new File(FileToSave + "\\"
									+ oldFilecopy.getName() + timeStamp));

						} else {

						}

						try {
	                		SystemMenu.checkSaveStatus="true";
	                		 FileWriter fileWriter = new FileWriter(newTextFile);
	                		 //get properties value
	                		 int start = 0;
	                		 DetailRecordAddSpace= new String(prop.getProperty(getPropertiesValue+".DetailRecordAddSpace"));
	                		 DetailRecordAddSpaceInt=Integer.parseInt(DetailRecordAddSpace);
	                		 for (int j = 0; j < headerno ; j++){
	                		    
	                			 if (getPropertiesValue.equals("ERScanUndeliveredERReturn(BIR56A)")){
	                				 
	                			 }
	                			 
	                			 else{
	                				 
	                		 for (int i = 0; i <ButtonNumber; i++){
	                			 
	                			 if(marks[j]!=0){  
	                			 HeaderRecordSaveNextline[i]= new String(prop.getProperty(getPropertiesValue+".HeaderRecordSaveNextline"+(i+1)));
	                			 fileWriter.write(passOptionNewTextFieldValue[i][j].toUpperCase());  			 
	                			 switch(headerRecordAddSpace[i]){
	          		           		case "0":
	          		        	   
	          		           			break;
	          			 	 			
	          		           		default:	
	          		           			while(countSpace!=headerRecordAddSpaceInt[i]){
	          		           			savingSpaceInFile=savingSpaceInFile+" ";
	          		           			countSpace++;
	          		           			}
	          		           			fileWriter.write(savingSpaceInFile);
	          		           			break;
	                			 }
	                			 savingSpaceInFile=new String(); 
	                			 countSpace=0;
	                			 fileWriter.write(HeaderRecordSaveNextline[i]);
	                		 }
	                		 }
	                		 
	                			 }
	                		 int size=marks[j];
	                		 
   		           			while(countSpace!=DetailRecordAddSpaceInt){
   		           			savingSpaceInFile=savingSpaceInFile+" ";
   		           			countSpace++;
   		           			}         
	                		 //to let the save format correct
	                		 for (int i = start; i <start + size; i++){
	                			 String saveTimerScanData = timerScanData.get(i).toString().toUpperCase();
	                			 
	                			 if (getPropertiesValue.equals("ERScanUndeliveredERReturn(BIR56A)")){
	                	    		 for (int c = 0; c <ButtonNumber; c++){
			           
			                			 fileWriter.write(passOptionNewTextFieldValue[c][j]);  			 

			                		 }
	                				 	int ScanDatasize = 1+i;
	                					String count=Integer.toString(ScanDatasize);
	                					while(count.length()!=7){
	                						count="0"+count;
	                					}
	                					fileWriter.write(count);
	           		           			while(countSpace!=DetailRecordAddSpaceInt){
	               		           			savingSpaceInFile=savingSpaceInFile+" ";
	               		           			countSpace++;
	               		           			} 
	                			 }
	                			 switch(DetailRecordAddSpace){
	          		           		case "0":
	          		           			fileWriter.write(saveTimerScanData);          		        	   
	          		           			break;
	          		           			
	          		           		default:
	          		           			fileWriter.write(saveTimerScanData); 
	          		           			fileWriter.write(savingSpaceInFile);
	          		           			break;
	                			 }
	                			 //This prevent creating a blank line at the end of the file
	                			  
	                				 fileWriter.write("\r\n");
	                			 
	                		 }
	                		 	start += size;
	                			savingSpaceInFile=new String(); 
	                			countSpace=0;
	                		 }
	                		 fileWriter.close();
							start = 0;
							// write csv files
							if (getPropertiesValue.equals("CTRNoteReceiptCTRAdviceLetter") || getPropertiesValue.equals("PFNoteReceiptPFReturn(BIR51/BIR52)") || getPropertiesValue.equals("CTRNoteReceiptCTRReturn(BIR60)")) 
							{
								System.out.println("It will not create CSV file");
							}
							else{
								FileWriter csvWriter = new FileWriter(csvFile);
								for (int j = 0; j < headerno; j++) {
									int size = marks[j];
									for (int i = start; i < start + size; i++) {
										String saveTimerScanData = timerScanData
												.get(i).toString();
										for (int k = 0; k < ButtonNumber; k++) {
											csvWriter
													.write(passOptionNewTextFieldValue[k][j]);
											csvWriter.write(",");
										}
										csvWriter.write(saveTimerScanData);
										csvWriter.write("\r\n");

									}
								}
								csvWriter.close();
							}
							// write log file
							if(timerScanData.size()<SystemMenu.Recordlimited){
							if (logFile.exists()) {
								try {
									Files.copy(logFile.toPath(),
											oldFilecopy.toPath());
								} catch (IOException e1) {
									e1.printStackTrace();
								}
								oldFilecopy.renameTo(new File(FileToSave + "\\"
										+ logFile.getName() +"_"+ timeStamp));

							} else {

							}
							FileWriter logWriter = new FileWriter(logFile);
								int size = SystemMenu.checkLogData.size();
								for (int i = 0; i < size; i++) {
									String saveLogData = SystemMenu.checkLogData.get(i).toString();		
									logWriter.write(saveLogData);
									logWriter.write("\r\n");

								}
							
							logWriter.close();
							}
							
						} catch (IOException iox) {
							iox.printStackTrace();
							System.out.println("File can not save any data");
						}
					}

					if (ConfirmDialoginput == 1) {

					}
					}
				}
			});

		}

		catch (IOException ex) {

			System.out.println("Problem occurs when reading file !");
			ex.printStackTrace();
		}

	}

}
