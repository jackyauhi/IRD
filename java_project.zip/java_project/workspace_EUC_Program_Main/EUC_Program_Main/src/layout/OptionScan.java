package layout;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.io.InputStream;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;

import java.util.List;
import java.util.Properties;
import java.util.Timer;
import java.util.TimerTask;

public class OptionScan extends JPanel {
	Timer timer = new Timer();

	private static final long serialVersionUID = 1L;
	
	String getTopicValue;
	String getHearderValue;
	int getNumOfButton;
	String getPropertiesValue;
    String watchFieldText;
    
    
	public JFrame f;
	public OptionNew optionNew;
	public OptionScan optionScan;
	public OptionVerify optionVerify;
	public JFrame jframe;
	JTextField field;
	int DetailRecordTotalDataInt;
	int recordcount = 0;


	List<String> timerScanData;
	String passOptionNewTextFieldValue[][];
	int marks[];
	int headerno;
	String countTimerScanData;
	String buttonNum;
	int ButtonNumber;
	int numOfButton;
	String num;
	String[] headers;
	String storeSplitTimerScanData[];
	String storeTinChangeToPrnData[];
	String splitTimerScanData[];
	String OutputData[];
	int OutputDataInt[];
	public OptionScan(JFrame jframe,OptionNew optionNew,List timerScanData,String passOptionNewTextFieldValue[][],int headerno, int marks[]) {
		this.optionNew = optionNew;
		optionScan = this;
		this.jframe=jframe;
		this.timerScanData=timerScanData;
		this.passOptionNewTextFieldValue=passOptionNewTextFieldValue;
		this.headerno=headerno;
		this.marks=marks;
		
		
		//get and pass the value from class String
		getTopicValue = SystemMenu.passTopicValue;
		getHearderValue = OptionMenu.passHeaderValue;
		getNumOfButton = OptionNew.passNumOfButton;

			
	}

	public void draw(){
		//get the value to define different button click action
		getPropertiesValue =getTopicValue.replaceAll("\\s","")+getHearderValue.replaceAll("\\s","");

		if(timerScanData.size()<SystemMenu.Recordlimited){
		System.out.println("timerScanData value = " + timerScanData);
		}
		SystemMenu.TinChangeToPrn ="false";
		String filePath = "resources/allOptionJava.properties";
		Properties prop = new Properties();

		try (InputStream inputStream = MainMenu.class.getClassLoader().getResourceAsStream(filePath)) {
			
			//Loading the properties.
	     	prop.load(inputStream);	
	     	
	     	// get properties value
			num = prop.getProperty(getPropertiesValue
					+ ".DetailRecordNUM");
			numOfButton = Integer.parseInt(num);
			buttonNum = prop.getProperty(getPropertiesValue + ".NUM");
			ButtonNumber = Integer.parseInt(buttonNum);

	     	
	     	

        	for (int i = 1; i < headerno ; i++)
        	{
	        	 if(passOptionNewTextFieldValue[0][i] == null){
	        		 headerno  -= 1;
	        	 }
	        }
	     		recordcount = marks[headerno-1];
	     		countTimerScanData = Integer.toString(marks[headerno-1]);
		f=jframe;
		JLabel topic = new JLabel(getTopicValue+" Menu" , SwingConstants.CENTER);
		Border border = BorderFactory.createLineBorder(Color.BLACK, 3);
		JLabel header = new JLabel(getHearderValue, SwingConstants.CENTER);
		Border headerborder = BorderFactory.createLineBorder(Color.BLACK, 2);
		header.setBounds(150,70,400,30);
		header.setFont(new Font("Serif", Font.PLAIN, 15));
		header.setBorder(headerborder);
		topic.setBounds(90,20,500,40);
		topic.setFont(new Font("Serif", Font.PLAIN, 30));
		topic.setBorder(border);
		JLabel count = new JLabel("Total No. of Records:", SwingConstants.CENTER);
		count.setBounds(140,180,126,21);
		JLabel countNum = new JLabel(countTimerScanData, SwingConstants.CENTER);
		countNum.setBounds(320,180,96,21);
		JButton back = new JButton("Back");	
		JButton verify = new JButton("Verify");

		
		add(header);
        add(topic);
        add(count);
        add(countNum);
        setBounds(700,200,700,700);
        setLayout(null);
        setVisible(true);
        add(back);
        add(verify);

        setBounds(700,200,700,700);
        back.setBounds(250,500,180,30);
        verify.setBounds(250,450,180,30);

        String DetailRecordTotalData= new String(prop.getProperty(getPropertiesValue+".DetailRecordTotalData"));
        DetailRecordTotalDataInt = Integer.parseInt(DetailRecordTotalData);
        

		JLabel scan = new JLabel("Scan:", SwingConstants.CENTER);
		
		scan.setBounds(170,130,96,21);
        add(scan);
		field = new JTextField();
		field.setBounds(270, 130, 200, 21);
		field.setText("");
		add(field);
		
		JLabel seeFieldText = new JLabel(watchFieldText, SwingConstants.CENTER);
		seeFieldText.setBounds(270,230,200,21);
		add(seeFieldText);
		JLabel fieldTextLabel = new JLabel("Field Text:", SwingConstants.CENTER);
		fieldTextLabel.setBounds(170,230,96,21);
		add(fieldTextLabel);
		
		headers = new String[numOfButton];
		for (int i = 0; i < numOfButton; i++) {
			headers[i] = prop.getProperty(getPropertiesValue + ".DetailRecordLabel" + (i + 1));
		}
		splitTimerScanData = new String[timerScanData.size()];
		storeSplitTimerScanData= new String[timerScanData.size()];
		storeTinChangeToPrnData= new String[timerScanData.size()];
		
		OutputData = new String[numOfButton + 1];
		OutputDataInt= new int[numOfButton + 1];
		for (int i = 0; i <= numOfButton; i++) {
			OutputData[i] = new String(prop.getProperty(getPropertiesValue+ ".DetailRecordData" + i));
			OutputDataInt[i] = Integer.parseInt(OutputData[i]);
		}
		
		field.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e) {
				
		           int key = e.getKeyCode();
		           if (key == KeyEvent.VK_ENTER) {
		        	   		
						  if(getPropertiesValue.equals("CTRScanUndeliveredCTRReturn(BIR60)")||getPropertiesValue.equals("CTRScanUndeliveredCTRAdviceLetter")||getPropertiesValue.equals("CTRScanUndeliveredCTRReminder/Compound")||getPropertiesValue.equals("CTRNoteReceiptCTRReturn(BIR60)")||getPropertiesValue.equals("CTRNoteReceiptCTRAdviceLetter")){
							   
						   }
						  else if(getPropertiesValue.equals("BRScanUndeliveredBRFeeDemandNotes&PenaltyNotices")){
							  if(field.getText().length()>25){
								  JOptionPane.showMessageDialog(null,"Too long! Please input again");
								  field.setText("");
							  }
						  }
						  else if(getPropertiesValue.equals("CTRScanUndeliveredCTRDemandNote")){
							  if(field.getText().length() == 11){
								  field.setText(field.getText()+" ");
							  }
							  if(field.getText().length() >(DetailRecordTotalDataInt + 1)){
								  JOptionPane.showMessageDialog(null,"Too long! Please input again");
								  field.setText("");
							  }
						  }
						   else{
							   if(field.getText().length()>DetailRecordTotalDataInt){
									  JOptionPane.showMessageDialog(null,"Too long! Please input again");
									  field.setText("");
									  
									  
							   }
						   }
						  switch(field.getText()){
						  case "":
							  break;
						  default:
							  
							  if(getPropertiesValue.equals("CTRScanUndeliveredCTRAdviceLetter")){
								  if(field.getText().length()<DetailRecordTotalDataInt-1){
									  JOptionPane.showMessageDialog(null,"Too Short! Please input again");
									  field.setText("");
								  }

								  else{
									  String fieldText = field.getText();
									  String getFieldText=field.getText();
									  
					        	   		if(fieldText.substring(fieldText.length()-1,fieldText.length()).equals("A")){
											  for (int j = 0; j < numOfButton; j++) {
												// Convert TIN to PRN
							    					if (headers[j].equals("PRN") && j == 0) {
							    						SystemMenu.TinChangeToPrn ="true";
							    						Pencvtin abc = new Pencvtin();
							    						String tin = field.getText().substring(0,10);				    						
							    						PencvtinBean bean = abc.execute(Pencvtin.OPTION_VALIDATE_AND_GENERATE_CHECK_DIGIT_OF_TIN," ", tin);				    						
							    						if (Pencvtin.RTN_CODE_NORMAL.equals(bean.getRtnCode()) == false) {
							    							if (field.getText().length() < OutputDataInt[numOfButton]) {
							    								if(getPropertiesValue.equals("CTRScanUndeliveredCTRDemandNote")){
							    									getFieldText = field.getText()+ " ";
							    								}
							    								else{		
							    									getFieldText = " "+ field.getText();
							    								}
							    							}
							    						} else {
							    							bean = abc.execute(Pencvtin.OPTION_CONVERT_PRN_TO_TIN_OR_VICE_VERSE," ", tin);
							    							getFieldText = bean.getPrn()+ field.getText().substring(10,field.getText().length());

							    							
							    						}
							    					}
							        	   			}
					        	   			timerScanData.add(getFieldText+"R");
					        	   			watchFieldText=getFieldText+"R";
					        	   			if(timerScanData.size()<SystemMenu.Recordlimited){
						        	   			SystemMenu.checkLogData.add("(OptionScan) User input Data = " + getFieldText);
						        	   			}
					        	   		}
					        	   		else{
											  for (int j = 0; j < numOfButton; j++) {
												// Convert TIN to PRN
							    					if (headers[j].equals("PRN") && j == 0) {
							    						SystemMenu.TinChangeToPrn ="true";
							    						Pencvtin abc = new Pencvtin();
							    						String tin = field.getText().substring(0,10);				    						
							    						PencvtinBean bean = abc.execute(Pencvtin.OPTION_VALIDATE_AND_GENERATE_CHECK_DIGIT_OF_TIN," ", tin);				    						
							    						if (Pencvtin.RTN_CODE_NORMAL.equals(bean.getRtnCode()) == false) {
							    							if (field.getText().length() < OutputDataInt[numOfButton]) {
							    								if(getPropertiesValue.equals("CTRScanUndeliveredCTRDemandNote")){
							    									getFieldText = field.getText()+ " ";
							    								}
							    								else{		
							    									getFieldText = " "+ field.getText();
							    								}
							    							}
							    						} else {
							    							bean = abc.execute(Pencvtin.OPTION_CONVERT_PRN_TO_TIN_OR_VICE_VERSE," ", tin);
							    							getFieldText = bean.getPrn()+ field.getText().substring(10,field.getText().length());

							    							
							    						}
							    					}
							        	   			}
					        	   			timerScanData.add(getFieldText);
					        	   			watchFieldText=getFieldText;
					        	   			if(timerScanData.size()<SystemMenu.Recordlimited){
						        	   			SystemMenu.checkLogData.add("(OptionScan) User input Data = " + getFieldText);
						        	   			}
					        	   		}

								   	   	recordcount++;
								   	   	marks[headerno-1] = recordcount;
										SystemMenu.checkSaveStatus="false";
							        	f.setVisible(false);	        	
							        	f.getContentPane().removeAll();
							        	optionScan.removeAll();
							        	optionScan.draw();
							        	f.setContentPane(optionScan);
							        	Dimension preferredSize = new Dimension(700,700);
							        	f.setPreferredSize(preferredSize);

							        	f.setBounds(700,200,700,700);
							        	f.setLocationRelativeTo(null);
							        	SwingUtilities.updateComponentTreeUI(f);
							        	f.pack();
							        	f.setVisible(true);
							        	f.invalidate();
							        	f.validate();
							        	f.repaint();
								  }
								  
							  }
							  
							  else{
							  if(field.getText().length()<DetailRecordTotalDataInt){	

									  JOptionPane.showMessageDialog(null,"Too Short! Please input again");
									  field.setText("");
								  
								  
							   }

							  else{
								  String getFieldText=field.getText();
								  for (int j = 0; j < numOfButton; j++) {
									// Convert TIN to PRN
				    					if (headers[j].equals("PRN") && j == 0) {
				    						SystemMenu.TinChangeToPrn ="true";
				    						Pencvtin abc = new Pencvtin();
				    						String tin = field.getText().substring(0,10);				    						
				    						PencvtinBean bean = abc.execute(Pencvtin.OPTION_VALIDATE_AND_GENERATE_CHECK_DIGIT_OF_TIN," ", tin);				    						
				    						if (Pencvtin.RTN_CODE_NORMAL.equals(bean.getRtnCode()) == false) {
				    							if (field.getText().length() < OutputDataInt[numOfButton]) {
				    								if(getPropertiesValue.equals("CTRScanUndeliveredCTRDemandNote")){
				    									getFieldText = field.getText()+ " ";
				    								}
				    								else{		
				    									getFieldText = " "+ field.getText();
				    								}
				    							}
				    						} else {
				    							bean = abc.execute(Pencvtin.OPTION_CONVERT_PRN_TO_TIN_OR_VICE_VERSE," ", tin);
				    							getFieldText = bean.getPrn()+ field.getText().substring(10,field.getText().length());

				    							
				    						}
				    					}
				        	   			}
								  	timerScanData.add(getFieldText);
								  	if(timerScanData.size()<SystemMenu.Recordlimited){
								  	SystemMenu.checkLogData.add("(OptionScan) User input Data = " + field.getText());
								  	}
							   	   	recordcount++;
							   	   	marks[headerno-1] = recordcount;
								   	
									  
									if (getPropertiesValue.equals("CTRScanUndeliveredCTRDemandNote"))
									{
								  for (int i = 5-1; i <5; i++){ //find REC-COUNT button to do this
										int size = marks[headerno-1];
										String count=Integer.toString(size);
										while(count.length()!=5){
											count="0"+count;
										}
										passOptionNewTextFieldValue[i][headerno - 1]=count;
								  }
									}
									SystemMenu.checkSaveStatus="false";
									watchFieldText=getFieldText;
						        	f.setVisible(false);	        	
						        	f.getContentPane().removeAll();
						        	optionScan.removeAll();
						        	optionScan.draw();
						        	f.setContentPane(optionScan);
						        	Dimension preferredSize = new Dimension(700,700);
						        	f.setPreferredSize(preferredSize);

						        	f.setBounds(700,200,700,700);
						        	f.setLocationRelativeTo(null);
						        	SwingUtilities.updateComponentTreeUI(f);
						        	f.pack();
						        	f.setVisible(true);
						        	f.invalidate();
						        	f.validate();
						        	f.repaint();
							  
							  		}
							  }
					        break;
						  }
						  
			                    
		              }
		           }
		         });
		
		
        
        //set action
        back.addActionListener( new ActionListener()
	    {
	        public void actionPerformed(ActionEvent e)
	        {	        	
	        	if(timerScanData.size()<SystemMenu.Recordlimited){
	        	SystemMenu.checkLogData.add("Click in "+ getPropertiesValue +" (OptionScan) (Back) button");	        	
	        	//SystemMenu.checkLogData.add("timerScanData value = " + timerScanData);
	        	}
	        	
	        	f.setVisible(false);
	        	f.getContentPane().removeAll();
	        	optionNew.timerScanData = timerScanData;
	        	optionNew.headerno = headerno;
	        	optionNew.draw();	        	
	        	f.setContentPane(optionNew);
	        	Dimension preferredSize = new Dimension(700,700);
	        	f.setPreferredSize(preferredSize);
	        	f.setBounds(700,200,700,700);
	        	f.setLocationRelativeTo(null);
	        	SwingUtilities.updateComponentTreeUI(f);
	        	f.pack();
	        	f.setVisible(true);
	        	f.invalidate();
	        	f.validate();
	        	f.repaint();
	        }
	    });	
        verify.addActionListener( new ActionListener()
	    {
	        public void actionPerformed(ActionEvent e)
	        {	        	
	        	if(timerScanData.size()<SystemMenu.Recordlimited){
				SystemMenu.checkLogData.add("Click in "+ getPropertiesValue +" (OptionScan) (verify) button");
				//SystemMenu.checkLogData.add("timerScanData value = " + timerScanData);
	        	}
				//create another window
	        	f.setVisible(false);
	        	f.getContentPane().removeAll();
//	        	if (optionVerify==null)
//	        	{	
	        		if (getPropertiesValue.equals("CTRNoteReceiptCTRAdviceLetter")||getPropertiesValue.equals("PFNoteReceiptPFReturn(BIR51/BIR52)")){
	        			marks[headerno-1] = recordcount;
	        		}
	        		
	        		optionVerify = new OptionVerify(f,optionScan, timerScanData,passOptionNewTextFieldValue,headerno,marks);

//	        	}
	        	optionVerify.draw();
	        	f.setContentPane(optionVerify);
	        	Dimension preferredSize = new Dimension(700,700);
	        	f.setPreferredSize(preferredSize);
	        	f.setBounds(700,200,700,700);
	        	f.setLocationRelativeTo(null);
	        	SwingUtilities.updateComponentTreeUI(f);
	        	f.pack();
	        	f.setVisible(true);
	        	f.invalidate();
	        	f.validate();
	        	f.repaint();

	        }
	    });
        
		}
		catch (IOException ex) {
			
			System.out.println("Problem occurs when reading file !");
			ex.printStackTrace();
		} 		
		
	}
		
}
