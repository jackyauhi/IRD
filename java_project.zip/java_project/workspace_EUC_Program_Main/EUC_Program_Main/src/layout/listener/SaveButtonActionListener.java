package layout.listener;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import javax.swing.JDialog;
import javax.swing.JOptionPane;

import layout.SystemMenu;
import layout.simple.SimpleHandler;
import layout.simple.SimpleRecord;

public class SaveButtonActionListener implements ActionListener{
	
	private SimpleHandler simpleHandler;
	private List<SimpleRecord> dataList;
	private Map<String, String> headerValues;
	private Boolean clearWhenSaved;
	
	public SaveButtonActionListener(SimpleHandler simpleHandler, List<SimpleRecord> dataList, Map<String, String> headerValues, Boolean clearWhenSaved) {
		this.simpleHandler = simpleHandler;
		this.dataList = dataList;
		this.headerValues = headerValues;
		this.clearWhenSaved = clearWhenSaved;
	}
	
	public void actionPerformed(ActionEvent e) {
		String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
		String fileName = simpleHandler.getFileName();
		String csvName = simpleHandler.getCSVName();
		String fileNameCopy = simpleHandler.getCopyFileName();
		String filePath = simpleHandler.getFilePath(dataList, headerValues);
		File outputFile = new File(filePath , fileName);
		File csvFile = new File(filePath , csvName);
		File previousFile = new File(filePath , fileNameCopy);
		File outputDir = new File(filePath);

		if (dataList.size() == 0) {
			JOptionPane optionPane2 = new JOptionPane("There is not any records can save", JOptionPane.ERROR_MESSAGE);
			JDialog dialog2 = optionPane2.createDialog("Failure");
			dialog2.setAlwaysOnTop(true);
			dialog2.setVisible(true);
			
			return;
		}
		
		int diaConfirmSave = JOptionPane.showConfirmDialog(null,
				"Do you want to save these records?" + 
				(outputFile.exists() ? "   You have existing file already." : ""),		
				"Select an Option...",
				JOptionPane.YES_NO_OPTION);
		
		if (diaConfirmSave != 0)
			return;
		
		if (outputDir.exists()) {
			outputDir.mkdirs();
		}

		if (outputFile.exists()) {
			try {
				Files.copy(outputFile.toPath(), previousFile.toPath());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			previousFile.renameTo(new File(outputDir + "\\" + previousFile.getName() + timeStamp));
		}
		
		try {
			SystemMenu.checkSaveStatus = "true";
			FileWriter fw = new FileWriter(csvFile);
			for (SimpleRecord simpleRecord : dataList) {
				fw.append(simpleRecord.parseToCSV());
				fw.append("\r\n");
			}
			fw.close();
		}catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("CSV can not save any data");
		}

		try {
			SystemMenu.checkSaveStatus = "true";
			FileWriter fw = new FileWriter(outputFile);
			for (SimpleRecord simpleRecord : dataList) {
				fw.append(simpleRecord.parseToString());
				fw.append("\r\n");
			}
			fw.close();
			System.out.println("Saved to "+outputFile.getAbsolutePath());
			if (clearWhenSaved) {
				dataList.clear();
			}
		} catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data");
		}
	}
}