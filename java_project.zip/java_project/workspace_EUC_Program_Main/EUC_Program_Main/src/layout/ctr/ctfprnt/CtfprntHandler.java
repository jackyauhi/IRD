package layout.ctr.ctfprnt;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.font.TextAttribute;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;

import layout.Pencvtin;
import layout.PencvtinBean;
import layout.simple.SimpleHandler;
import layout.simple.SimpleRecord;
import utils.Field;
import utils.Field.FIELD_TYPES;

public class CtfprntHandler extends SimpleHandler {

	private static String FNCID = "CTRScanDamagedCTRReturn(BIR60)";

	public CtfprntHandler() {
		record = new Ctfprnt();
		super.loadProperties();
	}

	@Override
	public String getFileName() {
		return properties.getProperty(FNCID + ".fileName");
	}

	@Override
	public void uploadData() {
		List<Field> fields = record.getFieldSeq();

		StringBuffer messages = new StringBuffer();

		for (Field field : fields) {
			if (field.getGroupId() == null || !field.getGroupId().equals("Return Type")) {
//				System.out.println("skip " + field.getName());
				continue;
			}

			String returnType = field.getName().replaceAll(" ", "");

			// get the value from property
			String uploadPath = properties.getProperty(FNCID + ".uploadPath." + returnType.replace(" ", ""));
			String oldFolderPath = properties.getProperty(FNCID + ".oldDataPath." + returnType.replace(" ", ""));
			String fileName = getFileName();
			String fileNameCopy = getCopyFileName();
			String oldFileNameBak = getOldFileName();

			File aimFolder = new File(uploadPath);
			File oldFile = new File(oldFolderPath, fileName);
			File oldFileCopy = new File(oldFolderPath, fileNameCopy);
			File uploadFile = new File(uploadPath, fileName);
			File oldFilePath = new File(oldFolderPath);
			File bakFileName = new File(oldFolderPath, oldFileNameBak);

			if (aimFolder.exists()) {
			} else {
				aimFolder.mkdirs();
			}
			if (oldFile.exists()) {
				oldFileCopy.delete();
				// uploadFile.delete();
				bakFileName.delete();
				if (uploadFile.exists()) {

					messages.append(uploadFile + " already existed.  Please proceed manually if needed."
							+ System.lineSeparator() + System.lineSeparator());

				} else {
					try {
						Files.copy(oldFile.toPath(), oldFileCopy.toPath());
//						System.out.println(oldFile.toPath() + " => " + oldFileCopy.toPath());
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					File destFile = new File(aimFolder, oldFile.getName());
					oldFileCopy.renameTo(destFile);
					oldFile.renameTo(new File(oldFilePath, oldFileNameBak));
					messages.append(
							destFile + " Upload successfully" + System.lineSeparator() + System.lineSeparator());
				}
			} else {
				messages.append(oldFile + "  File does not exists" + System.lineSeparator() + System.lineSeparator());
			}
		}

		JOptionPane.showMessageDialog(null, messages.toString());

	}

	@Override
	public String getOldFileName() {
		return properties.getProperty(FNCID + ".oldFileName");
	}

	public String getSavePath(List<SimpleRecord> dataList, Map<String, String> headerValues, String type) {

		List<Field> fields = record.getFieldSeq();

		String returnType = null;
		for (Field field : fields) {
			if (field.getGroupId() == null || !field.getGroupId().equals("Return Type")) {
				continue;
			}
			if (headerValues == null) {
				// default handling for Open dialog
				returnType = field.getName();
				break;
			}
			if (headerValues.get(field.getName()) == null || !headerValues.get(field.getName()).equals("1")) {
				continue;
			}
			returnType = field.getName();
		}

		return properties.getProperty(FNCID + "." + type + "." + returnType.replace(" ", ""));
	}

	@Override
	public String getUploadFilePath(List<SimpleRecord> dataList, Map<String, String> headerValues) {
		return getSavePath(dataList, headerValues, "uploadPath");
	}

	@Override
	public String getOldFilePath(List<SimpleRecord> dataList, Map<String, String> headerValues) {
		return getSavePath(dataList, headerValues, "oldDataPath");
	}

	@Override
	public String getFilePath(List<SimpleRecord> dataList, Map<String, String> headerValues) {
		return getSavePath(dataList, headerValues, "savePath");
	}

	@Override
	public String getCSVName() {
		return properties.getProperty(FNCID + ".csvName");
	}

	@Override
	public String getCopyFileName() {
		return properties.getProperty(FNCID + ".copyName");
	}

	@Override
	public Ctfprnt parseFromString(String string) {
		Ctfprnt ctfprnt = new Ctfprnt();
		ctfprnt.parseFromString(string);
		return ctfprnt;
	}

	public static void saveToFile(List<String> records, File output) throws Exception {
		File tmpFile = new File(output.getParentFile(), String.valueOf(new Date().getTime()));
		FileWriter fw = new FileWriter(output, false);

		for (String line : records) {
			fw.write(line + System.lineSeparator());
		}

		fw.close();

		Files.move(tmpFile.toPath(), output.toPath(), StandardCopyOption.REPLACE_EXISTING);
	}

	// public void saveToFile(List<Ctfprnt> records, File output) throws Exception{
	// List<String> lines = new ArrayList<>();
	// for (Ctfprnt record : records) {
	// lines.add(record.parseToString());
	// }
	// File tmpFile = new File(output.getParentFile(), String.valueOf(new
	// Date().getTime()));
	// FileWriter fw = new FileWriter(output, false);
	//
	// for (String line: lines) {
	// fw.write(line+System.lineSeparator());
	// }
	//
	// fw.close();
	//
	// Files.move(tmpFile.toPath(), output.toPath(),
	// StandardCopyOption.REPLACE_EXISTING);
	// }

	public List<Field> getHeaderFields() {
		List<Field> fields = new ArrayList<>();
		for (Field field : record.getFieldSeq()) {
			if (!field.isHeader())
				continue;
			fields.add(field);
		}
		return fields;
	}
	
	public Boolean shouldSaveExistingBeforeNew() {
		return true;
	}

	public List<Field> getContentFields() {
		return this.getReportColumns();
	}

	public Integer getScanRecordLength() {
		int length = 0;
		for (Field field : record.getFieldSeq()) {
			if (!field.getIsScanField())
				continue;
			length += field.getLength();
		}

		return length;
	}

	public List<Ctfprnt> loadFromFile(File file) throws IOException {
		List<Ctfprnt> records = new ArrayList<>();
		List<String> lines = Files.readAllLines(file.toPath(), Charset.defaultCharset());
		for (String line : lines) {
			try {
				Ctfprnt ctfprnt = new Ctfprnt();
				ctfprnt.parseFromString(line);
				records.add(ctfprnt);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return records;
	}

	private void validateField(JTextField tfField, Field field) throws Exception {
		String value = tfField.getText();

		boolean isValid = false;
		Date inputDate = null;
		Date today = new Date();

		switch (field.getType()) {
		case SECTION:
		case INPUT_SECTION:
		case BATCH_SECTION:

			/*
			 * Scanning EUC Program Findings (01-04) (01) Input Invalid Section, but no
			 * rejection [only A/BC/D/E/F/G/H/K/L/M/N/X/Y should be accepted]
			 * 
			 */

			String[] acceptedValues = new String[] { "A", "B", "C", "D", "E", "F", "G", "H", "K", "L", "M", "N", "X",
					"Y" };
			if (value.length() == 3) {
				if (String.valueOf(value.charAt(0)).equals("6")
						&& String.valueOf(value.charAt(value.length() - 1)).equals("1")) {
					for (String acceptedValue : acceptedValues) {
						if (String.valueOf(value.charAt(1)).equalsIgnoreCase(acceptedValue)) {
							isValid = true;
							break;
						}
					}
				}
			}

			if (!isValid) {
				throw new Exception("The Section input is not correct. Please input again");
			}

			break;
		case BATCH:
			try {
				int batchId = Integer.parseInt(value);
				if (batchId < 1)
					throw new Exception();
				if (String.valueOf(batchId).length() > 5)
					throw new Exception();
				isValid = true;
			} catch (Exception e) {
				throw new Exception("The Batch No input is not correct. Please input again");
			}
			break;
		case DDMMYY:

			try {
				SimpleDateFormat DDMMYYformat = new SimpleDateFormat("ddMMyy");
				DDMMYYformat.setLenient(false);
				inputDate = DDMMYYformat.parse(value);
				inputDate = DDMMYYformat.parse(value);

			} catch (Exception e) {
				throw new Exception("The Date input is not correct. Please input again");
			}

			if (inputDate.after(today)) {
				throw new Exception("The Date input is future date. Please input again");
			}

			isValid = true;

			break;
		case DDMMYYYY:

			try {
				SimpleDateFormat DDMMYYformat = new SimpleDateFormat("ddMMyyyy");
				DDMMYYformat.setLenient(false);
				inputDate = DDMMYYformat.parse(value);
				inputDate = DDMMYYformat.parse(value);

			} catch (Exception e) {
				throw new Exception("The Date input is not correct. Please input again");
			}

			if (inputDate.after(today)) {
				throw new Exception("The Date input is future date. Please input again");
			}

			isValid = true;

			break;
		default:

		}
	}

	@Override
	public void validateHeader(List<JComponent> fields) throws Exception {
		List<Field> headerFields = getHeaderFields();
		Map<String, Field> headerFieldMap = new HashMap<>();
		for (Field headerField : headerFields) {
			headerFieldMap.put(headerField.getName(), headerField);
		}
		for (JComponent field : fields) {
			Field headerField = headerFieldMap.get(field.getName());
			switch (headerField.getType()) {
			case RADIO:
				break;
			default:
				this.validateField((JTextField) field, headerFieldMap.get(field.getName()));
			}
		}
	}

	@Override
	public Boolean validateContent(List<Field> fields) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Ctfprnt scanFromSTring(String string, Map<String, String> headerValues) {

		Ctfprnt ctfprnt = new Ctfprnt();
		List<Field> fields = ctfprnt.getFieldSeq();

		String tin = string.substring(0, 10);

		/*
		 * Scanning EUC Program Findings (01-04) (03) Incorrect display format on Report
		 * Page - [Assessment year should be retrieved from the last 2 digits from
		 * barcode, i.e. 17 should be shown as 2017, add one more column to shown the
		 * Return Type, i.e. the last digit of the barcode]
		 */
		String assessmentYear = string.substring(tin.length()).substring(0, 2);
		
		String returnType = string.substring(tin.length()+assessmentYear.length());
		
		SimpleDateFormat yySdfIn = new SimpleDateFormat("yy");
		SimpleDateFormat yySdfOut = new SimpleDateFormat("yyyy");
		try {
			assessmentYear = yySdfOut.format(yySdfIn.parse(assessmentYear));
		}catch(Exception e) {}

		Pencvtin pencvtin = new Pencvtin();
		PencvtinBean bean = pencvtin.execute(Pencvtin.OPTION_VALIDATE_AND_GENERATE_CHECK_DIGIT_OF_TIN, " ", tin);
		bean = pencvtin.execute(Pencvtin.OPTION_CONVERT_PRN_TO_TIN_OR_VICE_VERSE, " ", tin);
		String prn = bean.getPrn();

		/*
		 * When the scanning selection is for Bulk issue or Type 4 Return, the Year in
		 * the output uploading file will be left empty.
		 */
		if (headerValues.get("Return for Bulk Issue").equals("1")
				|| headerValues.get("Return for Type 4 Returns").equals("1")) {
			String leftEmptyassessmentYear = "";
			for (int lIdx = 0; lIdx < assessmentYear.length()+properties.getProperty(FNCID + ".create.year.prefix").length(); lIdx++) {
				leftEmptyassessmentYear += " ";
			}
			assessmentYear = leftEmptyassessmentYear;
		}

		ctfprnt.setValue("PRN", prn);
		ctfprnt.setValue("Assessment Year", assessmentYear);
		ctfprnt.setValue("Return Type", returnType);

		for (Field field : fields) {
			if (headerValues.get(field.getName()) == null) {
				continue;
			}
			ctfprnt.setValue(field.getName(), headerValues.get(field.getName()));
		}
		return ctfprnt;
	}

	@Override
	public Object[][] parseToDisplayRecord(List<?> records) {
		List<Field> contentFields = this.getContentFields();

		Object[][] displayRecords = new Object[records.size()][contentFields.size() + 1];
		for (int rIdx = 0; rIdx < records.size(); rIdx++) {
			Ctfprnt ctfprnt = (Ctfprnt) records.get(rIdx);
			displayRecords[rIdx][0] = new JRadioButton();
			for (int cIdx = 0; cIdx < contentFields.size(); cIdx++) {
				Field contentField = contentFields.get(cIdx);
				String contentValue = ctfprnt.getValue(contentField.getName());
				switch (contentField.getType()) {
				case DDMMYYYY:
					SimpleDateFormat sdfIn = new SimpleDateFormat("ddMMyyyy");
					SimpleDateFormat sdfOut = new SimpleDateFormat("dd/MM/yyyy");
					try {
						contentValue = sdfOut.format(sdfIn.parse(contentValue));
					} catch (ParseException e) {
						e.printStackTrace();
					}
					break;
				default:

				}
				displayRecords[rIdx][cIdx + 1] = contentValue;
			}
		}

		return displayRecords;
	}

	@Override
	public List<String> getCustomizeReportTitle(List<SimpleRecord> dataList, Map<String, String> headerValues) {

		List<Field> fields = record.getFieldSeq();

		String returnType = null;
		for (Field field : fields) {
			if (field.getGroupId() == null || !field.getGroupId().equals("Return Type")) {
				continue;
			}
			if (headerValues.get(field.getName()) == null || !headerValues.get(field.getName()).equals("1")) {
				continue;
			}
			returnType = field.getName();
		}

		List<String> customizeTitles = new ArrayList<>();
		customizeTitles.add(returnType);

		return customizeTitles;
	}

	@Override
	public Object[] getDisplayHeader() {
		List<Field> contentFields = this.getContentFields();
		Object[] displayHeaders = new Object[contentFields.size()];
		for (int cIdx = 0; cIdx < contentFields.size(); cIdx++) {
			Field contentField = contentFields.get(cIdx);
			displayHeaders[cIdx] = contentField.getName();
		}
		return displayHeaders;
	}
	
	@Override
	public Boolean canNewIfRecordExists() {
		return false;
	}
	
	@Override
	public Boolean canBackIfRecordExists() {
		return false;
	}

	@Override
	public Boolean hasSaveButtonInVerifyWindow() {
		/*-	Should be No Save button on screen*/
		return true;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List afterScan(List dataList) {

		List<Field> fields = record.getFieldSeq();

		for (int dIdx = 0; dIdx < dataList.size(); dIdx++) {
			Ctfprnt ctfprnt = (Ctfprnt) dataList.get(dIdx);
			for (Field field : fields) {
				String value = null;
				String padding = null;
				switch (field.getType()) {
				case BATCH_SEQ:
					value = String.valueOf(dIdx + 1);
					padding = "";
					while (value.length() + padding.length() < field.getLength()) {
						padding += field.getPadding();
					}
					if (field.getPaddingDir() == Field.PADDING_DIR.LEFT) {
						value = padding + value;
					}
					if (field.getPaddingDir() == Field.PADDING_DIR.RIGHT) {
						value = value + padding;
					}
					ctfprnt.setValue(field.getName(), value);
					break;
				case BATCH_TOTAL:
					value = String.valueOf(dataList.size());
					padding = "";
					while (value.length() + padding.length() < field.getLength()) {
						padding += field.getPadding();
					}
					if (field.getPaddingDir() == Field.PADDING_DIR.LEFT) {
						value = padding + value;
					}
					if (field.getPaddingDir() == Field.PADDING_DIR.RIGHT) {
						value = value + padding;
					}
					ctfprnt.setValue(field.getName(), value);
					break;
				case FILLER:
					StringBuffer sb = new StringBuffer();
					for (int idx = 0; idx < field.getLength(); idx++) {
						sb.append(field.getPadding());
					}
					ctfprnt.setValue(field.getName(), sb.toString());
					break;
				default:
					value = ctfprnt.getValue(field.getName());
					if (value == null)
						value = "";
					if (field.getPadding() != null) {
						padding = "";
						while (value.length() + padding.length() < field.getLength()) {
							padding += field.getPadding();
						}
						if (field.getPaddingDir() == Field.PADDING_DIR.LEFT) {
							value = padding + value;
						}
						if (field.getPaddingDir() == Field.PADDING_DIR.RIGHT) {
							value = value + padding;
						}
						ctfprnt.setValue(field.getName(), value);
					}
				}
			}
			dataList.set(dIdx, ctfprnt);
		}
		return dataList;
	}

	private String[] getReportTitles() {
		String[] titles = new String[] { "Section", "Batch No.", "Date" };

		return titles;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public JScrollPane prepareContentPanel(List<SimpleRecord> dataList, Map<String, String> headerValues,
			JButton btnPrint, JButton btnBack) {

		JPanel contentPanel = new JPanel();
		contentPanel.setBorder(BorderFactory.createEmptyBorder());
		contentPanel.setLayout(new GridLayout(3, 4));

		String[] titles = getReportTitles();

		List<JLabel> labels = new ArrayList<>();

		for (String title : titles) {

			JLabel lbTitle = new JLabel(title + ":");
			Font font = lbTitle.getFont();
			Map attributes = font.getAttributes();
			attributes.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE_LOW_DASHED);
			lbTitle.setFont(font.deriveFont(attributes));

			labels.add(lbTitle);
		}

		JLabel lbTitle = new JLabel("Total No. of Records:");
		Font font = lbTitle.getFont();
		Map attributes = font.getAttributes();
		attributes.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE_LOW_DASHED);
		lbTitle.setFont(font.deriveFont(attributes));

		labels.add(lbTitle);

		List<Field> fields = record.getFieldSeq();
		for (String title : titles) {

			String value = headerValues.get(title);

			FIELD_TYPES fieldType = null;
			for (Field field : fields) {
				if (!field.getName().equals(title))
					continue;
				fieldType = field.getType();
			}
			switch (fieldType) {
			case DDMMYYYY:
				SimpleDateFormat sdfIn = new SimpleDateFormat("ddMMyyyy");
				SimpleDateFormat sdfOut = new SimpleDateFormat("dd/MM/yyyy");
				try {
					value = sdfOut.format(sdfIn.parse(value));
				} catch (ParseException e) {
					e.printStackTrace();
				}
				break;
			default:
			}

			labels.add(new JLabel(value));
		}

		String numberOfRecords = String.valueOf(dataList.size());
		String paddingStr = "&nbsp;";
		StringBuffer paddingSb = new StringBuffer();
		for (int lengthIdx = 0; lengthIdx < 5 - numberOfRecords.length(); lengthIdx++) {
			paddingSb.append(paddingStr);
		}
		numberOfRecords = paddingSb.toString() + numberOfRecords;

		labels.add(new JLabel("<html><u>" + numberOfRecords + "</u></html>"));

		labels.add(new JLabel("<html>" + "Validation & Updating <br/>" + "Report(s) verified. <br/>"
				+ "BU for destruction.<br/>" + "<br/>"
				+ "<u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u><br/>"
				+ "<center><i>Initial</i></center>" + "</html>"));
		labels.add(new JLabel(""));
		labels.add(new JLabel(""));
		labels.add(new JLabel("<html><br/><br/><br/><u>" + numberOfRecords + "</u></html>"));

		for (JLabel label : labels) {
			label.setAlignmentX(Component.CENTER_ALIGNMENT);
			label.setHorizontalAlignment(JLabel.CENTER);
			contentPanel.add(label);
		}

		JPanel closingPanel = new JPanel();
		closingPanel.setBorder(BorderFactory.createEmptyBorder());
		closingPanel.setLayout(new GridLayout(1, 3));

		JPanel buttonPanel = new JPanel();
		buttonPanel.setBorder(BorderFactory.createEmptyBorder());
		buttonPanel.setLayout(new GridLayout(2, 1));

		btnPrint.setMaximumSize(new Dimension(40, (int) btnPrint.getSize().getHeight()));
		btnBack.setMaximumSize(new Dimension(40, (int) btnPrint.getSize().getHeight()));

		buttonPanel.add(btnPrint);
		buttonPanel.add(btnBack);

		closingPanel.add(new JLabel("Date:"));
		closingPanel.add(buttonPanel);
		closingPanel.add(new JLabel(""));

		JPanel bodyPanel = new JPanel();
		bodyPanel.setBorder(BorderFactory.createEmptyBorder());
		bodyPanel.setLayout(new BorderLayout());
		bodyPanel.add(contentPanel, BorderLayout.CENTER);
		bodyPanel.add(closingPanel, BorderLayout.SOUTH);

		JScrollPane jScrollPane = new JScrollPane(bodyPanel);
		jScrollPane.setBorder(BorderFactory.createEmptyBorder());
		Border border = jScrollPane.getBorder();
		Border margin = new EmptyBorder(10, 10, 10, 10);
		jScrollPane.setBorder(new CompoundBorder(border, margin));

		return jScrollPane;
	}

	@Override
	public List<Field> getReportColumns() {
		List<Field> fields = record.getFieldSeq();
		List<Field> reportFields = new ArrayList<>();
		for (Field field : fields) {
			if (field.getIsReportField()) {
				reportFields.add(field);
			}
		}
		return reportFields;
	}

	@Override
	public Dimension getPreferredSize() {
		return new Dimension((getReportTitles().length + 1) * 140, 640);
	}
}
