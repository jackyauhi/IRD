package layout.ctr.ctfprnt;

import java.util.ArrayList;
import java.util.List;

import layout.simple.SimpleRecord;
import utils.Field;
import utils.Field.PADDING_DIR;

public class Ctfprnt extends SimpleRecord{
	
	public Ctfprnt() {
		fieldSeq = initFields();
	}

	@Override
	protected List<Field> initFields(){
		List<Field> datas = new ArrayList<>();
		/*MUST BE UNIQUE*/
		datas.add(new Field("Section", Field.FIELD_TYPES.SECTION, 3, null, null, true, false, true, false));
		datas.add(new Field("Batch No.", Field.FIELD_TYPES.BATCH, 5, "0", Field.PADDING_DIR.LEFT, true, false, true, false));
		datas.add(new Field("Batch Seq No.", Field.FIELD_TYPES.BATCH_SEQ, 5, "0", Field.PADDING_DIR.LEFT, false, false, true, false));
		datas.add(new Field("Batch Total", Field.FIELD_TYPES.BATCH_TOTAL, 5, "0", Field.PADDING_DIR.LEFT, false, false, true, false));
		datas.add(new Field("Date", Field.FIELD_TYPES.DDMMYYYY, 8, null, null, true, false, true, false));
		datas.add(new Field("Return for Bulk Issue", Field.FIELD_TYPES.RADIO, 1, null, null, true, false, false, "Return Type", false));
		datas.add(new Field("Return for Periodic Issue", Field.FIELD_TYPES.RADIO, 1, null, null, true, false, false, "Return Type", false));
		datas.add(new Field("Return for Review Issue", Field.FIELD_TYPES.RADIO, 1, null, null, true, false, false, "Return Type", false));
		datas.add(new Field("Return for Type 4 Returns", Field.FIELD_TYPES.RADIO, 1, null, null, true, false, false, "Return Type", false));
		datas.add(new Field("TC", Field.FIELD_TYPES.TEXT, 3, "324", Field.PADDING_DIR.RIGHT, false, false, true, false));
		datas.add(new Field("Filler1", Field.FIELD_TYPES.FILLER, 24, " ", Field.PADDING_DIR.LEFT, false, false, true, false));
		datas.add(new Field("Filler2", Field.FIELD_TYPES.FILLER, 3, " ", Field.PADDING_DIR.LEFT, false, false, true, false));
		datas.add(new Field("PRN", Field.FIELD_TYPES.PRN, 10, " ", Field.PADDING_DIR.RIGHT, false, false, true, true));
		datas.add(new Field("TIN", Field.FIELD_TYPES.TIN, 10, " ", Field.PADDING_DIR.LEFT, false, true, false, false));
		datas.add(new Field("Scan Year", Field.FIELD_TYPES.TEXT, 2, null, null, false, true, false, false));
		datas.add(new Field("Assessment Year", Field.FIELD_TYPES.TEXT, 4, null, null, false, false, true, true));
		datas.add(new Field("Return Type", Field.FIELD_TYPES.INTEGER, 1, null, null, false, true, false, true));
		datas.add(new Field("Return Found Flag", Field.FIELD_TYPES.TEXT, 1, " ", Field.PADDING_DIR.RIGHT, false, false, true, false));
		datas.add(new Field("Return Unique Flag", Field.FIELD_TYPES.TEXT, 1, " ", Field.PADDING_DIR.RIGHT, false, false, true, false));
		datas.add(new Field("Return Unique Section", Field.FIELD_TYPES.TEXT, 3, " ", Field.PADDING_DIR.RIGHT, false, false, true, false));
		datas.add(new Field("Return Print Count", Field.FIELD_TYPES.INTEGER, 6, " ", Field.PADDING_DIR.RIGHT, false, false, true, false));
		
		return datas;
	}

	@Override
	public String parseToString() {
		StringBuffer sb = new StringBuffer();
		
		for (Field field: fieldSeq) {
			if (!field.getShouldStoreToFile())
				continue;
			String value = getValue(field.getName());
			String padding = "";
			if (value.length() < field.getLength() && field.getPadding() != null) {
				for (int i = 0; i < value.length() - value.length(); i++) {
					padding += field.getPadding();
				}
				if (field.getPaddingDir() == PADDING_DIR.LEFT) {
					value = padding+value;
				}
				if (field.getPaddingDir() == PADDING_DIR.RIGHT) {
					value = value+padding;
				}
			}
			sb.append(value);
		}
		
		return sb.toString();
	}

	@Override
	public String parseToCSV() {
		StringBuffer sb = new StringBuffer();
		
		for (int fieldIdx = 0 ; fieldIdx < fieldSeq.size(); fieldIdx++) {
			Field field = fieldSeq.get(fieldIdx);
			if (!field.getShouldStoreToFile())
				continue;
			String value = getValue(field.getName());
			if (value == null) {
				throw new RuntimeException(field.getName()+" not in record");
			}
			String padding = "";
			if (value.length() < field.getLength() && field.getPadding() != null) {
				for (int i = 0; i < value.length() - value.length(); i++) {
					padding += field.getPadding();
				}
				if (field.getPaddingDir() == PADDING_DIR.LEFT) {
					value = padding+value;
				}
				if (field.getPaddingDir() == PADDING_DIR.RIGHT) {
					value = value+padding;
				}
			}
			sb.append(value + (fieldIdx + 1 >= fieldSeq.size() ? "," : ""));
		}
		
		return sb.toString();
	}

	@Override
	public void parseFromString(String string) {
		int startIdx = 0;
		for (Field field: fieldSeq) {
			if (!field.getShouldStoreToFile())
				continue;
			try {
//				System.out.println(field.getName()+" => "+string.substring(startIdx, startIdx+field.getLength()));
				setValue(field.getName(), string.substring(startIdx, startIdx+field.getLength()));
			}catch(Exception e) {
				e.printStackTrace();
				throw new RuntimeException(e.getMessage());
			}
			startIdx += field.getLength();
		}
	}
}

