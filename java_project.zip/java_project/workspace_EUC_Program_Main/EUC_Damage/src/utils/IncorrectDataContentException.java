package utils;

@SuppressWarnings("serial")
public class IncorrectDataContentException extends Exception{

}
