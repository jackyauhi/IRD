package utils;

public class Field{
	public static enum FIELD_TYPES{
		TEXT, INTEGER, DDMMYYYY, DDMMYY, BATCH_SEQ, RADIO, BATCH_TOTAL, SPACE, TIN, PRN, BATCH, BATCH_SECTION, INPUT_SECTION, SECTION_ID, FILLER, REC_COUNT, BATCH_DATE, SECTION
	}
	public static enum PADDING_DIR{
		LEFT, RIGHT
	}
	
	private String name;
	private FIELD_TYPES type; 
	private Integer length;
	private PADDING_DIR paddingDir;
	private String padding;
	private Boolean isHeader;
	private Boolean isScanField;
	private Boolean shouldStoreToFile;
	private String groupId;
	private Boolean isReportField;

	public Field(String name, FIELD_TYPES type, Integer length, String padding, PADDING_DIR paddingDir, Boolean isHeader, Boolean isScanField, Boolean shouldStoreToFile, String groupId, Boolean isReportField) {
		super();
		this.name = name;
		this.type = type;
		this.length = length;
		this.padding = padding;
		this.paddingDir = paddingDir;
		this.isHeader = isHeader;
		this.isScanField = isScanField;
		this.shouldStoreToFile = shouldStoreToFile;
		this.groupId = groupId;
		this.isReportField = isReportField;
	}
	
	public Field(String name, FIELD_TYPES type, Integer length, String padding, PADDING_DIR paddingDir, Boolean isHeader, Boolean isScanField, Boolean shouldStoreToFile, Boolean isReportField) {
		super();
		this.name = name;
		this.type = type;
		this.length = length;
		this.padding = padding;
		this.paddingDir = paddingDir;
		this.isHeader = isHeader;
		this.isScanField = isScanField;
		this.shouldStoreToFile = shouldStoreToFile;
		this.groupId = null;
		this.isReportField = isReportField;
	}
	
	public Boolean getIsReportField() {
		return isReportField;
	}

	public void setIsReportField(Boolean isReportField) {
		this.isReportField = isReportField;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public Boolean getShouldStoreToFile() {
		return shouldStoreToFile;
	}

	public void setShouldStoreToFile(Boolean shouldStoreToFile) {
		this.shouldStoreToFile = shouldStoreToFile;
	}

	public Boolean getIsHeader() {
		return isHeader;
	}

	public void setIsHeader(Boolean isHeader) {
		this.isHeader = isHeader;
	}

	public Boolean getIsScanField() {
		return isScanField;
	}

	public void setIsScanField(Boolean isScanField) {
		this.isScanField = isScanField;
	}

	public Boolean isHeader() {
		return this.isHeader;
	}
	public void seIsHeader(Boolean isHeader) {
		this.isHeader = isHeader;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public FIELD_TYPES getType() {
		return type;
	}
	public void setType(FIELD_TYPES type) {
		this.type = type;
	}
	public Integer getLength() {
		return length;
	}
	public void setLength(Integer length) {
		this.length = length;
	}
	public String getPadding() {
		return padding;
	}
	public void setPadding(String padding) {
		this.padding = padding;
	}
	public PADDING_DIR getPaddingDir() {
		return paddingDir;
	}
	public void setPaddingDir(PADDING_DIR paddingDir) {
		this.paddingDir = paddingDir;
	}
}