package layout;

import java.text.NumberFormat;
import java.text.ParsePosition;

/******************************************************************************
 * Amendment log (started at MIRC015) 
 * -------------
 * 
 * Ref no. Date       Amended by Description 
 * ------- ---------- ---------- ---------------------------------------------- 
 * MIRC015 13.02.2009 ycwang     New prefix "ZY" is introduced to dummy PRN
 * 
 * TAAS2   14.05.2014 ycwang     Enhanced for TAAS2 online functions
 * 
 * EUC	   01.08.2018 mcychung	 Enhanced for EUC barcode rewrite	
 * 
 ****************************************************************************** 
 * 
 */

public class PrnValidator {
	private static int[] multiplyArray = { 9, 8, 7, 6, 5, 4, 3, 2 };
	static final String DEFAULT_ERROR_CODE = "message.0001";

	public static ValidationResult validate(String prn) {
	
		prn = prn.trim().toUpperCase();
		int length = prn.length();
		if (isEmpty(prn))
			return new ValidationResult(true, "", IrdValidConstant.NORMAL_PRN, "");
		
		// Perform validateFormat() to verify if it is a special PRN9 number
		String prefix = prn.substring(0, length - 1);
		int code = validateFormat(prefix);
		if (code != IrdValidConstant.NORMAL_PRN)
			return new ValidationResult(false, prn, code, DEFAULT_ERROR_CODE);
		
		// Check if generated check digit equals the supplied value
		if (generateCheckDigit(prefix).charAt(0) != prn.charAt(length - 1)) {
			return new ValidationResult(false, prn, IrdValidConstant.INVALID_PRN_CHECK_DIGIT, DEFAULT_ERROR_CODE);
		}
		if (length == 8) {
			prn = " " + prn.trim();
			length++;
		}
		if (prn.startsWith("ZZ") || prn.startsWith("ZY")) {
			return new ValidationResult(true, prn, IrdValidConstant.DUMMY_PRN, "");
		}
		return new ValidationResult(true, prn, IrdValidConstant.NORMAL_PRN, "");
	}

	public static int validateFormat(String prn) {
		if ("ZZ999999".equals(prn)) {
			return IrdValidConstant.INVALID_PRN;
		}
		
		int length = prn.length();
		char secondChar = (length > 1) ? prn.charAt(1) : ' ';
		if (length == 7) {
			// Check for the starting 1st alpha characters and follows must be 6
			// numeric characters.
			if (!isAtoZ(prn.charAt(0)) || !isNumeric(prn, 1, 7))
				return IrdValidConstant.INVALID_PRN;
		} else if (length == 8) {
			// if there is a blank at the 2nd character position?
			if (secondChar == ' ')
				return IrdValidConstant.INVALID_PRN;
			// Check for the starting 2nd alpha characters and follows must be 6
			// numeric characters.
			if (!isAtoZ(prn, 0, 2) || !isNumeric(prn, 2, 8))
				return IrdValidConstant.INVALID_PRN;
		} else {
			return IrdValidConstant.INVALID_PRN;
		}

		char firstChar = prn.charAt(0);
		if (length == 7) {
			// IF PRN9 is 7 DIGITS
			// IF 1st character not within "A" to "Z, then false
			if (!isAtoZ(firstChar))
				return IrdValidConstant.INVALID_PRN;
		} else {
			// IF PRN9 is 8 DIGITS
			// IF 1st character is "Z" and 2nd character != "Z" and != "Y", then
			// false
			// MIRC015
			if (firstChar == 'Z' && secondChar != 'Z' && secondChar != 'Y')
				return IrdValidConstant.INVALID_PRN;

		}
		return IrdValidConstant.NORMAL_PRN;
	}

	public static String generate(String prn) throws java.lang.Exception {
		if (prn.trim().length() == 0)
			return "error";
		validateFormat(prn);
		return (prn + generateCheckDigit(prn));
	}
	
	public static Boolean isNeedCheckDigit(String prn) {
		
		prn = prn.trim().toUpperCase();
		int length = prn.length();
		if (length == 7) {
			if (isAtoZ(prn.charAt(0)) && isNumeric(prn, 1, 7))
				return true;
		} else if (length == 8) {
			if (isAtoZ(prn, 0, 2) && isNumeric(prn, 2, 8))
				return true;
		}
		return false;
	}

	public static String generateCheckDigit(String prn) {
		// The is to assume that PRN9 format have been through the
		// validateFormat()
		int weight = 0;
		int length = prn.length();

		// If prn is 7 DIGITS then append a space in front of it,
		// otherwise it will still treat space and 8 DIGITS.
		// This would make sure the space is always count as for
		// calculating the value of this check digit.
		if (length == 7) {
			prn = " " + prn;
			length++;
		}

		for (int i = 0; i < length; i++) {
			weight += getCodeHash(prn.charAt(i)) * multiplyArray[i];
		}

		// If 11-remainder = 10, then return 'A'
		// This means that there is no char greater than A for the ID card's
		// checkdigit
		// Since the greatest number for this type of subtract is 11.
		int remainder = weight % 11;
		if (remainder == 0) {
			return "0";
		} else {
			char checkDigit = Character.forDigit((11 - remainder), 11);
			return (checkDigit == 'a') ? "A" : Character.toString(checkDigit);
		}
	}

	protected static int[] codeHashTable = initCodeHashTable();

	public static int getCodeHash(char ch) {
		return codeHashTable[ch - ' '];
	}

	private static int[] initCodeHashTable() {
		int[] codeHashTable = new int[60];
		int i;
		char ch;

		i = 0;
		for (ch = '0'; ch <= '9'; ch++, i++) {
			codeHashTable[ch - ' '] = i;
		}
		i = 10;
		for (ch = 'A'; ch <= 'Z'; ch++, i++) {
			codeHashTable[ch - ' '] = i;
		}
		codeHashTable[0] = i;
		return codeHashTable;
	}
	
	public static boolean isAtoZ (char c) {
		return (c >= 'A') && (c <= 'Z');
	}
	
	public static boolean isAtoZ (String data, int init, int end) {
		
			for (int i = init; i < end; i++) {
				if (data.charAt(i) < 'A' || data.charAt(i) > 'Z') 
					return false;
			}
		
		return true;
	}
	
	public static boolean isEmpty(String s) {
		if ((s != null) && (s.trim().length() > 0))
	        return false;
	    else
	        return true;
	}
	public static boolean isNumeric(String str) {
		NumberFormat formatter = NumberFormat.getInstance();
		ParsePosition pos = new ParsePosition(0);
		formatter.parse(str, pos);
		return str.length() == pos.getIndex();
	}
	
	public static boolean isNumeric (char c) {
		return (c >= '0') && (c <= '9');
	}
	
	public static boolean isNumeric (String data, int init, int end) {
		
			for (int i = init; i < end; i++) {
				if (data.charAt(i) < '0' || data.charAt(i) > '9') 
					return false;
			}

		return true;
	}
	
}

