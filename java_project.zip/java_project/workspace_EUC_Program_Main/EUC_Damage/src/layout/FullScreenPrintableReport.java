package layout;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Properties;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;

import utils.PrintUtil;

@SuppressWarnings("serial")
public class FullScreenPrintableReport  extends JFrame {
	
	/**
	 * Create the panel.
	 */
	private JPanel prepareFooter(final JFrame f) {
		// print report
		JButton print = new JButton("Print");
		print.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PrintUtil printUtil = new PrintUtil(f);
				((JButton)e.getSource()).setVisible(false);
				printUtil.print();
				((JButton)e.getSource()).setVisible(true);
			}
		});
		
		JPanel footerPanel = new JPanel();
		footerPanel.setLayout(new BorderLayout(0, 0));
		footerPanel.add(print, BorderLayout.NORTH);
		footerPanel.add(new JLabel("-------------------------------------------------------------------------------------------------", SwingConstants.CENTER), BorderLayout.CENTER);
		footerPanel.add(new JLabel("*****************************************************************", SwingConstants.CENTER), BorderLayout.SOUTH);
		return footerPanel;
	}
	
	private JPanel prepareTitlePanel(String topicValue, String headerValue) {

		JPanel titlePanel = new JPanel();
		titlePanel.setLayout(new BorderLayout(0, 0));
		
		// report header
		JLabel lblRecordsSummaryReport = new JLabel("Records Summary Report", SwingConstants.CENTER);
		lblRecordsSummaryReport.setFont(new Font("新細明體", Font.BOLD, 12));
		JLabel topic = new JLabel(topicValue + " Menu",SwingConstants.CENTER);
		JLabel header = new JLabel(headerValue, SwingConstants.CENTER);
		titlePanel.add(topic, BorderLayout.NORTH);
		titlePanel.add(header, BorderLayout.CENTER);
		titlePanel.add(lblRecordsSummaryReport, BorderLayout.SOUTH);
		
		return titlePanel;
	}
	
	private JPanel prepareHeaderPanel() {
		JPanel headerPanel = new JPanel();
		headerPanel.setLayout(new BorderLayout(0, 0));
		headerPanel.add(new JLabel("*****************************************************************", SwingConstants.CENTER), BorderLayout.NORTH);
		headerPanel.add(new JLabel("-------------------------------------------------------------------------------------------------", SwingConstants.CENTER), BorderLayout.CENTER);
		
		return headerPanel;
	}
	
	public FullScreenPrintableReport(List<String> timerScanData, String passOptionNewTextFieldValue[][], int headerno ,int marks[]) {
		final JFrame f = new JFrame("Report");
		String topicValue = SystemMenu.passTopicValue;
		String headerValue = OptionMenu.passHeaderValue;
		// get the value to define different button click action
		String selectedAction = topicValue.replaceAll("\\s", "")+ headerValue.replaceAll("\\s", "");
		
		try (InputStream inputStream = MainMenu.class.getClassLoader().getResourceAsStream("resources/allOptionJava.properties")) {
			Properties prop = new Properties();
			prop.load(inputStream);
			
			setLayout(new BorderLayout(0, 0));
			// report border
			JPanel panel = new JPanel();
			panel.setLayout(new BorderLayout(0, 0));

			JPanel headerPanel = prepareHeaderPanel();
			headerPanel.add(prepareTitlePanel(topicValue, headerValue), BorderLayout.SOUTH);
			panel.add(headerPanel, BorderLayout.NORTH);
			
			panel.add(prepareFooter(f), BorderLayout.SOUTH);
			panel.add(prepareContentPanel(selectedAction, prop, timerScanData.size(), passOptionNewTextFieldValue, marks, headerno), BorderLayout.CENTER);
			
			String num = prop.getProperty(selectedAction + ".NUM");
			int numOfButton = Integer.parseInt(num);
			
			// set and show the container frame
			Dimension preferredSize = new Dimension(numOfButton * 200, 400);
			f.setPreferredSize(preferredSize);
			f.setBounds(700, 200, numOfButton * 200, 400);
			f.setLocationRelativeTo(null);
			f.pack();
			// report data
			f.setContentPane(panel);
			f.setVisible(true);
		}catch (IOException ex) {

			System.out.println("Problem occurs when reading file !");
			ex.printStackTrace();
		}
		
	}
	
	private JScrollPane prepareContentPanel(String propertiesValue, Properties prop, int timerScanDataSize, String[][] passOptionNewTextFieldValue, int[] marks, int headerno) {
		
		String num = prop.getProperty(propertiesValue + ".NUM");
		int numOfButton = Integer.parseInt(num);
		
		String[] label = new String[numOfButton + 1];
		String[][] labelData = new String[headerno+1][numOfButton + 1];

		// set column
		for (int btnIdx = 0; btnIdx <= numOfButton; btnIdx++) {
			if (btnIdx != numOfButton) {
				label[btnIdx] = prop.getProperty(propertiesValue + ".00" + (btnIdx + 1));
			} else {
				label[btnIdx] = "Total No. of Records:";
			}
		}
		
		int size = 0;
		if (propertiesValue.equals("CTRNoteReceiptCTRAdviceLetter")||propertiesValue.equals("PFNoteReceiptPFReturn(BIR51/BIR52)")){
			for (int headerIdx = 0; headerIdx < headerno; headerIdx++){
				size += marks[headerIdx];
			}
		}else{
			size = timerScanDataSize;
		}
		
		// set data
		for (int headernoIdx = 0; headernoIdx < headerno; headernoIdx++){
			for (int btnIdx = 0; btnIdx < numOfButton; btnIdx++) {
				labelData[headernoIdx][btnIdx] = passOptionNewTextFieldValue[btnIdx][headernoIdx];
			}
			
    		if (propertiesValue.equals("CTRNoteReceiptCTRAdviceLetter")||
    			propertiesValue.equals("PFNoteReceiptPFReturn(BIR51/BIR52)")){
    			labelData[headernoIdx][numOfButton] =  Integer.toString(marks[headernoIdx]);
    		}else{
    			labelData[headernoIdx][numOfButton] =  Integer.toString(size);
    		}
		}
		labelData[headerno][numOfButton] =  Integer.toString(size);
		
		//set Table with scroll
		final JTable table = new JTable(labelData, label);
		table.setEnabled(false);
		JScrollPane scroll = new JScrollPane(table);
		scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
		scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scroll.setPreferredSize(new Dimension(400, 300));
		table.getTableHeader().setReorderingAllowed(false);
		table.getTableHeader().setResizingAllowed(false);
		
		return scroll;
	}
	
}
