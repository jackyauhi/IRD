package layout;

import java.util.regex.Pattern;

public class Pencvtin {

	//private static Logger logger = Logger.getLogger(Pencvtin.class);
	public static String OPTION_CONVERT_PRN_TO_TIN_OR_VICE_VERSE 			= "1";
	public static String OPTION_VALIDATE_AND_GENERATE_CHECK_DIGIT_OF_TIN	= "2";
	
	public static String RTN_CODE_NORMAL							= " ";
	public static String RTN_CODE_INVALID_PARAMETER_OR_PRN_OR_TIN	= "1";
	public static String RTN_CODE_CHECK_DIGIT_OF_TIN_GENERATED		= "2";
	private static char CONVERT_TIN_0_TO_PRN = '6';
	private static char CONVERT_TIN_1_TO_PRN = '2';
	private static char CONVERT_TIN_2_TO_PRN = '8';
	private static char CONVERT_TIN_3_TO_PRN = '7';
	private static char CONVERT_TIN_4_TO_PRN = '5';
	private static char CONVERT_TIN_5_TO_PRN = '1';
	private static char CONVERT_TIN_6_TO_PRN = '9';
	private static char CONVERT_TIN_7_TO_PRN = '4';
	private static char CONVERT_TIN_8_TO_PRN = '0';
	private static char CONVERT_TIN_9_TO_PRN = '3';
	
	private static short TIN_POS_0_WEIGHTING_FACTOR = (short) 5;
	private static short TIN_POS_1_WEIGHTING_FACTOR = (short) 2;
	private static short TIN_POS_2_WEIGHTING_FACTOR = (short) 7;
	private static short TIN_POS_3_WEIGHTING_FACTOR = (short) 1;
	private static short TIN_POS_4_WEIGHTING_FACTOR = (short) 9;
	private static short TIN_POS_5_WEIGHTING_FACTOR = (short) 6;
	private static short TIN_POS_6_WEIGHTING_FACTOR = (short) 8;
	private static short TIN_POS_7_WEIGHTING_FACTOR = (short) 3;
	private static short TIN_POS_8_WEIGHTING_FACTOR = (short) 4;
	
	/*
	 *  Valid TIN Formats:
	 *  "123456789"		- No check digit / check digit = trailing space
	 *  "123456789 "	- Check digit = trailing space (for remainder = 10)
	 *  "1234567890"	- With check digit
	 */
	private static Pattern VALIDATE_TIN_PATTERN = Pattern.compile("[0-9]{8,9}[0-9 ]");
	
public PencvtinBean execute(String option, String prn, String tin) {
		
		// 1
		PencvtinBean pencvtinBean = new PencvtinBean();
		pencvtinBean.setRtnCode(RTN_CODE_NORMAL);
		
		// 2.1
		if ( (OPTION_CONVERT_PRN_TO_TIN_OR_VICE_VERSE.equals(option) == false) && (OPTION_VALIDATE_AND_GENERATE_CHECK_DIGIT_OF_TIN.equals(option) == false) ) {
			
			// 2.1.1
			pencvtinBean.setRtnCode(RTN_CODE_INVALID_PARAMETER_OR_PRN_OR_TIN);
		}
		
		// 2.2
		else if (OPTION_CONVERT_PRN_TO_TIN_OR_VICE_VERSE.equals(option)) {
			
			pencvtinBean = executeConvertPRNToTINOrViceVerse(pencvtinBean, prn, tin);
		}
		
		// 2.3
		else /* if (OPTION_VALIDATE_AND_GENERATE_CHECK_DIGIT_OF_TIN.equals(option)) */ {
			
			pencvtinBean = executeValidateAndGenerateCheckDigitOfTIN(pencvtinBean, tin);	
		}
		
		return pencvtinBean;
	}

private PencvtinBean executeConvertPRNToTINOrViceVerse(PencvtinBean pencvtinBean, String prn, String tin) {
	
	// 2.2.1
	if ( ((" ".equals(prn)) && (" ".equals(tin)))
			|| ((" ".equals(prn) == false) && (" ".equals(tin)) == false) ) {

		// 2.2.1.1
		pencvtinBean.setRtnCode(RTN_CODE_INVALID_PARAMETER_OR_PRN_OR_TIN);
	}

	// 2.2.2
//	else if (" ".equals(prn) == false) {
//
//		pencvtinBean = executeConvertPRNToTIN(pencvtinBean, prn);
//	}

	// 2.2.3
	else  {

		pencvtinBean = executeConvertTINToPRN(pencvtinBean, tin);
	}
	
	return pencvtinBean;
	
}

//Common method within this class
	private char generateTINCheckDigit(String tin) {
		
		// Appendix 1.3.1
		// (c - 48) to convert from char '0'-'9' to int value
		int totalWeightedSum = (tin.charAt(0) - 48) * TIN_POS_0_WEIGHTING_FACTOR;
		totalWeightedSum += (tin.charAt(1) - 48) * TIN_POS_1_WEIGHTING_FACTOR;
		totalWeightedSum += (tin.charAt(2) - 48) * TIN_POS_2_WEIGHTING_FACTOR;
		totalWeightedSum += (tin.charAt(3) - 48) * TIN_POS_3_WEIGHTING_FACTOR;
		totalWeightedSum += (tin.charAt(4) - 48) * TIN_POS_4_WEIGHTING_FACTOR;
		totalWeightedSum += (tin.charAt(5) - 48) * TIN_POS_5_WEIGHTING_FACTOR;
		totalWeightedSum += (tin.charAt(6) - 48) * TIN_POS_6_WEIGHTING_FACTOR;
		totalWeightedSum += (tin.charAt(7) - 48) * TIN_POS_7_WEIGHTING_FACTOR;
		totalWeightedSum += (tin.charAt(8) - 48) * TIN_POS_8_WEIGHTING_FACTOR;

		// Appendix 1.3.2
		int remainder = totalWeightedSum % 11;

		// Appendix 1.3.3
		if (remainder == 10) {
			return ' ';
		}
		else {
			return Character.forDigit(remainder, 10);
		}

	}
	
	private PencvtinBean executeConvertTINToPRN(PencvtinBean pencvtinBean, String tin) {
		
		// 2.2.3.1
		if (isValidTIN(tin) == false) {

			// 2.2.3.1.1
			pencvtinBean.setRtnCode(RTN_CODE_INVALID_PARAMETER_OR_PRN_OR_TIN);
		}
		
		else {
			
			// 2.2.3.2
			char tinCheckDigit = generateTINCheckDigit(tin);
			
			// 2.2.3.3
			String prn = convertTINToPRN(tin);
			
			// 2.2.3.4
			int validateFormatResult = PrnValidator.validateFormat(prn.trim());
			
			// 2.2.3.5
			if (validateFormatResult == IrdValidConstant.INVALID_PRN) {
				
				//if (logger.isDebugEnabled()) {
				System.out.println("After PrnValidator.validateFormat(...) prn=" + prn + ", validateFormatResult=" + validateFormatResult);
				//}

				// 2.2.3.5.1
				pencvtinBean.setRtnCode(RTN_CODE_INVALID_PARAMETER_OR_PRN_OR_TIN);
			}
			else {
				
				String prnCheckDigit = PrnValidator.generateCheckDigit(prn);
				
				// 2.2.3.6
				pencvtinBean.setPrn(prn + prnCheckDigit);
				
				
				String tinForChecking = (tin.length() < 10) ? (tin + ' ') : tin;

				// 2.2.3.7
				if (tinForChecking.substring(9, 10).equals(String.valueOf(tinCheckDigit)) == false) {
				// if (tin.length() < 10) {
					
					//if (logger.isDebugEnabled()) {
						System.out.println("tin.length=" + tin.length() + ", generate TIN check digit");
					//}
					
					// 2.2.3.7.1
					pencvtinBean.setRtnCode(RTN_CODE_CHECK_DIGIT_OF_TIN_GENERATED);
					pencvtinBean.setTin(tin.substring(0, 9) + tinCheckDigit);
				}
				else {
					
					// 2.2.3.8
					pencvtinBean.setTin(tin);
				}
			}
		}
		
		return pencvtinBean;
	}
	
	// Common method within this class
	private boolean isValidTIN(String tin) {
		
		return VALIDATE_TIN_PATTERN.matcher(tin).matches();
	}
	
	// Common method within this class
	private String convertTINToPRN(String tin) {
		
		// Appendix 2.1
		StringBuffer prn = new StringBuffer(convertTINToPRNComponentA(tin));
		
		//if (logger.isDebugEnabled()) {
			System.out.println("After convertTINToPRNComponentA(...) result=" + prn.toString());
		//}
		
		// Appendix 2.2
		prn.append(convertTINToPRNComponentN(tin));
		
		//if (logger.isDebugEnabled()) {
		System.out.println("After convertTINToPRNComponentB(...) result=" + prn.toString());
		//}
		
		return prn.toString();
	}
	
	private String convertTINToPRNComponentA(String tin) {
		
		StringBuffer reversedTINComponentB = new StringBuffer();
		
		// Appendix 2.1.1
		for (int i = 8; i >= 6; i--) {
			
			reversedTINComponentB.append(tin.charAt(i));
		}
		
		//if (logger.isDebugEnabled()) {
		System.out.println("convertTINToPRNComponentA reversedTINComponentB=" + reversedTINComponentB);
		//}
		
		int reversedTINComponentBValue = Integer.parseInt(reversedTINComponentB.toString()) - 100;
		
		//if (logger.isDebugEnabled()) {
			System.out.println("convertTINToPRNComponentA reversedTINComponentBValue=" + reversedTINComponentBValue);
		//}
		
		// Appendix 2.1.2
		StringBuffer prnComponentA = new StringBuffer();
		
		// First digit of PRN
		int quotient = (reversedTINComponentBValue - 1) / 26;
		if (quotient == 0) {
			prnComponentA.append(' ');
		}
		else {
			// (c + 64) to convert from int value to char 'A'-'Z' 
			prnComponentA.append((char) (quotient + 64));
		}
		
		// Second digit of PRN
		int remainder = ((reversedTINComponentBValue - 1) % 26) + 1; 
		// (c + 64) to convert from int value to char 'A'-'Z' 
		prnComponentA.append((char) (remainder + 64));
		
		return prnComponentA.toString();
	}
	
	private String convertTINToPRNComponentN(String tin) {
		
		StringBuffer prnComponentN = new StringBuffer();
		
		// Appendix 2.2
		// Loop 1st to 6th digits of PRN
		for (int i = 0; i <= 5; i++) {

			char c = tin.charAt(i);

			if (c == '0') {
				prnComponentN.append(CONVERT_TIN_0_TO_PRN);
			}
			else if (c == '1') {
				prnComponentN.append(CONVERT_TIN_1_TO_PRN);
			}
			else if (c == '2') {
				prnComponentN.append(CONVERT_TIN_2_TO_PRN);
			}
			else if (c == '3') {
				prnComponentN.append(CONVERT_TIN_3_TO_PRN);
			}
			else if (c == '4') {
				prnComponentN.append(CONVERT_TIN_4_TO_PRN);
			}
			else if (c == '5') {
				prnComponentN.append(CONVERT_TIN_5_TO_PRN);
			}
			else if (c == '6') {
				prnComponentN.append(CONVERT_TIN_6_TO_PRN);
			}
			else if (c == '7') {
				prnComponentN.append(CONVERT_TIN_7_TO_PRN);
			}
			else if (c == '8') {
				prnComponentN.append(CONVERT_TIN_8_TO_PRN);
			}
			else if (c == '9') {
				prnComponentN.append(CONVERT_TIN_9_TO_PRN);
			}

		}
				
		return prnComponentN.toString();
	}
	
	private PencvtinBean executeValidateAndGenerateCheckDigitOfTIN(PencvtinBean pencvtinBean, String tin) {
		
		// 2.3.1
		if (" ".equals(tin)) {
			
			// 2.3.1.1
			pencvtinBean.setRtnCode(RTN_CODE_INVALID_PARAMETER_OR_PRN_OR_TIN);
		}
		// 2.3.2
		else if (isValidTIN(tin) == false) {
			
			// 2.3.2.1
			pencvtinBean.setRtnCode(RTN_CODE_INVALID_PARAMETER_OR_PRN_OR_TIN);
		}
		else {
			
			char tinCheckDigit = generateTINCheckDigit(tin);

			// 2.3.3
			String prn = convertTINToPRN(tin);

			// 2.3.4
			int validateFormatResult = PrnValidator.validateFormat(prn.trim());

			// 2.3.5
			if (validateFormatResult == IrdValidConstant.INVALID_PRN) {

				//if (logger.isDebugEnabled()) {
				System.out.println("After PrnValidator.validateFormat(...) prn=" + prn + ", validateFormatResult=" + validateFormatResult);
				//}

				pencvtinBean.setRtnCode(RTN_CODE_INVALID_PARAMETER_OR_PRN_OR_TIN);
			}
			else {

				// Set PRN to space
				pencvtinBean.setPrn(" ");
				
				// Create a TIN for check digit checking which its length is always 10
				String tinForChecking = (tin.length() < 10) ? (tin + ' ') : tin; 

				// 2.3.6
				 if (tinForChecking.substring(9, 10).equals(String.valueOf(tinCheckDigit)) == false) {

					//if (logger.isDebugEnabled()) {
					 System.out.println("tin=" + tin + ", input tin check digit='" + tinForChecking.substring(9, 10) + "', expected tin check digit='" + tinCheckDigit + "', change to generated TIN check digit");
					//}

					// 2.3.6.1
					pencvtinBean.setRtnCode(RTN_CODE_CHECK_DIGIT_OF_TIN_GENERATED);
					pencvtinBean.setTin(tin.substring(0, 9) + tinCheckDigit);
				}
				else {
					
					//if (logger.isDebugEnabled()) {
					System.out.println("tin=" + tin + ", input tin check digit='" + tinForChecking.substring(9, 10) + "', expected tin check digit='" + tinCheckDigit + "', keep original TIN check digit");
					//}

					// 2.3.7
					pencvtinBean.setTin(tin);
				}
			}
			
		}
		
		return pencvtinBean;
	}
	
}
