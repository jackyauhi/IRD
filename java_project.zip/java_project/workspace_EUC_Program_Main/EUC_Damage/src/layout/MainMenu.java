package layout;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.border.Border;

public class MainMenu {
	
	JFrame f=new JFrame("EUC barcode scanning");	
    public static void main(String[] args) {
    	
		new MainMenu();
        
    }
     public MainMenu() {
	
    	 //set up path and properties for loading
    	String filePath = "resources/system.properties";
 		Properties prop = new Properties();
 		
 	    //button group
 		JButton exit = new JButton("Exit");
     	
     	JLabel header = new JLabel("Main Menu", SwingConstants.CENTER);
     	JLabel topic = new JLabel("Barcode Sanner" , SwingConstants.CENTER);
        Border border = BorderFactory.createLineBorder(Color.BLACK, 3);
        
        
 		try (InputStream inputStream = MainMenu.class.getClassLoader().getResourceAsStream(filePath)) {
 			
 			// Loading the properties.
 			prop.load(inputStream);
 			
 			String num= prop.getProperty("system.NUM");
			int numOfButton = Integer.parseInt(num);
			
			//Create button numbers from properties
			JButton[] bt= new JButton[numOfButton]; 
 			
 			
 			// Getting properties
 			for (int i = 0; i <numOfButton ; i++){
 				bt[i] = new JButton(prop.getProperty("system.00"+(i+1)));
 				

 				
 						
 			if (i%2 == 0)
 			{
 				//set the position
 				bt[i].setBounds(200,(150 + i*30),95,30);
 			}
 			else
 			{
 				int j=i-1; // set to let the row position equal
 				
 				bt[i].setBounds(380,(150 + j*30),95,30);
 			}
 			//add button to Jframe
 			f.getContentPane().add(bt[i]);
 			
 			bt[i].addActionListener( new ActionListener()
 	        {
 	            public void actionPerformed(ActionEvent e)
 	            {
 	            	
 	            	
 	            	f.dispose();
 	            	try {
 	            		
 	            		switch(e.getActionCommand()){
 	    				case "UPLOAD":
 	    					
 	    				new UploadMenu();
 	            		
 	    				break;
 	    	 	 			
 	    				default:
 	    					//pass button information and open window
						new SystemMenu(e.getActionCommand());
						break;
 	            		}
					} catch (IOException e1) {
						
						System.out.println("Problem occurs when get Action Command!");
						e1.printStackTrace();
						
					}
 	            }
 	        });

 			}			
 			
 		} catch (IOException ex) {
 			
 			System.out.println("Problem occurs when reading file !");
 			ex.printStackTrace();
 		} 
 		
 		 // set the layout and add button to Jframe
         header.setBounds(190,70,300,30);
         header.setFont(new Font("Serif", Font.PLAIN, 30));
         topic.setBounds(90,20,500,40);
         topic.setFont(new Font("Serif", Font.PLAIN, 30));
         topic.setBorder(border);
         
         exit.setBounds(290,500,95,30);
         
         f.getContentPane().add(header);
         f.getContentPane().add(topic);
         f.setBounds(700,200,700,700);
         f.setLocationRelativeTo(null);
         f.getContentPane().add(exit);
         f.getContentPane().setLayout(null);
         f.setVisible(true);  
         exit.addActionListener( new ActionListener()
         {
             public void actionPerformed(ActionEvent e)
             {
             	System.exit(0);
             }
         });
	
	}

    
    
}
