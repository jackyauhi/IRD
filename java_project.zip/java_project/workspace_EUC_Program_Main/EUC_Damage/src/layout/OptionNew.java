package layout;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;

public class OptionNew extends JPanel {


	private static final long serialVersionUID = 2L;
	public JFrame f;
	
   // public static String passTextFieldValue[] = new String[100];
    public static int passNumOfButton;

    
    
	String getTopicValue;
	String getHearderValue;
	String getPropertiesValue;
	
	String notNullText="false";
	String inputSectionTextError="false";
	String inputBatchNoTextError="false";
	String inputBatchSectionTextError="false";
	String inputInputSectionTextError="false";
	String inputDDMMYYTextError="false";
	String inputDDMMYYYYTextError="false";
	String dataExist="true";
	
	
	String labelValue;
	String labelValueTrim;
	
	public OptionMenu optionMenu;
	public OptionNew optionNew;
	public OptionScan optionScan;
	public JFrame jframe;
	
	List<String> timerScanData;
	String passOptionNewTextFieldValue[][];
	int marks[];
	int headerno;
	JTextField[] field;
	int ValidatelengthInt[];
	String ValidateFormat[];
	int numOfButton;
	String RecCount;
	String status;

	
	public OptionNew(JFrame jframe,OptionMenu optionMenu,List timerScanData,String passOptionNewTextFieldValue[][], int headerno,int marks[],String status) {
		this.jframe = jframe;
		this.optionMenu = optionMenu;
		optionNew=this;
		this.timerScanData=timerScanData;
		this.passOptionNewTextFieldValue=passOptionNewTextFieldValue;
		this.headerno=headerno;
		this.marks=marks;
		this.status=status;

		
		//get the value from class String
		getTopicValue = SystemMenu.passTopicValue;
		getHearderValue = OptionMenu.passHeaderValue;
		
			

  }
	
	public void draw(){
		//get the value to define different button click action
		getPropertiesValue =getTopicValue.replaceAll("\\s","")+getHearderValue.replaceAll("\\s","");
		

		
		inputSectionTextError="false";
		inputBatchNoTextError="false";
		inputBatchSectionTextError="false";
		inputInputSectionTextError="false";
		inputDDMMYYTextError="false";
		inputDDMMYYYYTextError="false";
		notNullText="false";
		
		
		
	    String filePath = "resources/allOptionJava.properties";
		Properties prop = new Properties();
		try (InputStream inputStream = MainMenu.class.getClassLoader().getResourceAsStream(filePath)) {
			
			//Loading the properties.
	     	prop.load(inputStream);	
			

			
			String num= prop.getProperty(getPropertiesValue+".NUM");
			numOfButton = Integer.parseInt(num);
			passNumOfButton=numOfButton;
			
			//Create button numbers from properties
			JLabel[] label= new JLabel[numOfButton];
			field = new JTextField[numOfButton];
			
			
			//set layout and button group
			f=jframe;
			JLabel topic = new JLabel(getTopicValue+" Menu" , SwingConstants.CENTER);
			Border border = BorderFactory.createLineBorder(Color.BLACK, 3);
			JLabel header = new JLabel(getHearderValue, SwingConstants.CENTER);
			Border headerborder = BorderFactory.createLineBorder(Color.BLACK, 2);
			header.setBounds(150,70,400,30);
			header.setFont(new Font("Serif", Font.PLAIN, 15));
			header.setBorder(headerborder);
			topic.setBounds(90,20,500,40);
			topic.setFont(new Font("Serif", Font.PLAIN, 30));
			topic.setBorder(border);
			JButton back = new JButton("Back");	
			JButton startToScan = new JButton("Start to Scan");
			add(header);
	        add(topic);
	        setBounds(700,200,700,700);
	        setLayout(null);
	        setVisible(true);
	        add(back);
	        add(startToScan);
	        startToScan.setBounds(250,450,180,30);
	        back.setBounds(250,500,180,30);
			JButton newheader = new JButton("Newheader");
			if (getPropertiesValue.equals("CTRNoteReceiptCTRAdviceLetter")||getPropertiesValue.equals("PFNoteReceiptPFReturn(BIR51/BIR52)")){
				add(newheader);
				//newheader.setBounds(0,550,116,30);
				newheader.setBounds(250,550,180,30);
			}
	        
	        //use to validate input value
	    	ValidateFormat=new String[numOfButton];
	    	String Validatelength[]=new String[numOfButton];
	    	ValidatelengthInt=new int[numOfButton];
	    	

	    	//get properties value
	        for (int i = 0; i <numOfButton; i++){
	        	ValidateFormat[i]= new String(prop.getProperty(getPropertiesValue+".ValidateFormat"+(i+1)));
				Validatelength[i]= new String(prop.getProperty(getPropertiesValue+".ValidateLength"+(i+1)));
				ValidatelengthInt[i]= Integer.parseInt(Validatelength[i]);
	        }
        	status = null;
	        for (int i = 0; i <numOfButton; i++){
	        label[i] = new JLabel(prop.getProperty(getPropertiesValue+".00"+(i+1)));
	        label[i].setBounds(200,(130 + i*30),96,21);
	        labelValue= new String(prop.getProperty(getPropertiesValue+".00"+(i+1)));
	        labelValueTrim=labelValue.replaceAll("\\s","");

	        add(label[i]);
	        field[i] = new JTextField();
	        field[i].setBounds(350, (130+ i*30), 96, 21);
	        
	        add(field[i]);
	        
	        //set the value of JTextField
	        switch(labelValueTrim){
			case "BatchID:":
				field[i].setText("BATCH");
				field[i].setEditable(false);
				passOptionNewTextFieldValue[i][headerno - 1]=field[i].getText();
        	break;
        	
			case "SectionID:":
				field[i].setText("##");
				field[i].setEditable(false);
				passOptionNewTextFieldValue[i][headerno - 1]=field[i].getText();
			break;
			
			case "Filler:":
				field[i].setText("      ");
				field[i].setEditable(false);
				passOptionNewTextFieldValue[i][headerno - 1]=field[i].getText();
        	break;
        	
			case "REC-COUNT":

				
				int size = timerScanData.size();
				String count=Integer.toString(size);
				while(count.length()!=5){
					count="0"+count;
				}
				field[i].setText(count);
				field[i].setEditable(false);
				passOptionNewTextFieldValue[i][headerno - 1]=field[i].getText();
				
        	break;
        	
			case "BatchDate:":
				if(SystemMenu.checkERBatchDateEmpty == "true"){
					SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
					Date now = new Date();
					String strDate = sdf.format(now);
		        
		        
					field[i].setText(strDate);
					field[i].setEditable(false);
					passOptionNewTextFieldValue[i][headerno - 1]=field[i].getText();
				}
				else{
					field[i].setText(passOptionNewTextFieldValue[i][headerno - 1]);
					field[i].setEditable(false);
				}
				
        	break;
        	
			default:
				
		        if (marks[headerno -1] != 0){
		        	field[i].setText(passOptionNewTextFieldValue[i][headerno - 1]);
		        }
		        else{
				field[i].setText("");
		        	//field[i].setText(passOptionNewTextFieldValue[i][headerno - 1]);
		        }
	        break;

	        }
	                
	    }

	        
	        //set action
	        back.addActionListener( new ActionListener()
		    {
		        public void actionPerformed(ActionEvent e)
		        {
		        	if(timerScanData.size()<SystemMenu.Recordlimited){
		        	SystemMenu.checkLogData.add("Click in "+ getPropertiesValue +" (OptionNew) (Back) button");
		        	//SystemMenu.checkLogData.add("timerScanData value = " + timerScanData);
		        	}

		        	f.setVisible(false);
		        	f.getContentPane().removeAll();
		        	optionMenu = new OptionMenu(f,getHearderValue, timerScanData,passOptionNewTextFieldValue, headerno,marks,null);
		        	optionMenu.draw();	        	
		        	f.setContentPane(optionMenu);
		        	Dimension preferredSize = new Dimension(700,700);
		        	f.setPreferredSize(preferredSize);
		        	f.setBounds(700,200,700,700);
		        	f.setLocationRelativeTo(null);
		        	SwingUtilities.updateComponentTreeUI(f);
		        	f.pack();
		        	f.setVisible(true);
		        	f.invalidate();
		        	f.validate();
		        	f.repaint();
		        }
		    }); 
	        startToScan.addActionListener( new ActionListener()
		    {
		        public void actionPerformed(ActionEvent e)
		        {
		        	if(timerScanData.size()<SystemMenu.Recordlimited){
		        	SystemMenu.checkLogData.add("Click in "+ getPropertiesValue +" (OptionNew) (Start To Scan) button");
		        	}
		        	
		        	//check JTextField input value null or not
		        	for (int i = 0; i <numOfButton ; i++){
		        		switch(field[i].getText()){
	    				case "":
	    				notNullText="true";
	                	break;
		        		}

		        	}
		        	
		        	if(notNullText=="true"){
		        		JOptionPane optionPane2 = new JOptionPane("Please fill all the information in the blank", JOptionPane.ERROR_MESSAGE);    
		        		JDialog dialog2 = optionPane2.createDialog("Failure");
		        		dialog2.setAlwaysOnTop(true);
		        		dialog2.setVisible(true); 
		        		inputSectionTextError="true";
		        	}
		        	else{
		        	//check JTextField input value correct or not
						for (int i = 0; i <numOfButton ; i++){
							switch(ValidateFormat[i]){
		    				case "Section":
		    					String inputSection = field[i].getText();
		    					// use to Validate value
		    				    String inputSectionValidate = inputSection.replaceAll("[^a-zA-Z0-9]+", "");
		    				    // compare the input length and property length 
		    					if(inputSectionValidate.length()!=ValidatelengthInt[i]){
		    						JOptionPane optionPane2 = new JOptionPane("The Section input is not correct. Please input again", JOptionPane.ERROR_MESSAGE);    
		    		        		JDialog dialog2 = optionPane2.createDialog("Failure");
		    		        		dialog2.setAlwaysOnTop(true);
		    		        		dialog2.setVisible(true); 
		    		        		inputSectionTextError="true";
		    						
		    					}
		    					else if(inputSection.length()!=ValidatelengthInt[i]){
		    						JOptionPane optionPane2 = new JOptionPane("The Section input is not correct. Please input again", JOptionPane.ERROR_MESSAGE);    
		    		        		JDialog dialog2 = optionPane2.createDialog("Failure");
		    		        		dialog2.setAlwaysOnTop(true);
		    		        		dialog2.setVisible(true); 
		    		        		inputSectionTextError="true";
		    					}
		    					else if(inputSectionValidate.length()==ValidatelengthInt[i]){
		    						String inputOnlyInterger=inputSection.substring(0,1).replaceAll("[^0-9]+", "");
		    						String inputOnlyInterger2=inputSection.substring(2,3).replaceAll("[^0-9]+", "");
		    						if(inputOnlyInterger.length()!=1||inputOnlyInterger2.length()!=1){
		    								JOptionPane optionPane2 = new JOptionPane("The Section input is not correct. Please input again", JOptionPane.ERROR_MESSAGE);    
		    								JDialog dialog2 = optionPane2.createDialog("Failure");
		    								dialog2.setAlwaysOnTop(true);
		    								dialog2.setVisible(true);
		    								inputSectionTextError="true";
				    				 	}	
		    					}
		    					else {	 
		    						inputSectionTextError="false";

		    					}
		    					break; 
		                	
		    				case "BatchNo":
		    					String inputBatchNo = field[i].getText();
		    					String inputBatchNoValidate = inputBatchNo.replaceAll("[^0-9]+", "");
				    			if(inputBatchNoValidate.length() != ValidatelengthInt[i]){
				    					JOptionPane optionPane2 = new JOptionPane("The Batch No input is not correct. Please input again", JOptionPane.ERROR_MESSAGE);    
					    		        JDialog dialog2 = optionPane2.createDialog("Failure");
					    		        dialog2.setAlwaysOnTop(true);
					    		        dialog2.setVisible(true);
					    		        inputBatchNoTextError="true";
				    				}
		    					else if(inputBatchNo.length()!=ValidatelengthInt[i]){
		    						JOptionPane optionPane2 = new JOptionPane("The Batch No input is not correct. Please input again", JOptionPane.ERROR_MESSAGE);    
		    		        		JDialog dialog2 = optionPane2.createDialog("Failure");
		    		        		dialog2.setAlwaysOnTop(true);
		    		        		dialog2.setVisible(true); 
		    		        		inputBatchNoTextError="true";
		    					}

		    					else{
		    						inputBatchNoTextError="false";
		    					}
		    					break;
		    					
		    				case "BatchSection":
		    					String inputBatchSection = field[i].getText();
		    					String inputBatchSectionValidate = inputBatchSection.replaceAll("[^a-zA-Z0-9]+", "");
				    			if(inputBatchSectionValidate.length()!=ValidatelengthInt[i]){
				    					JOptionPane optionPane2 = new JOptionPane("The Batch Section input is not correct. Please input again", JOptionPane.ERROR_MESSAGE);    
					    		        JDialog dialog2 = optionPane2.createDialog("Failure");
					    		        dialog2.setAlwaysOnTop(true);
					    		        dialog2.setVisible(true);
					    		        inputBatchSectionTextError="true";
				    				}
		    					else if(inputBatchSection.length()!=ValidatelengthInt[i]){
		    						JOptionPane optionPane2 = new JOptionPane("The Batch Section input is not correct. Please input again", JOptionPane.ERROR_MESSAGE);    
		    		        		JDialog dialog2 = optionPane2.createDialog("Failure");
		    		        		dialog2.setAlwaysOnTop(true);
		    		        		dialog2.setVisible(true); 
		    		        		inputBatchSectionTextError="true";
		    					}
		    					else{
		    						inputBatchSectionTextError="false";
		    					}
		    					break;
		    					
		    				case "InputSection":
		    					String inputInputSection = field[i].getText();
		    					String inputInputSectionValidate = inputInputSection.replaceAll("[^a-zA-Z0-9]+", "");
				    			if(inputInputSectionValidate.length()!=ValidatelengthInt[i]){
				    					JOptionPane optionPane2 = new JOptionPane("The Input Section input is not correct. Please input again", JOptionPane.ERROR_MESSAGE);    
					    		        JDialog dialog2 = optionPane2.createDialog("Failure");
					    		        dialog2.setAlwaysOnTop(true);
					    		        dialog2.setVisible(true);
					    		        inputInputSectionTextError="true";
				    				}
		    					else if(inputInputSection.length()!=ValidatelengthInt[i]){
		    						JOptionPane optionPane2 = new JOptionPane("The Input Section input is not correct. Please input again", JOptionPane.ERROR_MESSAGE);    
		    		        		JDialog dialog2 = optionPane2.createDialog("Failure");
		    		        		dialog2.setAlwaysOnTop(true);
		    		        		dialog2.setVisible(true); 
		    		        		inputInputSectionTextError="true";
		    					}
		    					else{
		    						inputInputSectionTextError="false";
		    					}
		    					break;	
		    					
		    				case "DDMMYY":
		    					String inputDDMMYY = field[i].getText();
		    					String inputDDMMYYValidate = inputDDMMYY.replaceAll("[^0-9]+", "");
		    					if(inputDDMMYYValidate.length()!=ValidatelengthInt[i]){
			    					JOptionPane optionPane2 = new JOptionPane("The Date input is not correct. Please input again", JOptionPane.ERROR_MESSAGE);    
				    		        JDialog dialog2 = optionPane2.createDialog("Failure");
				    		        dialog2.setAlwaysOnTop(true);
				    		        dialog2.setVisible(true);
				    		        inputDDMMYYTextError="true";
			    				}
		    					else if(inputDDMMYY.length()!=ValidatelengthInt[i]){
	    						JOptionPane optionPane2 = new JOptionPane("The Date input is not correct. Please input again", JOptionPane.ERROR_MESSAGE);    
	    		        		JDialog dialog2 = optionPane2.createDialog("Failure");
	    		        		dialog2.setAlwaysOnTop(true);
	    		        		dialog2.setVisible(true); 
	    		        		inputDDMMYYTextError="true";
		    					}
		    					else{
	    						
		    					
		    					SimpleDateFormat DDMMYYformat = new SimpleDateFormat("ddMMyy");
		    					DDMMYYformat.setLenient(false);
		    					Date InputDate = null;
		    					Date TodayDate = null;
		    					
								try {
									//Validate input date value
									DDMMYYformat.parse(field[i].getText());
									String requireDate=field[i].getText();
									String Today = new SimpleDateFormat("ddMMyy").format(Calendar.getInstance().getTime());
									InputDate = DDMMYYformat.parse(requireDate);
									TodayDate= DDMMYYformat.parse(Today);

									if(InputDate.after(TodayDate)){
										JOptionPane optionPane2 = new JOptionPane("The Date input is future date. Please input again", JOptionPane.ERROR_MESSAGE);    
			    		        		JDialog dialog2 = optionPane2.createDialog("Failure");
			    		        		dialog2.setAlwaysOnTop(true);
			    		        		dialog2.setVisible(true);
							            inputDDMMYYTextError="true";
							        }

								} catch (ParseException e1) {
									e1.printStackTrace();
									JOptionPane optionPane2 = new JOptionPane("The Date input is not correct. Please input again", JOptionPane.ERROR_MESSAGE);    
		    		        		JDialog dialog2 = optionPane2.createDialog("Failure");
		    		        		dialog2.setAlwaysOnTop(true);
		    		        		dialog2.setVisible(true);
		    		        		inputDDMMYYTextError="true";
								}
		    					}
								
								break;
								
		    				case "DDMMYYYY":
		    					String inputDDMMYYYY = field[i].getText();
		    					String inputDDMMYYYYValidate = inputDDMMYYYY.replaceAll("[^0-9]+", "");
		    					if(inputDDMMYYYYValidate.length()!=ValidatelengthInt[i]){
			    					JOptionPane optionPane2 = new JOptionPane("The Date input is not correct. Please input again", JOptionPane.ERROR_MESSAGE);    
				    		        JDialog dialog2 = optionPane2.createDialog("Failure");
				    		        dialog2.setAlwaysOnTop(true);
				    		        dialog2.setVisible(true);
				    		        inputDDMMYYYYTextError="true";
			    				}
		    					else if(inputDDMMYYYY.length()!=ValidatelengthInt[i]){
		    						JOptionPane optionPane2 = new JOptionPane("The Date input is not correct. Please input again", JOptionPane.ERROR_MESSAGE);    
		    						JDialog dialog2 = optionPane2.createDialog("Failure");
		    						dialog2.setAlwaysOnTop(true);
		    						dialog2.setVisible(true); 
		    						inputDDMMYYYYTextError="true";
		    					}
		    					else{
		    						SimpleDateFormat DDMMYYYYformat = new SimpleDateFormat("ddMMyyyy");
		    						DDMMYYYYformat.setLenient(false);
		    						Date InputDate = null;
			    					Date TodayDate = null;
									try {
										DDMMYYYYformat.parse(field[i].getText());
										String requireDate=field[i].getText();
										String Today = new SimpleDateFormat("ddMMyyyy").format(Calendar.getInstance().getTime());
										InputDate = DDMMYYYYformat.parse(requireDate);
										TodayDate= DDMMYYYYformat.parse(Today);

										if(InputDate.after(TodayDate)){
											JOptionPane optionPane2 = new JOptionPane("The Date input is future date. Please input again", JOptionPane.ERROR_MESSAGE);    
				    		        		JDialog dialog2 = optionPane2.createDialog("Failure");
				    		        		dialog2.setAlwaysOnTop(true);
				    		        		dialog2.setVisible(true);
								            inputDDMMYYTextError="true";
								        }
									} catch (ParseException e1) {
										e1.printStackTrace();
										JOptionPane optionPane2 = new JOptionPane("The Date input is not correct. Please input again", JOptionPane.ERROR_MESSAGE);    
										JDialog dialog2 = optionPane2.createDialog("Failure");
										dialog2.setAlwaysOnTop(true);
										dialog2.setVisible(true);
										inputDDMMYYYYTextError="true";
									}
		    					}
								break;

		    				default:

		                	break;
								}
						}
		        	}
						// checking the input value not have error
		if(inputSectionTextError=="false"&& inputBatchNoTextError=="false" && inputBatchSectionTextError=="false" && 
		inputInputSectionTextError=="false" && inputDDMMYYTextError=="false" && inputDDMMYYYYTextError=="false" && notNullText=="false"){
													for (int i = 0; i <numOfButton ; i++){
														passOptionNewTextFieldValue[i][headerno - 1]=field[i].getText();
													}
													//open another window
													f.setVisible(false);
													f.getContentPane().removeAll();
													if (optionScan==null)
													{	        		
														optionScan = new OptionScan(f,optionNew, timerScanData,passOptionNewTextFieldValue, headerno,marks);
													}
													optionScan.draw();
													f.setContentPane(optionScan);
													Dimension preferredSize = new Dimension(700,700);
													f.setPreferredSize(preferredSize);
													f.setBounds(700,200,700,700);
													f.setLocationRelativeTo(null);
													SwingUtilities.updateComponentTreeUI(f);
													f.pack();
													f.setVisible(true);
													f.invalidate();
													f.validate();
													f.repaint();
			        	
										}
						else{
							// to update the frame and do it again
							for (int i = 0; i <numOfButton ; i++){
								passOptionNewTextFieldValue[i][headerno - 1]=field[i].getText();
							}
							//open this window
							f.setVisible(false);
							f.getContentPane().removeAll();
							optionNew.draw();
							f.setContentPane(optionNew);
							Dimension preferredSize = new Dimension(700,700);
							f.setPreferredSize(preferredSize);
							f.setBounds(700,200,700,700);
							f.setLocationRelativeTo(null);
							SwingUtilities.updateComponentTreeUI(f);
							f.pack();
							f.setVisible(true);
							f.invalidate();
							f.validate();
							f.repaint();
						}
										

		        	
		        }
		    }); 
			newheader.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
		        	//check JTextField input value null or not
					if(timerScanData.size()<SystemMenu.Recordlimited){
					SystemMenu.checkLogData.add("Click in "+ getPropertiesValue +" (OptionNew) (New header) button");
					//SystemMenu.checkLogData.add("timerScanData value = " + timerScanData);
					}
					if (marks[headerno-1]==0){
		        		JOptionPane optionPane2 = new JOptionPane("No any Scan Record Find In this Batch/Header ", JOptionPane.ERROR_MESSAGE);    
		        		JDialog dialog2 = optionPane2.createDialog("Failure");
		        		dialog2.setAlwaysOnTop(true);
		        		dialog2.setVisible(true); 
					}
					else{

		        	for (int i = 0; i <numOfButton ; i++){
		        		switch(field[i].getText()){
	    				case "":
	    				notNullText="true";
	                	break;
		        		}

		        	}
		        	
		        	if(notNullText=="true"){
		        		JOptionPane optionPane2 = new JOptionPane("Please fill all the information in the blank", JOptionPane.ERROR_MESSAGE);    
		        		JDialog dialog2 = optionPane2.createDialog("Failure");
		        		dialog2.setAlwaysOnTop(true);
		        		dialog2.setVisible(true); 
		        		inputSectionTextError="true";
		        	}
		        	else{
		        	//check JTextField input value correct or not
						for (int i = 0; i <numOfButton ; i++){
							switch(ValidateFormat[i]){
		    				case "Section":
		    					String inputSection = field[i].getText();
		    					// use to Validate value
		    				    String inputSectionValidate = inputSection.replaceAll("[^a-zA-Z0-9]+", "");
		    				    // compare the input length and property length 
		    					if(inputSectionValidate.length()!=ValidatelengthInt[i]){
		    						JOptionPane optionPane2 = new JOptionPane("The Section input is not correct. Please input again", JOptionPane.ERROR_MESSAGE);    
		    		        		JDialog dialog2 = optionPane2.createDialog("Failure");
		    		        		dialog2.setAlwaysOnTop(true);
		    		        		dialog2.setVisible(true); 
		    		        		inputSectionTextError="true";
		    						
		    					}
		    					else if(inputSection.length()!=ValidatelengthInt[i]){
		    						JOptionPane optionPane2 = new JOptionPane("The Section input is not correct. Please input again", JOptionPane.ERROR_MESSAGE);    
		    		        		JDialog dialog2 = optionPane2.createDialog("Failure");
		    		        		dialog2.setAlwaysOnTop(true);
		    		        		dialog2.setVisible(true); 
		    		        		inputSectionTextError="true";
		    					}
		    					else if(inputSectionValidate.length()==ValidatelengthInt[i]){
		    						String inputOnlyInterger=inputSection.substring(0,1).replaceAll("[^0-9]+", "");
		    						String inputOnlyInterger2=inputSection.substring(2,3).replaceAll("[^0-9]+", "");
		    						if(inputOnlyInterger.length()!=1||inputOnlyInterger2.length()!=1){
		    								JOptionPane optionPane2 = new JOptionPane("The Section input is not correct. Please input again", JOptionPane.ERROR_MESSAGE);    
		    								JDialog dialog2 = optionPane2.createDialog("Failure");
		    								dialog2.setAlwaysOnTop(true);
		    								dialog2.setVisible(true);
		    								inputSectionTextError="true";
				    				 	}	
		    					}
		    					else {	 
		    						inputSectionTextError="false";

		    					}
		    					break; 
		                	
		    				case "BatchNo":
		    					String inputBatchNo = field[i].getText();
		    					String inputBatchNoValidate = inputBatchNo.replaceAll("[^0-9]+", "");
				    			if(inputBatchNoValidate.length() != ValidatelengthInt[i]){
				    					JOptionPane optionPane2 = new JOptionPane("The Batch No input is not correct. Please input again", JOptionPane.ERROR_MESSAGE);    
					    		        JDialog dialog2 = optionPane2.createDialog("Failure");
					    		        dialog2.setAlwaysOnTop(true);
					    		        dialog2.setVisible(true);
					    		        inputBatchNoTextError="true";
				    				}
		    					else if(inputBatchNo.length()!=ValidatelengthInt[i]){
		    						JOptionPane optionPane2 = new JOptionPane("The Batch No input is not correct. Please input again", JOptionPane.ERROR_MESSAGE);    
		    		        		JDialog dialog2 = optionPane2.createDialog("Failure");
		    		        		dialog2.setAlwaysOnTop(true);
		    		        		dialog2.setVisible(true); 
		    		        		inputBatchNoTextError="true";
		    					}

		    					else{
		    						inputBatchNoTextError="false";
		    					}
		    					break;
		    					
		    				case "BatchSection":
		    					String inputBatchSection = field[i].getText();
		    					String inputBatchSectionValidate = inputBatchSection.replaceAll("[^a-zA-Z0-9]+", "");
				    			if(inputBatchSectionValidate.length()!=ValidatelengthInt[i]){
				    					JOptionPane optionPane2 = new JOptionPane("The Batch Section input is not correct. Please input again", JOptionPane.ERROR_MESSAGE);    
					    		        JDialog dialog2 = optionPane2.createDialog("Failure");
					    		        dialog2.setAlwaysOnTop(true);
					    		        dialog2.setVisible(true);
					    		        inputBatchSectionTextError="true";
				    				}
		    					else if(inputBatchSection.length()!=ValidatelengthInt[i]){
		    						JOptionPane optionPane2 = new JOptionPane("The Batch Section input is not correct. Please input again", JOptionPane.ERROR_MESSAGE);    
		    		        		JDialog dialog2 = optionPane2.createDialog("Failure");
		    		        		dialog2.setAlwaysOnTop(true);
		    		        		dialog2.setVisible(true); 
		    		        		inputBatchSectionTextError="true";
		    					}
		    					else{
		    						inputBatchSectionTextError="false";
		    					}
		    					break;
		    					
		    				case "InputSection":
		    					String inputInputSection = field[i].getText();
		    					String inputInputSectionValidate = inputInputSection.replaceAll("[^a-zA-Z0-9]+", "");
				    			if(inputInputSectionValidate.length()!=ValidatelengthInt[i]){
				    					JOptionPane optionPane2 = new JOptionPane("The Input Section input is not correct. Please input again", JOptionPane.ERROR_MESSAGE);    
					    		        JDialog dialog2 = optionPane2.createDialog("Failure");
					    		        dialog2.setAlwaysOnTop(true);
					    		        dialog2.setVisible(true);
					    		        inputInputSectionTextError="true";
				    				}
		    					else if(inputInputSection.length()!=ValidatelengthInt[i]){
		    						JOptionPane optionPane2 = new JOptionPane("The Input Section input is not correct. Please input again", JOptionPane.ERROR_MESSAGE);    
		    		        		JDialog dialog2 = optionPane2.createDialog("Failure");
		    		        		dialog2.setAlwaysOnTop(true);
		    		        		dialog2.setVisible(true); 
		    		        		inputInputSectionTextError="true";
		    					}
		    					else{
		    						inputInputSectionTextError="false";
		    					}
		    					break;	
		    					
		    				case "DDMMYY":
		    					String inputDDMMYY = field[i].getText();
		    					String inputDDMMYYValidate = inputDDMMYY.replaceAll("[^0-9]+", "");
		    					if(inputDDMMYYValidate.length()!=ValidatelengthInt[i]){
			    					JOptionPane optionPane2 = new JOptionPane("The Date input is not correct. Please input again", JOptionPane.ERROR_MESSAGE);    
				    		        JDialog dialog2 = optionPane2.createDialog("Failure");
				    		        dialog2.setAlwaysOnTop(true);
				    		        dialog2.setVisible(true);
				    		        inputDDMMYYTextError="true";
			    				}
		    					else if(inputDDMMYY.length()!=ValidatelengthInt[i]){
	    						JOptionPane optionPane2 = new JOptionPane("The Date input is not correct. Please input again", JOptionPane.ERROR_MESSAGE);    
	    		        		JDialog dialog2 = optionPane2.createDialog("Failure");
	    		        		dialog2.setAlwaysOnTop(true);
	    		        		dialog2.setVisible(true); 
	    		        		inputDDMMYYTextError="true";
		    					}
		    					else{
	    						
		    					
		    					SimpleDateFormat DDMMYYformat = new SimpleDateFormat("ddMMyy");
		    					DDMMYYformat.setLenient(false);
	    						Date InputDate = null;
		    					Date TodayDate = null;
								try {
									//Validate input date value
									DDMMYYformat.parse(field[i].getText());
									String requireDate=field[i].getText();
									String Today = new SimpleDateFormat("ddMMyy").format(Calendar.getInstance().getTime());
									InputDate = DDMMYYformat.parse(requireDate);
									TodayDate= DDMMYYformat.parse(Today);

									if(InputDate.after(TodayDate)){
										JOptionPane optionPane2 = new JOptionPane("The Date input is future date. Please input again", JOptionPane.ERROR_MESSAGE);    
			    		        		JDialog dialog2 = optionPane2.createDialog("Failure");
			    		        		dialog2.setAlwaysOnTop(true);
			    		        		dialog2.setVisible(true);
							            inputDDMMYYTextError="true";
							        }
								} catch (ParseException e1) {
									e1.printStackTrace();
									JOptionPane optionPane2 = new JOptionPane("The Date input is not correct. Please input again", JOptionPane.ERROR_MESSAGE);    
		    		        		JDialog dialog2 = optionPane2.createDialog("Failure");
		    		        		dialog2.setAlwaysOnTop(true);
		    		        		dialog2.setVisible(true);
		    		        		inputDDMMYYTextError="true";
								}
		    					}
								
								break;
								
		    				case "DDMMYYYY":
		    					String inputDDMMYYYY = field[i].getText();
		    					String inputDDMMYYYYValidate = inputDDMMYYYY.replaceAll("[^0-9]+", "");
		    					if(inputDDMMYYYYValidate.length()!=ValidatelengthInt[i]){
			    					JOptionPane optionPane2 = new JOptionPane("The Date input is not correct. Please input again", JOptionPane.ERROR_MESSAGE);    
				    		        JDialog dialog2 = optionPane2.createDialog("Failure");
				    		        dialog2.setAlwaysOnTop(true);
				    		        dialog2.setVisible(true);
				    		        inputDDMMYYYYTextError="true";
			    				}
		    					else if(inputDDMMYYYY.length()!=ValidatelengthInt[i]){
		    						JOptionPane optionPane2 = new JOptionPane("The Date input is not correct. Please input again", JOptionPane.ERROR_MESSAGE);    
		    						JDialog dialog2 = optionPane2.createDialog("Failure");
		    						dialog2.setAlwaysOnTop(true);
		    						dialog2.setVisible(true); 
		    						inputDDMMYYYYTextError="true";
		    					}
		    					else{
		    						SimpleDateFormat DDMMYYYYformat = new SimpleDateFormat("ddMMyyyy");
		    						DDMMYYYYformat.setLenient(false);
		    						Date InputDate = null;
			    					Date TodayDate = null;
									try {
										//Validate input date value
										DDMMYYYYformat.parse(field[i].getText());
										String requireDate=field[i].getText();
										String Today = new SimpleDateFormat("ddMMyyyy").format(Calendar.getInstance().getTime());
										InputDate = DDMMYYYYformat.parse(requireDate);
										TodayDate= DDMMYYYYformat.parse(Today);

										if(InputDate.after(TodayDate)){
											JOptionPane optionPane2 = new JOptionPane("The Date input is future date. Please input again", JOptionPane.ERROR_MESSAGE);    
				    		        		JDialog dialog2 = optionPane2.createDialog("Failure");
				    		        		dialog2.setAlwaysOnTop(true);
				    		        		dialog2.setVisible(true);
								            inputDDMMYYTextError="true";
								        }
									} catch (ParseException e1) {
										e1.printStackTrace();
										JOptionPane optionPane2 = new JOptionPane("The Date input is not correct. Please input again", JOptionPane.ERROR_MESSAGE);    
										JDialog dialog2 = optionPane2.createDialog("Failure");
										dialog2.setAlwaysOnTop(true);
										dialog2.setVisible(true);
										inputDDMMYYYYTextError="true";
									}
		    					}
								break;

		    				default:

		                	break;
								}
						}
		        	}
						// checking the input value not have error
		if(inputSectionTextError=="false"&& inputBatchNoTextError=="false" && inputBatchSectionTextError=="false" && 
		inputInputSectionTextError=="false" && inputDDMMYYTextError=="false" && inputDDMMYYYYTextError=="false" && notNullText=="false"){
													for (int i = 0; i <numOfButton ; i++){
														passOptionNewTextFieldValue[i][headerno - 1]=field[i].getText();
													}
													//open another window
													headerno++;
													String status = "new";
													f.setVisible(false);
													optionNew = new OptionNew(f, optionMenu, timerScanData,passOptionNewTextFieldValue, headerno, marks,status);
													f.getContentPane().removeAll();
													optionNew.draw();
													f.setContentPane(optionNew);
													Dimension preferredSize = new Dimension(700, 700);
													f.setPreferredSize(preferredSize);
													f.setBounds(700, 200, 700, 700);
													f.setLocationRelativeTo(null);
													SwingUtilities.updateComponentTreeUI(f);
													f.pack();
													f.setVisible(true);
													f.invalidate();
													f.validate();
													f.repaint();
			        	
										}
						else{
							// to update the frame and do it again
							for (int i = 0; i <numOfButton ; i++){
								passOptionNewTextFieldValue[i][headerno - 1]=field[i].getText();
							}
							//open this window
							f.setVisible(false);
							f.getContentPane().removeAll();
							optionNew.draw();
							f.setContentPane(optionNew);
							Dimension preferredSize = new Dimension(700,700);
							f.setPreferredSize(preferredSize);
							f.setBounds(700,200,700,700);
							f.setLocationRelativeTo(null);
							SwingUtilities.updateComponentTreeUI(f);
							f.pack();
							f.setVisible(true);
							f.invalidate();
							f.validate();
							f.repaint();
						}
					}
				}
			});
            
	        
		}
		catch (IOException ex) {
				
				System.out.println("Problem occurs when reading file !");
				ex.printStackTrace();
			} 		
	}
}
