package layout;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Properties;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;
import javax.swing.table.TableColumn;

public class OptionVerify extends JPanel {
	
	String checklabelhighlight = "false";
	public OptionVerify OptionVerify;
	public OptionScan optionScan;
	public OptionMenu optionMenu;
	public OptionNew  optionNew;
	public JFrame f;
	public JFrame jframe;
	public Report report;
	JScrollPane scrollpane;
	String getTopicValue;
	String getHearderValue;
	int getNumOfButton;
	String getPropertiesValue;
	List<String> timerScanData;
	String passOptionNewTextFieldValue[][];
	int marks[];
	int headerno;
	int tempheaderno;
	JRadioButton[] radioButton;
	JTable table = null;
	String storeSplitTimerScanData[];
	String storeTinChangeToPrnData[];
	static ArrayList<String> routedClients = new ArrayList<String>();
	List<String> SaveTinChangeToPrnData = new ArrayList<String>();
	private boolean isBigData = false;
	String buttonNum;
	int ButtonNumber;
	Properties prop;
	/**
	 * Create the frame.
	 */
	public OptionVerify(JFrame jframe, OptionScan optionScan,
			List timerScanData, String passOptionNewTextFieldValue[][], int headerno, int marks[]) {
		this.optionScan = optionScan;
		this.OptionVerify = this;
		this.jframe = jframe;
		this.timerScanData = timerScanData;
		this.passOptionNewTextFieldValue = passOptionNewTextFieldValue;
		this.headerno = headerno;
		this.marks=marks;
		tempheaderno = headerno;
		// get and pass the value from class String
		getTopicValue = SystemMenu.passTopicValue;
		getHearderValue = OptionMenu.passHeaderValue;
		getNumOfButton = OptionNew.passNumOfButton;
	}

	/**
	 * Launch the application.
	 */
	public void draw() {
		checklabelhighlight = "false";
		if(timerScanData.size()<SystemMenu.Recordlimited){
		System.out.println("SystemMenu.SaveTinChangeToPrnData.size() value = " + SystemMenu.SaveTinChangeToPrnData.size());
		System.out.println("SystemMenu.SaveTinChangeToPrnData value = " + SystemMenu.SaveTinChangeToPrnData);
		System.out.println("timerScanData value = " + timerScanData);
		System.out.println("timerScanData value.size() = " + timerScanData.size());
		}
		f = jframe;
		// get the value to define different button click action
		getPropertiesValue = getTopicValue.replaceAll("\\s", "")
				+ getHearderValue.replaceAll("\\s", "");
		isBigData = getPropertiesValue.equals("PFNoteReceiptPFReturn(BIR51/BIR52)")||getPropertiesValue.equals("CTRNoteReceiptCTRAdviceLetter");
		String filePath = "resources/allOptionJava.properties";
		prop = new Properties();
		try (InputStream inputStream = MainMenu.class.getClassLoader()
				.getResourceAsStream(filePath)) {

			// Loading the properties.
			prop.load(inputStream);

			
			// get properties value
			String num = prop.getProperty(getPropertiesValue
					+ ".DetailRecordNUM");
			int numOfButton = Integer.parseInt(num);
			buttonNum = prop.getProperty(getPropertiesValue + ".NUM");
			ButtonNumber = Integer.parseInt(buttonNum);
			num = prop.getProperty(getPropertiesValue + ".DetailRecordNUM");
			numOfButton = Integer.parseInt(num);

			// set layout and button group
			JPanel middlePanel = new JPanel();
			middlePanel.setLayout(new BorderLayout());
			middlePanel.setPreferredSize(new Dimension(numOfButton * 250,
					(timerScanData.size()+1) * 23));
			
			JLabel topic = new JLabel(getTopicValue + " Menu",
					SwingConstants.CENTER);
			Border border = BorderFactory.createCompoundBorder(
					BorderFactory.createEmptyBorder(20, 20, 20, 20),
					BorderFactory.createMatteBorder(3, 3, 3, 3, Color.BLACK));
			JLabel header = new JLabel(getHearderValue, SwingConstants.CENTER);
			Border headerborder = BorderFactory.createCompoundBorder(
					BorderFactory.createEmptyBorder(0, 70, 10, 70),
					BorderFactory.createMatteBorder(3, 3, 3, 3, Color.BLACK));
			header.setBounds(150, 70, 400, 30);
			header.setFont(new Font("Serif", Font.PLAIN, 15));
			header.setBorder(headerborder);
			topic.setBounds(90, 20, 400, 40);
			topic.setFont(new Font("Serif", Font.PLAIN, 30));
			topic.setBorder(border);
			JLabel countNum = new JLabel("Total No. of Records:                           "
					+ Integer.toString(timerScanData.size()),
					SwingConstants.CENTER);
			JPanel headerPane = new JPanel(new BorderLayout());
			JPanel contentPane = new JPanel(new BorderLayout());
			JPanel bottomPanel = new JPanel(new BorderLayout());
			JPanel buttonPanel = new JPanel();
			JLabel tmplabel = new JLabel(" ", SwingConstants.LEFT);
			JLabel tmplabel2 = new JLabel(" ", SwingConstants.LEFT);
			JLabel tmplabel3 = new JLabel(" ", SwingConstants.LEFT);
			GridBagLayout layout = new GridBagLayout();
			buttonPanel.setLayout(layout);
			GridBagConstraints s = new GridBagConstraints();
			s.fill = GridBagConstraints.NONE;
			s.gridwidth = 2;
			s.gridheight = 2;
			s.weightx = 5;
			s.weighty = 20;
			JPanel container = null;
			if (!isBigData)
				container = new JPanel(new GridLayout(timerScanData.size() + 1 ,  numOfButton + 1 , 2, 2));
			JButton back = new JButton("Back");
			JButton delete = new JButton("Delete");
			JButton report = new JButton("Report");
			JButton newheader = new JButton("Newheader");
			headerPane.setPreferredSize(new Dimension(600, 150));
			headerPane.add(BorderLayout.NORTH, topic);
			headerPane.add(BorderLayout.CENTER, header);
			buttonPanel.add(delete);
			buttonPanel.add(report);
			buttonPanel.add(tmplabel);
			buttonPanel.add(back);
			buttonPanel.add(tmplabel2);
			if (getPropertiesValue.equals("CTRNoteReceiptCTRAdviceLetter")||getPropertiesValue.equals("PFNoteReceiptPFReturn(BIR51/BIR52)")){
				buttonPanel.add(newheader);
			}
			JButton save = new JButton("Save");
			buttonPanel.add(tmplabel3);
			buttonPanel.add(save);
			
			layout.setConstraints(delete, s);
			s.gridwidth = 0;
			s.weightx = 5;
			s.weighty = 20;
			layout.setConstraints(report, s);
			layout.setConstraints(tmplabel,s);
			layout.setConstraints(back, s);
			layout.setConstraints(tmplabel2,s);
			layout.setConstraints(newheader, s);
			layout.setConstraints(tmplabel3,s);
			layout.setConstraints(save,s);
			
			bottomPanel.add(BorderLayout.NORTH, countNum);
			bottomPanel.add(BorderLayout.CENTER, buttonPanel);
			
			if (SystemMenu.saveDisable==true) {
				save.setEnabled(false);
			}
			else {
				save.setEnabled(true);
			}
			JLabel[] OutputLabel = new JLabel[numOfButton];
			JLabel[] OutputDataLabel = new JLabel[numOfButton];
			JPanel[] highlightLabel = new JPanel[numOfButton];//(new BorderLayout());
			String OutputData[] = new String[numOfButton + 1];
			int OutputDataInt[] = new int[numOfButton + 1];
			String splitTimerScanData[] = new String[timerScanData.size()];
			storeSplitTimerScanData= new String[timerScanData.size()];
			storeTinChangeToPrnData= new String[timerScanData.size()];
			radioButton = new JRadioButton[timerScanData.size()];
			
			String[][] labelData = new String[timerScanData.size()][numOfButton];
			String[] label = new String[numOfButton + 1];
			String[] headers = new String[numOfButton];
			for (int i = 0; i < numOfButton; i++) {
				headers[i] = prop.getProperty(getPropertiesValue + ".DetailRecordLabel" + (i + 1));
			}
			// get header name
			
			if (!isBigData) {
				container.add(Box.createHorizontalStrut(2));
				for (int i = 0; i < numOfButton; i++) {
					OutputLabel[i] = new JLabel(prop.getProperty(getPropertiesValue + ".DetailRecordLabel" + (i + 1)));
					container.add(OutputLabel[i]);
				}
			
			} else {
				label[0] = "";
				for (int i = 1; i <= numOfButton; i++) {
					label[i] = (prop.getProperty(getPropertiesValue + ".DetailRecordLabel" + i));
				}
			}
			//middlePanel.add(BorderLayout.NORTH, top);
			for (int i = 0; i <= numOfButton; i++) {
				OutputData[i] = new String(prop.getProperty(getPropertiesValue
						+ ".DetailRecordData" + i));
				OutputDataInt[i] = Integer.parseInt(OutputData[i]);
			}

		
			// to let the display format correct

			SystemMenu.SaveTinChangeToPrnData= new ArrayList<String>();
			for (int i = 0; i < timerScanData.size(); i++) {
				splitTimerScanData[i] = timerScanData.get(i).toString()+"                                                            ";
				storeSplitTimerScanData[i] = timerScanData.get(i).toString();

				radioButton[i] = new JRadioButton("", false);
				if(!isBigData) {
				container.add(radioButton[i]);
				}
				for (int j = 0; j < numOfButton; j++) {
					checklabelhighlight = "false";
						if (splitTimerScanData[i].length() < OutputDataInt[numOfButton]) {
							if(getPropertiesValue.equals("CTRScanUndeliveredCTRDemandNote")){
								splitTimerScanData[i] = timerScanData.get(i).toString() + " ";
								storeSplitTimerScanData[i] = timerScanData.get(i).toString() + " ";
							}
							else{
								splitTimerScanData[i] = " " + timerScanData.get(i).toString();
								storeSplitTimerScanData[i] = " " + timerScanData.get(i).toString();
							}
						}
						if (!isBigData) {
							OutputDataLabel[j] = new JLabel(
								splitTimerScanData[i].substring(OutputDataInt[j], OutputDataInt[j + 1]),
								SwingConstants.LEFT);
						} else {
							labelData[i][j] = splitTimerScanData[i].substring(OutputDataInt[j], OutputDataInt[j + 1]);
						}
					// for BR Detail record 1 & 2 checking
					if (getTopicValue.equals("BR"))
					{
						if (storeSplitTimerScanData[i].length() == 25)
						{
							for(int fieldnum = 0; fieldnum < 6; fieldnum++)
							{
								OutputDataLabel[fieldnum] = new JLabel(" ", SwingConstants.LEFT);
							}
						OutputDataLabel[numOfButton-1] = new JLabel(storeSplitTimerScanData[i],SwingConstants.LEFT);;
						}
						else
						{
							OutputDataLabel[numOfButton-1] = new JLabel(" ", SwingConstants.LEFT);
						}
					}
					
					String inputo=storeSplitTimerScanData[i].replaceAll("[^o]+", "");
					String inputO=storeSplitTimerScanData[i].replaceAll("[^O]+", "");
					if(inputo.length()>=1||inputO.length()>=1){
						
						highlightLabel[j] = new JPanel(new BorderLayout());
						highlightLabel[j].add(BorderLayout.WEST,OutputDataLabel[j]);
						highlightLabel[j].setBackground(Color.red);
						if (!isBigData)	
							container.add(highlightLabel[j]);
					}
					else{
						if (!isBigData)
							container.add(OutputDataLabel[j]);
						//System.out.println("Add JLabel " + i + "-" + j);
					}
					
				}

				timerScanData.set(i, storeSplitTimerScanData[i]);
				if (!isBigData) {
					middlePanel.add(BorderLayout.NORTH, container);
				} 
			}
			if (isBigData) {
				RadioButtonObjectManager manager = new RadioButtonObjectManager(labelData, headers);
				table = new JTable(new RadioButtonTableModel(manager));
				table.setRowHeight(20);
				table.getTableHeader().setReorderingAllowed(false);
				table.getTableHeader().setResizingAllowed(false);
				TableColumn column = table.getColumnModel().getColumn(0);
				column.setCellEditor(new RadioButtonCellEditorRenderer());
				column.setCellRenderer(new RadioButtonCellEditorRenderer());
			}
			int size =timerScanData.size();
			if (SystemMenu.TinChangeToPrn =="true") {
				if(timerScanData.size()<SystemMenu.Recordlimited){
				SystemMenu.checkLogData.add("SystemMenu.SaveTinChangeToPrnData = " + SystemMenu.SaveTinChangeToPrnData);
				}
				 timerScanData = new ArrayList<String>(); 
				 for (int i = 0; i < size; i++) {
						 storeTinChangeToPrnData[i] = SystemMenu.SaveTinChangeToPrnData.get(i).toString();
						 timerScanData.add(storeTinChangeToPrnData[i]);
						
				 }
				 if(timerScanData.size()<SystemMenu.Recordlimited){
				 SystemMenu.checkLogData.add("SystemMenu.SaveTinChangeToPrnData = " + timerScanData); 
				 }
			}
			
			JScrollPane scroll = isBigData ? new JScrollPane(table) : new JScrollPane(middlePanel);
			scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
			scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			scroll.setPreferredSize(new Dimension(400, 300));
			contentPane.add(BorderLayout.NORTH, headerPane);
			contentPane.add(BorderLayout.CENTER, scroll);
			contentPane.add(BorderLayout.SOUTH, bottomPanel);
			add(contentPane);

			// set action
			back.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(timerScanData.size()<SystemMenu.Recordlimited){
					SystemMenu.checkLogData.add("Click in "+ getPropertiesValue +" (OptionVerify) (Back) button");
					SystemMenu.checkLogData.add("timerScanData value = " + timerScanData);
					}
					// create window layout
					if(timerScanData.size()==0){
						int ConfirmDialoginput = JOptionPane.showConfirmDialog(
								null, "All the record empty already. It will let you come back to Option Menu. Do you want to go?",
								"Select an Option...", JOptionPane.YES_NO_OPTION);
						if (ConfirmDialoginput == 0) {
						SystemMenu.checkSaveStatus="true";
						String status = null;
						timerScanData = new ArrayList<String>();
						SystemMenu.SaveTinChangeToPrnData= new ArrayList<String>();
						passOptionNewTextFieldValue = new String[SystemMenu.Arraylimited][SystemMenu.Arraylimited];
						marks = new int[SystemMenu.Arraylimited];
						headerno = 1;
						
						f.setVisible(false);
			        	f.getContentPane().removeAll();
			        	optionMenu = new OptionMenu(f,getHearderValue,timerScanData, passOptionNewTextFieldValue , headerno , marks , status);	        	
			        	optionMenu.draw();		        	
			        	f.setContentPane(optionMenu);
			        	Dimension preferredSize = new Dimension(700,700);
			        	f.setPreferredSize(preferredSize);        	
			        	f.setBounds(700,200,700,700);
			        	f.setLocationRelativeTo(null);
			        	SwingUtilities.updateComponentTreeUI(f);
			        	f.pack();
			        	f.setVisible(true);
			        	f.invalidate();
			        	f.validate();
			        	f.repaint();
						}
					}
					else{
					f.setVisible(false);
					f.getContentPane().removeAll();
					optionScan.headerno = tempheaderno;
					optionScan.timerScanData = timerScanData;
					optionScan.draw();
					f.setContentPane(optionScan);
					Dimension preferredSize = new Dimension(700, 700);
					f.setPreferredSize(preferredSize);
					f.setBounds(700, 200, 700, 700);
					f.setLocationRelativeTo(null);
					SwingUtilities.updateComponentTreeUI(f);
					f.pack();
					f.setVisible(true);
					f.invalidate();
					f.validate();
					f.repaint();
					}
				}
			});
			
			newheader.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(timerScanData.size()<SystemMenu.Recordlimited){
					SystemMenu.checkLogData.add("Click in "+ getPropertiesValue +" (OptionVerify) (New header) button");
					SystemMenu.checkLogData.add("timerScanData value = " + timerScanData);
					}
					if (marks[headerno-1]==0){
		        		JOptionPane optionPane2 = new JOptionPane("No any Scan Record Find In this Batch/Header ", JOptionPane.ERROR_MESSAGE);    
		        		JDialog dialog2 = optionPane2.createDialog("Failure");
		        		dialog2.setAlwaysOnTop(true);
		        		dialog2.setVisible(true); 
					}
					else{
					// create window layout					
					headerno++;
					String status = "new";
					f.setVisible(false);
					optionNew = new OptionNew(f, optionMenu, timerScanData,passOptionNewTextFieldValue, headerno, marks,status);
					f.getContentPane().removeAll();
					optionNew.draw();
					f.setContentPane(optionNew);
					Dimension preferredSize = new Dimension(700, 700);
					f.setPreferredSize(preferredSize);
					f.setBounds(700, 200, 700, 700);
					f.setLocationRelativeTo(null);
					SwingUtilities.updateComponentTreeUI(f);
					f.pack();
					f.setVisible(true);
					f.invalidate();
					f.validate();
					f.repaint();
					}
				}
			});
			delete.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (timerScanData.size()<SystemMenu.Recordlimited){
						SystemMenu.checkLogData.add(""
							+ "Click in "+ getPropertiesValue +" (OptionVerify) (Delete) button");
					}
					if (timerScanData.size()==0){
						int ConfirmDialoginput = JOptionPane.showConfirmDialog(
								null, "Do you want to delete this record?",
								"Select an Option...", JOptionPane.YES_NO_OPTION);
					}
					else{
						int ConfirmDialoginput = JOptionPane.showConfirmDialog(
							null, "Do you want to delete this record?",
							"Select an Option...", JOptionPane.YES_NO_OPTION);
							// 0=yes, 1=no, 2=cancel
						int check = 0;
						int position = 0;
						int recount =0;
						int removeno = 0;
						if (ConfirmDialoginput == 0) {
							SystemMenu.checkSaveStatus="false";
							int numOfData = timerScanData.size();
							for (int i = 0; i < numOfData; i++) {
								if ((!isBigData && radioButton[i].isSelected()) ||
									(isBigData && (Boolean) table.getModel().getValueAt(i, 0))) {
									System.out.println("delete row number = " + i);
									check = i;
									if (timerScanData.contains(storeSplitTimerScanData[i])) {
										if (isBigData) {
										timerScanData.remove(i);
										}
										else{
										timerScanData.remove(storeSplitTimerScanData[i]);
										}
										check-=recount;
										for(int j = 0 ; j < headerno ; j ++){
											check -= marks[j];
											if(check < 0){
												position = j;
												break;
											}
										}
										passOptionNewTextFieldValue = replace2Darray(passOptionNewTextFieldValue,headerno,marks,position); 
										recount++;
										if(marks[position] == 0){
											replaceintarry(marks, position, headerno);
											removeno++;
										}
									} else {
										System.out.println("processing not contain "
													+ storeSplitTimerScanData[i]);
									}
									if (SystemMenu.SaveTinChangeToPrnData.contains(storeTinChangeToPrnData[i])) {
										if (isBigData) {
										SystemMenu.SaveTinChangeToPrnData.remove(i);
										}
										else{
										SystemMenu.SaveTinChangeToPrnData.remove(storeTinChangeToPrnData[i]);	
										}
									}
								} else{
									if(timerScanData.size()<SystemMenu.Recordlimited){
										System.out.println("processing unselected " + storeSplitTimerScanData[i]);
									}
								}
							}
							if (getPropertiesValue.equals("CTRNoteReceiptCTRAdviceLetter")||getPropertiesValue.equals("PFNoteReceiptPFReturn(BIR51/BIR52)")){
								tempheaderno -= removeno;	
							}

							if (getPropertiesValue.equals("CTRScanUndeliveredCTRDemandNote")) {
								for (int i = 5-1; i <5; i++){ //find REC-COUNT button to do this
									int size = marks[headerno-1];
									String count=Integer.toString(size);
									while(count.length()!=5){
										count="0"+count;
									}
									passOptionNewTextFieldValue[i][headerno - 1]=count;
								}
							}
						}

						f.setVisible(false);
						OptionVerify.removeAll();
						OptionVerify.draw();
						f.setContentPane(OptionVerify);
						f.pack();
						f.setVisible(true);			
					}
				}

				private String[][] replace2Darray(String[][] passOptionNewTextFieldValue, int headerno, int[] marks, int position) {
					String[][] remainingStockout = passOptionNewTextFieldValue;
					String[][] swap = passOptionNewTextFieldValue;
					String[][] temp = new String [passOptionNewTextFieldValue.length][passOptionNewTextFieldValue.length];
					marks[position] -= 1;
					for(int i=0; i< passOptionNewTextFieldValue.length; i++){
			            for(int j=0; j < passOptionNewTextFieldValue.length; j++){
			            	temp[j][i] = swap[i][j];
			            }
			        }
						
						if(marks[position] == 0){
							List<String[]> stockout = new ArrayList<String[]>(Arrays.asList(temp));
					                    stockout.remove(position);
					                    remainingStockout = (String[][]) stockout.toArray(new String[][] {});
					                    for(int i=0; i< passOptionNewTextFieldValue.length - 1; i++){
								            for(int j=0; j < passOptionNewTextFieldValue.length - 1; j++){
								            	swap[i][j] = remainingStockout[j][i];
								            }
								        }      
					        return swap;
						}
					
					return remainingStockout;
					
				}
				private void replaceintarry(int[] marks, int position, int headerno) {
						if(marks[position+1] != 0){
							for ( int i = position ; i < headerno - 1 ; i++ )
							   {
								marks[ i ] = marks[ i + 1 ] ; 
								marks[ i + 1 ] = 0;
							   }
						}
				}
				
			});
			report.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(timerScanData.size()<SystemMenu.Recordlimited){
						SystemMenu.checkLogData.add("Click in "+ getPropertiesValue +" (OptionVerify) (Report) button");
					}
					// create window layout
					headerno = tempheaderno;
					new Report(timerScanData, passOptionNewTextFieldValue, headerno,marks);

				}
			});
			
			save.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(timerScanData.size()<SystemMenu.Recordlimited){
					SystemMenu.checkLogData.add("Click in "+ getPropertiesValue +" (OptionMenu) (Save) button");
					SystemMenu.checkLogData.add("timerScanData value = " + timerScanData);
					}
					String HeaderRecordSaveNextline[] = new String[ButtonNumber];
					String DialoginputContent;
					String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss")
							.format(Calendar.getInstance().getTime());
					String fileName = new String(prop
							.getProperty(getPropertiesValue + ".FileName"));
					String csvName = new String(prop
							.getProperty(getPropertiesValue + ".CSVName"));
					String logName = new String(prop
							.getProperty(getPropertiesValue + ".LogName"));
					String fileNameCopy = new String(prop
							.getProperty(getPropertiesValue + ".FileNameCopy"));
					String filePath = new String(prop
							.getProperty(getPropertiesValue + ".FilePath"));
					File newTextFile = new File(filePath + fileName);
					File csvFile = new File(filePath + csvName);
					File logFile = new File(filePath + logName);
					File oldFilecopy = new File(filePath + fileNameCopy);
					File FileToSave = new File(filePath);

					int countSpace = 0;
					String savingSpaceInFile = new String();
					String headerRecordAddSpace[] = new String[ButtonNumber];
					int headerRecordAddSpaceInt[] = new int[ButtonNumber];
					String DetailRecordAddSpace = new String();
					int DetailRecordAddSpaceInt = 0;
					for (int i = 0; i < ButtonNumber; i++) {
						headerRecordAddSpace[i] = new String(prop
								.getProperty(getPropertiesValue
										+ ".HeaderRecordAddSpace" + (i + 1)));
						headerRecordAddSpaceInt[i] = Integer
								.parseInt(headerRecordAddSpace[i]);
					}

					if (newTextFile.exists()) {
						DialoginputContent = "   You have existing file already.";
					} else {
						DialoginputContent = "";
					}
					if (marks[0]==0){
		        		JOptionPane optionPane2 = new JOptionPane("There are not any records can save", JOptionPane.ERROR_MESSAGE);    
		        		JDialog dialog2 = optionPane2.createDialog("Failure");
		        		dialog2.setAlwaysOnTop(true);
		        		dialog2.setVisible(true); 
					}
					else{
					int ConfirmDialoginput = JOptionPane.showConfirmDialog(
							null, "Do you want to save these records?"
									+ DialoginputContent,
							"Select an Option...", JOptionPane.YES_NO_OPTION);
					// 0=yes, 1=no, 2=cancel
					if (ConfirmDialoginput == 0) {

						if (FileToSave.exists()) {

						} else {
							FileToSave.mkdirs();
						}
						if (newTextFile.exists()) {
							try {
								Files.copy(newTextFile.toPath(),
										oldFilecopy.toPath());
							} catch (IOException e1) {
								e1.printStackTrace();
							}
							oldFilecopy.renameTo(new File(FileToSave + "\\"
									+ oldFilecopy.getName() + timeStamp));

						} else {

						}

						try {
	                		SystemMenu.checkSaveStatus="true";
	                		 FileWriter fileWriter = new FileWriter(newTextFile);
	                		 //get properties value
	                		 int start = 0;
	                		 DetailRecordAddSpace= new String(prop.getProperty(getPropertiesValue+".DetailRecordAddSpace"));
	                		 DetailRecordAddSpaceInt=Integer.parseInt(DetailRecordAddSpace);
	                		 for (int j = 0; j < headerno ; j++){
	                		    
	                			 if (getPropertiesValue.equals("ERScanUndeliveredERReturn(BIR56A)")){
	                				 
	                			 }
	                			 
	                			 else{
	                				 
	                		 for (int i = 0; i <ButtonNumber; i++){
	                			 if(marks[j]!=0){  
	                			 HeaderRecordSaveNextline[i]= new String(prop.getProperty(getPropertiesValue+".HeaderRecordSaveNextline"+(i+1)));
	                			 fileWriter.write(passOptionNewTextFieldValue[i][j].toUpperCase());  			 
	                			 switch(headerRecordAddSpace[i]){
	          		           		case "0":
	          		        	   
	          		           			break;
	          			 	 			
	          		           		default:	
	          		           			while(countSpace!=headerRecordAddSpaceInt[i]){
	          		           			savingSpaceInFile=savingSpaceInFile+" ";
	          		           			countSpace++;
	          		           			}
	          		           			fileWriter.write(savingSpaceInFile);
	          		           			break;
	                			 }
	                			 savingSpaceInFile=new String(); 
	                			 countSpace=0;
	                			 fileWriter.write(HeaderRecordSaveNextline[i]);
	                		 }
	                		 }
	                			 }
	                		 int size=marks[j];
	                		 
			           			while(countSpace!=DetailRecordAddSpaceInt){
			           			savingSpaceInFile=savingSpaceInFile+" ";
			           			countSpace++;
			           			}         
	                		 //to let the save format correct
	                		 for (int i = start; i <start + size; i++){
	                			 String saveTimerScanData = timerScanData.get(i).toString().toUpperCase();
	                			 
	                			 if (getPropertiesValue.equals("ERScanUndeliveredERReturn(BIR56A)")){
	                	    		 for (int c = 0; c <ButtonNumber; c++){
			           
			                			 fileWriter.write(passOptionNewTextFieldValue[c][j]);  			 

			                		 }
	                				 	int ScanDatasize = 1+i;
	                					String count=Integer.toString(ScanDatasize);
	                					while(count.length()!=7){
	                						count="0"+count;
	                					}
	                					fileWriter.write(count);
	           		           			while(countSpace!=DetailRecordAddSpaceInt){
	               		           			savingSpaceInFile=savingSpaceInFile+" ";
	               		           			countSpace++;
	               		           			} 
	                			 }
	                			 switch(DetailRecordAddSpace){
	          		           		case "0":
	          		           			fileWriter.write(saveTimerScanData);          		        	   
	          		           			break;
	          		           			
	          		           		default:
	          		           			fileWriter.write(saveTimerScanData); 
	          		           			fileWriter.write(savingSpaceInFile);
	          		           			break;
	                			 }
	                			 //This prevent creating a blank line at the end of the file
	                			  
	                				 fileWriter.write("\r\n");
	                			 
	                		 }
	                		 	start += size;
	                			savingSpaceInFile=new String(); 
	                			countSpace=0;
	                		 }
	                		 fileWriter.close();
							start = 0;
							// write csv files
							if (getPropertiesValue.equals("CTRNoteReceiptCTRAdviceLetter") || getPropertiesValue.equals("PFNoteReceiptPFReturn(BIR51/BIR52)") || getPropertiesValue.equals("CTRNoteReceiptCTRReturn(BIR60)")) 
							{
								System.out.println("It will not create CSV file");
							}
							else{
								FileWriter csvWriter = new FileWriter(csvFile);
								for (int j = 0; j < headerno; j++) {
									int size = marks[j];
									for (int i = start; i < start + size; i++) {
										String saveTimerScanData = timerScanData
												.get(i).toString();
										for (int k = 0; k < ButtonNumber; k++) {
											csvWriter
													.write(passOptionNewTextFieldValue[k][j]);
											csvWriter.write(",");
										}
										csvWriter.write(saveTimerScanData);
										csvWriter.write("\r\n");

									}
								}
								csvWriter.close();
							}
							// write log file
							if(timerScanData.size()<SystemMenu.Recordlimited){
							if (logFile.exists()) {
								try {
									Files.copy(logFile.toPath(),
											oldFilecopy.toPath());
								} catch (IOException e1) {
									e1.printStackTrace();
								}
								oldFilecopy.renameTo(new File(FileToSave + "\\"
										+ logFile.getName() +"_"+ timeStamp));

							} else {

							}
							FileWriter logWriter = new FileWriter(logFile);
								int size = SystemMenu.checkLogData.size();
								for (int i = 0; i < size; i++) {
									String saveLogData = SystemMenu.checkLogData.get(i).toString();		
									logWriter.write(saveLogData);
									logWriter.write("\r\n");

								}
							
							logWriter.close();
							}
						} catch (IOException iox) {
							iox.printStackTrace();
							System.out.println("File can not save any data");
						}
						SystemMenu.dataListRecordChange=false;
						SystemMenu.saveDisable=true;
						
						f.setVisible(false);	        	
			        	f.getContentPane().removeAll();
			        	OptionVerify.removeAll();
			        	OptionVerify.draw();
			        	f.setContentPane(OptionVerify);
			        	Dimension preferredSize = new Dimension(700,700);
			        	f.setPreferredSize(preferredSize);

			        	f.setBounds(700,200,700,700);
			        	f.setLocationRelativeTo(null);
			        	SwingUtilities.updateComponentTreeUI(f);
			        	f.pack();
			        	f.setVisible(true);
			        	f.invalidate();
			        	f.validate();
			        	f.repaint();
						
					}

					if (ConfirmDialoginput == 1) {

					}
					}
				}
			});
			
			

		}

		catch (IOException ex) {

			System.out.println("Problem occurs when reading file !");
			ex.printStackTrace();
		}

	}

}
