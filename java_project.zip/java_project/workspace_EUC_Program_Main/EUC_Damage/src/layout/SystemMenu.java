package layout;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.swing.*;
import javax.swing.border.Border;

import layout.simple.SimpleHandler;
import layout.simple.SimpleOptionMenu;
import layout.simple.SimpleRecord;

public class SystemMenu {
	
	public static boolean dataListRecordChange=false;
	public static boolean checkNewOpenButton=false;
	public static boolean saveDisable=true;
	public static boolean clickOpen=false;
	public static String deleteOpenFilePath= new String();
	public static String passTopicValue;
	public static String checkSaveStatus="true";
	public static String openFilePath;
	public static String checkERBatchDateEmpty = "true";
	
	public JFrame f;
	public OptionMenu optionMenu;
	
	String onlineFctID;
	List<String> timerScanData = new ArrayList<String>(); 
	public static List<String> SaveTinChangeToPrnData;
	public static List<String> checkLogData;
	String passOptionNewTextFieldValue[][] = new String[5000][5000];
	int marks[] = new int[5000];
	int headerno = 1;
	String status = null;
	public static String TinChangeToPrn = "false";
	public static int Recordlimited=150;
	public static int Arraylimited=5000;
	public static int MaxArraylimited=20000;
	
	public SystemMenu(String onlineFctID) throws IOException {
		checkNewOpenButton=false;
		clickOpen=false;
		checkSaveStatus="true";
		openFilePath="";
		checkERBatchDateEmpty = "true";
		SaveTinChangeToPrnData = new ArrayList<String>();
		checkLogData= new ArrayList<String>();
		TinChangeToPrn = "false";
		//get the value from the class action command
		this.onlineFctID = onlineFctID;
		
		//pass the value to other class
		passTopicValue=onlineFctID;
		
		
   	    String filePath = "resources/systemmenu.properties";
		Properties prop = new Properties();
		try (InputStream inputStream = MainMenu.class.getClassLoader().getResourceAsStream(filePath)) {
			// Loading the properties.
			prop.load(inputStream);	
			
			//layout and button group
			JButton main = new JButton("Main");
			f = new JFrame(onlineFctID);
			f.setBounds(700,200,700,700);
			f.setLocationRelativeTo(null);
			f.setVisible(true);
		    f.getContentPane().add(main);
			f.getContentPane().setLayout(null);	
			JLabel topic = new JLabel(onlineFctID+" Menu" , SwingConstants.CENTER);
			Border border = BorderFactory.createLineBorder(Color.BLACK, 3);
			topic.setBounds(90,20,500,40);
			topic.setFont(new Font("Serif", Font.PLAIN, 30));
			topic.setBorder(border);
			f.getContentPane().add(topic);
			main.setBounds(290,500,95,30);
			
			
			//set action
			main.addActionListener( new ActionListener()
			    {
			        public void actionPerformed(ActionEvent e)
			        {
			        	f.dispose();
		            	new MainMenu();
			        }
			    });
			
			//get value from properties
			String num= prop.getProperty(onlineFctID+".NUM");
			int numOfButton = Integer.parseInt(num);
			
			JButton[] bt= new JButton[numOfButton]; 
			
 			
            
 			for (int i = 0; i <numOfButton; i++){
 	 		bt[i] = new JButton(prop.getProperty(onlineFctID+".00"+(i+1)));
 	 		bt[i].setBounds(140,(100 + i*50),405,30); 	
 	 		f.getContentPane().add(bt[i]);
 	 		
 	 			bt[i].addActionListener( new ActionListener()
 	 			{
 	            public void actionPerformed(ActionEvent e)
 	            		{

 	            	String selectedSystem = SystemMenu.passTopicValue;
 	            	String selectedOnlineFunctionId = e.getActionCommand();
 	            	String selSysFncId = selectedSystem.replaceAll("\\s", "") + selectedOnlineFunctionId.replaceAll("\\s", "");
 	            	
 	            	f.setVisible(false);
		        	f.getContentPane().removeAll();
		        	
		        	Properties allProperties = new Properties();

		        	File resourceFolder = new File("./resources");
		        	try {
	    			    for (File nextFile : resourceFolder.listFiles()) {
	    			    	System.out.println(nextFile);
	    			    	
	    			    	if (!nextFile.getName().endsWith(".properties"))
	    			    		continue;
	    			    	
	    			    	Properties singleProperties = new Properties();
	    			    	singleProperties.load(new FileReader(nextFile));
	    			    	allProperties.putAll(singleProperties);
	    			    }
            		}catch(Exception ex) {ex.printStackTrace();}
		        	
		    		
 	            	if (allProperties.get(selSysFncId+".model") != null){
 	            		try {
 	            			String modelName = (String) allProperties.get(selSysFncId+".model");
 	            			String customHandler = "layout."+selectedSystem.replaceAll("\\s", "").toLowerCase()+"."+modelName.toLowerCase()+"."+modelName;

 	 	            		SimpleHandler handler = (SimpleHandler) Class.forName(customHandler+"Handler").newInstance(); 
 	 	            		SimpleOptionMenu simpleOptionMenu = new SimpleOptionMenu(f, selectedSystem, selectedOnlineFunctionId, timerScanData, handler, true);
 	 	            		simpleOptionMenu.draw();
 	 			        	f.setContentPane(simpleOptionMenu);
 	            		}catch(Exception ex) {ex.printStackTrace();}
 	            	}else {
 			        	optionMenu = new OptionMenu(f,e.getActionCommand(),timerScanData, passOptionNewTextFieldValue , headerno , marks , status);	        	
 			        	optionMenu.draw();	
 			        	f.setContentPane(optionMenu);
 	            	}
 	            	 	
		        	Dimension preferredSize = new Dimension(700,700);
		        	f.setPreferredSize(preferredSize);	        	
		        	f.setBounds(700,200,700,700);
		        	f.setLocationRelativeTo(null);
		        	SwingUtilities.updateComponentTreeUI(f);
		        	f.pack();
		        	f.setVisible(true);
		        	f.invalidate();
		        	f.validate();
		        	f.repaint();
 	            	
 	            	
 	            	
 	            			}
 	 				});
 	 		
 	 		
 	 		
 	 		
 			 }
 							
 		}
        catch (IOException ex) {
 			
 			System.out.println("Problem occurs when reading file !");
 			ex.printStackTrace();
 		} 
	}
	

	
}