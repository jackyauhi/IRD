package layout.simple;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.util.List;
import java.util.Map;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import utils.PrintUtil;

@SuppressWarnings("serial")
public class SimplePrintableReport extends JFrame {
	
	public SimplePrintableReport(List<SimpleRecord> dataList, SimpleHandler simpleHandler, String selectedSystem, String selectedOnlineFunctionId, Map<String, String> headerValues) {
		final JFrame f = new JFrame("Report");
		
		setLayout(new BorderLayout(0, 0));
		// report border
		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout(0, 0));
		
		final JButton btnPrint = new JButton("Print");
		final JButton btnBack = new JButton("Back");
		btnPrint.setSize(20, (int)btnPrint.getSize().getHeight());
		btnPrint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PrintUtil printUtil = new PrintUtil(f);
				btnPrint.setVisible(false);
				btnBack.setVisible(false);
				Color backGroundColor = getContentPane().getBackground();
				getContentPane().setBackground( Color.WHITE );
				printUtil.print();
				getContentPane().setBackground( backGroundColor );
				btnPrint.setVisible(true);
				btnBack.setVisible(true);
			}
		});
		
		btnBack.setSize(20, (int)btnBack.getSize().getHeight());
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.dispatchEvent(new WindowEvent(f, WindowEvent.WINDOW_CLOSING));
			}
		});
		
		JPanel bodyPanel = new JPanel();
		bodyPanel.add(prepareTitlePanel(selectedSystem + " Menu", selectedOnlineFunctionId, simpleHandler.getCustomizeReportTitle(dataList, headerValues)), BorderLayout.NORTH);
		bodyPanel.add(simpleHandler.prepareContentPanel(dataList, headerValues, btnPrint, btnBack), BorderLayout.CENTER);


		panel.add(prepareHeaderPanel(), BorderLayout.NORTH);
		
		panel.add(bodyPanel, BorderLayout.CENTER);
		
		panel.add(prepareFooter(), BorderLayout.SOUTH);
		
		// set and show the container frame
		Dimension preferredSize = simpleHandler.getPreferredSize();
		f.setPreferredSize(preferredSize);
		f.setBounds(700, 200, (int)preferredSize.getWidth(), (int)preferredSize.getHeight());
		f.setLocationRelativeTo(null);
		f.pack();
		f.setContentPane(panel);
		f.setVisible(true);
		
	}
	/**
	 * Create the panel.
	 */
	private JPanel prepareFooter() {
		// print report

		JPanel footerPanel = new JPanel();
		footerPanel.setLayout(new BorderLayout(0, 0));
		footerPanel.add(new JLabel("<html>"
				+ "<center>-------------------------------------------------------------------------------------------------</center><br/>"
				+ "<center>*****************************************************************</center>"
				+ "</html>", SwingConstants.CENTER), BorderLayout.CENTER);
		
		return footerPanel;
	}
	
	private JPanel prepareTitlePanel(String topicValue, String headerValue, List<String> customizeTitles) {

		JPanel titlePanel = new JPanel();
		titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));
		
		// report header
		JLabel lblRecordsSummaryReport = new JLabel("Records Summary Report");
		lblRecordsSummaryReport.setFont(new Font("新細明體", Font.BOLD, 12));
		lblRecordsSummaryReport.setAlignmentX(Component.CENTER_ALIGNMENT);
		JLabel topic = new JLabel(topicValue);
		topic.setAlignmentX(Component.CENTER_ALIGNMENT);
		JLabel header = new JLabel(headerValue);
		header.setAlignmentX(Component.CENTER_ALIGNMENT);
		
		titlePanel.add(topic);
		titlePanel.add(header);
		titlePanel.add(lblRecordsSummaryReport, Component.CENTER_ALIGNMENT);
		
		for (String customizeTitle : customizeTitles) {
			JLabel lbCustomizeTitle = new JLabel(customizeTitle);
			lbCustomizeTitle.setAlignmentX(Component.CENTER_ALIGNMENT);
			titlePanel.add(lbCustomizeTitle);
		}

		return titlePanel;
	}
	
	private JPanel prepareHeaderPanel() {
		JPanel headerPanel = new JPanel();
		headerPanel.setLayout(new BorderLayout(0, 0));
		headerPanel.add(new JLabel("<html>"
				+ "<center>*****************************************************************</center><br/>"
				+ "<center>-------------------------------------------------------------------------------------------------</center>"
				+ "</html>", SwingConstants.CENTER), BorderLayout.CENTER);
		
		return headerPanel;
	}
	
}
