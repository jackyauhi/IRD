package layout.simple;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import utils.Field;

public abstract class SimpleRecord {
	protected List<Field> fieldSeq;
	protected Map<String, String> data;
	
	public List<Field> getFieldSeq() {
		return fieldSeq;
	}

	public void setFieldSeq(List<Field> fieldSeq) {
		this.fieldSeq = fieldSeq;
	}

	public SimpleRecord() {
		data = new HashMap<>();
	}
	
	public void initialize() {
		fieldSeq = initFields();
	}
	
	protected abstract List<Field> initFields();
	
	public String getValue(String key) {
		return data.get(key);
	}
	
	public void setValue(String key, String value) {
		data.put(key, value);
	}
	
	public abstract String parseToString();
	
	public abstract String parseToCSV();
	
	public abstract void parseFromString(String string);
}
