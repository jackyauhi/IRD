package layout.simple;

import java.util.List;

import javax.swing.JTextField;

import utils.Field;

public abstract class SimpleValidator {
	public abstract void validateHeader(List<JTextField> fields) throws Exception;
	public abstract Boolean validateContent(List<Field> fields);
}
