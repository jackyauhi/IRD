package layout.simple;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import utils.Field;

public class SimpleBatchHeaderUtils {
	
	public static String prepareDefaultValue(Field.FIELD_TYPES fieldType, List<SimpleRecord> simpleRecords) {
		String value = null;
		switch(fieldType) {
			case SECTION_ID:
				value = "##";
			break;
			case FILLER:
				value = "      ";
			break;
			case REC_COUNT:
				String count = Integer.toString(simpleRecords.size());
				while (count.length() != 5) {
					count = "0" + count;
				}
				value = count;
			break;
			case BATCH_DATE:
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
				Date now = new Date();
				value = sdf.format(now);
			break;
			default:
				value = "";
		}
		return value;
	}
}
