package layout.simple;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;

import layout.SystemMenu;


@SuppressWarnings("serial")
public class SimpleOptionMenu extends JPanel {

	// pass the class action command value to other class

	private String selSysFncId;
	private String selectedOnlineFunctionId;
	private String selectedSystem;
	private JFrame jFrame;

	private List<SimpleRecord> dataList;
	private Map<String, String> headerValues;
	
	private SimpleHandler simpleHandler;
	
	public List<SimpleRecord> getDataList() {
		return dataList;
	}
	
	public Map<String, String> getHeaderValues() {
		return headerValues;
	}

	public void setHeaderValues(Map<String, String> headerValues) {
		this.headerValues = headerValues;
	}

	public void setDataList(List<SimpleRecord> dataList) {
		this.dataList = dataList;
	}

	@SuppressWarnings("unchecked")
	public SimpleOptionMenu(JFrame jFrame, String selectedSystem, String selectedOnlineFunctionId,
			@SuppressWarnings("rawtypes") List _dataLists, SimpleHandler simpleHandler, Boolean isParseString) {
		
		this.simpleHandler = simpleHandler;
		// get the value from the class action command
		selSysFncId = selectedSystem.replaceAll("\\s", "") + selectedOnlineFunctionId.replaceAll("\\s", "");

		this.jFrame = jFrame;
		this.selectedSystem = selectedSystem;
		this.selectedSystem = selectedSystem;
		this.dataList = new ArrayList<>();
		
		if (isParseString) {
			for (Object _dataList : _dataLists) {
				dataList.add(simpleHandler.parseFromString(String.valueOf(_dataList)));
			}
		}else {
			dataList.addAll(_dataLists);
		}
		// get the value from class String
		this.selectedOnlineFunctionId = selectedOnlineFunctionId;
	}

	public void draw() {
		if (dataList.size() < SystemMenu.Recordlimited) {
			System.out.println("dataList value = " + dataList);
		}

		JLabel topic = new JLabel(selectedSystem + " Menu", SwingConstants.CENTER);
		Border border = BorderFactory.createLineBorder(Color.BLACK, 3);
		
		JLabel header = new JLabel(selectedOnlineFunctionId, SwingConstants.CENTER);
		Border headerborder = BorderFactory.createLineBorder(Color.BLACK, 2);
		header.setBounds(150, 70, 400, 30);
		header.setFont(new Font("Serif", Font.PLAIN, 15));
		header.setBorder(headerborder);
		
		topic.setBounds(90, 20, 500, 40);
		topic.setFont(new Font("Serif", Font.PLAIN, 30));
		topic.setBorder(border);
		
		add(header);
		add(topic);
		
		setBounds(700, 200, 700, 700);
		setLayout(null);
		setVisible(true);
		
		add(prepareBackButton());
		add(prepareNewButton());
		add(prepareOpenButton());
		add(prepareSaveButton());
	}
	
	private JButton prepareSaveButton() {
		JButton save = new JButton("Save");
		save.setBounds(290, 250, 95, 30);
		save.addActionListener(new SaveButtonActionListener(jFrame, simpleHandler, dataList, headerValues, true));
		if (SystemMenu.saveDisable==true) {
			save.setEnabled(false);
		}
		else {
			save.setEnabled(true);
		}
		
		return save;
	}
	
	private JButton prepareOpenButton() {
		JButton open = new JButton("Open");
		open.setBounds(380, 150, 95, 30);
		
		open.addActionListener(new OpenButtonActionListener());
		if (SystemMenu.dataListRecordChange==true||SystemMenu.checkNewOpenButton==true) {
			open.setEnabled(false);
		}

		return open;
	}
	
	private JButton prepareNewButton() {

		JButton newbutton = new JButton("New");
		newbutton.setName("btnNew");
		newbutton.setBounds(200, 150, 95, 30);

		newbutton.addActionListener(new NewButtonActionListener());
		System.out.println("dataList Menu value = " + dataList.size());
		if (SystemMenu.dataListRecordChange==true||SystemMenu.checkNewOpenButton==true||SystemMenu.clickOpen==true) {
				newbutton.setEnabled(false);
		}

		
		return newbutton;
	}
	
	private JButton prepareBackButton() {
		JButton back = new JButton("Back");
		back.setBounds(290, 500, 95, 30);
		back.setName("btnBack");
		back.addActionListener(new BackButtonActionListener());

		if (SystemMenu.dataListRecordChange==true) {
			back.setEnabled(false);
		}
		else {
			back.setEnabled(true);
		}
		return back;
	}
	
	class SaveButtonActionListener implements ActionListener{
		
		private SimpleHandler simpleHandler;
		private List<SimpleRecord> dataList;
		private Map<String, String> headerValues;
		private JFrame jFrame;
		
		public SaveButtonActionListener(JFrame jFrame, SimpleHandler simpleHandler, List<SimpleRecord> dataList, Map<String, String> headerValues, Boolean clearWhenSaved) {
			this.simpleHandler = simpleHandler;
			this.dataList = dataList;
			this.headerValues = headerValues;
			this.jFrame = jFrame;
		}
		
		public void actionPerformed(ActionEvent e) {
			String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
			String fileName = simpleHandler.getFileName();
			String filePath = simpleHandler.getFilePath(dataList, headerValues);
			File outputFile = new File(filePath , fileName);
			File outputDir = new File(filePath);
			String fileNameCopy = simpleHandler.getCopyFileName();
			File previousFile = new File(filePath , fileNameCopy);
			
			if (dataList.size() == 0) {
				JOptionPane optionPane2 = new JOptionPane("There is not any records can save", JOptionPane.ERROR_MESSAGE);
				JDialog dialog2 = optionPane2.createDialog("Failure");
				dialog2.setAlwaysOnTop(true);
				dialog2.setVisible(true);
				
				return;
			}
			
			int diaConfirmSave = JOptionPane.showConfirmDialog(null,
					"Do you want to save these records?" + 
					(outputFile.exists() ? "   You have existing file already." : ""),		
					"Select an Option...",
					JOptionPane.YES_NO_OPTION);
			
			if (diaConfirmSave != 0)
				return;
			
			if (!outputDir.exists()) {
				outputDir.mkdirs();
			}
			SystemMenu.dataListRecordChange=false;
			SystemMenu.saveDisable=true;
			SystemMenu.checkNewOpenButton=true;
			if(SystemMenu.clickOpen==true) {
				File deletePerviousFiles = new File(SystemMenu.deleteOpenFilePath);
				deletePerviousFiles.delete();
			}
			else {
				if (outputFile.exists()) {
					try {
						Files.copy(outputFile.toPath(), previousFile.toPath());
					} catch (IOException e1) {
						e1.printStackTrace();
					}
					previousFile.renameTo(new File(outputDir + "\\" + previousFile.getName() + timeStamp));
				}
			}
			try {
				SystemMenu.checkSaveStatus = "true";
				FileWriter fw = new FileWriter(outputFile);
				for (SimpleRecord simpleRecord : dataList) {
					fw.append(simpleRecord.parseToString());
					fw.append("\r\n");
				}
				fw.close();
				System.out.println("Saved to "+outputFile.getAbsolutePath());
				
				dataList.clear();
				
				jFrame.setVisible(false);
				jFrame.getContentPane().removeAll();

				SimpleOptionMenu simpleOptionMenu = new SimpleOptionMenu(jFrame, selectedSystem, selectedOnlineFunctionId, dataList, simpleHandler, false);
				simpleOptionMenu.draw();
				
				jFrame.setContentPane(simpleOptionMenu);
				Dimension preferredSize = new Dimension(700, 700);
				jFrame.setPreferredSize(preferredSize);
				jFrame.setBounds(700, 200, 700, 700);
				jFrame.setLocationRelativeTo(null);
				SwingUtilities.updateComponentTreeUI(jFrame);
				jFrame.pack();
				jFrame.setVisible(true);
				jFrame.invalidate();
				jFrame.validate();
				jFrame.repaint();
				
			} catch (IOException iox) {
				iox.printStackTrace();
				System.out.println("File can not save any data");
			}
			
		}
		
	}
	
	class BackButtonActionListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			if (dataList.size() < SystemMenu.Recordlimited) {
				SystemMenu.checkLogData.add("Click in " + selSysFncId + " (OptionMenu) (Back) button");
			}


				jFrame.dispose();
				try {
					new SystemMenu(selectedSystem);
				} catch (IOException e1) {
					System.out.println("Problem occurs when get Action Command!");
					e1.printStackTrace();
				}
			
		}
	}


	class OpenButtonActionListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			if (dataList.size() < SystemMenu.Recordlimited) {
				SystemMenu.checkLogData.add("Click in " + selSysFncId + " (OptionMenu) (Open) button");
			}
			jFrame.setVisible(false);
			jFrame.getContentPane().removeAll();
			SimpleOptionOpen soo = new SimpleOptionOpen(jFrame, selectedSystem, selectedOnlineFunctionId, dataList, simpleHandler);
			soo.draw();
			jFrame.setContentPane(soo);
			Dimension preferredSize = new Dimension(700, 700);
			jFrame.setPreferredSize(preferredSize);
			jFrame.setBounds(700, 200, 700, 700);
			jFrame.setLocationRelativeTo(null);
			SwingUtilities.updateComponentTreeUI(jFrame);
			jFrame.pack();
			jFrame.setVisible(true);
			jFrame.invalidate();
			jFrame.validate();
			jFrame.repaint();

		}
	}
	
	class NewButtonActionListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			if (dataList.size() < SystemMenu.Recordlimited) {
				SystemMenu.checkLogData.add("Click in " + selSysFncId + " (OptionMenu) (New) button");
			}
			
				
				// open another window
				setVisible(false);
				removeAll();
				SimpleOptionNew son = new SimpleOptionNew(jFrame, selectedSystem, selectedOnlineFunctionId, dataList, simpleHandler);
				son.draw();
				jFrame.setContentPane(son);
				Dimension preferredSize = new Dimension(700, 700);
				jFrame.setPreferredSize(preferredSize);
				jFrame.setBounds(700, 200, 700, 700);
				jFrame.setLocationRelativeTo(null);
				SwingUtilities.updateComponentTreeUI(jFrame);
				jFrame.pack();
				jFrame.setVisible(true);
				jFrame.invalidate();
				jFrame.validate();
				jFrame.repaint();

			
		}
	}

	
	
}
