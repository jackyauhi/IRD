package layout.simple;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.nio.file.Files;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;

import layout.SystemMenu;

public class SimpleOptionOpen extends JPanel {
	private static final long serialVersionUID = 2L;
	// JFrame f;
	private String selectedOnlineFunctionId;
//	public OptionOpen optionOpen;
//	public OptionNew optionNew;
	private JTextField tfBrowseUri;

	private JFrame jFrame;
	private List<SimpleRecord> dataList;
	private String selectedSystem;
	private SimpleHandler simpleHandler;

	public SimpleOptionOpen(JFrame jFrame, String selectedSystem, String selectedOnlineFunctionId,
			List<SimpleRecord> _dataLists, SimpleHandler simpleHandler) {

		this.selectedSystem = selectedSystem;
		this.jFrame = jFrame;
		this.dataList = _dataLists;
		this.selectedOnlineFunctionId = selectedOnlineFunctionId;
		this.simpleHandler = simpleHandler;
	}

	public void draw() {
		
		JLabel topic = new JLabel(selectedSystem + " Menu", SwingConstants.CENTER);
		Border border = BorderFactory.createLineBorder(Color.BLACK, 3);
		JLabel header = new JLabel(selectedOnlineFunctionId, SwingConstants.CENTER);
		Border headerborder = BorderFactory.createLineBorder(Color.BLACK, 2);
		
		header.setBounds(150, 70, 400, 30);
		header.setFont(new Font("Serif", Font.PLAIN, 15));
		header.setBorder(headerborder);
		topic.setBounds(90, 20, 500, 40);
		topic.setFont(new Font("Serif", Font.PLAIN, 30));
		topic.setBorder(border);
		tfBrowseUri = new JTextField();
		add(header);
		add(topic);
		add(prepareBrowseButton());
		add(prepareBackButton());
		add(prepareLoadButton());
		add(tfBrowseUri);
		
		setBounds(700, 200, 700, 700);
		setLayout(null);
		setVisible(true);
		
		tfBrowseUri.setBounds(150, 250, 180, 30);
		String openFileName = simpleHandler.getFileName();
		String openFilePath = simpleHandler.getFilePath(null, null);
		System.out.println("Default path "+openFilePath);
		
		File openFile = new File(openFilePath, openFileName);
		tfBrowseUri.setText(SystemMenu.openFilePath == "" ? openFile.getAbsolutePath() : SystemMenu.openFilePath);


	}
	
	private JButton prepareLoadButton() {
		JButton btnLoad = new JButton("Continue to Scan");
		SystemMenu.clickOpen=true;
		btnLoad.setBounds(250, 450, 180, 30);
		btnLoad.addActionListener(new LoadButtonActionListener());
		return btnLoad;
	}
	
	private JButton prepareBrowseButton() {
		JButton browse = new JButton("Browse");
		browse.setBounds(350, 250, 180, 30);
		browse.addActionListener(new BrowseButtonActionListener());
		
		return browse;
	}
	
	private JButton prepareBackButton() {
		JButton back = new JButton("Back");
		back.setBounds(250, 500, 180, 30);
		back.addActionListener(new BackButtonActionListener());
		return back;
	}
	
	private class LoadButtonActionListener implements ActionListener{
		@SuppressWarnings("unchecked")
		public void actionPerformed(ActionEvent e) {
			SystemMenu.deleteOpenFilePath=tfBrowseUri.getText();
			File loadFile = new File(tfBrowseUri.getText());
			if (!loadFile.exists()) {	
				JOptionPane optionPane2 = new JOptionPane(
						"You do not have this file. Please check your file path again.",
						JOptionPane.ERROR_MESSAGE);
				JDialog dialog2 = optionPane2.createDialog("Failure");
				dialog2.setAlwaysOnTop(true);
				dialog2.setVisible(true);
				return;
			}
			
			dataList.clear();
			String content = "";
			try {
				content = new String(Files.readAllBytes(loadFile.toPath()));
				dataList = simpleHandler.loadFromFile(loadFile);
			}catch(Exception exception) {
    			JOptionPane optionPane2 = new JOptionPane("Some Data's length is not correct. Please check the file again. Here is the incorrect data "+content, JOptionPane.ERROR_MESSAGE);    
				JDialog dialog2 = optionPane2.createDialog("Failure");
				dialog2.setAlwaysOnTop(true);
				dialog2.setVisible(true);
				return;
			}
			
			// open another window
			setVisible(false);
			removeAll();
			SimpleOptionNew son = new SimpleOptionNew(jFrame, selectedSystem, selectedOnlineFunctionId, dataList, simpleHandler);
			son.draw();
			jFrame.setContentPane(son);
			Dimension preferredSize = new Dimension(700, 700);
			jFrame.setPreferredSize(preferredSize);
			jFrame.setBounds(700, 200, 700, 700);
			jFrame.setLocationRelativeTo(null);
			SwingUtilities.updateComponentTreeUI(jFrame);
			jFrame.pack();
			jFrame.setVisible(true);
			jFrame.invalidate();
			jFrame.validate();
			jFrame.repaint();
		}
	}
	
	private class BrowseButtonActionListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			JFileChooser fileChooser = new JFileChooser();
			fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
			int result = fileChooser.showOpenDialog(null);

			if (result != JFileChooser.APPROVE_OPTION) {
				return;
			}

			File selectedFile = fileChooser.getSelectedFile();
			tfBrowseUri.setText(selectedFile.getAbsolutePath());
			SystemMenu.openFilePath = selectedFile.getAbsolutePath();
			SystemMenu.deleteOpenFilePath= selectedFile.getAbsolutePath();
		}
	}
	
	private class BackButtonActionListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			jFrame.setVisible(false);
			jFrame.getContentPane().removeAll();
			
			SimpleOptionMenu simpleOptionMenu = new SimpleOptionMenu(jFrame, selectedSystem, selectedOnlineFunctionId, dataList, simpleHandler, false);
			simpleOptionMenu.draw();
			
			jFrame.setContentPane(simpleOptionMenu);
			Dimension preferredSize = new Dimension(700, 700);
			jFrame.setPreferredSize(preferredSize);
			jFrame.setBounds(700, 200, 700, 700);
			jFrame.setLocationRelativeTo(null);
			SwingUtilities.updateComponentTreeUI(jFrame);
			jFrame.pack();
			jFrame.setVisible(true);
			jFrame.invalidate();
			jFrame.validate();
			jFrame.repaint();

		}
	}

}
