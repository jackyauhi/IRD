package layout;

import javax.swing.JPanel;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.font.TextAttribute;
import java.awt.print.PageFormat;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.IOException;
import java.io.InputStream;
import java.text.MessageFormat;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Vector;

public class Report extends JPanel {

	public JFrame f;
	public Report Report;
	String[][] passOptionNewTextFieldValue;
	int[] marks;
	int headerno;
	String getPropertiesValue;
	String getTopicValue;
	String getHearderValue;
	List timerScanData;
	JButton print;

	/**
	 * Create the panel.
	 */
	public Report(List timerScanData, String passOptionNewTextFieldValue[][], int headerno ,int marks[]) {
		this.Report = this;
		this.timerScanData = timerScanData;
		this.passOptionNewTextFieldValue = passOptionNewTextFieldValue;
		this.headerno = headerno;
		this.marks = marks;
		f = new JFrame("Report");
		getTopicValue = SystemMenu.passTopicValue;
		getHearderValue = OptionMenu.passHeaderValue;
		// get the value to define different button click action
		getPropertiesValue = getTopicValue.replaceAll("\\s", "")
				+ getHearderValue.replaceAll("\\s", "");

		String filePath = "resources/allOptionJava.properties";
		Properties prop = new Properties();
		setLayout(new BorderLayout(0, 0));

		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout(0, 0));

		JPanel panel_1 = new JPanel();
		panel.add(panel_1, BorderLayout.SOUTH);
		panel_1.setLayout(new BorderLayout(0, 0));

		JPanel panel_2 = new JPanel();
		panel.add(panel_2, BorderLayout.NORTH);
		panel_2.setLayout(new BorderLayout(0, 0));
		JPanel panelheader = new JPanel();
		panelheader.setLayout(new BorderLayout(0, 0));
		// report border
		JLabel label0 = new JLabel(
				"*****************************************************************");
		label0.setHorizontalAlignment(SwingConstants.CENTER);
		JLabel label1 = new JLabel(
				"-------------------------------------------------------------------------------------------------");
		label1.setHorizontalAlignment(SwingConstants.CENTER);
		JLabel label2 = new JLabel(
				"*****************************************************************");
		label2.setHorizontalAlignment(SwingConstants.CENTER);
		JLabel label3 = new JLabel(
				"-------------------------------------------------------------------------------------------------");
		label3.setHorizontalAlignment(SwingConstants.CENTER);
		
		// report item
		print = new JButton("Print");
		panel_2.add(label0, BorderLayout.NORTH);
		panel_2.add(label1, BorderLayout.CENTER);
		panel_1.add(print, BorderLayout.NORTH);
		panel_1.add(label3, BorderLayout.CENTER);
		panel_1.add(label2, BorderLayout.SOUTH);

		JPanel panel_3 = new JPanel(new BorderLayout(0, 0));

		
		// report header
		JLabel lblRecordsSummaryReport = new JLabel("Records Summary Report");
		lblRecordsSummaryReport.setFont(new Font("�s�ө���", Font.BOLD, 12));
		lblRecordsSummaryReport.setHorizontalAlignment(SwingConstants.CENTER);
		JLabel topic = new JLabel(getTopicValue + " Menu",
				SwingConstants.CENTER);
		JLabel header = new JLabel(getHearderValue, SwingConstants.CENTER);
		panelheader.add(topic, BorderLayout.NORTH);
		panelheader.add(header, BorderLayout.CENTER);
		panelheader.add(lblRecordsSummaryReport, BorderLayout.SOUTH);
		
		
		// show report header when print
		final MessageFormat printingHeader = new MessageFormat("Records Summary Report");
		final MessageFormat printingBottom = new MessageFormat(getPropertiesValue);
		
		// report data
		try (InputStream inputStream = MainMenu.class.getClassLoader()
				.getResourceAsStream(filePath)) {

			// Loading the properties.
			prop.load(inputStream);
			String num = prop.getProperty(getPropertiesValue + ".NUM");
			int numOfButton = Integer.parseInt(num);
			
			String[] label = new String[numOfButton + 1];
			String[][] labelData = new String[headerno+1][numOfButton + 1];

			

			// set column
			for (int i = 0; i <= numOfButton; i++) {
				if (i != numOfButton) {
					label[i] = prop.getProperty(getPropertiesValue
							+ ".00" + (i + 1));
				} else {
					label[i] = "Total No. of Records:";
				}

			}
			
			int size = 0;
    		if (getPropertiesValue.equals("CTRNoteReceiptCTRAdviceLetter")||getPropertiesValue.equals("PFNoteReceiptPFReturn(BIR51/BIR52)")){
    			for (int i = 0; i < headerno; i++){
    				size += marks[i];
    			}
    		}
    		else
    		{
    			size = timerScanData.size();
    		}


			
			// set data
			for (int j = 0; j < headerno; j++){
			for (int i = 0; i < numOfButton; i++) {
				labelData[j][i] = passOptionNewTextFieldValue[i][j];
			}
			
    		if (getPropertiesValue.equals("CTRNoteReceiptCTRAdviceLetter")||getPropertiesValue.equals("PFNoteReceiptPFReturn(BIR51/BIR52)")){
    			labelData[j][numOfButton] =  Integer.toString(marks[j]);
    		}
    		else
    		{
    			labelData[j][numOfButton] =  Integer.toString(size);
    		}
    		

			}
			labelData[headerno][numOfButton] =  Integer.toString(size);
			
			//set Table with scroll
			final JTable table = new JTable(labelData, label);
			table.setEnabled(false);
			JScrollPane scroll = new JScrollPane(table);
			scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
			scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			scroll.setPreferredSize(new Dimension(400, 300));
			table.getTableHeader().setReorderingAllowed(false);
			table.getTableHeader().setResizingAllowed(false);
			panel_2.add(panelheader, BorderLayout.SOUTH);
			panel.add(scroll, BorderLayout.CENTER);
			
			// set and show the container frame
			Dimension preferredSize = new Dimension(numOfButton * 200, 400);
			f.setPreferredSize(preferredSize);
			f.setBounds(700, 200, numOfButton * 200, 400);
			f.setLocationRelativeTo(null);
			f.pack();
			f.setContentPane(panel);
			f.setVisible(true);

			// print report
			print.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					try {
						table.print(JTable.PrintMode.FIT_WIDTH, printingHeader, printingBottom);
					} catch (PrinterException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			});

		} catch (IOException ex) {

			System.out.println("Problem occurs when reading file !");
			ex.printStackTrace();
		}
	}

}
