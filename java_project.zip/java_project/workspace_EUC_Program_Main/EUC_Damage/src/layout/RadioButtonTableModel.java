package layout;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.table.AbstractTableModel;

@SuppressWarnings("serial")
public class RadioButtonTableModel extends AbstractTableModel implements PropertyChangeListener {

	private final RadioButtonObjectManager manager;
	
	public RadioButtonTableModel(RadioButtonObjectManager manager) {
		super();
        this.manager = manager;
        manager.propertyChangeSupport.addPropertyChangeListener(this);
        for (RadioButtonObject object : manager.getObjects()) {
            object.getPropertyChangeSupport().addPropertyChangeListener(this);
        }			
	}
	
	@Override
	public int getRowCount() {
		// TODO Auto-generated method stub
		return manager.getObjects().size();
	}

	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return manager.getColumnCount() + 1;
	}
	
	public RadioButtonObject getValueAt(int rowIndex) {
		return manager.getObjects().get(rowIndex);
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		// TODO Auto-generated method stub
		RadioButtonObject object = getValueAt(rowIndex);
		if (columnIndex == 0)
			return object.isSelected();
		else
			return object.getValueAt(columnIndex - 1);
	}
	
	@Override
	public void setValueAt(Object value, int rowIndex, int columnIndex) {
		if (columnIndex == 0) {
			getValueAt(rowIndex).setSelected(Boolean.TRUE.equals(value));
		}
	}
	
	@Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		return columnIndex == 0;
	}

	@Override
	public Class<?> getColumnClass(int columnIndex) {
		switch (columnIndex) {
			case 0:
				return Boolean.class;
			default:
				return String.class;
		}
	}
	
	@Override
	public String getColumnName(int columnIndex) {
		if (columnIndex == 0)
			return "";
		else
			return manager.getColumnNames()[columnIndex - 1];
	}

	@Override
	public void propertyChange(PropertyChangeEvent evt) {
		// TODO Auto-generated method stub
		if (evt.getSource() == manager) {
			// OK, not the cleanest thing, just to get the list of it.
			if (evt.getPropertyName().equals("objects")) {
				((RadioButtonObject) evt.getNewValue()).getPropertyChangeSupport().addPropertyChangeListener(this);
			}
			fireTableDataChanged();
		} else if (evt.getSource() instanceof RadioButtonObject) {
			int index = manager.getObjects().indexOf(evt.getSource());
			fireTableRowsUpdated(index, index);
		}
	}
}
