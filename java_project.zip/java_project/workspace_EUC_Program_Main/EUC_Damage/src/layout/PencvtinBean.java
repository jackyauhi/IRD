package layout;

public class PencvtinBean {
	
	private String prn;
	private String tin;
	private String rtnCode;

	public String getPrn() {
		return prn;
	}

	public void setPrn(String prn) {
		this.prn = prn;
	}

	public String getTin() {
		return tin;
	}

	public void setTin(String tin) {
		this.tin = tin;
	}

	public String getRtnCode() {
		return rtnCode;
	}

	public void setRtnCode(String rtnCode) {
		this.rtnCode = rtnCode;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("PencvtinBean [prn=").append(prn).append(", tin=")
				.append(tin).append(", rtnCode=").append(rtnCode).append("]");
		return builder.toString();
	}

}
