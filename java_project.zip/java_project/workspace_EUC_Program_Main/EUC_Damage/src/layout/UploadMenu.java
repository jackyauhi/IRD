package layout;

import javax.swing.*;
import javax.swing.border.Border;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowListener;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class UploadMenu {
	JFrame f;
	
	
    public static void main(String[] args) {
    	
		new MainMenu();
        
    }
     public UploadMenu() {
	
    	String filePath = "resources/system.properties";
 		Properties prop = new Properties();
 	    //button group	
 		JButton main = new JButton("Main");
     	f=new JFrame("UPLOAD Menu");
     	JLabel topic = new JLabel("UPLOAD Menu" , SwingConstants.CENTER);
         Border border = BorderFactory.createLineBorder(Color.BLACK, 3);

			//load the file path
 		try (InputStream inputStream = MainMenu.class.getClassLoader().getResourceAsStream(filePath)) {

 	         
 			// Loading the properties.
 			prop.load(inputStream);
 			
	         String num= prop.getProperty("system.NUM");
		     int numOfButton = Integer.parseInt(num);
		     int UploadMenuNumOfButton=numOfButton-1; // load the same Properties so button will less than MainMenu
		     
	         JButton[] bt= new JButton[UploadMenuNumOfButton];
 		
	         // Getting properties
 			for (int i = 0; i <UploadMenuNumOfButton ; i++){
 				bt[i] = new JButton(prop.getProperty("system.00"+(i+1)));
 				//String str = prop.getProperty("system.00"+(i+1));

 				
 						
 			if (i%2 == 0)
 			{
 				bt[i].setBounds(200,(150 + i*30),95,30);
 			}
 			else
 			{
 				int j=i-1; // set to let the row position equal
 				
 				bt[i].setBounds(380,(150 + j*30),95,30);
 			}
 			f.getContentPane().add(bt[i]);
 			bt[i].addActionListener( new ActionListener()
 	        {
 	            public void actionPerformed(ActionEvent e)
 	            {

 	            	f.dispose();
 	            	try {
 	            		
 	            		
						new UploadSystemMenu(e.getActionCommand());//get button information
					} catch (IOException e1) {
						
						System.out.println("Problem occurs when get Action Command!");
						e1.printStackTrace();
						
					}
 	            }
 	        });

 			}			
 			
 		} catch (IOException ex) {
 			
 			System.out.println("Problem occurs when reading file !");
 			ex.printStackTrace();
 		} 

 		topic.setBounds(90,20,500,40);
         topic.setFont(new Font("Serif", Font.PLAIN, 30));
         topic.setBorder(border);
         
        
         main.setBounds(290,500,95,30);
         
         
         f.getContentPane().add(topic);
         
         f.setBounds(700,200,700,700);
         f.setLocationRelativeTo(null);
         f.getContentPane().add(main);
         f.getContentPane().setLayout(null);
         f.setVisible(true);  
         main.addActionListener( new ActionListener()
         {
             public void actionPerformed(ActionEvent e)
             {
            	 f.dispose();
            	 new MainMenu();
             }
         });
	
	}

    
    
}
