package layout;

import java.beans.PropertyChangeSupport;
import java.util.ArrayList;
import java.util.List;

public class RadioButtonObjectManager {
	
	protected PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(this);
	private List<RadioButtonObject> objects = new ArrayList<RadioButtonObject>();
	private String[] columnNames;
	
	public RadioButtonObjectManager(String[][] data, String[] columnNames) {
		
		this.columnNames = columnNames;
		for (int i = 0; i < data.length; i++) {
			RadioButtonObject obj = new RadioButtonObject(data[i]);
			addObject(obj);
		}
	}

	public void addObject(RadioButtonObject object) {
		objects.add(object);
		object.setManager(this);
		propertyChangeSupport.firePropertyChange("objects", null, object);
    }
	
	public List<RadioButtonObject> getObjects() {
        return objects;
    }
	
	public void setAsSelected(RadioButtonObject object) {
        for (RadioButtonObject o : objects) {
            o.setSelected(object == o);
        }
    }
	
	public String[] getColumnNames() {
		return columnNames;
	}

	public void setColumnNames(String[] columnNames) {
		this.columnNames = columnNames;
	}

	public int getColumnCount() {
		
		if (objects.size() > 0) {
			return objects.get(0).getSize();
		}
		return 0;
	}
}
