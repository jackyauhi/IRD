package layout.listener;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import javax.swing.JDialog;
import javax.swing.JOptionPane;

import layout.SystemMenu;
import layout.simple.SimpleHandler;
import layout.simple.SimpleRecord;

public class SaveButtonActionListener implements ActionListener{
	
	private SimpleHandler simpleHandler;
	private List<SimpleRecord> dataList;
	private Map<String, String> headerValues;

	
	public SaveButtonActionListener(SimpleHandler simpleHandler, List<SimpleRecord> dataList, Map<String, String> headerValues, Boolean clearWhenSaved) {
		this.simpleHandler = simpleHandler;
		this.dataList = dataList;
		this.headerValues = headerValues;

	}
	
	public void actionPerformed(ActionEvent e) {
		String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
		String fileName = simpleHandler.getFileName();
		String filePath = simpleHandler.getFilePath(dataList, headerValues);
		File outputFile = new File(filePath , fileName);
		String fileNameCopy = simpleHandler.getCopyFileName();
		File previousFile = new File(filePath , fileNameCopy);
		File outputDir = new File(filePath);
		
		if (dataList.size() == 0) {
			JOptionPane optionPane2 = new JOptionPane("There is not any records can save", JOptionPane.ERROR_MESSAGE);
			JDialog dialog2 = optionPane2.createDialog("Failure");
			dialog2.setAlwaysOnTop(true);
			dialog2.setVisible(true);
			
			return;
		}
		
		int diaConfirmSave = JOptionPane.showConfirmDialog(null,
				"Do you want to save these records?" + 
				(outputFile.exists() ? "   You have existing file already." : ""),		
				"Select an Option...",
				JOptionPane.YES_NO_OPTION);
		
		if (diaConfirmSave != 0)
			return;
		
		if (!outputDir.exists()) {
			outputDir.mkdirs();
		}
		SystemMenu.dataListRecordChange=false;
		SystemMenu.saveDisable=true;
		SystemMenu.checkNewOpenButton=true;
		FileWriter fw;
		if(SystemMenu.clickOpen==true) {
			File deletePerviousFiles = new File(SystemMenu.deleteOpenFilePath);
			deletePerviousFiles.delete();
		}
		else {
			if (outputFile.exists()) {
				try {
					Files.copy(outputFile.toPath(), previousFile.toPath());
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				previousFile.renameTo(new File(outputDir + "\\" + previousFile.getName() + timeStamp));
			}
			
		}
		try {
			SystemMenu.checkSaveStatus = "true";
			if(SystemMenu.clickOpen==true) 
				fw = new FileWriter(outputFile+timeStamp);
			else
				fw = new FileWriter(outputFile);
			for (SimpleRecord simpleRecord : dataList) {
				fw.append(simpleRecord.parseToString());
				fw.append("\r\n");
			}
			fw.close();
			System.out.println("Saved to "+outputFile.getAbsolutePath());

		} catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data");
		}

		dataList.clear();
		
	}
}