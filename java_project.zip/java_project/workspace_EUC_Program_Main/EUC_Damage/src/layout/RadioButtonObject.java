package layout;

import java.beans.PropertyChangeSupport;

public class RadioButtonObject {
	 
	private PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(this);
	private RadioButtonObjectManager manager;
	private String[] values;
	private boolean selected;

	public RadioButtonObject(String[] values) {
		this.values = values;
	}
	
	public PropertyChangeSupport getPropertyChangeSupport() {
		return propertyChangeSupport;
	}
	
	public String getValueAt(int i) {
		return values[i];
	}
	
	public void setValueAt(String value, int i) {
		this.values[i] = value;
		propertyChangeSupport.firePropertyChange("value", null, value);
	}
	
	public int getSize() {
		return (values != null) ? values.length : 0;
	}
	
	public RadioButtonObjectManager getManager() {
		return manager;
	}
	
	public void setManager(RadioButtonObjectManager manager) {
		this.manager = manager;
		propertyChangeSupport.firePropertyChange("manager", null, manager);
	}

	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		if (this.selected != selected) {
			this.selected = selected;
			if (selected) {
				manager.setAsSelected(this);
			}
			propertyChangeSupport.firePropertyChange("selected", !selected, selected);
		}
	}
}
