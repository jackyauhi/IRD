package layout;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileReader;
//import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
//import java.nio.file.StandardCopyOption;
import java.util.Properties;

import javax.swing.*;
import javax.swing.border.Border;

import layout.simple.SimpleHandler;
//import layout.simple.SimpleOptionMenu;
public class UploadSystemMenu {
	
	
	public JFrame f;
	Properties prop;
	String onlineFctID;
	String getPropertiesValue;
	
	public UploadSystemMenu(final String onlineFctID) throws IOException {
		//get the value from the MainMenu action command
		this.onlineFctID = onlineFctID;
		
		
   	    //String filePath = "resources/uploadsystemmenu.properties";
   	    
   	    String filePath = System.getProperty("uploadSystemMenuProp");
   	    
		prop = new Properties();
		try (InputStream inputStream = MainMenu.class.getClassLoader().getResourceAsStream(filePath)) {
			
			// Loading the properties.
			prop.load(inputStream);	
			
			String num= prop.getProperty(onlineFctID+".NUM");
			
			
			
			//layout and button group
			JButton back = new JButton("Back");
			f = new JFrame(onlineFctID);
			f.setBounds(700,200,700,700);
			f.setLocationRelativeTo(null);
			f.setVisible(true);
		    f.getContentPane().add(back);
			f.getContentPane().setLayout(null);			
			JLabel topic = new JLabel("Upload "+onlineFctID+" Menu" , SwingConstants.CENTER);
			Border border = BorderFactory.createLineBorder(Color.BLACK, 3);
			topic.setBounds(90,20,500,40);
			topic.setFont(new Font("Serif", Font.PLAIN, 30));
			topic.setBorder(border);
			f.getContentPane().add(topic);
			
			back.setBounds(290,500,95,30);
			back.addActionListener( new ActionListener()
			    {
			        public void actionPerformed(ActionEvent e)
			        {
			        	
			        	f.dispose();
		            	new UploadMenu();
			        }
			    });    
			

			    	int numOfButton = Integer.parseInt(num);
			    	JButton[] bt= new JButton[numOfButton]; 
			
 			
 				
 					for (int i = 0; i <numOfButton; i++){
 	 				bt[i] = new JButton(prop.getProperty(onlineFctID+".00"+(i+1)));
 	 				bt[i].setBounds(140,(100 + i*50),405,30); 	
 	 				f.getContentPane().add(bt[i]);
 		 	 	 		
 		 	 	 			bt[i].addActionListener( new ActionListener()
 		 	 	 			{
 		 	 	 			
 		 	 	            public void actionPerformed(ActionEvent e)
 		 	 	            		{
 		 	 	            //get the value to define different button click action
 		 	 	 			getPropertiesValue = onlineFctID.replaceAll("\\s", "") + e.getActionCommand().replaceAll("\\s", "");
 		 	 	 		
	 		 	 	 			String selectedSystem = onlineFctID;
	 		 	 	 			String selSysFncId = getPropertiesValue;

		 		 	 	 		Properties allProperties = new Properties();
	
		 		 	 	 	File resourceFolder = new File("./resources");
		 			        	try {
		 		    			    for (File nextFile : resourceFolder.listFiles()) {
		 		    			    	System.out.println(nextFile);
		 		    			    	
		 		    			    	if (!nextFile.getName().endsWith(".properties"))
		 		    			    		continue;
		 		    			    	
		 		    			    	Properties singleProperties = new Properties();
		 		    			    	singleProperties.load(new FileReader(nextFile));
		 		    			    	allProperties.putAll(singleProperties);
		 		    			    }
		 	            		}catch(Exception ex) {ex.printStackTrace();}
		 			        	
		 			    		SimpleHandler simpleHandler = null;
		 	 	            	if (allProperties.get(selSysFncId+".model") != null){
		 	 	            		try {
		 	 	            			String modelName = (String) allProperties.get(selSysFncId+".model");
		 	 	            			String customHandler = "layout."+selectedSystem.replaceAll("\\s", "").toLowerCase()+"."+modelName.toLowerCase()+"."+modelName;
		
		 	 	            			simpleHandler = (SimpleHandler) Class.forName(customHandler+"Handler").newInstance(); 
		 	 	            		}catch(Exception ex) {ex.printStackTrace();}
		 	 	            	}
		 	 	            	if (simpleHandler != null) {
		 	 	            		simpleHandler.uploadData();
		 	 	            	}else {
		 	 	            		
	 	 	            		//get the value from property
 				        		 String aimFolderFilePath = new String(prop.getProperty(getPropertiesValue+".AimFolderFilePath"));
 				        		 String oldFileFilePath = new String(prop.getProperty(getPropertiesValue+".OldFileFilePath"));
				        		 String fileName = new String(prop.getProperty(getPropertiesValue+".FileName"));
 				        		 String fileNameCopy = new String(prop.getProperty(getPropertiesValue+".FileNameCopy"));
 				        		 String oldFileNameBak = new String(prop.getProperty(getPropertiesValue+".OldFileName"));
		        		
 		 	 	          //   File aimFolder = new File("L:/FU6/2.EUC Saving file");
 		 	 	         //    File oldFile = new File("D:/2.EUC Saving file/thetextfile.txt");
 		 	 	        //     File oldFilecopy = new File("D:/2.EUC Saving file/thetextfile23571283756372.txt");
 		 	 	         //   File aimFolderFileExists = new File("L:/FU6/2.EUC Saving file/thetextfile.txt");
 		 	 	        //  File aimFolder = new File("T:/jackyau/2.EUC Saving file");
 		 	 	     //  File aimFolderFileExists = new File("T:/jackyau/2.EUC Saving file/thetextfile.txt");
 				        		 
 				        	  File aimFolder = new File(aimFolderFilePath);
 	 		 	 	          File oldFile = new File(oldFileFilePath+fileName);
 	 		 	 	          File oldFilecopy = new File(oldFileFilePath+fileNameCopy);
 	 		 	 	          File aimFolderFileExists = new File(aimFolderFilePath+fileName);
 	 		 	 	          File oldFilePath = new File(oldFileFilePath);
 	 		 	 	          File bakFileName = new File(oldFileFilePath+oldFileNameBak);
 				        		 
 		 	 	             
 		 	 	             	if (aimFolder.exists()){
 		 	 	             		
 		 	 	             	}
 		 	 	             	else{
 		 	 	             		aimFolder.mkdirs();
 		 	 	             	}
 		 	 	             	if (oldFile.exists()){
 		 	 	             			oldFilecopy.delete();
 		 	 	             			//aimFolderFileExists.delete();
 		 	 	             			bakFileName.delete();
 		 	 	             		if(aimFolderFileExists.exists()){
 		 	 	             		JOptionPane.showMessageDialog(null,"File already existed in Upload folder.  Please proceed manually if needed.");
 		 	 	             				}
 		 	 	             		else{
 		 	 	             			try {
 		 	 	             				Files.copy(oldFile.toPath(), oldFilecopy.toPath());
 		 	 	             			} catch (IOException e1) {
 		 	 	             				// TODO Auto-generated catch block
 		 	 	             				e1.printStackTrace();
 		 	 	             					}
 		 	 	             				oldFilecopy.renameTo(new File(aimFolder + "\\" + oldFile.getName()));
 		 	 	             				oldFile.renameTo(new File(oldFilePath + "\\" + oldFileNameBak));
 		 	 	             			JOptionPane.showMessageDialog(null,"Upload successfully");
 		 	 	             		}
 		 	 	             		}

 		 	 	             		
 		 	 	             	else{
 		 	 	             			System.out.println(oldFile + "  File does not exists");
 		 	 	             		JOptionPane.showMessageDialog(null,oldFile+ "  File does not exists.");
 		 	 	             			}
 	
	 		 	 	           }
		 	 	            	}
 		 	 	 			
 		 	 	 			
 		 	 	 				 
 		 	 	 	  });
 		 	 	 		
 		 	 	 		
 		 	 	 		
 		 	 	 		
 		 			} 					
 					
 					
 					
 					
 					
 					
 					
 					
 					
 					
 			}
				catch (IOException ex) {
			
					System.out.println("Problem occurs when reading file !");
					ex.printStackTrace();
		} 
 				
 				
	}

	


	
}