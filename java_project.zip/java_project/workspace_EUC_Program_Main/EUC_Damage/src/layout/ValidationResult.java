package layout;

/**
 * 
 * @author ycwang
 * 
 *
 *
 ******************************************************************************
 * Amendment log
 * -------------
 * 
 * Ref no.    Date       Amended by     Description
 * -------  ----------   ----------     ---------------------------------------
 *                                                                                     
 ******************************************************************************
 */

public class ValidationResult {
	
	boolean success;
	String formattedValue;
	int rtnCode;
	String errorCode;
	String[] msgParams;
	
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	public String getFormattedValue() {
		return formattedValue;
	}
	public void setFormattedValue(String formattedValue) {
		this.formattedValue = formattedValue;
	}
	public int getRtnCode() {
		return rtnCode;
	}
	public void setRtnCode(int rtnCode) {
		this.rtnCode = rtnCode;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String[] getMsgParams() {
		return msgParams;
	}
	public void setMsgParams(String[] msgParams) {
		this.msgParams = msgParams;
	}
	
	public ValidationResult() {
		
		success = true;
		formattedValue = "";
		rtnCode = 0;
		errorCode = "";
	}
	
	public ValidationResult(boolean success, String formattedValue, int rtnCode, String errorCode) {
		
		super();
		this.success = success;
		this.formattedValue = formattedValue;
		this.rtnCode = rtnCode;
		if (success)
			this.errorCode = "";
		else
			this.errorCode = errorCode;	
	}
	
	public ValidationResult(boolean success, String formattedValue, int rtnCode, String errorCode, String[] msgParams) {
		this(success, formattedValue, rtnCode, errorCode);
		this.msgParams = msgParams;	
	}
}
