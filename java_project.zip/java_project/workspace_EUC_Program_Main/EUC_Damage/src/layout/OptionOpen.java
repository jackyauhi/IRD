package layout;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Desktop;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.net.URI;
import java.net.URISyntaxException;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;


public class OptionOpen extends JPanel {
	private static final long serialVersionUID = 2L;
	public JFrame f;
	//JFrame f;
	String getTopicValue;
	String getHearderValue;
	String getPropertiesValue;
	int getNumOfButton;
	
	public JFrame jframe;
	public OptionMenu optionMenu;
	public OptionOpen optionOpen;
	public OptionNew optionNew;
	
	String[] checkSpaceInOpenFile;
	List<String> timerScanData;
	List<String> saveTimerScanData;
	String passOptionNewTextFieldValue[][];
	int headerno;
	int marks[];
	JTextField textBrowseUri;
	Properties prop;
	String blockTimerScanData ="false";
	String status = null;
	
	String OutputData[];
	int OutputDataInt[];
	int ButtonNumber;
	String buttonNum;
	int numOfButton;
	String num;
	String[] headers;
	boolean checkPrnExist;
	
	public OptionOpen(JFrame jframe,OptionMenu optionMenu,List timerScanData,String passOptionNewTextFieldValue[][], int headerno, int marks[]) {
		this.jframe = jframe;
		optionOpen =this;
		this.optionMenu = optionMenu;
		getTopicValue = SystemMenu.passTopicValue;
		getHearderValue = OptionMenu.passHeaderValue;
		this.timerScanData=timerScanData;
		this.passOptionNewTextFieldValue=passOptionNewTextFieldValue;
		this.headerno=headerno;
		this.marks = marks;
		
		getNumOfButton = OptionNew.passNumOfButton;

	}
	public void draw(){
		checkPrnExist=false;
		blockTimerScanData ="false";
		//get the value to define different button click action
		getPropertiesValue =getTopicValue.replaceAll("\\s","")+getHearderValue.replaceAll("\\s","");
		
	    String filePath = "resources/allOptionJava.properties";
		prop = new Properties();
		try (InputStream inputStream = MainMenu.class.getClassLoader().getResourceAsStream(filePath)) {
			
			//Loading the properties.
	     	prop.load(inputStream);	
	     	
	     	// get properties value
			num = prop.getProperty(getPropertiesValue
					+ ".DetailRecordNUM");
			numOfButton = Integer.parseInt(num);
			buttonNum = prop.getProperty(getPropertiesValue + ".NUM");
			ButtonNumber = Integer.parseInt(buttonNum);
			
	     	
		f=jframe;
		JLabel topic = new JLabel(getTopicValue+" Menu" , SwingConstants.CENTER);
		Border border = BorderFactory.createLineBorder(Color.BLACK, 3);
		JLabel header = new JLabel(getHearderValue, SwingConstants.CENTER);
		Border headerborder = BorderFactory.createLineBorder(Color.BLACK, 2);
		header.setBounds(150,70,400,30);
		header.setFont(new Font("Serif", Font.PLAIN, 15));
		header.setBorder(headerborder);
		topic.setBounds(90,20,500,40);
		topic.setFont(new Font("Serif", Font.PLAIN, 30));
		topic.setBorder(border);
		JButton back = new JButton("Back");	
		JButton browse = new JButton("Browse");
		JButton continueToScan = new JButton("Continue to Scan");
		textBrowseUri = new JTextField();
		add(header);
        add(topic);
        setBounds(700,200,700,700);
        setLayout(null);
        setVisible(true);
        add(back);
        add(browse);
        add(continueToScan);
        add(textBrowseUri);
        back.setBounds(250,500,180,30);
        continueToScan.setBounds(250,450,180,30);
        browse.setBounds(350,250,180,30);
        textBrowseUri.setBounds(150,250,180,30);
        String openFileName = new String(prop.getProperty(getPropertiesValue+".FileName"));
		String openFilePath = new String(prop.getProperty(getPropertiesValue+".FilePath"));
		
		if(SystemMenu.openFilePath==""){
        textBrowseUri.setText(openFilePath+openFileName);

		}
		else{
		textBrowseUri.setText(SystemMenu.openFilePath);
		}
		
        //set Action
        back.addActionListener( new ActionListener()
	    {
	        public void actionPerformed(ActionEvent e)
	        {
	        	if(timerScanData.size()<SystemMenu.Recordlimited){
	        			SystemMenu.checkLogData.add("Click in "+ getPropertiesValue +" (OptionOpen) (Back) button");
	        			SystemMenu.checkLogData.add("timerScanData value = " + timerScanData);
	        	}
	    				String status = null;
						//timerScanData = new ArrayList<String>();
						//passOptionNewTextFieldValue = new String[SystemMenu.Arraylimited][SystemMenu.Arraylimited];
						//marks = new int[SystemMenu.Arraylimited];
						//headerno = 1;
						f.setVisible(false);
			        	f.getContentPane().removeAll();
			        	optionMenu = new OptionMenu(f,getHearderValue,timerScanData, passOptionNewTextFieldValue , headerno , marks , status);	        	
			        	optionMenu.draw();		        	
			        	f.setContentPane(optionMenu);
			        	Dimension preferredSize = new Dimension(700,700);
			        	f.setPreferredSize(preferredSize);		        	
			        	f.setBounds(700,200,700,700);
			        	f.setLocationRelativeTo(null);
			        	SwingUtilities.updateComponentTreeUI(f);
			        	f.pack();
			        	f.setVisible(true);
			        	f.invalidate();
			        	f.validate();
			        	f.repaint();

	        }
	    }); 
        
        continueToScan.addActionListener( new ActionListener()
	    {
	        public void actionPerformed(ActionEvent e)
	        {
	        	if(timerScanData.size()<SystemMenu.Recordlimited){
    			SystemMenu.checkLogData.add("Click in "+ getPropertiesValue +" (OptionOpen) (Continue To Scan) button");
    			SystemMenu.checkLogData.add("timerScanData value = " + timerScanData);
	        	}
	        	File newTextFile = new File(textBrowseUri.getText());
                if (newTextFile.exists()){
                	SystemMenu.checkERBatchDateEmpty = "false";
    	        	timerScanData = new ArrayList<String>();
    	        	passOptionNewTextFieldValue = new String[SystemMenu.Arraylimited][SystemMenu.Arraylimited];
					marks = new int[SystemMenu.Arraylimited];
					headerno = 1;
					saveTimerScanData= new ArrayList<String>();
					
    	        	try {
    					BufferedReader fileReader = new BufferedReader(new FileReader(newTextFile));
    					String line=null;
    				    try {
    						while ((line = fileReader.readLine()) != null)
    						{
    							timerScanData.add(line.trim());
    							//if(timerScanData.size()<SystemMenu.Recordlimited){
    						//		System.out.println("timerScanData value = " + timerScanData);
    						//		}
    						}
    						fileReader.close();
    					} 
    				    catch (IOException e1) {
    						e1.printStackTrace();
    					}
    				} 
    	        	catch (FileNotFoundException e1) {
    					e1.printStackTrace();
    				}
    	        	if(timerScanData.size()==0){
	        			JOptionPane optionPane2 = new JOptionPane("The File do not contain data. Please Check", JOptionPane.ERROR_MESSAGE);    
	    				JDialog dialog2 = optionPane2.createDialog("Failure");
	    				dialog2.setAlwaysOnTop(true);
	    				dialog2.setVisible(true);
    	        	}
    	        	else{
    	        	String totalLine= prop.getProperty(getPropertiesValue+".HeaderRecordReadTotalline");
    	        	int totalLineNum=Integer.parseInt(totalLine);
    	        	String spilt= prop.getProperty(getPropertiesValue+".HeaderRecordReadDataSplit");
    	    		int spiltNum = Integer.parseInt(spilt);
    	    		String Minus= prop.getProperty(getPropertiesValue+".HeaderRecordReadTotallineNotSplit");
    	    		int MinusNum = Integer.parseInt(Minus);
    	    		String arrayStorePlace= prop.getProperty(getPropertiesValue+".ArrayStoreNotSplitDataPlace");
    	    		int arrayStorePlaceNum = Integer.parseInt(arrayStorePlace);
    	    		String controlArrayStorePlace= prop.getProperty(getPropertiesValue+".ControlArrayStoreNotSplitDataPlace");
    	    		int controlArrayStorePlaceNum = Integer.parseInt(controlArrayStorePlace);
    	    		String ListStorePlace= prop.getProperty(getPropertiesValue+".ArrayListStoreNotSplitDataPlace");
    	    		int ListStorePlaceNum = Integer.parseInt(ListStorePlace);
    	    		String ListDeletePlace= prop.getProperty(getPropertiesValue+".DeleteArrayListStorePlace");
    	    		int ListDeletePlaceNum = Integer.parseInt(ListDeletePlace);
    	    		

    	        	String readData[]=new String[spiltNum+1];
    	            int readDataInt[] = new int[spiltNum+1];
    	            
    	            String splitTimerScanData[]=new String[timerScanData.size()];
    	            String storeSplitTimerScanData[]=new String[timerScanData.size()];
    	            String ERScanUndeliveredERReturnAddSpace[]=new String[timerScanData.size()];
    	            
    	            checkSpaceInOpenFile=new String[timerScanData.size()];
    	    		headers = new String[numOfButton];
    	    		for (int i = 0; i < numOfButton; i++) {
    	    			headers[i] = prop.getProperty(getPropertiesValue + ".DetailRecordLabel" + (i + 1));
    	    		}
    	    		OutputData = new String[numOfButton + 1];
    	    		OutputDataInt= new int[numOfButton + 1];
    	    		for (int i = 0; i <= numOfButton; i++) {
    	    			OutputData[i] = new String(prop.getProperty(getPropertiesValue+ ".DetailRecordData" + i));
    	    			OutputDataInt[i] = Integer.parseInt(OutputData[i]);
    	    		}
    	            if (getPropertiesValue.equals("ERScanUndeliveredERReturn(BIR56A)"))
    				{
    	            	int ERDataSize =timerScanData.size();
    	            	for (int i = 0; i <timerScanData.size(); i++){
    	            		ERScanUndeliveredERReturnAddSpace[i]=timerScanData.get(i).toString()+" ";
    	            		
    	            	}
    	            	timerScanData= new ArrayList<String>();
    	            	for (int i = 0; i <ERDataSize; i++){
    	            		timerScanData.add(ERScanUndeliveredERReturnAddSpace[i]);
    	            	}
    				}
    	          if (getPropertiesValue.equals("CTRNoteReceiptCTRAdviceLetter"))
    				{
    	            	for (int i = 0; i <spiltNum+1 ; i++){
    		     			readData[i]= new String(prop.getProperty(getPropertiesValue+".HeaderRecordReadNextlineSplitData"+i));
    		     			readDataInt[i] = Integer.parseInt(readData[i]);
    		    		}
    	            	List<String> storeHeaderRecordData = new ArrayList<String>(); ;
    	            	String classificFileData= new String();
    	            	String checkingData= new String();
    	            	int timerScanDataSize=timerScanData.size();
    	            	int countInt[]=new int[SystemMenu.Arraylimited];
    	            	int countString[]=new int[SystemMenu.Arraylimited];
    	            	for (int i = 0; i <SystemMenu.Arraylimited ; i++){
    	            		countInt[i]=0;
    	            		countString[i]=0;
    	            	}
    	            	int check=0; //no. of new header record
    	            	int check2=0; //
    	            	int check3=0;
    	            	for (int i = 0; i <timerScanDataSize; i++){
    	            	classificFileData=timerScanData.get(i).toString().replaceAll("\\s","");
    	            	checkingData=classificFileData.substring(0,1);

    	            	checkingData=checkingData.replaceAll("[^0-9]+", "");
    	            	 if (checkingData.length()==1){
    	            				if(check!=check3){
    	            				check=check3;
    	            				}
    	            			
    	            			
    	            			countInt[check]++;
    	            			storeHeaderRecordData.add(timerScanData.get(i).toString());
    	            		}
    	            		else{
    	            			if(check2 != check){
    	            				check2=check;
    	            				}
    	            			countString[check2]++;
    	            		}

    	            		if(countString[check3]!=0){
    	            			check3++;
    	            		}

    	            	}
    	            	headerno=check3;
    	            	int HeaderRecordsize =storeHeaderRecordData.size();
    	            	for (int i = 0; i <HeaderRecordsize; i++){
    	            		
    	            		if (timerScanData.contains(storeHeaderRecordData.get(i).toString())) {
    							timerScanData.remove(storeHeaderRecordData.get(i).toString());

    						} 

    	            	}
		    			for (int i = 0; i < timerScanData.size(); i++) {
		    				checkSpaceInOpenFile[i]= timerScanData.get(i).toString();
		    				for (int j = 0; j < numOfButton; j++) {
		    					if (headers[j].equals("PRN") && j == 0) {
		    						checkPrnExist=true;
		    						if (checkSpaceInOpenFile[i].length() < OutputDataInt[numOfButton]) {
		    							if(getPropertiesValue.equals("CTRScanUndeliveredCTRDemandNote")){
		    								saveTimerScanData.add(timerScanData.get(i).toString() + " ");
										}
		    							else{
		    								saveTimerScanData.add(" "+ timerScanData.get(i).toString());
										}
									}
		    						else{
		    							saveTimerScanData.add(timerScanData.get(i).toString());
		    						}
		    					}
		    				}
		    			}
		    			if(checkPrnExist==true){
		    				timerScanData=new ArrayList<String>();
		    				timerScanData=saveTimerScanData;
		    			}
    	            	int storeHeaderRecordDataSize=storeHeaderRecordData.size();
    	            	for (int c = 0; c <headerno; c++){
    	            		for (int i = 0; i <2; i++){
    		    			splitTimerScanData[i]=storeHeaderRecordData.get(i).toString();
    		    			
    		    			
    		    			if(i==1){
    		    				
    		    				passOptionNewTextFieldValue[2][c]=splitTimerScanData[i].trim();
    		    			}
    		    			else{
    		    				for (int j = 0; j <spiltNum ; j++){
    				    		passOptionNewTextFieldValue[j][c]=splitTimerScanData[i].substring(readDataInt[j],readDataInt[j+1]);
    				    			
    				    			}
    		    				}
    		    			}
    	            		for (int i = 0; i <storeHeaderRecordDataSize; i++){
    	            			if (storeHeaderRecordData.contains(splitTimerScanData[i])) {
    	            				storeHeaderRecordData.remove(splitTimerScanData[i]);

    							}
    	            		}
    	        	 
    	            	}
    	            	for (int i = 0; i <headerno ; i++){
    	            		marks[i]=countString[i];
    	            	}
    				}
    	          else if (getPropertiesValue.equals("PFNoteReceiptPFReturn(BIR51/BIR52)"))
    				{
    	            	for (int i = 0; i <spiltNum+1 ; i++){
    		     			readData[i]= new String(prop.getProperty(getPropertiesValue+".HeaderRecordReadNextlineSplitData"+i));
    		     			readDataInt[i] = Integer.parseInt(readData[i]);
    		    		}

    	            	List<String> storeHeaderRecordData = new ArrayList<String>(); ;
    	            	String classificFileData= new String();
    	            	String checkingData= new String();
    	            	int timerScanDataSize=timerScanData.size();
    	            	int countInt[]=new int[SystemMenu.MaxArraylimited];
    	            	int countString[]=new int[SystemMenu.MaxArraylimited];
    	            	for (int i = 0; i <SystemMenu.MaxArraylimited ; i++){
    	            		countInt[i]=0;
    	            		countString[i]=0;
    	            	}
    	            	int check=0; //no. of new header record
    	            	int check2=0; //
    	            	int check3=0;
    	            	
    	            	for (int i = 0; i <timerScanDataSize; i++){
    	            	classificFileData=timerScanData.get(i).toString().replaceAll("\\s","");
    	            	checkingData=classificFileData.replaceAll("[^#]", "");
    	            	if(timerScanData.size()<SystemMenu.Recordlimited){
    	            		System.out.println("checkingData = "+checkingData.length());
    	            		}
    	            	 if (checkingData.length()==2){
             				if(check!=check3){
             					check=check3;
             				}

             				countInt[check]++;
             				storeHeaderRecordData.add(timerScanData.get(i).toString());
    	            	 }
    	            	 else{
    	            		if(check2 != check){
    	            			check2=check;
             				}
    	            		countString[check2]++;
    	            	 }

    	            	 if(countString[check3]!=0){
    	            		 check3++;
    	            	 }
    	            		}
    	            	headerno=check3;
    	            	int HeaderRecordsize =storeHeaderRecordData.size();
    	            	for (int i = 0; i <HeaderRecordsize; i++){
    	            		
    	            		if (timerScanData.contains(storeHeaderRecordData.get(i).toString())) {
    							timerScanData.remove(storeHeaderRecordData.get(i).toString());

    						} 

    	            	}
    	            	
    	            	int storeHeaderRecordDataSize=storeHeaderRecordData.size();
    	            	for (int c = 0; c <headerno; c++){
    	            		splitTimerScanData[c]=storeHeaderRecordData.get(c).toString();

    		    				for (int j = 0; j <spiltNum ; j++){
    				    		passOptionNewTextFieldValue[j][c]=splitTimerScanData[c].substring(readDataInt[j],readDataInt[j+1]);
    				    			
    				    			}
    	        	 
    	            	}
    	            	for (int i = 0; i <headerno ; i++){
    	            		marks[i]=countString[i];
    	            	}
    	            	
    				}
    	           else{
    	        	 //List<String> DetailRecordStoreList = new ArrayList<String>();
    	        	   int DetailRecordListSize;
    	        	   DetailRecordListSize=timerScanData.size();
    	        	   String storeDetailRecord[]=new String[timerScanData.size()];
    	        	   for (int i = 0; i <spiltNum+1 ; i++){
    		     			readData[i]= new String(prop.getProperty(getPropertiesValue+".HeaderRecordReadNextlineSplitData"+i));
    		     			readDataInt[i] = Integer.parseInt(readData[i]);
    		    		}
    	        	   
		    			if(getPropertiesValue.equals("ERScanUndeliveredERReturn(BIR56A)")){
		    				for (int i = 0; i <timerScanData.size(); i++){
		    					splitTimerScanData[i]=timerScanData.get(i).toString()+"                                                                                       ";

		    					storeDetailRecord[i]=splitTimerScanData[i].substring(23,36);
		    					for (int j = 0; j <spiltNum ; j++){
		    		    			passOptionNewTextFieldValue[j][headerno-1]=splitTimerScanData[i].substring(readDataInt[j],readDataInt[j+1]);
		    		    			
		    		    			}
		    					

		    				}
		    			}
		    			
		    			else{
    		    		for (int i = 0; i <totalLineNum-MinusNum; i++){
    		    			splitTimerScanData[i]=timerScanData.get(i).toString()+"                                                                                       ";

    		    			for (int j = 0; j <spiltNum ; j++){
    		    			passOptionNewTextFieldValue[j][headerno-1]=splitTimerScanData[i].substring(readDataInt[j],readDataInt[j+1]);
    		    			
    		    			}

    		    		}
    		    	
    		    		for (int i = arrayStorePlaceNum; i <controlArrayStorePlaceNum; i++){
    		    			passOptionNewTextFieldValue[i][headerno-1]=timerScanData.get(ListStorePlaceNum).toString().trim();
    		    			
    		    		}
    		    		int count=0;
    		    		int DeletePlace=0;
    		    		while (count != ListDeletePlaceNum)
    					{
    		    			storeSplitTimerScanData[DeletePlace]=timerScanData.get(DeletePlace).toString();
    		    			if (timerScanData.contains(storeSplitTimerScanData[DeletePlace])){	    	    				
    				    		timerScanData.remove(storeSplitTimerScanData[DeletePlace]);
    				    	}
    		    			count++;
    					}
    		    			for (int i = 0; i < timerScanData.size(); i++) {
    		    				checkSpaceInOpenFile[i]= timerScanData.get(i).toString();
    		    				for (int j = 0; j < numOfButton; j++) {
    		    					if (headers[j].equals("PRN") && j == 0) {
    		    						checkPrnExist=true;
    		    						if (checkSpaceInOpenFile[i].length() < OutputDataInt[numOfButton]) {
    		    							if(getPropertiesValue.equals("CTRScanUndeliveredCTRDemandNote")){
    		    								saveTimerScanData.add(timerScanData.get(i).toString() + " ");
    										}
    		    							else{
    		    								saveTimerScanData.add(" "+ timerScanData.get(i).toString());
    										}
    									}
    		    						else{
    		    							saveTimerScanData.add(timerScanData.get(i).toString());
    		    						}
    		    					}
    		    				}
    		    			}
    		    			if(checkPrnExist==true){
    		    				timerScanData=new ArrayList<String>();
    		    				timerScanData=saveTimerScanData;
    		    			}
		    			}
		    			
    		    		if(getPropertiesValue.equals("ERScanUndeliveredERReturn(BIR56A)")){
    		    			timerScanData=new ArrayList<String>();
    		    			for (int i = 0; i <DetailRecordListSize; i++){
    		    				timerScanData.add(storeDetailRecord[i]);
    		    			}
    		    		}
    		    		marks[0] = timerScanData.size();
    	        	 
    	        	 
    	            }
                
	        	String DetailRecordTotalData= prop.getProperty(getPropertiesValue+".DetailRecordTotalData");
	    		int DetailRecordTotalDataInt = Integer.parseInt(DetailRecordTotalData);
	            String saveBlocktimerscanData[]=new String[timerScanData.size()];
	    		String blocktimerScanData;
	    		List<String> IncorrectDataDisplay= new ArrayList<String>();
	    		int timerScanDataSize = timerScanData.size();
	    		if(getPropertiesValue.equals("BRScanUndeliveredBRFeeDemandNotes&PenaltyNotices")){
	    			for (int i = 0; i < timerScanDataSize; i++) {
	    				blocktimerScanData=timerScanData.get(i).toString();
	    				if(blocktimerScanData.length()>25){
							saveBlocktimerscanData[i]=timerScanData.get(i).toString();
		    				IncorrectDataDisplay.add(saveBlocktimerscanData[i]);
							blockTimerScanData ="true";
						}
	    				if(blocktimerScanData.length()<DetailRecordTotalDataInt){
		    				saveBlocktimerscanData[i]=timerScanData.get(i).toString();
		    				IncorrectDataDisplay.add(saveBlocktimerscanData[i]);
							blockTimerScanData ="true";
		    				}
	    			}
	    		}
	    		else if(getPropertiesValue.equals("ERScanUndeliveredERReturn(BIR56A)")){
	    			for (int i = 0; i < timerScanDataSize; i++) {
	    				blocktimerScanData=timerScanData.get(i).toString().trim();
	    				if(blocktimerScanData.length()>DetailRecordTotalDataInt){
							saveBlocktimerscanData[i]=timerScanData.get(i).toString();
		    				IncorrectDataDisplay.add(saveBlocktimerscanData[i]);
							blockTimerScanData ="true";
						}
	    				if(blocktimerScanData.length()<DetailRecordTotalDataInt){
		    				saveBlocktimerscanData[i]=timerScanData.get(i).toString();
		    				IncorrectDataDisplay.add(saveBlocktimerscanData[i]);
							blockTimerScanData ="true";
		    				}
	    			}
	    		}
	    		else{
	    		for (int i = 0; i < timerScanDataSize; i++) {
	    			blocktimerScanData=timerScanData.get(i).toString();
	    			if(getPropertiesValue.equals("CTRScanUndeliveredCTRReturn(BIR60)")||getPropertiesValue.equals("CTRScanUndeliveredCTRAdviceLetter")||getPropertiesValue.equals("CTRScanUndeliveredCTRReminder/Compound")||getPropertiesValue.equals("CTRNoteReceiptCTRReturn(BIR60)")||getPropertiesValue.equals("CTRNoteReceiptCTRAdviceLetter")){
						   
					   }
					else{
						if(blocktimerScanData.length()>DetailRecordTotalDataInt){
							saveBlocktimerscanData[i]=timerScanData.get(i).toString();
		    				IncorrectDataDisplay.add(saveBlocktimerscanData[i]);
							blockTimerScanData ="true";
						}
					   }
	    			if(blocktimerScanData.length()<DetailRecordTotalDataInt){
	    				saveBlocktimerscanData[i]=timerScanData.get(i).toString();
	    				IncorrectDataDisplay.add(saveBlocktimerscanData[i]);
						blockTimerScanData ="true";
	    				}
	    			}
	    		}
	        	if (getPropertiesValue.equals("CTRNoteReceiptCTRAdviceLetter")||getPropertiesValue.equals("PFNoteReceiptPFReturn(BIR51/BIR52)")){
	        		if(blockTimerScanData=="true"){
	        			JOptionPane optionPane2 = new JOptionPane("Some Data's length is not correct. Please check the file again. Here is the incorrect data "+IncorrectDataDisplay, JOptionPane.ERROR_MESSAGE);    
	    				JDialog dialog2 = optionPane2.createDialog("Failure");
	    				dialog2.setAlwaysOnTop(true);
	    				dialog2.setVisible(true);
	    	    		}
	        		else{
	    	        	f.setVisible(false);
	    	        	f.getContentPane().removeAll();
	    	        	optionNew = new OptionNew(f,optionMenu,timerScanData,passOptionNewTextFieldValue,headerno,marks,status);
	       	    	    optionNew.draw();
	    	        	f.setContentPane(optionNew);
	    	        	Dimension preferredSize = new Dimension(700,700);
	    	        	f.setPreferredSize(preferredSize);	        	
	    	        	f.setBounds(700,200,700,700);
	    	        	f.setLocationRelativeTo(null);
	    	        	SwingUtilities.updateComponentTreeUI(f);
	    	        	f.pack();
	    	        	f.setVisible(true);
	    	        	f.invalidate();
	    	        	f.validate();
	    	        	f.repaint();
	        		}
	        	}
	        	
	        	else{
	        		if(timerScanData.size()<SystemMenu.Recordlimited){
	        		System.out.println("timerScanData value ="+ timerScanData);
	        		}
	    		for (int i = 0; i < timerScanDataSize; i++) {
	    			if (timerScanData.contains(saveBlocktimerscanData[i])){	    	    				
					    timerScanData.remove(saveBlocktimerscanData[i]);
					    
					    	}	    			
	    		}
	    		if(blockTimerScanData=="true"){
    			JOptionPane optionPane2 = new JOptionPane("Some Date's length is not correct and deleted. Please check the file again. Here is the incorrect data "+IncorrectDataDisplay, JOptionPane.ERROR_MESSAGE);    
				JDialog dialog2 = optionPane2.createDialog("Failure");
				dialog2.setAlwaysOnTop(true);
				dialog2.setVisible(true);
	    		}
	    		marks[0]=timerScanData.size();
	        	f.setVisible(false);
	        	f.getContentPane().removeAll();
	        	optionNew = new OptionNew(f,optionMenu,timerScanData,passOptionNewTextFieldValue,headerno,marks,status);	        	
	        	optionNew.draw();
	        	f.setContentPane(optionNew);
	        	Dimension preferredSize = new Dimension(700,700);
	        	f.setPreferredSize(preferredSize);	        	
	        	f.setBounds(700,200,700,700);
	        	f.setLocationRelativeTo(null);
	        	SwingUtilities.updateComponentTreeUI(f);
	        	f.pack();
	        	f.setVisible(true);
	        	f.invalidate();
	        	f.validate();
	        	f.repaint();
	        	}
                }
                }
              else{
                	JOptionPane optionPane2 = new JOptionPane("You do not have this file. Please check your file path again.", JOptionPane.ERROR_MESSAGE);    
    		        JDialog dialog2 = optionPane2.createDialog("Failure");
    		        dialog2.setAlwaysOnTop(true);
    		        dialog2.setVisible(true);
                }	

	        }
	    }); 
        browse.addActionListener( new ActionListener()
	    {
	        public void actionPerformed(ActionEvent e)
	        {
	        	if(timerScanData.size()<SystemMenu.Recordlimited){
				SystemMenu.checkLogData.add("Click in "+ getPropertiesValue +" (OptionOpen) (Browse) button");
	        	}
	        	JFileChooser fileChooser = new JFileChooser();
	        	fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
	        	int result = fileChooser.showOpenDialog(null);
	        	
	        	if (result == JFileChooser.APPROVE_OPTION) {
	        	    // user selects a file
	        		File selectedFile = fileChooser.getSelectedFile();
	        		File newTextFile = new File(selectedFile.getAbsolutePath());
	        	
	        	//File newTextFile = new File(selectedFile.getAbsolutePath());
	        	textBrowseUri.setText(selectedFile.getAbsolutePath());
	        	SystemMenu.openFilePath=selectedFile.getAbsolutePath();
	        	}
	        	
	        }
	    }); 
        
		}
        catch (IOException ex) {
			
			System.out.println("Problem occurs when reading file !");
			ex.printStackTrace();
		} 
              
        
	}
	
}
