package ird.taas2.cloud;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.log4j.Logger;

import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.Statement;

public class ModelWorker {

	private Logger logger = Logger.getLogger(ModelWorker.class);
	public static List<String> errorPathList = new ArrayList<String>();
	public static List<String> varibleNameList = new ArrayList<String>();
	public static String errorLog = new String();
	public static String orignalText ="";
	public static List<String> realPathList = new ArrayList<String>();
	public static List<String> nullPointerPathList = new ArrayList<String>();
	public static boolean equalGetName=true;
	public static boolean equalSetName=true;
	public static boolean textLengthNonZero=true;
	public static boolean nullpointerPath=false;
	public static void main(String[] args) throws Exception {
		ModelWorker mw = new ModelWorker();
//		mw.process(new File(args[0]));
		String inputPath="D:\\ccshare\\jyyau_view_ClearCase_MTN\\TAAS2_UAT\\CloudMigration\\Application";
//		String inputPath="D:\\ccshare\\jyyau_view_ClearCase_MTN\\TAAS2_UAT\\CloudMigration\\Application\\Batch_Common\\CT_Batch_Common\\src\\ird\\taas2\\batch\\ct\\model\\r6607b\\R6607BBlock.java";
//		String inputPath="D:\\ccshare\\jyyau_view_ClearCase_MTN\\TAAS2_UAT\\CloudMigration\\Application\\Common\\CT_Common\\src\\ird\\taas2\\ct\\model\\Ctaspcdac.java";
//		String inputPath="D:\\ccshare\\jyyau_view_ClearCase_MTN\\TAAS2_UAT\\CloudMigration\\Application\\Batch\\ACS_Batch\\src\\ird\\taas2\\batch\\acs\\irdtrcmt1\\Irdtrc002.java";
		
		try (Stream<Path> walk = Files.walk(Paths.get(inputPath))) {
			List<String> result = walk.filter(f -> Files.isRegularFile(f))
					.map(x -> x.toString())
//					.filter(s -> s.toLowerCase().contains("validator")||s.toLowerCase().contains("worker"))
					.filter(s -> s.toLowerCase().contains(".java"))
					.filter(s -> s.toLowerCase().contains("model"))
					.filter(s -> !s.toLowerCase().contains("daoimpl"))
					.collect(Collectors.toList());
			walk.close();

				for (int j = 0; j < result.size(); j++) {
					boolean realPath=true;
					if(realPath) {
						errorLog= new String();
						mw.process(new File(result.get(j).toString()));
						if(equalGetName==false||equalSetName==false) {
							errorPathList.add(result.get(j).toString());
							errorPathList.add(errorLog);
						}
						if(nullpointerPath) {
							nullPointerPathList.add(result.get(j).toString());
						}		
					}
				}
			}
			catch (IOException e) {
				e.printStackTrace();
			}
		
		try {
		FileWriter fileWriter = new FileWriter("T:\\jackyau\\errorPathList_lastMain888.txt");
		for (int i = 0; i < errorPathList.size(); i++) {
			fileWriter.write(errorPathList.get(i).toString()+System.lineSeparator());
		}
		fileWriter.close();			
	} catch (IOException iox) {
		iox.printStackTrace();
		System.out.println("File can not save any data in outputPathList");
	}
		try {
		FileWriter fileWriter = new FileWriter("T:\\jackyau\\nullPointerPathList_lastMain888.txt");
		for (int i = 0; i < nullPointerPathList.size(); i++) {
			fileWriter.write(nullPointerPathList.get(i).toString()+System.lineSeparator());
		}
		fileWriter.close();			
	} catch (IOException iox) {
		iox.printStackTrace();
		System.out.println("File can not save any data in outputPathList");
	}
	}

	public void process(File modelFile) throws Exception {

		checkGetter(modelFile);
		checkSetter(modelFile);
	}

	public Boolean checkGetter(File modelFile) throws Exception {
		varibleNameList.clear();
		textLengthNonZero=true;
		equalGetName=true;
		CompilationUnit cu = StaticJavaParser.parse(modelFile);
		cu.findAll(VariableDeclarator.class).forEach(variable -> {
			logger.info(variable.getTypeAsString() + " " + variable.getName());
			varibleNameList.add(variable.getName().toString());
		});

		cu.findAll(MethodDeclaration.class).forEach(method -> {
			if (!method.getNameAsString().startsWith("get")) {
				return;
			}
			
			logger.info(method.getTypeAsString() + " " + method.getName());
			String[] splitGetMethodName = method.getName().toString().split("get",2);
			
			logger.info(splitGetMethodName[1].trim());

			method.findAll(VariableDeclarator.class).forEach(variable -> {
				logger.info(method.getName()+"."+variable.getTypeAsString() + " " + variable.getName());
				variable.getInitializer().ifPresent(expression -> {
			        expression.ifStringLiteralExpr(stringLiteralExpr -> {
			        	logger.info(stringLiteralExpr);
			        });
			    });
			});	
			
			Optional<BlockStmt> block = method.getBody();
			if(block.isPresent()) {
			NodeList<Statement> statements = block.get().getStatements();
			logger.info("{");
			for (Statement tmp : statements) {
				tmp.removeComment();
				logger.info("\t"+tmp.toString());
				logger.info("=.="+method.getName().toString().toLowerCase().substring(3,4)
						+method.getName().toString().substring(4,method.getName().toString().length()));
				if(!tmp.toString().toLowerCase().contains(splitGetMethodName[1].toLowerCase().trim())) {
					if(varibleNameList.contains(method.getName().toString().toLowerCase().substring(3,4)
							+method.getName().toString().substring(4,method.getName().toString().length()))) {
//					logger.info(tmp.toString().toLowerCase());
//					logger.info(splitGetMethodName[1].toLowerCase().trim());
					errorLog=errorLog+"Original text in java:    "+method.getTypeAsString() + " " + method.getName()+"   ...(Get)(return)...   "+tmp.toString()+System.lineSeparator();
					errorLog=errorLog+"Compare log:    "+splitGetMethodName[1].trim().toLowerCase().trim()+"   !contains   "+tmp.toString().toLowerCase() +System.lineSeparator();
					equalGetName=false;
					}
				}
			}
			logger.info("}");

			}
		});
		if(equalGetName==false) {
		cu.findAll(VariableDeclarator.class).forEach(variable -> {
			errorLog=errorLog+"Varible Name : " + variable.getName().toString()+System.lineSeparator();
		});
		}

		return false;
	}

	public Boolean checkSetter(File modelFile) throws Exception {
		varibleNameList.clear();
		equalSetName=true;
		CompilationUnit cu = StaticJavaParser.parse(modelFile);
		cu.findAll(VariableDeclarator.class).forEach(variable -> {
			logger.info(variable.getTypeAsString() + " " + variable.getName());
			varibleNameList.add(variable.getName().toString());
		});

		cu.findAll(MethodDeclaration.class).forEach(method -> {
			if (!method.getNameAsString().startsWith("set")) {
				return;
			}
			
			logger.info(method.getTypeAsString() + " " + method.getName()+":"+method.getParameters());

			method.findAll(VariableDeclarator.class).forEach(variable -> {
				logger.info(method.getName()+"."+variable.getTypeAsString() + " " + variable.getName());
				variable.getInitializer().ifPresent(expression -> {
			        expression.ifStringLiteralExpr(stringLiteralExpr -> {
			        	logger.info(stringLiteralExpr);
			        });
			    });
			});	
			
			Optional<BlockStmt> block = method.getBody();
			if(block.isPresent()) {
			NodeList<Statement> statements = block.get().getStatements();
			logger.info("{");
			for (Statement tmp : statements) {
				tmp.removeComment();
				logger.info("\t"+tmp.toString());
				if(!tmp.toString().toLowerCase().contains(method.getName().toString().substring(3,method.getName().toString().length()).toLowerCase().trim())) {
					if(varibleNameList.contains(method.getName().toString().toLowerCase().substring(3,4)
							+method.getName().toString().substring(4,method.getName().toString().length()))) {
					errorLog=errorLog+"Original text in java:    "+method.getTypeAsString() + " " + method.getName()+"   ...(Set)(return)...   "+tmp.toString()+System.lineSeparator();
					errorLog=errorLog+"Compare log:    "+method.getName().toString().substring(3,method.getName().toString().length()).toLowerCase().trim()+"   !contains   "+tmp.toString().toLowerCase() +System.lineSeparator();
					equalSetName=false;
					}
				}
				if(tmp.toString().toLowerCase().contains(method.getName().toString().substring(3,method.getName().toString().length()).toLowerCase().trim())) {
					Pattern pattern = Pattern.compile("this\\s*[.]\\s*([a-zA-Z0-9_]+)\\s+[=]\\s+([a-zA-Z0-9_]+)[;]");
					Matcher patternMatcher=pattern.matcher(tmp.toString());
					String storeVarible =null;
					String varible1 =null;
					String varible2 =null;
					while (patternMatcher.find()){
						storeVarible = patternMatcher.group();
						varible1= patternMatcher.group(1);
						varible2= patternMatcher.group(2);
						if(!varible1.equals(varible2)) {
//							if(varibleNameList.contains(varible1)&&varibleNameList.contains(varible2)) {
							if(varibleNameList.contains(varible1)) {
								if(varibleNameList.contains(varible2)) {	
							errorLog=errorLog+"Original text in java:    "+storeVarible+"   ...(Set)(return)...   "+tmp.toString()+System.lineSeparator();
							errorLog=errorLog+"Compare log:    "+varible1+"   !contains   "+varible2+System.lineSeparator();
							equalGetName=false;
								}
							}
						}
					}
				}

				
			}
			logger.info("}");

			}
		});
		if(equalGetName&&equalSetName==false) {
		cu.findAll(VariableDeclarator.class).forEach(variable -> {
			errorLog=errorLog+"Varible Name : " + variable.getName().toString()+System.lineSeparator();
		});
		}
		return false;
	}
}
