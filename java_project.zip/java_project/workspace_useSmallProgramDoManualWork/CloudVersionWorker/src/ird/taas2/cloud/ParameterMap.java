package ird.taas2.cloud;

import java.util.HashMap;

import org.apache.log4j.Logger;

public class ParameterMap extends HashMap<String, String> {
	private Logger logger = Logger.getLogger(ParameterMap.class);

	private static final long serialVersionUID = 1L;
	
	public static ParameterMap getParameterMap(String[] args) {
		ParameterMap parameterMap = new ParameterMap();

		for (int argsIdx = 0; argsIdx < args.length; argsIdx++) {
			String arg = args[argsIdx];
			if (!arg.startsWith("-")) {
				continue;
			}
			String value = null;
			try {
				value = args[argsIdx + 1];
			} catch (Exception e) {
			}
			if (value == null || value.startsWith("-")) {
				parameterMap.put(arg.substring(1), "true");
			} else {
				parameterMap.put(arg.substring(1), value);
			}
		}

		return parameterMap;
	}

	public String get(String key) {
		if (super.get(key) == null) {
			logger.warn("param[" + key + "] not exists ");
		}
		return super.get(key);
	}

	public String getDefault(String key, String defaultValue) {
		if (super.get(key) == null) {
			logger.warn("param[" + key + "] not exists, use defaultValue " + defaultValue);
			return defaultValue;
		}
		logger.info("param[" + key + "]: " + super.get(key));
		return super.get(key);
	}
}