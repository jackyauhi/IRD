package ird.taas2.cloud;

import java.io.File;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.HashMap;

public class CompareWorker {
	public static void main(String[] args)throws Exception{
		CompareWorker cw = new CompareWorker();
		cw.process(new File(args[0]), new File(args[1]));
	}
	
	private void process(File full, File delta) throws Exception{
		Map<String, Record> fullRecord =  parse(full);
		Map<String, Record> deltaRecord =  parse(delta);
		
		for(Entry<String, Record> entry: deltaRecord.entrySet()) {
			String filename =entry.getKey();
			Record record = entry.getValue();
			if (fullRecord.get(filename) == null) {
				System.out.println("\t!!!NEW\t"+record);
			}else {
				String existingVersion = fullRecord.get(filename).getVersionSelected();
				String deltaVersion = record.getVersionSelected();
				if (deltaVersion.contains("=>")) {
					deltaVersion = deltaVersion.substring(deltaVersion.lastIndexOf("=>")+2);
					deltaVersion = deltaVersion.trim();
				}
				
				if(!existingVersion.equalsIgnoreCase(deltaVersion)){
					System.out.println("\t!!!UPDATE\t"+filename+"\t"+fullRecord.get(filename).getVersionSelected()+"\t==>\t"+deltaVersion);
					
				}
			} 
		}
	}
	
	private Map<String, Record> parse(File file)throws Exception{
		Map<String, Record> records = new HashMap<>();
		
		List<String> lines = Files.readAllLines(file.toPath(), Charset.defaultCharset());
		
		for(String line: lines) {
			if (line.trim().length() == 0) {
				continue;
			}
			if (!line.contains("\t")) {
				continue;
			}
			
			String[] data = line.split("\t");
			for (int i = 0; i < data.length; i++) {
				data[i] = data[i].trim();
			}
			
			Record record = new Record();
			record.setFilename(data[0]);
			if (data.length > 1) {
				record.setPic(data[1]);
			}
			if (data.length > 2) {
				record.setReason(data[2]);
			}
			if (data.length > 3) {
				record.setVersionSelected(data[3]);
			}
			
			if (records.get(record.getFilename()) != null) {
				System.out.println(record.getFilename()+" already exists?");
				System.out.println("\t"+record);
			}
			records.put(record.getFilename(), record);
		}
		
		
		return records;
	}
	
	class Record{
		private String filename;
		private String pic;
		private String reason;
		private String versionSelected;

		public String getFilename() {
			return filename;
		}
		public void setFilename(String filename) {
			this.filename = filename;
		}
		public String getPic() {
			return pic;
		}
		public void setPic(String pic) {
			this.pic = pic;
		}
		public String getReason() {
			return reason;
		}
		public void setReason(String reason) {
			this.reason = reason;
		}
		public String getVersionSelected() {
			return versionSelected;
		}
		public void setVersionSelected(String versionSelected) {
			this.versionSelected = versionSelected;
		}
		@Override
		public String toString() {
			return "Record [filename=" + filename + ", pic=" + pic + ", reason=" + reason + ", versionSelected="
					+ versionSelected + "]";
		}
	
		
	}
}
