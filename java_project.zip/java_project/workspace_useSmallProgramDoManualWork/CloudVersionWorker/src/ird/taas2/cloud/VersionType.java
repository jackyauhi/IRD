package ird.taas2.cloud;

public enum VersionType {
	BATCH("Batch"), ONLINE("Online"), MERGE("Merge"), UNKNOWN("Unknown"), BLANK("Blank"), SAME("Same"), MANUAL("Manual");
	
	private String value;
	 
	VersionType(String value) {
        this.value = value;
    }

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
	

}
