package ird.taas2.cloud;

import java.io.File;
import java.io.FileWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;

import org.apache.log4j.Logger;

import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.ImportDeclaration;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.PackageDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.Parameter;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.ObjectCreationExpr;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

public class MethodFinder {
	
	private Logger logger = Logger.getLogger(MethodFinder.class);
	
	public static void main(String[] args) throws Exception {
		MethodFinder mf = new MethodFinder();
		mf.process(new File(args[0]), new File(args[0]));
	}

	private Integer counterIndex = 1;
	private Set<String> declarationSet 		= null;
	private Set<String> methodVariableSet 	= null;
	private Set<String> invokedVariableSet 	= null;
	private Set<String> initVariableSet 	= null;
	private Set<String> invokedMethodSet 	= null;
	private Set<String> importSet 	= null;
	
	class FileRecord{
		private String path;
		private Map<String, Set<String>> map;
		public String getPath() {
			return path;
		}
		public void setPath(String path) {
			this.path = path;
		}
		public Map<String, Set<String>> getMap() {
			return map;
		}
		public void setMap(Map<String, Set<String>> map) {
			this.map = map;
		}
		
	}
	
	class MethodStruct {    
	    String parentNodes; 
	    String returnType;  
	    String methodName;  
	    String parameters;  
	    public MethodStruct(String parentNodes, String returnType, String methodName, String parameters) {
	    	this.parentNodes = parentNodes;
	    	this.returnType = returnType;
	    	this.methodName = methodName;
	    	this.parameters = parameters;
	    }
	}
	
	class MethodVisitor extends VoidVisitorAdapter<List<MethodStruct>> {
		
		@Override
		public void visit(FieldDeclaration field, List<MethodStruct> methodStructs) {
            super.visit(field, methodStructs);
            
            field.getVariables().forEach(variable -> {
            	String msg = "[OBJECT VARIABLE]"+getParents(field)+"==>"+variable.getType()+" "+variable.getName();
            	if (!declarationSet.contains(msg)) {
            		declarationSet.add(msg);
            	}
            });
            
            
		}
		
		@Override
		public void visit(VariableDeclarator variable, List<MethodStruct> methodStructs) {
			String msg = "[METHOD VARIABLE]"+getParents(variable)+"==>"+variable.getType()+" "+variable.getName();
        	if (!methodVariableSet.contains(msg)) {
        		methodVariableSet.add(msg);
        	}
        	
        	variable.getInitializer().ifPresent(initValue -> {
        		String initMsg = "[METHOD VARIABLE ASSIGNMENT]"+(getParents(variable)+"==>"+variable.getType()+" "+variable.getName()+" = "+initValue.toString());
            	if (!initVariableSet.contains(initMsg)) {
            		initVariableSet.add(initMsg);
            	}
        	});
            
		}
		
        @Override
        public void visit(MethodDeclaration declaration, List<MethodStruct> methodStructs) {
            super.visit(declaration, methodStructs);
            
            counterIndex++;

            // adding individual methodStruct into the list
            methodStructs.add(getMethodStruct(declaration));
        }

        public void visit(MethodCallExpr n, List<MethodStruct> methodStructs) {
        	String msg = "[INVOKED METHOD]"+getParents(n)+"==>"+n;
        	if (!invokedMethodSet.contains(msg)) {
        		invokedMethodSet.add(msg);
        	}
        }
        
        public void visit(NameExpr n, List<MethodStruct> methodStructs) {
        	String msg = "[INVOKED VARIABLE]"+getParents(n)+"==>" + n;

        	if (!invokedVariableSet.contains(msg)) {
        		invokedVariableSet.add(msg);
        	}
        			
        }

        MethodStruct getMethodStruct(MethodDeclaration declaration) {
            return new MethodStruct(
                    getParents(declaration),
                    declaration.getTypeAsString(),
                    declaration.getNameAsString(),
                    getParameterAsString(declaration.getParameters()));
        }
                
        String getParents(final Node declaration) {
            final StringBuilder path = new StringBuilder();

            declaration.walk(Node.TreeTraversal.PARENTS, node -> {
                if (node instanceof ClassOrInterfaceDeclaration) {
                    path.insert(0, ((ClassOrInterfaceDeclaration) node).getNameAsString());
                    path.insert(0, '$');
                }
                if (node instanceof ObjectCreationExpr) {
                    path.insert(0, ((ObjectCreationExpr) node).getType().getNameAsString());
                    path.insert(0, '$');
                }
                if (node instanceof MethodDeclaration) {
                    path.insert(0, ((MethodDeclaration) node).getNameAsString());
                    path.insert(0, '#');
                }
                if (node instanceof CompilationUnit) {
                    final Optional<PackageDeclaration> pkg = ((CompilationUnit) node).getPackageDeclaration();
                    if (pkg.isPresent()) {
                        path.replace(0, 1, ".");
                        path.insert(0, pkg.get().getNameAsString());
                    }
                }
            });

            // convert StringBuilder into String and return the String
            return path.toString();
        }

        String getParameterAsString(NodeList<Parameter> parameters) {
            // easy task! convert parameter string list
            // into a single string (comma separated)
        	return parameters.toString();
        }
    }

	private void process(File dir, File root) throws Exception{
		if (dir.isDirectory()) {
			File[] childs = dir.listFiles();
			
			for (File child: childs) {
				process(child, root);
			}
			return;
		}
				
		File file = new File(dir.getAbsolutePath());
				
		if (!file.getName().toLowerCase().endsWith(".java")) {
			return;
		}
		
		Map<String, Set<String>> map = find(file);
		FileRecord fr = new FileRecord();
		fr.setMap(map);
		fr.setPath(file.getAbsolutePath().replace(root.getAbsolutePath(), ""));
		
		File folder = new File("methodJson");
		if (!folder.isDirectory()) {
			folder.mkdirs();
		}
		
		String path = fr.getPath();
		while(path.contains(File.separator)) {
			path = path.replace(File.separator, "--");
		}
		
		File outputFile = new File(folder, path);
		
		logger.info(outputFile.getAbsolutePath());
		
		FileWriter fw = new FileWriter(outputFile, false);
		
		//Gson gson = new GsonBuilder().setPrettyPrinting().create();
		
		for (Entry<String, Set<String>> mapEntry: map.entrySet()) {
			for (String detailRecord: mapEntry.getValue()) {
				fw.append(detailRecord+System.lineSeparator());
			}
		}
		
		
		fw.close();
	}
	
	public Map<String, Set<String>> find(File file)throws Exception{
		
		Map<String, Set<String>> map = new HashMap<>();
		
		declarationSet = new HashSet<>();
		methodVariableSet = new HashSet<>();
		invokedVariableSet = new HashSet<>();
		invokedMethodSet = new HashSet<>();
		invokedMethodSet = new HashSet<>();
		importSet = new HashSet<>();
		initVariableSet = new HashSet<>();
		
	    CompilationUnit cu = StaticJavaParser.parse(new String(Files.readAllBytes(file.toPath()), Charset.defaultCharset()));

	    List<MethodStruct> methodStructs = new LinkedList<>();
        cu.accept(new MethodVisitor(), methodStructs);
        
        NodeList<ImportDeclaration> importDeclarations = cu.getImports();
        for (int idIdx = 0; idIdx < importDeclarations.size(); idIdx++) {
        	ImportDeclaration importDeclaration = importDeclarations.get(idIdx);
        	importSet.add("[IMPORT]"+importDeclaration.getName().toString());
        }
        

        map.put("declaration", declarationSet);
        map.put("methodVariable", methodVariableSet);
        map.put("invokedVariable", invokedVariableSet);
        map.put("invokedMethod", invokedMethodSet);
        //map.put("importSet", importSet);
        map.put("initVariableSet", initVariableSet);

        
//        List<NameExpr>  nes = cu.findAll(NameExpr.class);

        Set<String> methodSet = new HashSet<>();
        
        for (MethodStruct methodStruct: methodStructs) {
        	methodSet.add("[METHOD]"+methodStruct.parentNodes+"."+methodStruct.methodName+"=>("+methodStruct.parameters+")");
        }
        //map.put("methods", methodSet);
           	   
        return map;
	}
	
	
}
