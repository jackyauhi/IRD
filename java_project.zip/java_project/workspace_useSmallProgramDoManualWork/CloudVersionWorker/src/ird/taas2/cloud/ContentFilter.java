package ird.taas2.cloud;

import java.io.File;
import java.io.FileWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Logger;

import java.util.List;
import java.util.TreeMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.ArrayList;

public class ContentFilter {

	private Logger logger = Logger.getLogger(ContentFilter.class);

	public static void main(String[] args) throws Exception {
		ContentFilter cf = new ContentFilter();
		cf.process(ParameterMap.getParameterMap(args));
	}

	private void process(ParameterMap parameterMap) throws Exception {

		File folder = new File(parameterMap.get("dir"));
		String keywords = parameterMap.getDefault("keywords", "");

		if (!folder.exists()) {
			throw new Exception("index files folder not exists");
		}
		if (keywords.trim().length() == 0) {
			throw new Exception("keyword not specified");
		}

		String types = parameterMap.getDefault("types", "");
		Boolean isSimpleOutput = parameterMap.getDefault("format", "simple").equals("simple");

		Set<String> keywordSet = new HashSet<>();
		if (keywords.contains(",")) {
			keywordSet = new HashSet<>(Arrays.asList(keywords.split(",")));
		} else {
			keywordSet.add(keywords);
		}

		File outputFile = new File("content_worker_" + new Date().getTime() + ".txt");

		for (String keyword : keywordSet) {
			if (keyword.contains(".")) {
				continue;
			}
			throw new Exception("Please provide keyword as CALLER.METHOD (e.g. foo.bar)");
		}

		Set<String> tmpSet = new HashSet<>();
		for (String keyword : keywordSet) {
			tmpSet.add(keyword.trim());
		}
		keywordSet = tmpSet;

		Set<String> typeSet = new HashSet<>();

		if (types.trim().length() != 0) {
			if (types.contains(",")) {
				typeSet = new HashSet<>(Arrays.asList(types.split(",")));
			} else {
				typeSet.add(types);
			}
		}

		scan(folder, keywordSet, typeSet, isSimpleOutput, outputFile);
	}

	private class SearchThread extends Thread {

		private File[] files;
		private Integer start;
		private Integer end;
		private Set<String> keywordSet;
		private Set<String> criteriaSet;
		private List<String> matchLines;
		private Map<String, Set<String>> keywordFileMap;
		private Map<String, Set<String>> rootMap;

		public void setRootMap(Map<String, Set<String>> rootMap) {
			this.rootMap = rootMap;
		}

		public Map<String, Set<String>> getKeywordFileMap() {
			return keywordFileMap;
		}

		public List<String> getMatchLines() {
			return matchLines;
		}

		public SearchThread(Set<String> criteriaSet) {
			super();

			this.matchLines = new ArrayList<>();
			this.criteriaSet = criteriaSet;
			this.keywordFileMap = new HashMap<>();

		}

		public void setFiles(File[] files) {
			this.files = files;
		}

		public void setStart(Integer start) {
			this.start = start;
		}

		public void setEnd(Integer end) {
			this.end = end;
		}

		public void setKeywordSet(Set<String> keywordSet) {
			this.keywordSet = keywordSet;
		}

		@Override
		public void run() {
			if (end == null) {
				end = files.length;
			}
			for (; start < end; start++) {
				try {
					find(files[start]);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		private void find(File folder) throws Exception {

			String fileContent = new String(Files.readAllBytes(folder.toPath()));
			Boolean isKeywordFound = false;
			for (String keyword : keywordSet) {
				if (!keyword.contains(".")) {
					if (!fileContent.contains(keyword)) {
						continue;
					}

					isKeywordFound = true;
					break;

				} else {
					String action = keyword.split("\\.")[1];
					if (!fileContent.contains(action)) {
						continue;
					}
					isKeywordFound = true;
					break;

				}
			}
			if (!isKeywordFound) {
				return;
			}

			List<String> lines = Files.readAllLines(folder.toPath(), Charset.defaultCharset());

			Map<String, List<String>> classInstanceMap = new HashMap<>();
			for (String line : lines) {
				if (!line.contains("[OBJECT VARIABLE]") && !line.contains("[METHOD VARIABLE]")) {
					continue;
				}

				String variableLine = line.substring(line.indexOf("==>") + "==>".length());
				if (!variableLine.contains(" ")) {
					continue;
				}
				String className = variableLine.split(" ")[0];
				String instanceName = variableLine.split(" ")[1];

				for (String keyword : keywordSet) {
					if (!keyword.contains(".")) {
						continue;
					}
					String keywordClassName = keyword.split("\\.")[0];
					if (!keywordClassName.equals(className)) {
						continue;
					}
					if (classInstanceMap.get(className) == null) {
						classInstanceMap.put(className, new ArrayList<>());
					}

					classInstanceMap.get(className).add(instanceName);
				}

			}

			Set<String> tmpKeywordSet = new HashSet<>(keywordSet);
			for (String keyword : keywordSet) {
				if (!keyword.contains(".")) {
					continue;
				}
				String keywordClassName = keyword.split("\\.")[0];
				String actionName = keyword.split("\\.")[1];
				if (classInstanceMap.get(keywordClassName) == null) {
					continue;
				}
				for (String instanceName : classInstanceMap.get(keywordClassName)) {
					if (tmpKeywordSet.contains(instanceName + "." + actionName)) {
						continue;
					}
					tmpKeywordSet.add(instanceName + "." + actionName);
					logger.info("[ADD]" + instanceName + "." + actionName);
					if (rootMap.get(keyword) == null) {
						rootMap.put(keyword, new HashSet<>());
					}
					rootMap.get(keyword).add(instanceName + "." + actionName);
				}
			}
			keywordSet = tmpKeywordSet;

			for (String line : lines) {
				
				String matchedKeyword = null;

				for (String keyword : keywordSet) {
					if (!line.toLowerCase().contains(keyword.trim().toLowerCase())) {
						continue;
					}

					Boolean isMatchCriteria = false;

					if (criteriaSet == null || criteriaSet.size() == 0) {
						isMatchCriteria = true;
					} else {
						for (String criteria : criteriaSet) {
							if (!line.contains(criteria)) {
								continue;
							}
							isMatchCriteria = true;
							break;
						}
					}

					if (!isMatchCriteria) {
						continue;
					}
					
					if (matchedKeyword == null || matchedKeyword.length() < keyword.length()) {
						matchedKeyword = keyword;
					}
				}
				
				if (matchedKeyword == null) {
					continue;
				}
				
				matchLines.add(matchedKeyword + "|" + folder.getName() + ":" + line);
				if (keywordFileMap.get(matchedKeyword) == null) {
					keywordFileMap.put(matchedKeyword, new HashSet<>());
				}
				keywordFileMap.get(matchedKeyword).add(folder.getName().replace("--", File.separator));
			}

		}

	}

	private String getCallSource(String keyword, Map<String, Set<String>> rootMap) throws Exception {
		List<String> chain = new ArrayList<>();
		do {
			Boolean isFound = false;
			Set<String> searchedKeywords = new HashSet<>(chain);
			for (Entry<String, Set<String>> rootEntry : rootMap.entrySet()) {
				if (searchedKeywords.contains(rootEntry.getKey())) {
					continue;
				}
				if (!rootEntry.getValue().contains(keyword)) {
					continue;
				}
				chain.add(rootEntry.getKey());
				keyword = rootEntry.getKey();
				isFound = true;
				break;
			}
			if (!isFound) {
				break;
			}
		} while (true);
		return chain.get(chain.size() - 1);
	}

	private String getCallChain(String keyword, Map<String, Set<String>> rootMap) throws Exception {
		List<String> chain = new ArrayList<>();
		do {
			Boolean isFound = false;
			Set<String> searchedKeywords = new HashSet<>(chain);
			for (Entry<String, Set<String>> rootEntry : rootMap.entrySet()) {
				if (searchedKeywords.contains(rootEntry.getKey())) {
					continue;
				}
				if (!rootEntry.getValue().contains(keyword)) {
					continue;
				}
				chain.add(rootEntry.getKey());
				keyword = rootEntry.getKey();
				isFound = true;
				break;
			}
			if (!isFound) {
				break;
			}
		} while (true);
		return chain.toString().replaceAll(", ", " => ");
	}

	private void scan(File folder, Set<String> keywordSet, Set<String> typeSet, Boolean isSimpleOutput, File outputFile)
			throws Exception {
		File[] files = folder.listFiles();

		Integer handleCount = 50;

		JobFinder jf = new JobFinder();

		List<String> previousLines = null;

		Map<String, Set<String>> rootMap = new HashMap<>();

		TreeMap<String, Set<String>> jobInvokeMap = new TreeMap<>();

		Map<String, Set<String>> keywordFileMap = new HashMap<>();

		do {
			Boolean isFirstRun = previousLines == null;

			logger.info("===================" + keywordSet + "===================");

			List<String> matchLines = new ArrayList<>();
			for (int i = 0; i < Math.ceil(files.length / handleCount); i++) {
				Integer start = i * handleCount;
				Integer end = (i * handleCount) + handleCount;
				if (i * handleCount > files.length) {
					end = null;
				}
				SearchThread st = new SearchThread(typeSet);
				st.setRootMap(rootMap);
				st.setEnd(end);
				st.setStart(start);
				st.setFiles(files);
				st.setKeywordSet(keywordSet);
				st.start();
				st.join();
				matchLines.addAll(st.getMatchLines());
				if (!isFirstRun) {
					continue;
				}
				keywordFileMap.putAll(st.getKeywordFileMap());
			}

			if (previousLines != null && equalLists(previousLines, matchLines)) {

				logger.info("NO MORE RECORD");
				break;
			}

			keywordSet = new HashSet<>();

			for (String matchLine : matchLines) {
				String keyword = matchLine.substring(0, matchLine.indexOf("|"));
				ClassMethod cm = new ClassMethod(matchLine);
				String className = cm.getClassName();
				String actionName = cm.getMethodName();
				String implClassName = null;
				if (cm.getClassName().toLowerCase().endsWith("impl")) {
					implClassName = className;
					className = className.substring(0, className.length() - 4);
				}
				Boolean isImplClass = implClassName != null;
				keywordSet.add(className + "." + actionName);
				if (isImplClass) {
					keywordSet.add(implClassName + "." + actionName);
				}

				if (rootMap.get(keyword) == null) {
					rootMap.put(keyword, new HashSet<>());
				}

				rootMap.get(keyword).add(className + "." + actionName);
				if (isImplClass) {
					rootMap.get(keyword).add(implClassName + "." + actionName);
				}

				logger.info(isSimpleOutput ? className + "." + actionName
						: "[" + keyword + "] contains :" + className + "." + actionName);
				if (isImplClass) {
					logger.info(isSimpleOutput ? implClassName + "." + actionName
							: "[" + keyword + "] contains :" + implClassName + "." + actionName);
				}

				String jobName = jf.getJobName(className, folder);
				String jobNameWithImplClassName = isImplClass ? jf.getJobName(implClassName, folder) : null;

				if (jobName != null) {
					String job = jobName.split("\\.")[0];
					if (jobInvokeMap.get(job) == null) {
						jobInvokeMap.put(job, new HashSet<>());
					}
					jobInvokeMap.get(job).add(isSimpleOutput ? getCallSource(className + "." + actionName, rootMap)
							: getCallChain(className + "." + actionName, rootMap));
				}
				if (jobNameWithImplClassName != null && isImplClass) {
					String job = jobNameWithImplClassName.split("\\.")[0];
					if (jobInvokeMap.get(job) == null) {
						jobInvokeMap.put(job, new HashSet<>());
					}
					jobInvokeMap.get(job).add(isSimpleOutput ? getCallSource(implClassName + "." + actionName, rootMap)
							: getCallChain(implClassName + "." + actionName, rootMap));
				}

			}

			previousLines = matchLines;

			if (keywordSet.size() == 0) {
				logger.info("NO MORE RECORD");
				break;
			}

		} while (true);

		logger.info("=========================[BATCH JOB / TC EFFECTED]============================");

		FileWriter fw = new FileWriter(outputFile, false);

		for (Entry<String, Set<String>> entry : jobInvokeMap.entrySet()) {
			String jobName = entry.getKey();
			if (jobName == null) {
				continue;
			}

			if (isSimpleOutput) {
				Set<String> fileList = new HashSet<>();
				for (String keyword : entry.getValue()) {
					for (String filePath : keywordFileMap.get(keyword)) {
						File file = new File(filePath);
						fileList.add(file.getName());
					}
				}
				logger.info(entry.getKey() + "\t" + String.join(", ", fileList));
				fw.append(entry.getKey() + "\t" + String.join(", ", fileList) + System.lineSeparator());
			} else {

				logger.info(entry.getKey() + "\t" + entry.getValue());
			}
		}

		fw.close();

		logger.info("Exported to " + outputFile.getAbsolutePath());
	}

	private boolean equalLists(List<String> one, List<String> two) {
		if (one == null && two == null) {
			return true;
		}

		if ((one == null && two != null) || one != null && two == null || one.size() != two.size()) {
			return false;
		}

		// to avoid messing the order of the lists we will use a copy
		// as noted in comments by A. R. S.
		one = new ArrayList<String>(one);
		two = new ArrayList<String>(two);

		Collections.sort(one);
		Collections.sort(two);
		return one.equals(two);
	}

	class ClassMethod {
		private String className;
		private String methodName;

		public ClassMethod(String matchLine) {
			matchLine.substring(matchLine.indexOf("|") + 1);
			String classAction = matchLine.substring(matchLine.indexOf("]") + 1);
			classAction = classAction.substring(0, classAction.indexOf("==>"));
			String[] packageName = classAction.split("\\.");
			classAction = packageName[packageName.length - 1];
			classAction = classAction.replace("#", ".");

			className = classAction.split("\\.")[0];
			methodName = classAction.split("\\.")[1];
		}

		public String getClassName() {
			return className;
		}

		public void setClassName(String className) {
			this.className = className;
		}

		public String getMethodName() {
			return methodName;
		}

		public void setMethodName(String methodName) {
			this.methodName = methodName;
		}

	}

}
