package ird.taas2.cloud;

import java.io.File;
import java.io.FileWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.log4j.Logger;

public class SqlIdWorker {
	private Logger logger = Logger.getLogger(SqlIdWorker.class);

	public static void main(String[] args) throws Exception {
		SqlIdWorker siw = new SqlIdWorker();
		siw.process(ParameterMap.getParameterMap(args));
	}

	private void process(ParameterMap parameterMap) throws Exception {

		File folder = new File(parameterMap.get("dir"));
		String keywords = parameterMap.getDefault("keywords", "");
		
		File inFile = new File(parameterMap.getDefault("in", ""));

		if (!folder.exists()) {
			throw new Exception("index files folder not exists");
		}
		if (keywords.trim().length() == 0 && !inFile.exists()) {
			throw new Exception("keyword not specified");
		}

		String types = parameterMap.getDefault("types", "");
		Boolean isSimpleOutput = parameterMap.getDefault("format", "simple").equals("simple");

		Set<String> keywordSet = new HashSet<>();
		if (keywords.contains(",")) {
			keywordSet = new HashSet<>(Arrays.asList(keywords.split(",")));
		} else {
			keywordSet.add(keywords);
		}
		
		if (inFile.exists()) {
			List<String> keywordLines  = Files.readAllLines(inFile.toPath());
			for (String keywordLine: keywordLines) {
				keywordSet.add(keywordLine.trim());
			}
		}

		File outputFile = new File(this.getClass().getSimpleName()+"_" + new Date().getTime() + ".txt");

		Set<String> tmpSet = new HashSet<>();
		for (String keyword : keywordSet) {
			if (keyword.trim().length() == 0) {
				continue;
			}
			tmpSet.add(keyword.trim());
		}
		keywordSet = tmpSet;
		
		for (String keyword : keywordSet) {
			if (keyword.contains(".")) {
				continue;
			}
			throw new Exception("Invalid keyword found ("+keyword+") Please provide keyword as CALLER.METHOD (e.g. foo.bar)");
		}

		Set<String> typeSet = new HashSet<>();

		if (types.trim().length() != 0) {
			if (types.contains(",")) {
				typeSet = new HashSet<>(Arrays.asList(types.split(",")));
			} else {
				typeSet.add(types);
			}
		}

		scan(folder, keywordSet, typeSet, isSimpleOutput, outputFile);
	}

	private class SearchThread extends Thread {

		private File[] files;
		private Integer start;
		private Integer end;
		private Set<String> keywordSet;
		private Set<String> criteriaSet;
		private Map<String, Map<String, List<String>>> daoMethodMap;
		
		public Map<String, Map<String, List<String>>> getDaoMethodMap() {
			return daoMethodMap;
		}

		public SearchThread(Set<String> criteriaSet) {
			super();
			this.criteriaSet = criteriaSet;
			this.daoMethodMap = new HashMap<>();

		}

		public void setFiles(File[] files) {
			this.files = files;
		}

		public void setStart(Integer start) {
			this.start = start;
		}

		public void setEnd(Integer end) {
			this.end = end;
		}

		public void setKeywordSet(Set<String> keywordSet) {
			this.keywordSet = keywordSet;
		}

		@Override
		public void run() {
			if (end == null) {
				end = files.length;
			}
			for (; start < end; start++) {
				try {
					find(files[start]);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		
		private boolean isDaoImplClass(String filename) {
			String[] filenameParts = filename.split("--");
			if (filename.contains("--dao--") || filenameParts[filenameParts.length-1].toLowerCase().contains("daoimpl")) {
				return true;
			}
			return false;
		}

		private void find(File sourceFile) throws Exception {
			
			if (!isDaoImplClass(sourceFile.getName())) {
				return;
			}

			String fileContent = new String(Files.readAllBytes(sourceFile.toPath()));
			Boolean isKeywordFound = false;
			for (String keyword : keywordSet) {
				if (!keyword.contains(".")) {
					if (!fileContent.contains(keyword)) {
						continue;
					}

					isKeywordFound = true;
					break;

				} else {
					String action = keyword.split("\\.")[1];
					if (!fileContent.contains(action)) {
						continue;
					}
					isKeywordFound = true;
					break;

				}
			}
			if (!isKeywordFound) {
				return;
			}

			List<String> lines = Files.readAllLines(sourceFile.toPath(), Charset.defaultCharset());

			for (String line : lines) {
				
				String matchedKeyword = null;

				for (String keyword : keywordSet) {
					if (!line.toLowerCase().contains(keyword.trim().toLowerCase())) {
						continue;
					}

					Boolean isMatchCriteria = false;

					if (criteriaSet == null || criteriaSet.size() == 0) {
						isMatchCriteria = true;
					} else {
						for (String criteria : criteriaSet) {
							if (!line.contains(criteria)) {
								continue;
							}
							isMatchCriteria = true;
							break;
						}
					}

					if (!isMatchCriteria) {
						continue;
					}
					
					if (matchedKeyword == null || matchedKeyword.length() < keyword.length()) {
						matchedKeyword = keyword;
						logger.info("[FOUND] "+matchedKeyword+" in "+line);
					}
					
					
					//logger.info(keyword + "|" + sourceFile.getName() + ":" + line);
					
				}
				
				if (matchedKeyword == null) {
					continue;
				}


				String packageStr = line.substring(0, line.indexOf("#"));
				String[] parts = packageStr.split("\\.");
				String className = parts[parts.length-1];

				String methodname = line.substring(line.indexOf("#")+1);
				methodname = methodname.substring(0, methodname.indexOf("==>"));
				if (daoMethodMap.get(className) == null) {
					daoMethodMap.put(className, new HashMap<>());
				}
				if (daoMethodMap.get(className).get(methodname) == null) {
					daoMethodMap.get(className).put(methodname, new ArrayList<>());
				}
				
				daoMethodMap.get(className).get(methodname).add(matchedKeyword);
			}

		}

	}

	private void scan(File folder, Set<String> keywordSet, Set<String> typeSet, Boolean isSimpleOutput, File outputFile)
			throws Exception {
		File[] files = folder.listFiles();

		Integer handleCount = 50;
		
		Map<String, Map<String, List<String>>> daoMethodMap = new HashMap<>();

		do {

			logger.info("===================" + keywordSet + "===================");

			for (int i = 0; i < Math.ceil(files.length / handleCount); i++) {
				Integer start = i * handleCount;
				Integer end = (i * handleCount) + handleCount;
				if (i * handleCount > files.length) {
					end = null;
				}
				SearchThread st = new SearchThread(typeSet);
				st.setEnd(end);
				st.setStart(start);
				st.setFiles(files);
				st.setKeywordSet(keywordSet);
				st.start();
				st.join();
				daoMethodMap.putAll(st.getDaoMethodMap());
			}

			keywordSet = new HashSet<>();
			
			break;

		} while (true);
		
		logger.info("=====================[RESULT]========================");
		
		FileWriter fw = new FileWriter(outputFile, false);
		
		for (Entry<String, Map<String, List<String>>> daoMethodEntry: daoMethodMap.entrySet() ) {
			for (Entry<String, List<String>> methodEntry: daoMethodEntry.getValue().entrySet() ) {
				for (String dao: methodEntry.getValue()) {
					String msg = String.format("%s\t%s\t%s", daoMethodEntry.getKey(), methodEntry.getKey(), dao);
					logger.info(msg);
					fw.append(msg+System.lineSeparator());
				}
			}
		}
		fw.close();
		
		logger.info("Exported output "+outputFile.getAbsolutePath());
	}

	class ClassMethod {
		private String className;
		private String methodName;

		public ClassMethod(String matchLine) {
			matchLine.substring(matchLine.indexOf("|") + 1);
			String classAction = matchLine.substring(matchLine.indexOf("]") + 1);
			classAction = classAction.substring(0, classAction.indexOf("==>"));
			String[] packageName = classAction.split("\\.");
			classAction = packageName[packageName.length - 1];
			classAction = classAction.replace("#", ".");

			className = classAction.split("\\.")[0];
			methodName = classAction.split("\\.")[1];
		}

		public String getClassName() {
			return className;
		}

		public void setClassName(String className) {
			this.className = className;
		}

		public String getMethodName() {
			return methodName;
		}

		public void setMethodName(String methodName) {
			this.methodName = methodName;
		}

	}
}
