//package javaAutoRunCloudVersionWorker;
////STEP 1. Import required packages
//import java.io.BufferedReader;
//import java.io.File;
//import java.io.FileNotFoundException;
//import java.io.FileReader;
//import java.io.FileWriter;
//import java.io.IOException;
//import java.nio.file.Files;
//import java.nio.file.Path;
//import java.nio.file.Paths;
//import java.sql.*;
//import java.text.SimpleDateFormat;
//import java.util.ArrayList;
//import java.util.Comparator;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Scanner;
//import java.util.regex.Pattern;
//import java.util.stream.Collectors;
//import java.util.stream.Stream;
//
//import ird.taas2.cloud.CloudVersionWorker;
//
//public class connectDatabaseAndUsingSQL {
//
////   public static void deleteFile(File element) {
////	    if (element.isDirectory()) {
////	        for (File sub : element.listFiles()) {
////	            deleteFile(sub);
////	        }
////	    }
////	    element.delete();
////	}
//   public static void main(String[] args) {
//
//			
////			try{    
////			    ProcessBuilder pbuilder = new ProcessBuilder(autoConvertorBat);
////			    
////			    pbuilder.directory(new File(convertorFilePath) ); // this is where you set the root folder for the executable to run with
////			    pbuilder.redirectErrorStream(true);
////			    Process process =  pbuilder.start();
////		
////			    Scanner s = new Scanner(process.getInputStream());
////			    StringBuilder text = new StringBuilder();
////			    System.out.println(System.lineSeparator());
////			    while (s.hasNextLine()) {
////			      System.out.println(s.nextLine());
////			    }
////			    s.close();
////			    int result = process.waitFor();
////			    
////			}catch( Exception e) {
////				e.printStackTrace();
////			}
//   }//end main
//   public static void checkFileProcess(int j) {
//		  getBlockData=true;
//		  blockSystemStore = blockSystemStore + blockFileMap.get(checkFileList.get(j).toString()) +System.lineSeparator();
//		  blockPathStore = blockPathStore +checkFileList.get(j).toString()+System.lineSeparator();
//		  removeFileList.add(realFileList.get(j).toString());
//		  removeFileMap.put(realFileList.get(j).toString(), cluster);
//   }
//   public static void callHelperBatToProcess(String inputPath,String name) {
//		try{    
//		    ProcessBuilder pbuilder = new ProcessBuilder(helperBat);
//		    
//		    pbuilder.directory(new File(convertorFilePath) ); // this is where you set the root folder for the executable to run with
//		    pbuilder.redirectErrorStream(true);
//		    Process process =  pbuilder.start();
//
//		    Scanner s = new Scanner(process.getInputStream());
//		    StringBuilder text = new StringBuilder();
//		    System.out.println(System.lineSeparator());
//		    while (s.hasNextLine()) {
//		      System.out.println(s.nextLine());
//		    }
//		    s.close();
//		    int result = process.waitFor();
//		    
//		}catch( Exception e) {
//			e.printStackTrace();
//		}	    
//
//
//		   File dir = new File(inputPath);
//
//		   File listDir[] = dir.listFiles();
//		   for (int j = 0; j < listDir.length; j++) {
////			   System.out.println("dir = " + dir.lastModified());
//		       if (listDir[j].isDirectory()) {
//		           if (listDir[j].lastModified() > lastModifiedTime)
//		           {
//		               chosenFilePath = listDir[j];
//		               lastModifiedTime = listDir[j].lastModified();
//		           }
//		           }
//		   }
////		   System.out.println("chosenFile = " + chosenFilePath);
//		   realName= new File(chosenFilePath.getParent()+"\\"+name);
//		   outputcheckingFileList.add(reqId+","+realName+","+chosenFilePath.getAbsolutePath());
//		   File renameFolder = new File(chosenFilePath.getAbsolutePath());
//		   renameFolder.renameTo(realName);
//		   
//			try {
//				BufferedReader fileReader = new BufferedReader(new FileReader(convertorFilePath+"\\"+name+".txt"));
//				String line=null;
//			    try {
//					while ((line = fileReader.readLine()) != null)
//					{	
//						if(line.contains("@@\\")) {
//				        	String[] spiltData = line.split(Pattern.quote("@@\\"),2);
//				        	if(spiltData[0].contains("\\TAAS2_DEV")) {
//				        		String[] spiltData1 = spiltData[0].split(Pattern.quote("\\TAAS2_DEV"),2);
//				        		checkingExportFile.add(spiltData1[1]);
//				        	}
//				          }
//						else {
//							checkingExportFile.add(line);
//						}
//
//					}
//					fileReader.close();
//				} 
//			    catch (IOException e1) {
//					e1.printStackTrace();
//				}
//				} 
//		   	catch (FileNotFoundException e1) {
//					e1.printStackTrace();
//				}
//			
//			try (Stream<Path> walk = Files.walk(Paths.get(inputPath))) {
//				List<String> result = walk.filter(Files::isRegularFile)
//						.map(x -> x.toString()).collect(Collectors.toList());
//				for (int j = 0; j < result.size(); j++) {
//					if(result.get(j).toString().contains("\\TAAS2_DEV")) {
//						String[] spiltData = result.get(j).toString().split(Pattern.quote("\\TAAS2_DEV"),2);
//						if(!checkingExportFile.contains(spiltData[1])) {
//							problemExportFile.add(name+" , "+spiltData[1]);
//						}
////						System.out.println("spiltData[1] = " + spiltData[1]);
//					}
//					
//				}
//				
//			} catch (IOException e) {
//				e.printStackTrace();
//			}	
//		   
//		   
//		   countFile++;
//		   
//		   
//
////           //export.txt delete()
////		   File deleteText = new File(convertorFilePath+"\\"+requiredName+".txt");
////		   if(deleteText.exists()) {
////			   deleteText.delete();
////		   }
////		   System.out.println("This "+requiredName+" Output List Finish");
//   }
//   public static void generateExportFile(List<String> requiredList,String name,String status) {
//	   	if(status.equalsIgnoreCase("BAT")) {
//	    		try {
//	    			FileWriter fileWriter = new FileWriter(convertorFilePath+"\\"+name+".txt");
//	    			for (int j = 0; j < requiredList.size(); j++) {
//	    				fileWriter.write(requiredList.get(j).toString()+System.lineSeparator());
//	    			}
//	    			fileWriter.close();
//	    		} catch (IOException iox) {
//	    			iox.printStackTrace();
//	    			System.out.println("File can not save any data in outputPathList");
//	    		}
//	    		try {
//	    			FileWriter fileWriter = new FileWriter(convertorFilePath+"\\"+helperName);
//	    			fileWriter.write("###### Helper 1 Setup ######"+System.lineSeparator());
//	    			fileWriter.write("CLEARCASE_PATH="+ClearCaseView+System.lineSeparator());
//	    			fileWriter.write("run_action_list=export_tc_batch"+System.lineSeparator());
//	    			fileWriter.write(System.lineSeparator());
//	    			fileWriter.write("#[action_type : 1-SCAN, 2-DEPLOY, 3-EXPORT, 4-CHECK_VER, 9-SCAN_ALL_TC]"+System.lineSeparator());
//	    			fileWriter.write("#[target_env 	: 1=/Application/, 2=/PRD_Application/Online/, 3=/PRD_Application/Batch/]"+System.lineSeparator());
//	    			fileWriter.write(System.lineSeparator());
//	    			fileWriter.write("#[EXPORT Action, Function : to export Batch]"+System.lineSeparator());
//	    			fileWriter.write("#[sample for action type 3]"+System.lineSeparator());
//	    			fileWriter.write("export_tc_batch.action_type=3"+System.lineSeparator());
//	    			fileWriter.write("export_tc_batch.target_env=3"+System.lineSeparator());
//	    			fileWriter.write("export_tc_batch.scan_off=true"+System.lineSeparator());
//	    			fileWriter.write("export_tc_batch.ct_only=false"+System.lineSeparator());
//	    			fileWriter.write("export_tc_batch.target_label="+System.lineSeparator());
//	    			fileWriter.write("export_tc_batch.function_list="+System.lineSeparator());
//	    			fileWriter.write("export_tc_batch.adhoc_file_list="+name+".txt"+System.lineSeparator());
//	    			fileWriter.close();
//	    		} catch (IOException iox) {
//	    			iox.printStackTrace();
//	    			System.out.println("File can not save any data in outputPathList");
//	    		}
//	      }
//	    else if(status.equalsIgnoreCase("WAS")) {
//	  		try {
//				FileWriter fileWriter = new FileWriter(convertorFilePath+"\\"+name+".txt");
// 			for (int j = 0; j < requiredList.size(); j++) {
// 				fileWriter.write(requiredList.get(j).toString()+System.lineSeparator());
// 			}
//				fileWriter.close();
//			} catch (IOException iox) {
//				iox.printStackTrace();
//				System.out.println("File can not save any data in outputPathList");
//			}
//	  		try {
//				FileWriter fileWriter = new FileWriter(convertorFilePath+"\\"+helperName);
//				fileWriter.write("###### Helper 1 Setup ######"+System.lineSeparator());
//				fileWriter.write("CLEARCASE_PATH="+ClearCaseView+System.lineSeparator());
//				fileWriter.write("run_action_list=export_tc_online"+System.lineSeparator());
//				fileWriter.write(System.lineSeparator());
//				fileWriter.write("#[action_type : 1-SCAN, 2-DEPLOY, 3-EXPORT, 4-CHECK_VER, 9-SCAN_ALL_TC]"+System.lineSeparator());
//				fileWriter.write("#[target_env 	: 1=/Application/, 2=/PRD_Application/Online/, 3=/PRD_Application/Batch/]"+System.lineSeparator());
//				fileWriter.write(System.lineSeparator());
//				fileWriter.write("#[EXPORT Action, Function : to export Online]]"+System.lineSeparator());
//				fileWriter.write("#[sample for action type 3]"+System.lineSeparator());
//				fileWriter.write("export_tc_online.action_type=3"+System.lineSeparator());
//				fileWriter.write("export_tc_online.target_env=2"+System.lineSeparator());
//				fileWriter.write("export_tc_online.scan_off=true"+System.lineSeparator());
//				fileWriter.write("export_tc_online.ct_only=false"+System.lineSeparator());
//				fileWriter.write("export_tc_online.jsp_only=false"+System.lineSeparator());
//				fileWriter.write("export_tc_online.target_label="+System.lineSeparator());
//				fileWriter.write("export_tc_online.function_list="+System.lineSeparator());
//				fileWriter.write("export_tc_online.adhoc_file_list="+name+".txt"+System.lineSeparator());
//				fileWriter.close();
//			} catch (IOException iox) {
//				iox.printStackTrace();
//				System.out.println("File can not save any data in outputPathList");
//			}
//	  		
//	      }   		
//   }
//}//end FirstExample
