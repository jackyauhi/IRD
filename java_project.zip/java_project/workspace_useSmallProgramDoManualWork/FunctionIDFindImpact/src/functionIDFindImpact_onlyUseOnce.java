import java.io.BufferedReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class functionIDFindImpact_onlyUseOnce {
	public static List<String> inputPathList = new ArrayList<String>();
	public static List<String> functionNameList = new ArrayList<String>();
	public static List<String> outputInputPathList = new ArrayList<String>();
	public static List<String> outputFunctionNameList = new ArrayList<String>();
	public static Map<String, String> functionName = new HashMap<String, String>();
	public static Map<String, String> resultMap = new HashMap<String, String>();
	
	public static void main(String[] args) {
//		String inputList="T:\\jackyau\\filePath111.txt";
		String inputList="T:\\jackyau\\test3.csv";
//		String inputPath="T:\\jackyau\\ProgramList_ALL_TCs_20200921";
		String inputPath="D:\\Alex_things\\ProgramList_ALL_TCs_20210120";

		String outputInputPath="T:\\jackyau\\InputPath_functionID_Type_main1.csv";
		String outputFunctionName="T:\\jackyau\\functionID_InputPath_Type_main1.csv";
		String content=null;
		String[] splitData;
		String[] splitFilePath;
		List<String> batchOnlineList = new ArrayList<String>();
		List<String> statementsList = new ArrayList<String>();
		try {
			BufferedReader fileReader = new BufferedReader(new FileReader(inputList));
			String line=null;
		    try {
				while ((line = fileReader.readLine()) != null)
				{	
//					String[] splitData = line.split(Pattern.quote("\\"));
//					System.out.println("splitData[splitData.length] =" + splitData.length);
					splitData = line.split(",",2);
					splitFilePath = splitData[1].split(",",2);
					inputPathList.add(splitFilePath[0]);
					statementsList.add(splitFilePath[1]);
					batchOnlineList.add(splitData[0]);
//					System.out.println("inputPathList =" + splitFilePath[0]);
//					System.out.println("statementsList =" + splitFilePath[1]);
//					System.out.println("batchOnlineList =" + splitData[0]);
				}
				fileReader.close();
			} 
		    catch (IOException e1) {
				e1.printStackTrace();
			}
			} 
	   	catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
		int countpath=0;
		for (int i = 0; i < inputPathList.size(); i++) {
			String ImpactFunctionString="";
			boolean haveFunctionNameList = false;
			int count =0;
			if(countpath==20) {
				break;
			}
		try (Stream<Path> walk = Files.walk(Paths.get(inputPath))) {
			List<String> result = walk.map(x -> x.toString())
					.filter(f -> f.contains(".txt")).collect(Collectors.toList());

			for (int j = 0; j < result.size(); j++) {
				try {
					content = new String(Files.readAllBytes(Paths.get(result.get(j).toString())));				
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(content.contains(inputPathList.get(i).toString())) {
					String[] splitData1 = result.get(j).toString().split(Pattern.quote("\\"));
					String[] splitName = splitData1[splitData1.length-1].split(Pattern.quote("_"));
					if(count==0) {
						ImpactFunctionString=splitName[splitName.length-2];
						functionNameList.add(splitName[splitName.length-2]);
					}
					else {
						ImpactFunctionString=ImpactFunctionString+System.lineSeparator()+splitName[splitName.length-2];
						functionNameList.add(splitName[splitName.length-2]);
					}
					count++;
					haveFunctionNameList=true;
				}
			}
			if(haveFunctionNameList) {
				outputInputPathList.add(inputPathList.get(i).toString()+","+"\""+ImpactFunctionString+"\""+System.lineSeparator());
				System.out.println(inputPathList.get(i).toString()+System.lineSeparator());
				for (int f = 0; f < functionNameList.size(); f++) {
					functionName.put(functionNameList.get(f).toString(), inputPathList.get(i).toString());
				}
				resultMap.put(inputPathList.get(i).toString()+"1314151617181921"+batchOnlineList.get(i).toString()+"1314151617181921"+statementsList.get(i).toString(), ImpactFunctionString);
			}
			else {
				outputInputPathList.add(inputPathList.get(i).toString()+","+System.lineSeparator());
				System.out.println(inputPathList.get(i).toString()+System.lineSeparator());
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		}//end of for loop
		functionNameList.clear();
        // Get all keys
        Set<String> keySet = functionName.keySet();
        for (String key : keySet) {
        	functionNameList.add(key);
        }
		
	      for (int j = 0; j < functionNameList.size(); j++) {
	    	  String InputPathString="";
	    	  String batchOnlineString="";
	    	  String statementString="";
	    	  int count =0;
	    	  
	    	  System.out.println(functionNameList.get(j).toString());

	          for (Map.Entry<String, String> entry : resultMap.entrySet()) {
//	              String k = entry.getKey();
//	              String v = entry.getValue();
//	              System.out.println("Key: " + k + ", Value: " + v);
	              if (entry.getValue().contains(functionNameList.get(j).toString())) {
	                  System.out.println("entry.getKey() = "+entry.getKey());
	    			  splitData = entry.getKey().split("1314151617181921",2);
					  splitFilePath = splitData[1].split("1314151617181921",2);
					  String[] splitFilePathFront = splitFilePath[1].split(Pattern.quote("\""),2);
					  String[] splitFilePathEnd=new String[1];
					  splitFilePathEnd[0]="";
					  if(splitFilePathFront.length==2) {
						  splitFilePathEnd = splitFilePathFront[1].split(";",2);
						  splitFilePathEnd[0]=splitFilePathEnd[0]+";";
					  }
		    		  if(count==0) {
		    			  InputPathString=splitData[0];
		    			  batchOnlineString=splitFilePath[0];
		    			  statementString=splitFilePathFront[0]+splitFilePathEnd[0];
		    			  System.out.println("inputPathList =" + InputPathString);
		    			  System.out.println("batchOnlineString =" + batchOnlineString);
		    			  System.out.println("statementString =" + statementString);
		    		  }
		    		  else {
		    			  InputPathString=InputPathString+System.lineSeparator()+splitData[0];
		    			  batchOnlineString=batchOnlineString+System.lineSeparator()+splitFilePath[0];
		    			  statementString=statementString+System.lineSeparator()+splitFilePathFront[0]+splitFilePathEnd[0];
		    			  System.out.println("InputPathString =" + InputPathString);
		    			  System.out.println("batchOnlineString =" + batchOnlineString);
		    			  System.out.println("statementString =" + statementString);
		    		  }
		    		  count++;
	              }
	          }
	    	  outputFunctionNameList.add(functionNameList.get(j).toString()+","+"\""+batchOnlineString+"\""+","+"\""+InputPathString+"\""+","+"\""+statementString+"\""+","+System.lineSeparator());
	      }
		try {
		FileWriter fileWriter = new FileWriter(outputInputPath);
		for (int i = 0; i < outputInputPathList.size(); i++) {
			fileWriter.write(outputInputPathList.get(i).toString());
		}
		fileWriter.close();			
	} catch (IOException iox) {
		iox.printStackTrace();
		System.out.println("File can not save any data in outputPathList");
	}
		try {
		FileWriter fileWriter = new FileWriter(outputFunctionName);
		for (int i = 0; i < outputFunctionNameList.size(); i++) {
			fileWriter.write(outputFunctionNameList.get(i).toString());
		}
		fileWriter.close();			
	} catch (IOException iox) {
		iox.printStackTrace();
		System.out.println("File can not save any data in outputPathList");
	}
	}
}