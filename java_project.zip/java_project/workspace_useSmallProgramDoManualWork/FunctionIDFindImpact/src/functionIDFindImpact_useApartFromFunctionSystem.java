import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class functionIDFindImpact_useApartFromFunctionSystem {
	public static List<String> inputPathList = new ArrayList<String>();
	public static List<String> functionNameList = new ArrayList<String>();
	public static List<String> outputInputPathList = new ArrayList<String>();
	public static List<String> outputFunctionNameList = new ArrayList<String>();
	public static Map<String, String> functionName = new HashMap<String, String>();
	public static Map<String, String> resultMap = new HashMap<String, String>();
	
	public static void main(String[] args) throws Exception {
//		String inputList="T:\\jackyau\\test11.txt";
		String inputList="T:\\jackyau\\test4.csv";
//		String inputPath="T:\\jackyau\\ProgramList_ALL_TCs_20200921";
		String inputPath="D:\\Alex_things\\ProgramList_ALL_TCs_20210902";

		String outputInputPath="T:\\jackyau\\InputPath_functionID_Type_mainmain111.csv";
		String outputFunctionName="T:\\jackyau\\functionID_InputPath_Type_test.csv";
		String content=null;
		String[] splitData1;
		String[] splitFilePath;
		List<String> batchOnlineList = new ArrayList<String>();
		List<String> statementsList = new ArrayList<String>();
		try {
//			BufferedReader fileReader = new BufferedReader(new FileReader(inputList));
			BufferedReader fileReader = new BufferedReader(new InputStreamReader(new FileInputStream(inputList),StandardCharsets.UTF_8));
			String line=null;
		    try {
				while ((line = fileReader.readLine()) != null)
				{	
//					String[] splitData = line.split(Pattern.quote("\\"));
//					System.out.println("splitData[splitData.length] =" + splitData.length);
//					if(line.contains(",")) {
//						String[] splitData = line.split(",");
//						inputPathList.add(splitData[0]);
//					}
//					else {
					//.txt only
//						inputPathList.add(line);
//					}
					splitData1 = line.split(",",2);
					splitFilePath = splitData1[1].split(",",2);
					inputPathList.add(splitFilePath[0]);
					statementsList.add(splitFilePath[1]);
					batchOnlineList.add(splitData1[0]);
				}
				fileReader.close();
			} 
		    catch (IOException e1) {
				e1.printStackTrace();
			}
			} 
	   	catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
		int countpath=0;
		for (int i = 0; i < inputPathList.size(); i++) {
			String ImpactFunctionString="";
			boolean haveFunctionNameList = false;
			int count =0;
			if(countpath==20) {
				break;
			}
		try (Stream<Path> walk = Files.walk(Paths.get(inputPath))) {
			List<String> result = walk.map(x -> x.toString())
					.filter(f -> f.contains(".txt")).collect(Collectors.toList());

			for (int j = 0; j < result.size(); j++) {
				try {
					content = new String(Files.readAllBytes(Paths.get(result.get(j).toString())));				
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				File fileToSave = new File(result.get(j).toString());
				File functionSystem = new File(fileToSave.getParent());
				if(content.contains(inputPathList.get(i).toString())) {
//					System.out.println("fileToSave.getParent() ="+fileToSave.getParent());
//					System.out.println("fileToSave1.getName ="+functionSystem.getName());
					String[] splitData = result.get(j).toString().split(Pattern.quote("\\"));
					String[] splitName = splitData[splitData.length-1].split(Pattern.quote("_"));
//					if(count==0) {
						ImpactFunctionString=splitName[splitName.length-2];
//						functionNameList.add(splitName[splitName.length-2]);
//					}
//					else {
//						ImpactFunctionString=ImpactFunctionString+System.lineSeparator()+splitName[splitName.length-2];
//						functionNameList.add(splitName[splitName.length-2]);
//					}
					outputInputPathList.add(ImpactFunctionString+","+batchOnlineList.get(i).toString()+","+inputPathList.get(i).toString()+","+statementsList.get(i).toString()+","+functionSystem.getName()+System.lineSeparator());
					System.out.println(inputPathList.get(i).toString()+System.lineSeparator());
					count++;
					haveFunctionNameList=true;
				}
			}
			if(haveFunctionNameList) {
//				outputInputPathList.add(inputPathList.get(i).toString()+","+"\""+ImpactFunctionString+"\""+System.lineSeparator());
//				System.out.println(inputPathList.get(i).toString()+System.lineSeparator());
////				for (int f = 0; f < functionNameList.size(); f++) {
////					functionName.put(functionNameList.get(f).toString(), inputPathList.get(i).toString());
				}
////				resultMap.put(inputPathList.get(i).toString(), ImpactFunctionString);
//			}
			else {
				outputInputPathList.add(ImpactFunctionString+","+batchOnlineList.get(i).toString()+","+inputPathList.get(i).toString()+","+statementsList.get(i).toString()+","+System.lineSeparator());
				System.out.println(inputPathList.get(i).toString()+System.lineSeparator());
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		}//end of for loop
//		functionNameList.clear();
//        // Get all keys
//        Set<String> keySet = functionName.keySet();
//        for (String key : keySet) {
//        	functionNameList.add(key);
//        }
//		
//	      for (int j = 0; j < functionNameList.size(); j++) {
//	    	  String InputPathString="";
//	    	  int count =0;
//	    	  
//	    	  System.out.println(functionNameList.get(j).toString());
//
//	          for (Map.Entry<String, String> entry : resultMap.entrySet()) {
////	              String k = entry.getKey();
////	              String v = entry.getValue();
////	              System.out.println("Key: " + k + ", Value: " + v);
//	              if (entry.getValue().contains(functionNameList.get(j).toString())) {
////	                  System.out.println(entry.getKey());
//		    		  if(count==0) {
//		    			  InputPathString=entry.getKey();
//		    		  }
//		    		  else {
//		    			  InputPathString=InputPathString+System.lineSeparator()+entry.getKey();
//		    		  }
//		    		  count++;
//	              }
//	          }
//	    	  outputFunctionNameList.add(functionNameList.get(j).toString()+","+"\""+InputPathString+"\""+System.lineSeparator());
//	      }
		try {
			BufferedWriter fileWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(outputInputPath), StandardCharsets.UTF_8));
//		FileWriter fileWriter = new FileWriter(outputInputPath);
		//Function name	Batch/Online	Files	Statements
//ImpactFunctionString+","+batchOnlineList.get(i).toString()+","+inputPathList.get(i).toString()+","+statementsList.get(i).toString()+","+functionSystem.getName()+System.lineSeparator());
		fileWriter.write("Function name,Batch/Online,Files,Statements,functionSystem"+System.lineSeparator());
		for (int i = 0; i < outputInputPathList.size(); i++) {
			fileWriter.write(outputInputPathList.get(i).toString());
		}
		fileWriter.close();			
	} catch (IOException iox) {
		iox.printStackTrace();
		System.out.println("File can not save any data in outputPathList");
	}
//		try {
//		FileWriter fileWriter = new FileWriter(outputFunctionName);
//		for (int i = 0; i < outputFunctionNameList.size(); i++) {
//			fileWriter.write(outputFunctionNameList.get(i).toString());
//		}
//		fileWriter.close();			
//	} catch (IOException iox) {
//		iox.printStackTrace();
//		System.out.println("File can not save any data in outputPathList");
//	}
	}
}