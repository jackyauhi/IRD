import java.io.BufferedReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class outputSpitContent {
	public static ArrayList<String> inputFileList = new ArrayList<String>();
	public static ArrayList<String> outputFileList = new ArrayList<String>();
	
	public static void main(String[] args) {
		String inputPath="D:\\User\\searchPath\\OnlinePath_main.txt";
		String spitPartOfContent="\\jsp\\";
		String spitPartOfContent1="\\ird\\";
		String outputPath="T:\\jackyau\\OnlinePath_main.txt";
		String finalContent="";
		try {
			BufferedReader fileReader = new BufferedReader(new FileReader(inputPath));
			String line=null;
		    try {
				while ((line = fileReader.readLine()) != null)
				{	
					if(line.contains(spitPartOfContent)) {
						String[] keepSpitContent= line.split(Pattern.quote(spitPartOfContent),2);
						finalContent=spitPartOfContent+keepSpitContent[1];
//						while(finalContent.contains("  ")) {
//							finalContent=finalContent.replaceAll("  ", " ");
//						}
						inputFileList.add(finalContent);
					}
					if(line.contains(spitPartOfContent1)) {
						String[] keepSpitContent= line.split(Pattern.quote(spitPartOfContent1),2);
						finalContent=spitPartOfContent1+keepSpitContent[1];
//						while(finalContent.contains("  ")) {
//							finalContent=finalContent.replaceAll("  ", " ");
//						}
						inputFileList.add(finalContent);
					}
				}
				fileReader.close();
			} 
		    catch (IOException e1) {
				e1.printStackTrace();
			}
			} 
	   	catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
		try {
			FileWriter fileWriter = new FileWriter(outputPath);
			for (int i = 0; i < inputFileList.size(); i++) {
				fileWriter.write(inputFileList.get(i).toString()+System.lineSeparator());
			}
			fileWriter.close();
		} catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data in outputPathList");
		}
	}
}