//STEP 1. Import required packages
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import ird.taas2.cloud.CloudVersionWorker;

public class connectDatabaseAndUsingSQL {
	public static File chosenFilePath=null;
	public static long lastModifiedTime = Long.MIN_VALUE;
	public static List<String> inputFileList = new ArrayList<String>();
	public static List<String> checkingExportFile = new ArrayList<String>();
	static boolean exportFileExist=true;
	public static List<String> problemExportFile = new ArrayList<String>();
	public static HashMap<String, String> blockFileMap = new HashMap<String, String>();
	public static List<String> blockPathText = new ArrayList<String>();
	public static String blockSystemStore = new String();
	public static String blockPathStore = new String();
	public static List<String> checkFileList = new ArrayList<String>();
	public static List<String> realFileList = new ArrayList<String>();
	public static List<String> removeFileList = new ArrayList<String>();
	public static HashMap<String, String> removeFileMap = new HashMap<String, String>();
	public static List<String> outputFileList = new ArrayList<String>();
	public static List<String> outputcheckingFileList = new ArrayList<String>();
	public static String convertorFilePath = "";
	public static String helperBat ="";
	public static String autoConvertorBat = "";
   // JDBC driver name and database URL
   static final String JDBC_DRIVER = "com.ibm.db2.jcc.DB2Driver";  
   static final String DB_URL = "jdbc:db2://10.31.90.26:50010/tadb";

   //  Database credentials
   static final String USER = "dtabatd1";
   static final String PASS = "batcom246";
   static String file_list = "";
   static String cluster = "";
   static String onlineName = "_online_export";
   static String batchName = "_batch_export";
   static String reqId="";
   static String requiredName="";
   static File realName = null;
   static String helperName="helper.properties";
   static String ClearCaseView="";
   static String excelPath="";
   static boolean noNeedBlock=true;
   static boolean getBlockData=false;
   static int countFile = 0;
   public static void deleteFile(File element) {
	    if (element.isDirectory()) {
	        for (File sub : element.listFiles()) {
	            deleteFile(sub);
	        }
	    }
	    element.delete();
	}
   public static void main(String[] args) {
   convertorFilePath =  args[0];
//   ClearCaseView="D:/ccshare/jyyau_view_ClearCase_UAT/";
//   excelPath="Q:\\IR1E\\Cloud Migration\\Guidelines\\Program Change List";
   ClearCaseView=args[1];
   excelPath=args[2];
   helperBat=convertorFilePath+"\\helper1.bat";
   autoConvertorBat=convertorFilePath+"\\1Non_Auto_Convertor.bat";
   requiredName="";
   Connection conn = null;
   Statement stmt = null;
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
//	String inputPath=args[0];
   String inputPath=convertorFilePath+"\\output";
   String blockPathList=convertorFilePath+"\\version_list.txt";
   String inputList=convertorFilePath+"\\req_id.txt";
   File deleteFile = new File(inputPath);
   deleteFile(deleteFile);
   deleteFile = new File(convertorFilePath+"\\Result\\output");
   deleteFile(deleteFile);
   
   String[] args1 =  new String[] {"-prefix","Common Program Selection List","-dir", excelPath, "-out", blockPathList, "-pIdx", "0", "-vIdx", "3"};

   CloudVersionWorker cvw = new CloudVersionWorker();
		   try {
			cvw.process(cvw.getParameterMap(args1));
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

	try {
		BufferedReader fileReader = new BufferedReader(new FileReader(blockPathList));
		String line=null;
	    try {
			while ((line = fileReader.readLine()) != null)
			{	
				line=line.replaceAll("\\s*", "");
					if(line.contains("\\")) {
						String[] spiltData = line.split(Pattern.quote("\\"),2);
						line="\\"+spiltData[1];
						if(line.contains("@@\\")) {
				        	String[] spiltData1 = line.split(Pattern.quote("@@\\"),2);
				        	line=spiltData1[0];
						}
						blockFileMap.put(line, spiltData[0]);	
					}						
			}
			fileReader.close();
		} 
	    catch (IOException e1) {
			e1.printStackTrace();
		}
		} 
   	catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
	try {
		BufferedReader fileReader = new BufferedReader(new FileReader(inputList));
		String line=null;
	    try {
			while ((line = fileReader.readLine()) != null)
			{	
				inputFileList.add(line);

			}
			fileReader.close();
		} 
	    catch (IOException e1) {
			e1.printStackTrace();
		}
		} 
   	catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
	for (int i = 0; i < inputFileList.size(); i++) {
//      System.out.println("Start");
		reqId=inputFileList.get(i).toString();
		noNeedBlock=true;
		exportFileExist=true;
		checkFileList.clear();
		realFileList.clear();
		blockSystemStore = "";
		blockPathStore ="";
		getBlockData=false;
   try{
      //STEP 2: Register JDBC driver
      Class.forName(JDBC_DRIVER);

      //STEP 3: Open a connection
//      System.out.println("Connecting to database...");
      conn = DriverManager.getConnection(DB_URL,USER,PASS);

      //STEP 4: Execute a query
//      System.out.println("Creating statement...");
      stmt = conn.createStatement();
      String sql;
      sql = "SELECT * FROM ccmpplus.tbl_req where req_id ="+reqId;
      ResultSet rs = stmt.executeQuery(sql);
      String test="";
      //STEP 5: Extract data from result set
      while(rs.next()){
         //Retrieve by column name
         file_list = rs.getString("file_list");
         cluster = rs.getString("cluster");
         test=rs.getString("prd_rel_notes_ts");
       System.out.print(" prd_rel_notes_ts: " + test);
//         System.out.print(" cluster: " + cluster);
      }
      //STEP 6: Clean-up environment
      rs.close();
      stmt.close();
      conn.close();
      
      String[] file_list_path = file_list.split(System.lineSeparator());
      for (int j = 0; j < file_list_path.length; j++) {
    	  String checkFilePath = "";
    	  if(file_list_path[j].contains("Application\\")) {
    		  String[] spiltData = file_list_path[j].split(Pattern.quote("Application\\"),2);
	          if(spiltData[1].contains("@@\\")) {
	        	String[] spiltData1 = spiltData[1].split(Pattern.quote("@@\\"),2);
	        	checkFilePath=spiltData1[0];
	          }
	          if(checkFilePath.contains("\\")) {
	        	  String[] spiltData2 = checkFilePath.split(Pattern.quote("\\"),2);
	        	  checkFilePath="\\"+spiltData2[1];
	          }
    	  }
//    	  if(j == 0) {
//    		  checkFilePath="\\Common\\CT_Common\\src\\ird\\taas2\\ct\\dao\\CtfacmvxAdhocRc1Dao.java";
//    	  }
//    	  if(j == 1) {
//    		  checkFilePath="\\Common\\BR_Common\\src\\ird\\taas2\\br\\dao\\TMP_BRFPOVPT_SqlMap.xml";
//    	  }
//    	  if(j == 2) {
//    		  checkFilePath="\\Common\\BR_Common\\src\\ird\\taas2\\br\\dao\\impl\\BrapapsupDaoImpl.java";
//    	  }
//    	  System.out.println(checkFilePath);
    	  checkFileList.add(checkFilePath);
    	  realFileList.add(file_list_path[j]);
      }
      //block
      for (int j = 0; j < checkFileList.size(); j++) {
//    	  System.out.println(checkFileList.get(j).toString());
    	  if(blockFileMap.containsKey(checkFileList.get(j).toString())) {
    		  if(blockFileMap.get(checkFileList.get(j).toString()).equals("Merge")) {
    			  checkFileProcess(j);
    		  }
    		  else if(blockFileMap.get(checkFileList.get(j).toString()).equals("Batch")) {
    	    	  if(cluster.equalsIgnoreCase("WAS")) {
    	    		  checkFileProcess(j);
    	    	  }
    		  }
    		  else if(blockFileMap.get(checkFileList.get(j).toString()).equals("Online")) {
    	    	  if(cluster.equalsIgnoreCase("BAT")) {
    	    		  checkFileProcess(j);
    	    	  }
    		  }
    		  else if(blockFileMap.get(checkFileList.get(j).toString()).equals("Manual")) {
    			  checkFileProcess(j);
    		  }
    	  }
      }

      realFileList.removeAll(removeFileList);

      if(getBlockData) {
    	  blockPathText.add(reqId+","+'"'+blockSystemStore+'"'+","+'"'+blockPathStore+'"');
      }
	  if(cluster.equalsIgnoreCase("BAT")) {
		   requiredName=reqId+batchName;
	   }
//	  else if (cluster.equalsIgnoreCase("WAS")) {
	  else {
		   requiredName=reqId+onlineName;
	  }
      generateExportFile(realFileList,requiredName,cluster);
      
   }catch(SQLException se){
      //Handle errors for JDBC
      se.printStackTrace();
   }catch(Exception e){
      //Handle errors for Class.forName
      e.printStackTrace();
   }finally{
      //finally block used to close resources
      try{
         if(stmt!=null)
            stmt.close();
      }catch(SQLException se2){
      }// nothing we can do
      try{
         if(conn!=null)
            conn.close();
      }catch(SQLException se){
         se.printStackTrace();
      }//end finally try
   }//end try
   
   		callHelperBatToProcess(inputPath,requiredName);
	}//end for loop
	List<String> removeBatList = new ArrayList<String>();
	List<String> removeWasList = new ArrayList<String>();
	//create folder for removeFileList
    for (int j = 0; j < removeFileList.size(); j++) {
  	  System.out.println(removeFileList.get(j).toString());
  		  if(removeFileMap.get(removeFileList.get(j).toString()).equalsIgnoreCase("BAT")) {
  			removeBatList.add(removeFileList.get(j).toString());
  		  }
  		  else if(removeFileMap.get(removeFileList.get(j).toString()).equalsIgnoreCase("WAS")) {
  			removeWasList.add(removeFileList.get(j).toString());
  		  }
    }
    generateExportFile(removeWasList,"manual_online_export","WAS");
    callHelperBatToProcess(inputPath,"manual_online_export");
    generateExportFile(removeBatList,"manual_batch_export","BAT");
    callHelperBatToProcess(inputPath,"manual_batch_export");
    
	try {
		FileWriter fileWriter = new FileWriter(convertorFilePath+"\\problemExportFile.txt");
		for (int j = 0; j < problemExportFile.size(); j++) {
			fileWriter.write(problemExportFile.get(j).toString()+ System.lineSeparator());
		}
		fileWriter.close();
		} catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data in inputFileList");
			}
	try {
		FileWriter fileWriter = new FileWriter(convertorFilePath+"\\blockReqID_noFileGenerate.csv");
		fileWriter.write("Request_Id"+","+"Choosing_System"+","+"File_Path"+ System.lineSeparator());
		for (int j = 0; j < blockPathText.size(); j++) {
			fileWriter.write(blockPathText.get(j).toString()+ System.lineSeparator());
		}
		fileWriter.close();
		} catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data in inputFileList");
			}
		try {
			FileWriter fileWriter = new FileWriter(convertorFilePath+"\\checkingFile.csv");
			fileWriter.write("Request_Id"+","+"File_Folder_Name"+","+"File_Folder_Original_Name"+ System.lineSeparator());
			for (int j = 0; j < outputcheckingFileList.size(); j++) {
				fileWriter.write(outputcheckingFileList.get(j).toString()+ System.lineSeparator());
			}
			fileWriter.close();
		} catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data in inputFileList");
			}
		
	if(countFile!=0) {
			try (Stream<Path> walk = Files.walk(Paths.get(inputPath))) {
				
				List<String> result = walk.filter(Files::isRegularFile)
						.map(x -> x.toString()).collect(Collectors.toList());
		
				outputFileList=result;
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			try{    
			    ProcessBuilder pbuilder = new ProcessBuilder(autoConvertorBat);
			    
			    pbuilder.directory(new File(convertorFilePath) ); // this is where you set the root folder for the executable to run with
			    pbuilder.redirectErrorStream(true);
			    Process process =  pbuilder.start();
		
			    Scanner s = new Scanner(process.getInputStream());
			    StringBuilder text = new StringBuilder();
			    System.out.println(System.lineSeparator());
			    while (s.hasNextLine()) {
			      System.out.println(s.nextLine());
			    }
			    s.close();
			    int result = process.waitFor();
			    
			}catch( Exception e) {
				e.printStackTrace();
			}
		}
   }//end main
   public static void checkFileProcess(int j) {
		  getBlockData=true;
		  blockSystemStore = blockSystemStore + blockFileMap.get(checkFileList.get(j).toString()) +System.lineSeparator();
		  blockPathStore = blockPathStore +checkFileList.get(j).toString()+System.lineSeparator();
		  removeFileList.add(realFileList.get(j).toString());
		  removeFileMap.put(realFileList.get(j).toString(), cluster);
   }
   public static void callHelperBatToProcess(String inputPath,String name) {
		try{    
		    ProcessBuilder pbuilder = new ProcessBuilder(helperBat);
		    
		    pbuilder.directory(new File(convertorFilePath) ); // this is where you set the root folder for the executable to run with
		    pbuilder.redirectErrorStream(true);
		    Process process =  pbuilder.start();

		    Scanner s = new Scanner(process.getInputStream());
		    StringBuilder text = new StringBuilder();
		    System.out.println(System.lineSeparator());
		    while (s.hasNextLine()) {
		      System.out.println(s.nextLine());
		    }
		    s.close();
		    int result = process.waitFor();
		    
		}catch( Exception e) {
			e.printStackTrace();
		}	    


		   File dir = new File(inputPath);

		   File listDir[] = dir.listFiles();
		   for (int j = 0; j < listDir.length; j++) {
//			   System.out.println("dir = " + dir.lastModified());
		       if (listDir[j].isDirectory()) {
		           if (listDir[j].lastModified() > lastModifiedTime)
		           {
		               chosenFilePath = listDir[j];
		               lastModifiedTime = listDir[j].lastModified();
		           }
		           }
		   }
//		   System.out.println("chosenFile = " + chosenFilePath);
		   realName= new File(chosenFilePath.getParent()+"\\"+name);
		   outputcheckingFileList.add(reqId+","+realName+","+chosenFilePath.getAbsolutePath());
		   File renameFolder = new File(chosenFilePath.getAbsolutePath());
		   renameFolder.renameTo(realName);
		   
			try {
				BufferedReader fileReader = new BufferedReader(new FileReader(convertorFilePath+"\\"+name+".txt"));
				String line=null;
			    try {
					while ((line = fileReader.readLine()) != null)
					{	
						if(line.contains("@@\\")) {
				        	String[] spiltData = line.split(Pattern.quote("@@\\"),2);
				        	if(spiltData[0].contains("\\TAAS2_DEV")) {
				        		String[] spiltData1 = spiltData[0].split(Pattern.quote("\\TAAS2_DEV"),2);
				        		checkingExportFile.add(spiltData1[1]);
				        	}
				          }
						else {
							checkingExportFile.add(line);
						}

					}
					fileReader.close();
				} 
			    catch (IOException e1) {
					e1.printStackTrace();
				}
				} 
		   	catch (FileNotFoundException e1) {
					e1.printStackTrace();
				}
			
			try (Stream<Path> walk = Files.walk(Paths.get(inputPath))) {
				List<String> result = walk.filter(Files::isRegularFile)
						.map(x -> x.toString()).collect(Collectors.toList());
				for (int j = 0; j < result.size(); j++) {
					if(result.get(j).toString().contains("\\TAAS2_DEV")) {
						String[] spiltData = result.get(j).toString().split(Pattern.quote("\\TAAS2_DEV"),2);
						if(!checkingExportFile.contains(spiltData[1])) {
							problemExportFile.add(name+" , "+spiltData[1]);
						}
//						System.out.println("spiltData[1] = " + spiltData[1]);
					}
					
				}
				
			} catch (IOException e) {
				e.printStackTrace();
			}	
		   
		   
		   countFile++;
		   
		   

//           //export.txt delete()
//		   File deleteText = new File(convertorFilePath+"\\"+requiredName+".txt");
//		   if(deleteText.exists()) {
//			   deleteText.delete();
//		   }
		   System.out.println("This "+requiredName+" Output List Finish");
   }
   public static void generateExportFile(List<String> requiredList,String name,String status) {
	   	if(status.equalsIgnoreCase("BAT")) {
	    		try {
	    			FileWriter fileWriter = new FileWriter(convertorFilePath+"\\"+name+".txt");
	    			for (int j = 0; j < requiredList.size(); j++) {
	    				fileWriter.write(requiredList.get(j).toString()+System.lineSeparator());
	    			}
	    			fileWriter.close();
	    		} catch (IOException iox) {
	    			iox.printStackTrace();
	    			System.out.println("File can not save any data in outputPathList");
	    		}
	    		try {
	    			FileWriter fileWriter = new FileWriter(convertorFilePath+"\\"+helperName);
	    			fileWriter.write("###### Helper 1 Setup ######"+System.lineSeparator());
	    			fileWriter.write("CLEARCASE_PATH="+ClearCaseView+System.lineSeparator());
	    			fileWriter.write("run_action_list=export_tc_batch"+System.lineSeparator());
	    			fileWriter.write(System.lineSeparator());
	    			fileWriter.write("#[action_type : 1-SCAN, 2-DEPLOY, 3-EXPORT, 4-CHECK_VER, 9-SCAN_ALL_TC]"+System.lineSeparator());
	    			fileWriter.write("#[target_env 	: 1=/Application/, 2=/PRD_Application/Online/, 3=/PRD_Application/Batch/]"+System.lineSeparator());
	    			fileWriter.write(System.lineSeparator());
	    			fileWriter.write("#[EXPORT Action, Function : to export Batch]"+System.lineSeparator());
	    			fileWriter.write("#[sample for action type 3]"+System.lineSeparator());
	    			fileWriter.write("export_tc_batch.action_type=3"+System.lineSeparator());
	    			fileWriter.write("export_tc_batch.target_env=3"+System.lineSeparator());
	    			fileWriter.write("export_tc_batch.scan_off=true"+System.lineSeparator());
	    			fileWriter.write("export_tc_batch.ct_only=false"+System.lineSeparator());
	    			fileWriter.write("export_tc_batch.target_label="+System.lineSeparator());
	    			fileWriter.write("export_tc_batch.function_list="+System.lineSeparator());
	    			fileWriter.write("export_tc_batch.adhoc_file_list="+name+".txt"+System.lineSeparator());
	    			fileWriter.close();
	    		} catch (IOException iox) {
	    			iox.printStackTrace();
	    			System.out.println("File can not save any data in outputPathList");
	    		}
	      }
//	    else if(status.equalsIgnoreCase("WAS")) {
		else {
	  		try {
				FileWriter fileWriter = new FileWriter(convertorFilePath+"\\"+name+".txt");
 			for (int j = 0; j < requiredList.size(); j++) {
 				fileWriter.write(requiredList.get(j).toString()+System.lineSeparator());
 			}
				fileWriter.close();
			} catch (IOException iox) {
				iox.printStackTrace();
				System.out.println("File can not save any data in outputPathList");
			}
	  		try {
				FileWriter fileWriter = new FileWriter(convertorFilePath+"\\"+helperName);
				fileWriter.write("###### Helper 1 Setup ######"+System.lineSeparator());
				fileWriter.write("CLEARCASE_PATH="+ClearCaseView+System.lineSeparator());
				fileWriter.write("run_action_list=export_tc_online"+System.lineSeparator());
				fileWriter.write(System.lineSeparator());
				fileWriter.write("#[action_type : 1-SCAN, 2-DEPLOY, 3-EXPORT, 4-CHECK_VER, 9-SCAN_ALL_TC]"+System.lineSeparator());
				fileWriter.write("#[target_env 	: 1=/Application/, 2=/PRD_Application/Online/, 3=/PRD_Application/Batch/]"+System.lineSeparator());
				fileWriter.write(System.lineSeparator());
				fileWriter.write("#[EXPORT Action, Function : to export Online]]"+System.lineSeparator());
				fileWriter.write("#[sample for action type 3]"+System.lineSeparator());
				fileWriter.write("export_tc_online.action_type=3"+System.lineSeparator());
				fileWriter.write("export_tc_online.target_env=2"+System.lineSeparator());
				fileWriter.write("export_tc_online.scan_off=true"+System.lineSeparator());
				fileWriter.write("export_tc_online.ct_only=false"+System.lineSeparator());
				fileWriter.write("export_tc_online.jsp_only=false"+System.lineSeparator());
				fileWriter.write("export_tc_online.target_label="+System.lineSeparator());
				fileWriter.write("export_tc_online.function_list="+System.lineSeparator());
				fileWriter.write("export_tc_online.adhoc_file_list="+name+".txt"+System.lineSeparator());
				fileWriter.close();
			} catch (IOException iox) {
				iox.printStackTrace();
				System.out.println("File can not save any data in outputPathList");
			}
	  		
	      }   		
   }
}//end FirstExample
