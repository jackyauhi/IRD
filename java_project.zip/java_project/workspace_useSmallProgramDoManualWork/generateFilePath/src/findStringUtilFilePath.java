import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class findStringUtilFilePath {
//	public static String ReadFileContent(String inputPath) throws IOException {
//		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(inputPath),"UTF-8"));
//        String bufferedReaderline;
//        String fileContent="";
//        while ((bufferedReaderline = br.readLine()) != null) {
//        	fileContent=fileContent+bufferedReaderline+System.lineSeparator();
//        }
//		return fileContent;
//	}
	
	public static ArrayList<String> latestFileList = new ArrayList<String>();
//	public static String requireCsvFile ="D:\\AutoConvertor\\Main_20200917\\ibatis2mybatis-master\\outputRequiredFileMain.csv";
	public static String requireCsvFile ="D:\\User\\jackyau\\outputRequiredFileMain.csv";
	public static ArrayList<String> finalStringUtilList = new ArrayList<String>();
	public static ArrayList<String> finalStringUtilOrignalTextList = new ArrayList<String>();
	public static ArrayList<String> finalStringUtilNewTextList = new ArrayList<String>();
	public static void main(String[] args) throws Exception {
	try {
		BufferedReader fileReader = new BufferedReader(new FileReader(requireCsvFile));
		String line=null;
	    try {
			while ((line = fileReader.readLine()) != null)
			{	
				String[] dataStore = line.split(",");
				latestFileList.add(dataStore[1]);
		
			}
			fileReader.close();
		} 
	    catch (IOException e1) {
			e1.printStackTrace();
		}
		} 
   	catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
	boolean haveStringUtil=false;
	boolean containStringUtil=false;
	boolean requireCloudPath=false;
	String cloudApplicationPath="D:\\ccshare\\jyyau_view_ClearCase_MTN\\TAAS2_UAT\\CloudMigration\\Application";
	String cloudFullPath="";
	int count=0;
	for (int i = 0; i < latestFileList.size(); i++) {
		String project="";
//		if(count==366) {
//			break;
//		}
//		System.out.println("latestFileList.get(i).toString() =" +latestFileList.get(i).toString());
		File javaFile = new File(latestFileList.get(i).toString());		
		haveStringUtil=false;
		containStringUtil=false;
		if (javaFile.getName().endsWith(".java")) {
		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(latestFileList.get(i).toString()),"UTF-8"));
        String bufferedReaderline;
        String fileContent="";
        while ((bufferedReaderline = br.readLine()) != null) {
        	fileContent=fileContent+bufferedReaderline+System.lineSeparator();
        }
        
//		String fileContent=findStringUtilFilePath.ReadFileContent(latestFileList.get(i).toString());	
        if (fileContent.contains("org.apache.commons.lang.StringUtils")){
        	containStringUtil=true;
        }
        if(fileContent.contains("org.springframework.util.StringUtils")) {
        	containStringUtil=true;
        }
        if(fileContent.contains("com.opensymphony.oscache.util.StringUtil")){
        	containStringUtil=true;
        }
        if(containStringUtil) {
//        	System.out.println("latestFileList.get(i).toString() =" +latestFileList.get(i).toString());
        	String[] cloudPath = null;
    		String[] splitProject= null; 
        	if(latestFileList.get(i).toString().contains("\\Batch\\Batch")) {
        		cloudPath = latestFileList.get(i).toString().split(Pattern.quote("\\Batch\\Batch"),2);
        		cloudFullPath=cloudApplicationPath+"\\Batch"+cloudPath[1];
        	}
        	else if(latestFileList.get(i).toString().contains("\\Batch_Common")){
        		cloudPath = latestFileList.get(i).toString().split(Pattern.quote("\\Batch_Common"),2);
        		cloudFullPath=cloudApplicationPath+"\\Batch_Common"+cloudPath[1];
        	}
        	else if(latestFileList.get(i).toString().contains("\\Common")){
        		cloudPath = latestFileList.get(i).toString().split(Pattern.quote("\\Common"),2);
        		cloudFullPath=cloudApplicationPath+"\\Common"+cloudPath[1];
        	}
        	else if(latestFileList.get(i).toString().contains("\\Online\\Online")){
        		cloudPath = latestFileList.get(i).toString().split(Pattern.quote("\\Online\\Online"),2);
        		cloudFullPath=cloudApplicationPath+"\\Online"+cloudPath[1];
        	}
        	else if(latestFileList.get(i).toString().contains("\\Report")){
        		cloudPath = latestFileList.get(i).toString().split(Pattern.quote("\\Report"),2);
        		cloudFullPath=cloudApplicationPath+"\\Report"+cloudPath[1];
        	}
        	else {
//        		System.out.println("latestFileList.get(i).toString() =" +latestFileList.get(i).toString());
        	}
    		splitProject = cloudPath[1].split(Pattern.quote("\\"));
    		project=splitProject[1];
        	String[] cloudPath1 = cloudFullPath.split(Pattern.quote(cloudApplicationPath),2);
//        	File destDir = new File("T:\\jackyau\\test"+cloudPath1[1]);
//        	File destDirParent=new File(destDir.getParent());
//			if (!destDirParent.exists()) {
//				destDirParent.mkdirs();
//			}
//			try {
//				BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("T:\\jackyau\\test"+cloudPath1[1]), StandardCharsets.UTF_8));
//			    writer.write(fileContent);
//			    writer.close();
//			} catch (IOException iox) {
//				iox.printStackTrace();
//				System.out.println("File can not save any data in outputPathList");
//			}
//        	System.out.println("cloudFullPath =" +cloudFullPath);
    		BufferedReader cloudBr = new BufferedReader(new InputStreamReader(new FileInputStream(cloudFullPath),"UTF-8"));
            String cloudBufferedReaderline;
            String cloudFileContent="";
            while ((cloudBufferedReaderline = cloudBr.readLine()) != null) {
            	cloudFileContent=cloudFileContent+cloudBufferedReaderline+System.lineSeparator();
            }
//        	String cloudFileContent=findStringUtilFilePath.ReadFileContent(cloudFullPath);	
            String storePatternGroup ="";
    		Pattern removeCommentPattern = Pattern.compile("//.*[a-zA-Z0-9.]*StringUtil[s]");
    		Matcher removeCommentPatternMatcher=removeCommentPattern.matcher(fileContent);
    		while (removeCommentPatternMatcher.find()){
    			storePatternGroup = removeCommentPatternMatcher.group();
    			fileContent=fileContent.replaceAll(Pattern.quote(storePatternGroup), "");
    		}
    		removeCommentPatternMatcher=removeCommentPattern.matcher(cloudFileContent);
    		while (removeCommentPatternMatcher.find()){
    			storePatternGroup = removeCommentPatternMatcher.group();
    			cloudFileContent=cloudFileContent.replaceAll(Pattern.quote(storePatternGroup), "");
    		}
		Pattern stringUtilPattern = Pattern.compile("[a-zA-Z0-9.]*StringUtil[s]*\\s*[.]\\s*[a-zA-Z0-9]*");
		Matcher stringUtilPatternMatcher=stringUtilPattern.matcher(fileContent);
		Pattern importStringUtilPattern = Pattern.compile("import\\s+[a-zA-Z0-9.]*StringUtil[s]*");
		Matcher importStringUtilPatternMatcher=importStringUtilPattern.matcher(fileContent);

		
		ArrayList<String> stringUtilList = new ArrayList<String>();
		ArrayList<String> removerRepeatStringUtilList = new ArrayList<String>();
		String originalFinalStringUtil = "";
		String newFinalStringUtil = "";
		String checking = "";
		
		String compareOriginalImport="1";
		String compareNewImport="2";
//		List<String> compareOriginalImport = new ArrayList<String>();
//		List<String> compareNewImport = new ArrayList<String>();
		boolean needCompare=false;
		ArrayList<String> removedOriginalStringUtil = new ArrayList<String>();
		ArrayList<String> removedNewStringUtil = new ArrayList<String>();
		ArrayList<String> realOriginalStringUtil = new ArrayList<String>();
		ArrayList<String> realNewStringUtil = new ArrayList<String>();
//		HashMap<String, String> StringUtilMap = new HashMap<String, String>();
		
		while (importStringUtilPatternMatcher.find()){
			storePatternGroup = importStringUtilPatternMatcher.group();
			originalFinalStringUtil=originalFinalStringUtil+storePatternGroup+System.lineSeparator();
			removedOriginalStringUtil.add(storePatternGroup);
			realOriginalStringUtil.add(storePatternGroup);
			finalStringUtilOrignalTextList.add(storePatternGroup);
			compareOriginalImport=storePatternGroup;
//			checking="import";
		}
		while (stringUtilPatternMatcher.find()){
			storePatternGroup = stringUtilPatternMatcher.group();
			stringUtilList.add(storePatternGroup);
			}
		while(stringUtilList.size()!=0) {
			removerRepeatStringUtilList.add(stringUtilList.get(0).toString());
			String storeValue=stringUtilList.get(0).toString();
			stringUtilList.removeAll(removerRepeatStringUtilList);
			removedOriginalStringUtil.add(storeValue);
			realOriginalStringUtil.add(storeValue);
			finalStringUtilOrignalTextList.add(storePatternGroup);
			if(stringUtilList.size()==0)
				originalFinalStringUtil=originalFinalStringUtil+storeValue;
			else 
				originalFinalStringUtil=originalFinalStringUtil+storeValue+System.lineSeparator();
		}
		
		stringUtilList = new ArrayList<String>();
		removerRepeatStringUtilList = new ArrayList<String>();
		stringUtilPatternMatcher=stringUtilPattern.matcher(cloudFileContent);
		importStringUtilPatternMatcher=importStringUtilPattern.matcher(cloudFileContent);
		
		while (importStringUtilPatternMatcher.find()){
			storePatternGroup = importStringUtilPatternMatcher.group();
			newFinalStringUtil=newFinalStringUtil+storePatternGroup+System.lineSeparator();
			removedNewStringUtil.add(storePatternGroup);
			realNewStringUtil.add(storePatternGroup);
			finalStringUtilNewTextList.add(storePatternGroup);
			compareNewImport=storePatternGroup;
		}
		while (stringUtilPatternMatcher.find()){
			storePatternGroup = stringUtilPatternMatcher.group();
			stringUtilList.add(storePatternGroup);
			}
		while(stringUtilList.size()!=0) {
			removerRepeatStringUtilList.add(stringUtilList.get(0).toString());
			String storeValue=stringUtilList.get(0).toString();
			stringUtilList.removeAll(removerRepeatStringUtilList);
			removedNewStringUtil.add(storeValue);
			realNewStringUtil.add(storeValue);
			finalStringUtilNewTextList.add(storePatternGroup);
			if(stringUtilList.size()==0)
				newFinalStringUtil=newFinalStringUtil+storeValue;
			else 
				newFinalStringUtil=newFinalStringUtil+storeValue+System.lineSeparator();
		}
//		System.out.println("--------------------------------------------------");
//		System.out.println(realOriginalStringUtil+System.lineSeparator());
//		System.out.println("--------------------------------------------------");
//		System.out.println(realNewStringUtil+System.lineSeparator());
//		System.out.println("--------------------------------------------------");
		if(realOriginalStringUtil.size()!=realNewStringUtil.size()) { 
			needCompare=true;
		}
		if(compareOriginalImport.equals(compareNewImport)) {
			needCompare=true;
		}
		if(needCompare) {
			originalFinalStringUtil="";
			newFinalStringUtil="";			
			realOriginalStringUtil.removeAll(removedNewStringUtil);
			realNewStringUtil.removeAll(removedOriginalStringUtil);
//			System.out.println("================================================");
//			System.out.println(realOriginalStringUtil+System.lineSeparator());
//			System.out.println("================================================");
//			System.out.println(realNewStringUtil+System.lineSeparator());
//			System.out.println("================================================");
			for (int r = 0; r < realOriginalStringUtil.size(); r++) {
				if(realOriginalStringUtil.size()!=realNewStringUtil.size()) {  
					String newStoreValue =""; 
					if(realOriginalStringUtil.get(r).toString().contains("com.opensymphony.oscache.util.StringUtil")) {
						newStoreValue=realOriginalStringUtil.get(r).toString().replaceAll("com.opensymphony.oscache.util.StringUtil", "ird.taas2.utils.StringUtils");
						if(r==realOriginalStringUtil.size()-1) {
							originalFinalStringUtil=originalFinalStringUtil+realOriginalStringUtil.get(r).toString();
							newFinalStringUtil=newFinalStringUtil+newStoreValue;
						}
						else {
							originalFinalStringUtil=originalFinalStringUtil+realOriginalStringUtil.get(r).toString()+System.lineSeparator();
							newFinalStringUtil=newFinalStringUtil+newStoreValue+System.lineSeparator();
						}
					}
					else if(realOriginalStringUtil.get(r).toString().contains("StringUtil.")) {
						newStoreValue=realOriginalStringUtil.get(r).toString().replaceAll("StringUtil.", "StringUtils.");
						if(r==realOriginalStringUtil.size()-1) {
							originalFinalStringUtil=originalFinalStringUtil+realOriginalStringUtil.get(r).toString();
							newFinalStringUtil=newFinalStringUtil+newStoreValue;
						}
						else {
							originalFinalStringUtil=originalFinalStringUtil+realOriginalStringUtil.get(r).toString()+System.lineSeparator();
							newFinalStringUtil=newFinalStringUtil+newStoreValue+System.lineSeparator();
						}
					}
				}
				else {
					if(r==realOriginalStringUtil.size()-1) {
						originalFinalStringUtil=originalFinalStringUtil+realOriginalStringUtil.get(r).toString();
						newFinalStringUtil=newFinalStringUtil+realNewStringUtil.get(r).toString();
					}
					else {
						originalFinalStringUtil=originalFinalStringUtil+realOriginalStringUtil.get(r).toString()+System.lineSeparator();
						newFinalStringUtil=newFinalStringUtil+realNewStringUtil.get(r).toString()+System.lineSeparator();
					}
				}
			}
		}

		if(!originalFinalStringUtil.equals("")&&!newFinalStringUtil.equals("")) {
			finalStringUtilList.add(project+","+cloudPath1[1]+","+"\""+originalFinalStringUtil+"\""+","+"\""+newFinalStringUtil+"\""+","+checking);
			System.out.println(cloudPath1[1]);
			count++;
		}
//		System.out.println("finalStringUtilList =" +finalStringUtilList);
		
		}//end of containStringUtil==true;
	  }
	}
	try {
	FileWriter fileWriter = new FileWriter("D:\\User\\jackyau\\testString11.csv");
	fileWriter.write("Projects"+","+"Programs"+","+"Original"+","+"New"+","+"Remarks"+System.lineSeparator());
	for (int i = 0; i < finalStringUtilList.size(); i++) {
		fileWriter.write(finalStringUtilList.get(i).toString()+System.lineSeparator());
	}
	fileWriter.close();
} catch (IOException iox) {
	iox.printStackTrace();
	System.out.println("File can not save any data in outputPathList");
}
	
	List<String> remove = new ArrayList<String>();
	List<String> storeold = new ArrayList<String>();
	List<String> storenew = new ArrayList<String>();
	while(finalStringUtilOrignalTextList.size()!=0) {
		remove.add(finalStringUtilOrignalTextList.get(0).toString());
		String storeValue=finalStringUtilOrignalTextList.get(0).toString();
		finalStringUtilOrignalTextList.removeAll(remove);
		storeold.add(storeValue);
	}
	
	remove = new ArrayList<String>();
	while(finalStringUtilNewTextList.size()!=0) {
		remove.add(finalStringUtilNewTextList.get(0).toString());
		String storeValue=finalStringUtilNewTextList.get(0).toString();
		finalStringUtilNewTextList.removeAll(remove);
		storenew.add(storeValue);
	}
	
	try {
	FileWriter fileWriter = new FileWriter("D:\\User\\jackyau\\original.txt");
	for (int i = 0; i < storeold.size(); i++) {
		fileWriter.write(storeold.get(i).toString()+System.lineSeparator());
	}
	fileWriter.close();
} catch (IOException iox) {
	iox.printStackTrace();
	System.out.println("File can not save any data in outputPathList");
}
	try {
	FileWriter fileWriter = new FileWriter("D:\\User\\jackyau\\new.txt");
	for (int i = 0; i < storenew.size(); i++) {
		fileWriter.write(storenew.get(i).toString()+System.lineSeparator());
	}
	fileWriter.close();
} catch (IOException iox) {
	iox.printStackTrace();
	System.out.println("File can not save any data in outputPathList");
}
//	System.out.println("finalStringUtilOrignalTextList = "+finalStringUtilOrignalTextList);

	}
}