
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;



public class getCorrectVersionCopy {
	
	public static void main(String[] args) throws Exception{
		String filepath ="T:\\jackyau";

		List<String> sourcefiles = Files.readAllLines(Paths.get(filepath+"\\source2.txt"));
		List<String> targetfiles = Files.readAllLines(Paths.get(filepath+"\\target2.txt"));
		
//		for(String file : files){
////			System.out.println(file);
//			checkinPath(file);
////			getLatestVersion(file);
//		}
		
		System.out.println("--------------------------------------------------------------------------------------");
//		for(String file : targetfiles){
		for (int i = 0; i < targetfiles.size(); i++) {
			String targetpath = targetfiles.get(i).toString();
			String sourcepath = sourcefiles.get(i).toString();
			File fileToSave = new File(targetpath);
			File fileToSaveParent=new File(fileToSave.getParent());
			if (!fileToSaveParent.exists()) {
				fileToSaveParent.mkdirs();
			}
//			getLatestVersion(targetpath);
			getVersionCopy(sourcepath,targetpath);
		}
		
		
		
	}
	
	public static void getVersionCopy(String sourcepath,String targetpath) throws Exception {
		try {
//			ClearCaseUtils.doCheckout(path);
			String command = "cleartool get �Vto " + "\""+targetpath + "\""+" "+"\""+sourcepath+ "\""+System.lineSeparator();
			ProcessBuilder builder = new ProcessBuilder();
			builder.redirectErrorStream(true);
			Process p = builder.command("cmd.exe", "/c", command).start();
			BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
			String line;
			System.out.println(command);
			
			while ((line = reader.readLine()) != null) {
//				System.out.println(line);
			}
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Fail to get version copy.");
			System.exit(1);
		}
	}
	
	

	
	static void getLatestVersion(String path) {
		String command = "cleartool find "+path+" -type f -version \"version(\\main\\LATEST)\" -print";
		ProcessBuilder builder = new ProcessBuilder();
		builder.redirectErrorStream(true);
		try {
			Process p = builder.command("cmd.exe", "/c", command).start();
			BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
			String line;
			while ((line = reader.readLine()) != null) {
				try {
					System.out.println(line);
				} catch (NumberFormatException | IndexOutOfBoundsException e) {
					continue;
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Fail to load Clearcase version.");
			System.exit(1);
		}
	}

}
