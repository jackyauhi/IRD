
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
//import java.util.regex.Matcher;
//import java.util.regex.Pattern;

//import org.apache.commons.io.FileUtils;
//import org.apache.poi.hsmf.datatypes.Types;

//import com.google.common.io.Files;
//import com.opencsv.CSVWriter;
//import com.opencsv.ResultSetHelperService;

public class ExportSIT0383csv {

	static final String JDBC_DRIVER = "com.ibm.db2.jcc.DB2Driver";
	static final String DB_URL = "jdbc:db2://10.31.90.23:50010/tadb";
	static final String USERNAME = "tsit0410";
	static final String PASSWORD = "Tsit0410";
	static Connection conn;

	public static void main(String[] args) throws SQLException, IOException {
		int countTable = 0;
		conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
		String tableSql = "SELECT DISTINCT TABNAME FROM syscat.columns WHERE \"SCALE\" = 2 AND TABSCHEMA = 'TSIT0410' AND TABNAME LIKE 'TBL_%' AND TABNAME NOT LIKE '%_ZM_%'";
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(tableSql);
		List<String> tableList = new ArrayList<String>();
		List<String> columnList = new ArrayList<String>();
		List<String> dataList = new ArrayList<String>();
		List<String> checkAgain = new ArrayList<String>();
		String outputPath="T:\\jackyau\\result_tsit0410.csv";
		while (rs.next()) {
			String table = rs.getString("tabname");
//			table="TBL_CTCOKSPCN";
//			System.out.println(table);
			String selectSql = "SELECT " + "*" + " FROM " + table;


//			System.out.println(selectSql);

			stmt = conn.createStatement();
			ResultSet result = stmt.executeQuery(selectSql);
			ResultSetMetaData md = result.getMetaData();
			List<String> row = new ArrayList<String>();
			List<String> col = new ArrayList<String>();

			while (result.next()) {
				col = new ArrayList<String>();
				for (int i = 1; i <= md.getColumnCount(); i++) {
					String str = "";
					String columnName = "";
					String tableName = "";
					String requiredData = "";
					// VARCHAR -> + ""
					str = result.getString(i);
					boolean requireNumber=isDouble(str);
//					System.out.println("str = "+ str);
//					System.out.println("getColumnName = "+ md.getColumnName(i));
//					System.out.println(table);
//					System.out.println(requireNumber);
					if(requireNumber) {
						String[] splitNumber=str.split("[.]",2);
//						System.out.println("str = "+ str);
//						System.out.println("splitNumber[0] = "+ splitNumber[0]);
						if(splitNumber.length==2) {
//							System.out.println("splitNumber[1] = "+ splitNumber[1]);
							int numberRequired=Integer.parseInt(splitNumber[1]);
	//						float floatNum=Float.valueOf(splitNumber[1]);
							if(numberRequired>0) {
//								System.out.println("numberRequired = "+ numberRequired);
//								System.out.println("str = "+ str);
//								System.out.println("getColumnName = "+ md.getColumnName(i));
//								System.out.println(table);
								
								requiredData="\""+str+"\"";
								tableName="\""+table+"\"";
								columnName="\""+md.getColumnName(i)+"\"";
								
								tableList.add(tableName);
								columnList.add(columnName);
								dataList.add(requiredData);
							}
						}
						else {
							checkAgain.add(table+","+md.getColumnName(i)+","+str);
							System.out.println("take care!!!!");
							System.out.println("str = "+ str);
							System.out.println("getColumnName = "+ md.getColumnName(i));
							System.out.println(table);
						}
					}
				}
			}

//			FileUtils.writeLines(new File("D:\\User\\jackyau2\\csv_tsit0383\\" + table + ".csv"), row);

			stmt.close();
			result.close();

//			System.out.println("table = "+table+" done!!");
//			countTable++;
//			System.out.println("Count no of table = "+countTable);
//			break;
		}

		rs.close();
		try {
			FileWriter fileWriter = new FileWriter(outputPath);
			fileWriter.write("Table,Column,Data"+System.lineSeparator());
			for (int j = 0; j < tableList.size(); j++) {
				fileWriter.write(tableList.get(j).toString()+","+columnList.get(j).toString()+","+dataList.get(j).toString()+System.lineSeparator());
			}
			fileWriter.close();
		} catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data in inputFileList");
			}
	}
	public static boolean isDouble(String string) {
		float dnum;
		int intValue;
//	    System.out.println(String.format("Parsing string: \"%s\"", string));
		if(string != null) {
			string=string.replaceAll("\\s", "");
			string=string.replaceAll(" ", "");
		}	
	    if(string == null || string.equals("")) {
//	        System.out.println("String cannot be parsed, it is null or empty.");
	        return false;
	    }
	    else {
		    try {
		    	dnum = Float.valueOf(string);
		    	String[] splitNumber=string.split("[.]");
		    	if(splitNumber.length!=2) {
		    		return false;
		    	}
		    	else {
		    		if(splitNumber[1].length()==2) {
		    			//find .## value
//		    			System.out.println("string = "+string);
		    			return true;
		    		}
		    	}
//		    	Pattern pattern = Pattern.compile("[a-zA-Z]");
//				Matcher patternMatcher=pattern.matcher(string);
//				if(patternMatcher.find()) {
//					System.out.println("use this function!!");
//					System.out.println("string = "+string);
//				}
//				else {
//					return true;
//				}
		    } catch (NumberFormatException e) {
	//	        System.out.println("Input String cannot be parsed to Integer.");
		    }
	    }
	    return false;
	}
	
	public static boolean isEncoded(String text) {
//		Charset charset = Charset.forName("US-ASCII");
		Charset charset = Charset.forName("UTF-8");
		String checked = new String(text.getBytes(charset), charset);
		return !checked.equals(text);

	}

	public static boolean containsDigit(final String aString) {
		return aString != null && !aString.isEmpty() && aString.chars().anyMatch(Character::isDigit);
	}

	public static void sqlToCSV(String query, String filename) throws IOException, SQLException {

		Statement st;
		FileWriter fw = new FileWriter(filename + ".csv");
		st = conn.createStatement();
		ResultSet rs = st.executeQuery(query);

		int cols = rs.getMetaData().getColumnCount();

		for (int i = 1; i <= cols; i++) {
			fw.append(rs.getMetaData().getColumnLabel(i));
			if (i < cols)
				fw.append(',');
			else
				fw.append('\n');
		}

		while (rs.next()) {

			for (int i = 1; i <= cols; i++) {
				String tempData = rs.getString(i);
				String data = tempData != null ? tempData.replace("\"", "") : "";
				fw.append(data);
				if (i < cols)
					fw.append(',');
			}
			fw.append('\n');
		}
		st.close();

		fw.flush();
		fw.close();

	}

}
