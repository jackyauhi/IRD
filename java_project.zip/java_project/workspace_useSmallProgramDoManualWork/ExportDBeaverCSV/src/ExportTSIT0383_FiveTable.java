
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.Writer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FileUtils;

import org.apache.poi.hsmf.datatypes.Types;

import com.google.common.io.Closer;
import com.google.common.io.Files;
import com.opencsv.CSVWriter;
import com.opencsv.ResultSetHelperService;

public class ExportTSIT0383_FiveTable {

	static final String JDBC_DRIVER = "com.ibm.db2.jcc.DB2Driver";
	static final String DB_URL = "jdbc:db2://10.31.90.23:50010/tadb";
	//jdbc:mysql://host/database?characterSetResults=UTF-8&characterEncoding=UTF-8&useUnicode=yes
	static final String USERNAME = "tsit0383";
	static final String PASSWORD = "Tsit0383";
	static Connection conn;
	public static List<String> tableList = new ArrayList<String>();
	
	public static void main(String[] args) throws SQLException, IOException {
		int countTable = 0;
		conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
//		Statement stmt = conn.createStatement();
		tableList.add("TBL_CTQMQMHNC");
		tableList.add("TBL_CTQMQMHNT");
		tableList.add("TBL_CTQMQMHOO");
		tableList.add("TBL_CTQMQMSNC");
		tableList.add("TBL_CTQMQMSNT");

		for (int j = 0; j < tableList.size(); j++) {
			String table=tableList.get(j).toString();
			String selectSql = new String(("SELECT " + "*" + " FROM " + table).getBytes(),"UTF-8");
			Statement stmt = conn.createStatement();
			ResultSet result = stmt.executeQuery(selectSql);
			ResultSetMetaData md = result.getMetaData();
			List<String> row = new ArrayList<String>();
			List<String> col = new ArrayList<String>();

			for (int i = 1; i <= md.getColumnCount(); i++) {
				col.add("\"" + md.getColumnName(i) + "\"");
//				System.out.println("getColumn = = "+md.getColumnName(i) + " - " + md.getColumnTypeName(i));
			}

			row.add(String.join(",", col));
			while (result.next()) {
				col = new ArrayList<String>();
				for (int i = 1; i <= md.getColumnCount(); i++) {
					String str = "";
					// VARCHAR -> + ""
//					str = result.getString(i);
//					OutputStream out = new OutputStream();
//					PrintStream out = new PrintStream(System.out, false, "UTF8");  //This is the key
//					out.println("str = "+ str);
					if(result.getString(i)!=null) {
						str =new String(result.getString(i).getBytes(),"UTF-8");
					}
//					System.out.println("str = "+ str);
					str = result.getString(i) != null ? "" + result.getString(i) + "" : "";
					if(result.getString(i)!=null && i!=1 && !md.getColumnName(i).toUpperCase().contains("PRN")){
						if (isEncoded(result.getString(i)))
							str = result.getString(i) != null ? "" + result.getString(i) + "" : "";
						if (containsDigit(result.getString(i)) || result.getString(i).equals(""))
							if(md.getColumnTypeName(i).equals("VARCHAR") || md.getColumnTypeName(i).equals("CHAR"))
//								str = result.getString(i) != null ? "\"" + result.getString(i) + "\"" : "";
								str = result.getString(i) != null ?  result.getString(i)  : "";
						if (md.getColumnTypeName(i).equals("TIMESTAMP"))
							str = result.getTimestamp(i) != null
									? new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.").format(result.getTimestamp(i))
											+ String.format("%06d", result.getTimestamp(i).getNanos() / 1000)
									: "";
					}
					
	

					// containsDigit(result.getString(i))
					str="\""+str+"\"";
					col.add(str);
					
				}
//				System.out.println(String.join(",", col));
				row.add(String.join(",", col));
//				System.out.println("col = "+col);
			}

			FileUtils.writeLines(new File("D:\\Round_3_Auto\\temp\\db dump\\temp\\TSIT0383_DB_DUMP\\" + table + ".csv"), row);
//			FileUtils.writeLines(new File("D:\\User\\jackyau2\\csv\\" + table + ".txt"), row);

			stmt.close();
			result.close();

			System.out.println("table = "+table+" done!!");
			countTable++;
			System.out.println("Count no of table = "+countTable);
//			break;
		}

	}
//	private static void writeUtf8ToFile(File file, boolean append, String data)
//		    throws IOException {
//		  boolean skipBOM = append && file.isFile() && (file.length() > 0);
//		  Closer res = new Closer(null);
//		  try {
//		    OutputStream out = res.using(new FileOutputStream(file, append));
//		    Writer writer = res.using(new OutputStreamWriter(out, Charset.forName("UTF-8")));
//		    if (!skipBOM) {
//		      writer.write('\uFEFF');
//		    }
//		    writer.write(data);
//		  } finally {
//		    res.close();
//		  }
//		}
	public static boolean isEncoded(String text) {
//		Charset charset = Charset.forName("US-ASCII");
		Charset charset = Charset.forName("UTF-8");
		String checked = new String(text.getBytes(charset), charset);
		return !checked.equals(text);

	}

	public static boolean containsDigit(final String aString) {
		return aString != null && !aString.isEmpty() && aString.chars().anyMatch(Character::isDigit);
	}

	public static void sqlToCSV(String query, String filename) throws IOException, SQLException {

		Statement st;
		FileWriter fw = new FileWriter(filename + ".csv");
		st = conn.createStatement();
		ResultSet rs = st.executeQuery(query);

		int cols = rs.getMetaData().getColumnCount();

		for (int i = 1; i <= cols; i++) {
			fw.append(rs.getMetaData().getColumnLabel(i));
			if (i < cols)
				fw.append(',');
			else
				fw.append('\n');
		}

		while (rs.next()) {

			for (int i = 1; i <= cols; i++) {
				String tempData = rs.getString(i);
				String data = tempData != null ? tempData.replace("\"", "") : "";
				fw.append(data);
				if (i < cols)
					fw.append(',');
			}
			fw.append('\n');
		}
		st.close();

		fw.flush();
		fw.close();

	}

}
