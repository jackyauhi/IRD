import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class nestedforeach {
	public static int count =0;
	public static void main(String[] args) throws Exception{
		String dirCLD = args[0];
//		String dirCLD = "D:\\ccshare\\jyyau_view_ClearCase_MTN\\TAAS2_UAT\\CloudMigration\\Application";
		test4(dirCLD);
		
	}
	public static void test4(String dirCLD) throws IOException{
		String inputPath=dirCLD+"\\AutoSyncFiles";
		String outputPath=dirCLD+"\\WarningFiles";

		Stream<Path> fwalk = Files.walk(Paths.get(inputPath));
//		Stream<Path> fwalk = Files.walk(Paths.get(inputPath));
		List<String> cldFList = fwalk.filter(f -> Files.isRegularFile(f))
				.map(x -> x.toString())
				.filter(s -> s.toLowerCase().endsWith("xml"))
				.collect(Collectors.toList());
		fwalk.close();
		
		for(String file : cldFList) {
//			System.out.println(file);
			if(containNestedForeach(file)){
				System.out.println(file);
				process(file,outputPath);
			}
			if(containShrVariable(file)){
				System.out.println(file);
				process(file,outputPath);
			}
		}

		
	}
	private static boolean containShrVariable(String file) throws IOException {
		// TODO Auto-generated method stub
		String content = null;
		try {
			content = new String(Files.readAllBytes(Paths.get(file)));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Pattern pattern = Pattern.compile("<if test=\"\\s*[sS][hH][rR]\\s*[!=]=\\s*([a-zA-Z0-9_]+)\\s*\">");
		String storeVarible =null;
		Matcher patternMatcher=pattern.matcher(content);
		if (patternMatcher.find()){
//			storeVarible = patternMatcher.group();
//			System.out.println("storeVarible =" +storeVarible);
			return true;
		}
		pattern = Pattern.compile("<if test=\"\\s*([a-zA-Z0-9._ !=]+)[.][sS][hH][rR]\\s*[!=]=\\s*([a-zA-Z0-9_]+)\\s*\">");
		storeVarible =null;
		patternMatcher=pattern.matcher(content);
		if (patternMatcher.find()){
//			storeVarible = patternMatcher.group();
//			System.out.println("storeVarible =" +storeVarible);
			return true;
		}
//		count++;
//		System.out.println("file =" +file);
//		System.out.println("count =" +count);
		
		return false;
	}
	
	private static boolean containNestedForeach(String file) throws IOException {
		// TODO Auto-generated method stub
		List<String> content = Files.readAllLines(Paths.get(file));
		
		String contentStr = String.join("", content);

		contentStr = contentStr.replaceAll("<sql id=\"([a-zA-Z0-9._ ]*)([Ww])here_([Cc])lause([a-zA-Z0-9._ ]*)\"[\\s\\S]*sql>", "");
		

		
		if(contentStr.indexOf("foreach")==-1) return false;
		
		contentStr = contentStr.substring(contentStr.indexOf("foreach")+7, contentStr.length());
		

		if(!contentStr.substring(contentStr.indexOf("foreach")-2).startsWith("</")) return true;
		
		
		return false;
	}
	   public static void process(String inputPath, String outputPath) throws IOException {
		   String[] splitPath=null;
				

					String filePath="";
					String sourcePath="";
						if(inputPath.contains("\\Application\\")){
							splitPath = inputPath.split(Pattern.quote("\\Application\\"),2);
							filePath="\\"+splitPath[1];
							sourcePath=inputPath;
						}
						else if(inputPath.contains("\\TAAS2_UAT\\")){
							splitPath = inputPath.split(Pattern.quote("\\TAAS2_UAT\\"),2);
							filePath="\\"+splitPath[1];
							sourcePath=inputPath;
						}
						else {
			        		System.out.println("Remove this file : " +inputPath);
						}
		        	

					if(!filePath.equals("")) {
						File fileToSave = new File(outputPath+filePath);
						File sourceFile = new File(sourcePath);
						File fileToSaveParent=new File(fileToSave.getParent());
						if (!fileToSaveParent.exists()) {
							fileToSaveParent.mkdirs();
						}
								fileToSave.delete();
								transform(sourceFile,"UTF-8",fileToSave,"UTF-8");
					}	
	   }
	   public static void transform(File source, String srcEncoding, File target, String tgtEncoding) throws IOException {
		    BufferedReader br = null;
		    BufferedWriter bw = null;
		    try{
		        br = new BufferedReader(new InputStreamReader(new FileInputStream(source),srcEncoding));
		        bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(target), tgtEncoding));
		        char[] buffer = new char[16384];
		        int read;
		        while ((read = br.read(buffer)) != -1)
		            bw.write(buffer, 0, read);
		    } finally {
		        try {
		            if (br != null)
		                br.close();
		        } finally {
		            if (bw != null)
		                bw.close();
		        }
		    }
		}
}