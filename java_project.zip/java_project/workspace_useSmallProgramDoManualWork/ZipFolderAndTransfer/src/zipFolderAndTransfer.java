


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;




public class zipFolderAndTransfer {
	public static List<String> inputFileList = new ArrayList<String>();
	public static List<String> outputFileList = new ArrayList<String>();
	public static List<String> filesListInDir = new ArrayList<String>();
	public static List<String> cloudCheckinList = new ArrayList<String>();
	public static String cloudCheckinPath = "";
	public static String folderPath = "";
//	public static File targetFile = new File("");
	public static String cloudFileZipName = "Cloud_Check_in_Files";
	public static void main(String[] args) throws IOException {
//		String inputPath="D:\\helper_tmp\\Result\\output";
//		String outputPath="Q:\\IR1E\\Cloud Migration\\working\\CloudDeployment\\Production Deployment File";
//		String outputPath="D:\\helper_tmp\\Result";
//		String inputPath=args[0];
//		String outputPath=args[1];
		//D:\helper_tmp\output
		String inputPath="D:\\helper_tmp\\output";
//		String inputPath="D:\\User\\1.MybatisConvertor\\output";
		String outputPath="H:\\DEV\\TAAS\\Cloud Migration\\Phase 2\\Cloud Deployment\\ExportSourceCode";
//		String outputPath="T:\\jackyau\\hihi";
		String ClearCaseApplicationPath="D:\\ccshare\\jyyau_view_ClearCase_MTN\\TAAS2_UAT\\CloudMigration\\Application";
		String convertorFilePath="D:\\helper_tmp";
		//D:\User\1.MybatisConvertor
//		String convertorFilePath="D:\\User\\1.MybatisConvertor";
		String requiredFilePath=convertorFilePath+"\\AutoSyncFiles";
		String tempCloudCheckinFiles=outputPath+"\\CloudMigration";
        try (Stream<Path> walk = Files.walk(Paths.get(convertorFilePath+"\\AutoSyncFiles"))) {
			List<String> result = walk.filter(Files::isRegularFile)
					.map(x -> x.toString()).collect(Collectors.toList());
			for (int j = 0; j < result.size(); j++) {
				cloudCheckinPath=result.get(j).toString().replaceAll(Pattern.quote(requiredFilePath), Matcher.quoteReplacement(ClearCaseApplicationPath));
				cloudCheckinList.add(cloudCheckinPath);					
			}
        }
		for (int i = 0; i < cloudCheckinList.size(); i++) {
			System.out.println("cloudCheckinList.get(i).toString() = "+cloudCheckinList.get(i).toString());
			String[] inputSplit = cloudCheckinList.get(i).toString().split("TAAS2_UAT",2);
			folderPath=inputSplit[1];
			
			File fileToSave = new File(outputPath+"\\"+folderPath);
			File fileToSaveParent=new File(fileToSave.getParent());
			if (!fileToSaveParent.exists()) {
				fileToSaveParent.mkdirs();
			}
			File sourceFile = new File(cloudCheckinList.get(i).toString());
			File targetFile = new File(outputPath+"\\"+folderPath);
			
			try {
				transform(sourceFile,"UTF-8",targetFile,"UTF-8");
				System.out.println("transform from:"+sourceFile.getAbsolutePath() + System.lineSeparator());
				System.out.println("To:"+targetFile.getAbsolutePath() + System.lineSeparator());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
		zipFolderAndTransfer.zipDirectory(tempCloudCheckinFiles, outputPath+"\\"+cloudFileZipName+".zip");
		
		File dir = new File(inputPath);
        File listDir[] = dir.listFiles();
        for (int i = 0; i < listDir.length; i++) {
			String[] splitData = listDir[i].getAbsolutePath().split(Pattern.quote("\\"));
			String zipName = splitData[splitData.length-1];
			System.out.println("zipName = "+zipName);
			String[] reqId=zipName.split("_",2);
            if (listDir[i].isDirectory()) {
            	File checking = new File(outputPath+"\\"+zipName+".zip");
            	if(checking.exists()) {
            		checking.delete();
            	}
            	if(!listDir[i].getName().startsWith("manual_")) {
        			File fileToZip = new File(outputPath+"\\"+reqId[0]);
        			if (!fileToZip.exists()) {
        				fileToZip.mkdirs();
        			}
            		zipFolderAndTransfer.zipDirectory(listDir[i].getAbsolutePath(), fileToZip+"\\"+zipName+".zip");
            		File sourceFile = new File(outputPath+"\\"+cloudFileZipName+".zip");
        			File targetFile = new File(fileToZip+"\\"+cloudFileZipName+".zip");
        			
        			try {
        				copy(sourceFile,targetFile);
        				System.out.println("transform from:"+sourceFile.getAbsolutePath() + System.lineSeparator());
        				System.out.println("To:"+targetFile.getAbsolutePath() + System.lineSeparator());
        			} catch (IOException e) {
        				// TODO Auto-generated catch block
        				e.printStackTrace();
        			}			
            	}
            }		
        }
        File deleteFile = new File(tempCloudCheckinFiles);
        deleteFile(deleteFile);
        File deleteFile1 = new File(outputPath+"\\"+cloudFileZipName+".zip");
        deleteFile1.delete();
	}
	private static void copy(File src, File dest) throws IOException { 
		InputStream is = null; 
		OutputStream os = null; 
		try { 
			is = new FileInputStream(src); 
			os = new FileOutputStream(dest); // buffer size 1K 
			byte[] buf = new byte[1024]; 
			int bytesRead; 
			while ((bytesRead = is.read(buf)) > 0) { 
				os.write(buf, 0, bytesRead); 
				} 
			} finally { 
				is.close(); 
				os.close(); 
				} 
		}

	public static void deleteFile(File element) {
	    if (element.isDirectory()) {
	        for (File sub : element.listFiles()) {
	            deleteFile(sub);
	        }
	    }
	    element.delete();
	}
	public static void zipDirectory(String sourceDirPath, String zipFilePath) throws IOException {
	    Path p = Files.createFile(Paths.get(zipFilePath));
	    try (ZipOutputStream zs = new ZipOutputStream(Files.newOutputStream(p))) {
	        Path pp = Paths.get(sourceDirPath);
	        Files.walk(pp)
	          .filter(path -> !Files.isDirectory(path))
	          .forEach(path -> {
	              ZipEntry zipEntry = new ZipEntry(pp.relativize(path).toString());
	              try {
	                  zs.putNextEntry(zipEntry);
	                  Files.copy(path, zs);
	                  zs.closeEntry();
	            } catch (IOException e) {
	                System.err.println(e);
	            }
	          });
	    }
	}
	public static void transform(File source, String srcEncoding, File target, String tgtEncoding) throws IOException {
	    BufferedReader br = null;
	    BufferedWriter bw = null;
	    try{
	        br = new BufferedReader(new InputStreamReader(new FileInputStream(source),srcEncoding));
	        bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(target), tgtEncoding));
	        char[] buffer = new char[16384];
	        int read;
	        while ((read = br.read(buffer)) != -1)
	            bw.write(buffer, 0, read);
	    } finally {
	        try {
	            if (br != null)
	                br.close();
	        } finally {
	            if (bw != null)
	                bw.close();
	        }
	    }
	}
    
}