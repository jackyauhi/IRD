import java.io.BufferedReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class outputPartOfContent {
	public static ArrayList<String> inputFileList = new ArrayList<String>();
	public static ArrayList<String> outputFileList = new ArrayList<String>();
	
	public static void main(String[] args) {
		String inputPath="T:\\jackyau\\sql_log_Output.txt";
		String requiredPartOfContent=" ";
		String outputPath="T:\\jackyau\\existing_sql_log_Output.txt";
		try {
			BufferedReader fileReader = new BufferedReader(new FileReader(inputPath));
			String line=null;
		    try {
				while ((line = fileReader.readLine()) != null)
				{	
					if(line.contains(requiredPartOfContent)) {
						inputFileList.add(line);
					}
				}
				fileReader.close();
			} 
		    catch (IOException e1) {
				e1.printStackTrace();
			}
			} 
	   	catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
		int count=0;
		try {
			FileWriter fileWriter = new FileWriter(outputPath);
			for (int i = 0; i < inputFileList.size(); i++) {
				if(count==0) {
					fileWriter.write(inputFileList.get(i).toString()+System.lineSeparator());
					count++;
				}
				else {
					count=0;
					}
			}
			fileWriter.close();
		} catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data in outputPathList");
		}
	}
}