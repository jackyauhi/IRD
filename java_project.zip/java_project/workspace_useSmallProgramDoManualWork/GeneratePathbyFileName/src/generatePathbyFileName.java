import java.io.BufferedReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class generatePathbyFileName {
	public static ArrayList<String> inputFileList = new ArrayList<String>();
	public static ArrayList<String> inputFileNameList = new ArrayList<String>();
	public static ArrayList<String> inputFileProjectNameList = new ArrayList<String>();
	public static ArrayList<String> inputFilePathList = new ArrayList<String>();
	public static ArrayList<String> inputFileInformationList = new ArrayList<String>();
	public static ArrayList<String> outputFileList = new ArrayList<String>();
	
	public static void main(String[] args) {
		int count=0;
		String inputPath="D:\\ccshare\\jyyau_view_ClearCase_PRD\\TAAS2_DEV\\PRD_Application";
		String inputText="T:\\jackyau\\fileName.csv";
//		String requiredPartOfContent=" ";
		String outputPath="T:\\jackyau\\fileNamePath.csv";
		try {
			BufferedReader fileReader = new BufferedReader(new FileReader(inputText));
			String line1=null;
		    try {
				while ((line1 = fileReader.readLine()) != null)
				{	
					String[] splitCsv = line1.split(",");
					if(splitCsv.length==0) {
						break;
					}
					String informationList ="";
					String line = splitCsv[1];
					String[] splitData = line.split(Pattern.quote("\\src"),2);
					String[] splitProjectName= splitData[0].split(Pattern.quote("\\"));
					inputFileProjectNameList.add(splitProjectName[splitProjectName.length-1]);
					System.out.println("splitProjectName[splitProjectName.length-1] =" + splitProjectName[splitProjectName.length-1]);
					inputFilePathList.add(splitProjectName[splitProjectName.length-1]+"\\src"+splitData[1]);
					System.out.println("splitProjectName[splitProjectName.length-1]+src+splitData1[1] =" + splitProjectName[splitProjectName.length-1]);
					for (int i = 0; i < splitCsv.length; i++) {
						if(i==0) {
							
						}
						else if(i==1) {
							
						}
						else if(splitCsv.length-1==i) {
							informationList=informationList+splitCsv[i];
						}
						else {
							informationList=informationList+splitCsv[i]+",";
						}
					}
					inputFileInformationList.add(informationList);
					System.out.println("inputFileInformationList.get(count).toString()" +inputFileInformationList.get(count).toString());
					count++;
				}
				fileReader.close();
			} 
		    catch (IOException e1) {
				e1.printStackTrace();
			}
			} 
	   	catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
		try (Stream<Path> walk = Files.walk(Paths.get(inputPath))) {

//			List<String> result = walk.map(x -> x.toString())
//					.filter(f -> f.contains(".LOG.")).collect(Collectors.toList());
			List<String> result = walk.filter(Files::isRegularFile)
					.map(x -> x.toString()).collect(Collectors.toList());
			for (int i = 0; i < inputFilePathList.size(); i++) {
				String filePathName = inputFilePathList.get(i).toString();
				for (int j = 0; j < result.size(); j++) {
//					System.out.println("result.get(j).toString() =" + result.get(j).toString());
					if(result.get(j).toString().contains("\\src")) {
						String[] splitData = result.get(j).toString().split(Pattern.quote("\\src"),2);
						String[] splitProjectName= splitData[0].split(Pattern.quote("\\"));
						String filepath = splitProjectName[splitProjectName.length-1]+"\\src"+splitData[1];
//						File filePath = new File(result.get(j).toString());
						if(filepath.equals(filePathName)) {
							outputFileList.add(inputFileProjectNameList.get(i).toString()+","+result.get(j).toString()+","+inputFileInformationList.get(i).toString());
							System.out.println("result.get(j).toString() =" + result.get(j).toString());
						}
				  }
				}
			}
//			result.forEach(System.out::println);

//			try {
//			FileWriter fileWriter = new FileWriter(outputPath);
//			for (int i = 0; i < result.size(); i++) {
//				if(result.get(i).toString().contains("ExportProgramList")) {
//					System.out.println("result.get(i).toString().contains"+result.get(i).toString());
//				}
//				else {
//				fileWriter.write(result.get(i).toString()+System.lineSeparator());
//				}
//			}
//			fileWriter.close();
//		} catch (IOException iox) {
//			iox.printStackTrace();
//			System.out.println("File can not save any data in outputPathList");
//		}
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
		FileWriter fileWriter = new FileWriter(outputPath);
		for (int i = 0; i < outputFileList.size(); i++) {
			fileWriter.write(outputFileList.get(i).toString()+System.lineSeparator());
		}
		fileWriter.close();
	} catch (IOException iox) {
		iox.printStackTrace();
		System.out.println("File can not save any data in outputPathList");
	}
//		try {
//		FileWriter fileWriter = new FileWriter(outputPath);
//		for (int i = 0; i < inputFileList.size(); i++) {
//			if(count==0) {
//				fileWriter.write(inputFileList.get(i).toString()+System.lineSeparator());
//				count++;
//			}
//			else {
//				count=0;
//				}
//		}
//		fileWriter.close();
//	} catch (IOException iox) {
//		iox.printStackTrace();
//		System.out.println("File can not save any data in outputPathList");
//	}
//		try {
//			BufferedReader fileReader = new BufferedReader(new FileReader(inputPath));
//			String line=null;
//		    try {
//				while ((line = fileReader.readLine()) != null)
//				{	
//					if(line.contains(requiredPartOfContent)) {
//						inputFileList.add(line);
//					}
//				}
//				fileReader.close();
//			} 
//		    catch (IOException e1) {
//				e1.printStackTrace();
//			}
//			} 
//	   	catch (FileNotFoundException e1) {
//				e1.printStackTrace();
//			}
//		int count=0;
//		try {
//			FileWriter fileWriter = new FileWriter(outputPath);
//			for (int i = 0; i < inputFileList.size(); i++) {
//				if(count==0) {
//					fileWriter.write(inputFileList.get(i).toString()+System.lineSeparator());
//					count++;
//				}
//				else {
//					count=0;
//					}
//			}
//			fileWriter.close();
//		} catch (IOException iox) {
//			iox.printStackTrace();
//			System.out.println("File can not save any data in outputPathList");
//		}
	}
}