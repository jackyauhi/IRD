import java.io.BufferedReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class findSQLMethodCallInJava {
	public static ArrayList<String> xmlmethodList = new ArrayList<String>();
	public static ArrayList<String> javaMethodNameList = new ArrayList<String>();
	public static ArrayList<String> inputFileList = new ArrayList<String>();
	public static ArrayList<String> outputFileList = new ArrayList<String>();
	public static List<String> daoImplFilePath = new ArrayList<String>();
	public static List<String> allJavaFilePath = new ArrayList<String>();
	public static List<String> errorFileList = new ArrayList<String>();
	public static String javaMethodName ="";
	public static void main(String[] args) {
		String inputList="T:\\jackyau\\requiredList.csv";
		String inputPath="D:\\ccshare\\jyyau_view_ClearCase\\TAAS2_DEV\\Application";
		String javamethodName="T:\\jackyau\\javamethodName.csv";
		String outputPath="T:\\jackyau\\functionPathID1.csv";
		String javainputText="T:\\jackyau\\javainputText.txt";
		try {
			BufferedReader fileReader = new BufferedReader(new FileReader(inputList));
			String line=null;
		    try {
				while ((line = fileReader.readLine()) != null)
				{	

						String[] dataStore = line.split(",");
						String xmlStore ="";
			       		if(dataStore.length>=2){
							if(dataStore[0].contains(".xml")) {
								String[] tempStore = dataStore[0].split(".xml");
								xmlStore=tempStore[0];
							}
//							System.out.println(" xmlmethodList =" + xmlStore+"."+dataStore[1]);
							xmlmethodList.add(xmlStore+"."+dataStore[1]);
			       		}
				}
				fileReader.close();
			} 
		    catch (IOException e1) {
				e1.printStackTrace();
			}
			} 
	   	catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
		try {
			BufferedReader fileReader = new BufferedReader(new FileReader(javainputText));
			String line=null;
		    try {
				while ((line = fileReader.readLine()) != null)
				{	
					allJavaFilePath.add(line);
				}
				fileReader.close();
			} 
		    catch (IOException e1) {
				e1.printStackTrace();
			}
			} 
	   	catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
//		try (Stream<Path> walk = Files.walk(Paths.get(inputPath))) {
//			List<String> result = walk.map(x -> x.toString()).filter(f -> f.contains(".java")).collect(Collectors.toList());
//			allJavaFilePath=result;
//		}catch (IOException e) {
//			e.printStackTrace();
//		}
//		try {
//			FileWriter fileWriter = new FileWriter(javainputText);
//			for (int i = 0; i < allJavaFilePath.size(); i++) {
//				fileWriter.write(allJavaFilePath.get(i).toString()+System.lineSeparator());
//			}
//			fileWriter.close();			
//		} catch (IOException iox) {
//			iox.printStackTrace();
//			System.out.println("File can not save any data in outputPathList");
//		}
		
		for (int i = 0; i < xmlmethodList.size(); i++) {
			for (int j = 0; j < allJavaFilePath.size(); j++) {				
				File javaFilePath= new File(allJavaFilePath.get(j).toString());
				if(javaFilePath.getName().endsWith("DaoImpl.java")) {
				String daoImplFileContent = "";
				try {
					daoImplFileContent = new String(Files.readAllBytes(Paths.get(allJavaFilePath.get(j).toString())));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(daoImplFileContent.contains(xmlmethodList.get(i).toString().trim())) {
					if(!daoImplFileContent.contains("public class")) {
						System.out.println("result.get(j).toString() =" + allJavaFilePath.get(j).toString());
						errorFileList.add(allJavaFilePath.get(j).toString());
					}
					try {
						BufferedReader fileReader = new BufferedReader(new FileReader(allJavaFilePath.get(j).toString()));
						String line=null;
					    try {
							while ((line = fileReader.readLine()) != null)
							{	
								String lineNoSpace ="";
								lineNoSpace=line.replaceAll("\\s*", "");
								if(line.startsWith("public class")) {
									
								}		
								else if(lineNoSpace.startsWith("public")||lineNoSpace.startsWith("private")) {
									if(line.contains("(")) {
									String[] requiredInformation = line.split(Pattern.quote("("));
									String[] requiredInformation1 = requiredInformation[0].split(" ");
//									for (int sp = 0; sp < requiredInformation1.length; sp++) {				
//										if(requiredInformation[sp].contains("(")) {
//											String[] requiredInformation1 = requiredInformation[sp].split(Pattern.quote("("));
//											javaMethodName=requiredInformation1[0];
////											System.out.println("javaMethodName =" + javaMethodName);
//										}
									int requiredNum=requiredInformation1.length;
									String requiredjavaMethodName="";
									while(requiredjavaMethodName.equals("")) {
										requiredjavaMethodName=requiredInformation1[requiredNum-1];
										javaMethodName=requiredjavaMethodName;
//										System.out.println("javaMethodName =" + javaMethodName);
										requiredNum--;
										}
									}
									else {
										errorFileList.add(allJavaFilePath.get(j).toString());
									}
								}
								if(line.contains(xmlmethodList.get(i).toString().trim())) {
									javaMethodNameList.add(xmlmethodList.get(i).toString().trim()+","+javaMethodName);
									System.out.println("javaMethodNameList =" + xmlmethodList.get(i).toString().trim()+","+javaMethodName);
								}
								
							}
							fileReader.close();
						} 
					    catch (IOException e1) {
							e1.printStackTrace();
						}
						} 
				   	catch (FileNotFoundException e1) {
							e1.printStackTrace();
						}
					}
				}		
			}
		}
		try {
			FileWriter fileWriter = new FileWriter(javamethodName);
			for (int i = 0; i < javaMethodNameList.size(); i++) {
				fileWriter.write(javaMethodNameList.get(i).toString()+System.lineSeparator());
			}
			fileWriter.close();			
		} catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data in outputPathList");
		}
		
		System.out.println("errorFileList Here "+System.lineSeparator());
		for (int i = 0; i < errorFileList.size(); i++) {
			System.out.println(errorFileList.get(i).toString()+System.lineSeparator());
		}
		for (int i = 0; i < javaMethodNameList.size(); i++) {
			for (int j = 0; j < allJavaFilePath.size(); j++) {
				File javaFilePath= new File(allJavaFilePath.get(j).toString());
				if(!javaFilePath.getName().endsWith("Dao.java")||!javaFilePath.getName().endsWith("DaoImpl.java")) {
				String fileContent = "";
				try {
					fileContent = new String(Files.readAllBytes(Paths.get(allJavaFilePath.get(j).toString())));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
				String[] javaMethod = javaMethodNameList.get(i).toString().split(",");
//		   		if(javaMethod.length<2) {
//		   			errorFileList.add(allJavaFilePath.get(j).toString());
//		   		}
				String[] checkingName = javaMethod[0].split(Pattern.quote("."));
				String checkingName2 =checkingName[0].substring(1,checkingName[0].length());
				String checkingName1 = checkingName2+"Dao."+javaMethod[1];
//				System.out.println("checkingName1 ="+checkingName1);
					if(fileContent.contains(checkingName1)) {
						System.out.println("outputFileList.toString() =" + javaMethodNameList.get(i).toString()+","+checkingName1+","+javaFilePath.getAbsolutePath());
						outputFileList.add(javaMethodNameList.get(i).toString()+","+checkingName1+","+javaFilePath.getAbsolutePath());
					}
				}
			}
		  }
//		for (int jMethod = 0; jMethod < javaMethodNameList.size(); jMethod++) {
//		String[] javaMethod = javaMethodNameList.get(jMethod).toString().split(",");
//   		if(javaMethod.length<2) {
//   			errorFileList.add(allJavaFilePath.get(j).toString());
//   		}
//			if(fileContent.contains(javaMethod[1])) {
//				System.out.println("outputFileList.toString() =" + javaMethodNameList.get(jMethod).toString()+","+javaFilePath.getAbsolutePath());
//				outputFileList.add(javaMethodNameList.get(jMethod).toString()+","+javaFilePath.getAbsolutePath());
//			}
//		}
//	  }//if(!fileName.endsWith("Dao.java")||!fileName.endsWith("DaoImpl.java")) {
			try {
				FileWriter fileWriter = new FileWriter(outputPath);
				for (int i = 0; i < outputFileList.size(); i++) {
					fileWriter.write(outputFileList.get(i).toString()+System.lineSeparator());
				}
				fileWriter.close();			
			} catch (IOException iox) {
				iox.printStackTrace();
				System.out.println("File can not save any data in outputPathList");
			}
			
			System.out.println("errorFileList Here "+System.lineSeparator());
			for (int i = 0; i < errorFileList.size(); i++) {
				System.out.println(errorFileList.get(i).toString()+System.lineSeparator());
			}
			
	}
}