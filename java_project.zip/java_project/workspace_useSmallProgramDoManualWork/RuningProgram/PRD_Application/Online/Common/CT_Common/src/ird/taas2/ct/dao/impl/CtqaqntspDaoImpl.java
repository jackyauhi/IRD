//Check in version of WAS_PRD,04-02-17,bhssham:2:XyIIeBMkIKHkjTp1mHQ+0B0tZ0/kVFSmbgciDbVnTmU=
//Check in version of WAS_PRD,02-02-17,jwccheung:1:bjtoNgb315RWg3xAelCjvx0tZ0/kVFSmbgciDbVnTmU=
package ird.taas2.ct.dao.impl;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import ird.taas2.ct.dao.CtqaqntspDao;
import ird.taas2.ct.model.Ctqaqncpa;
import ird.taas2.ct.model.Ctqaqncsp;
import ird.taas2.ct.model.Ctqaqntsp;
import ird.taas2.data.dao.impl.BaseDaoIbatisImpl;

@Component("ctqaqntspDao")
public class CtqaqntspDaoImpl extends BaseDaoIbatisImpl<Ctqaqntsp> implements CtqaqntspDao{

	@SuppressWarnings("deprecation")
	@Override
	public Ctqaqntsp selectByPrimaryKey(Integer assYr, String prn,
			String suspendType, String taxType, Integer brn, Integer spBrn)
			throws SQLException {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("prn", prn);
		paramMap.put("assYr", assYr);
		paramMap.put("suspendType", suspendType);
		paramMap.put("taxType", taxType);
		paramMap.put("brn", brn);
		paramMap.put("spBrn", spBrn);

		return (Ctqaqntsp)getSqlMapClientTemplate().queryForObject("Ctqaqntsp.selectByPrimaryKey", paramMap);
	}

	public void insert(Ctqaqntsp ctqaqntsp) throws SQLException {
		getSqlMapClientTemplate().insert("Ctqaqntsp.insert", ctqaqntsp);
	}

	public int deleteByPrimaryKey(Integer assYr, String prn,
			String suspendType, String taxType, Integer brn, Integer spBrn)
			throws SQLException {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("prn", prn);
		paramMap.put("assYr", assYr);
		paramMap.put("suspendType", suspendType);
		paramMap.put("taxType", taxType);
		paramMap.put("brn", brn);
		paramMap.put("spBrn", spBrn);

		return getSqlMapClientTemplate().delete("Ctqaqntsp.deleteByPrimaryKey", paramMap);
	}	
	
	public int updateByPrimaryKey(Ctqaqntsp ctqaqntsp) throws SQLException {
        int rows = getSqlMapClientTemplate().update("Ctqaqntsp.updateByPrimaryKey", ctqaqntsp);
        return rows;
    }

	@Override
	public List<Ctqaqntsp> selectByCtars(Integer assYr, String prn,
			String suspendType, String taxType, Integer brn)
			throws SQLException {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("prn", prn);
		paramMap.put("assYr", assYr);
		paramMap.put("suspendType", suspendType);
		paramMap.put("taxType", taxType);
		paramMap.put("brn", brn);

		return (List<Ctqaqntsp>) getSqlMapClientTemplate().queryForList("Ctqaqntsp.selectByCtars", paramMap);
	}
}
