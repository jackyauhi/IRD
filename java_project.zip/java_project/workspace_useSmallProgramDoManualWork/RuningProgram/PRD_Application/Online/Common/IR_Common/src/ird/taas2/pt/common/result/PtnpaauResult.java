//Check in version of WAS_PRD,04-02-17,bhssham:2:iXso0dtT5P94Y0T/hC+jlCUZXIITPICmTrcnVE4AdmU=
//Check in version of WAS_PRD,03-02-17,jwccheung:1:xIJGOpQQU/ckdvBYfhkWTCUZXIITPICmTrcnVE4AdmU=
package ird.taas2.pt.common.result;

public class PtnpaauResult {

	private String returnCode;

	public String getReturnCode() {
		return returnCode;
	}

	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}
	
	
}
