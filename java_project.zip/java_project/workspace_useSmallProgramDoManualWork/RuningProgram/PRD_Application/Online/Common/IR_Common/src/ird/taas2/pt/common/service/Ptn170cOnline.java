//Check in version of WAS_PRD,04-02-17,bhssham:2:75jW06NxCOQi9wGx8yEtzCUZXIITPICmTrcnVE4AdmU=
//Check in version of WAS_PRD,03-02-17,jwccheung:1:UrC00XChXa9937PjcteK1CUZXIITPICmTrcnVE4AdmU=
package ird.taas2.pt.common.service;

import ird.taas2.pt.common.service.result.Ptn170cResult;

import java.util.Map;

import org.springframework.stereotype.Component;

@Component("ptn170c")
public interface Ptn170cOnline {
	public static final String FIELD_TC5170_PTM1701HIDDEN = "ptm1701hidden";
	public static final String FIELD_TC5170_PTM1701OC = "tc5170.oc";
	public static final String FIELD_TC5170_PTM1701PUN = "tc5170.pun1";
	
	public Map<String, Object> resolveErrArgs(Integer errorCode, String pun, Short oc);
	public Ptn170cResult execute(String pun, Short oc);
	public boolean ownNoOtherProperty(String ownerId, String pun);
}
