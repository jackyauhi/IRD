//Check in version of WAS_PRD,04-02-17,bhssham:2:NHGdPi29RhmhGkA8zHrBfX5iMoGcrJmk6HVM6jhRWOc=
//Check in version of WAS_PRD,02-02-17,jwccheung:1:ETqvlC2Lws9uzJdZ1kZoBn5iMoGcrJmk6HVM6jhRWOc=
package ird.taas2.pe.utils;

import ird.taas2.common.utils.DateUtils;
import ird.taas2.core.enums.TaasSystem;
import ird.taas2.pe.common.model.tc.TC0178;
import ird.taas2.pe.constant.PeConstant;
import ird.taas2.pe.utils.model.PenfmadrBean;
import ird.taas2.pe.utils.model.PenfoadrBean;
import ird.taas2.pe.utils.model.PenfonamBean;
import ird.taas2.pe.utils.model.PenpradsBean;
import ird.taas2.pe.utils.model.PenreadrBean;
import ird.taas2.pe.utils.model.PenrenamBean;
import ird.taas2.report.enums.RptFileExtension;
import ird.taas2.report.pe.irc8433.Irc8433AddrList;
import ird.taas2.report.pe.irc8433.Irc8433AddrPanel;
import ird.taas2.report.pe.irc8433.Irc8433Data;
import ird.taas2.report.pe.irc8433.Irc8433Root;
import ird.taas2.report.service.IrdReportService;
import ird.taas2.utils.EpsReport;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("Penprads")
public class Penprads {
	private static Logger logger = Logger.getLogger(Penprads.class);

	private static final int MAX_COL = 20;
	private static final int MAX_ROW = 7;
	@Autowired
	private IrdReportService irdReportService;

	@Autowired
	private Penrenam penrenam;
	@Autowired
	private Penreadr penreadr;
	@Autowired
	private Penfmadr penfmadr;
	
	public void generateReportXML(List<EpsReport> epsReportList,
			String reportId, String reportTxId) throws Exception {
		if (epsReportList == null) {
			throw new Exception(
					"Input parameter (epsReportList) cannot be null");
		}
		List<List<EpsReport>> reports = new ArrayList<List<EpsReport>>();
		reports.add(epsReportList);
		irdReportService.generateAndSubmitReports(reportId, reportTxId,TaasSystem.PE, RptFileExtension.XML, reports);
		logger.info("generateAndSubmitReports Completed with Success!!");
	}

	public PenrenamBean retrievePEName(String prn) throws Exception {
		PenrenamBean penrenamBean = penrenam.execute(prn);
		return penrenamBean;
	}

	public PenfonamBean formatPEName(PenrenamBean penrenamBean)
			throws Exception {
		PenfonamBean penfonamBean = Penfonam.execute(penrenamBean.getNameInd(),penrenamBean.getNameLine1(), penrenamBean.getNameLine2());
		return penfonamBean;
	}

	public PenfoadrBean formatPEAddress(PenreadrBean penreadrBean)
			throws Exception {
		PenfoadrBean penfoadrBean = new PenfoadrBean();
		penfoadrBean = Penfoadr.execute(penreadrBean.getFormat(),
				penreadrBean.getAreaCode(), penreadrBean.getSource(),
				penreadrBean.getAddrLangInd(), penreadrBean.getAddrFlat(),
				penreadrBean.getAddrBlk(), penreadrBean.getAddrFloor(),
				penreadrBean.getAddrLine1(), penreadrBean.getAddrLine2(),
				penreadrBean.getAddrLine3(), penreadrBean.getAddrLine4(),
				penreadrBean.getAddrLine5(), penreadrBean.getCoLangInd(),
				penreadrBean.getCoDetailsLine1(),
				penreadrBean.getCoDetailsLine2(),
				penreadrBean.getCoDetailsLine3());
		return penfoadrBean;
	}
	
	public PenfoadrBean formatPEAddress(PenpradsBean penpradsBean)
			throws Exception {
		PenfoadrBean penfoadrBean = new PenfoadrBean();
		penfoadrBean = Penfoadr.execute(penpradsBean.getFormat(),
				penpradsBean.getAreaCode(), penpradsBean.getSource(),
				penpradsBean.getAddrLangInd(), penpradsBean.getAddrFlat(),
				penpradsBean.getAddrBlk(), penpradsBean.getAddrFloor(),
				penpradsBean.getAddrLine1(), penpradsBean.getAddrLine2(),
				penpradsBean.getAddrLine3(), "", "",
				penpradsBean.getCoLangInd(),
				penpradsBean.getCoDetailsLine1(),
				penpradsBean.getCoDetailsLine2(),
				penpradsBean.getCoDetailsLine3());
		return penfoadrBean;
	}
	
	public Irc8433Root prepareIrc8433ReportDetails(PenpradsBean penpradsBean,TC0178 tc0178) {
		Irc8433Root irc8433Root = new Irc8433Root();
		List<Irc8433Data> irc8433DataList = new ArrayList<Irc8433Data>();
		Irc8433Data irc8433Data = new Irc8433Data();
		Irc8433AddrPanel addrPanel = new Irc8433AddrPanel();
		List<Irc8433AddrList> addrList = new ArrayList<Irc8433AddrList>();

		irc8433Data.setSectionCode(penpradsBean.getInputSection());
		if ("".equals(penpradsBean.getSection())) {
			irc8433Data.setFileNo(tc0178.getPrn() + " ("+ penpradsBean.getInputSection() + ")");
		} else {
			irc8433Data.setFileNo(penpradsBean.getSection() + "-"+ tc0178.getPrn() + " (" + penpradsBean.getInputSection()+ ")");
		}
		
		if ("1".equals(penpradsBean.getAssrInd())) {
			irc8433Data.setChiAssessor(penpradsBean.getAssrNameChi());
			irc8433Data.setEngAssessor(penpradsBean.getAssrName());	
		} else {
			irc8433Data.setChiAssessor("");
			irc8433Data.setEngAssessor("");
		}

		SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy", Locale.US);
		irc8433Data.setEngIssueDate(sdf.format(penpradsBean.getIssueDate()).toUpperCase());
		irc8433Data.setEngRequestDate(sdf.format(penpradsBean.getRequestDate()).toUpperCase());
				
		

		String requestDateChi = DateUtils.dateToString(penpradsBean.getRequestDate(),"ddMMyyyy");
		if("0".equals(requestDateChi.substring(0, 1))){
			irc8433Data.setChiRequestDay(requestDateChi.substring(1, 2));
		}else{
			irc8433Data.setChiRequestDay(requestDateChi.substring(0, 2));
		}
		if("0".equals(requestDateChi.substring(2, 3))){
			irc8433Data.setChiRequestMonth(requestDateChi.substring(3, 4));
		}else{
			irc8433Data.setChiRequestMonth(requestDateChi.substring(2, 4));
		}		
		irc8433Data.setChiRequestYear(requestDateChi.substring(4, 8));		
		
		String issueDateChi = DateUtils.dateToString(penpradsBean.getIssueDate(),"ddMMyyyy");
		if("0".equals(issueDateChi.substring(0, 1))){
			irc8433Data.setChiIssueDay(issueDateChi.substring(1, 2));
		}else{
			irc8433Data.setChiIssueDay(issueDateChi.substring(0, 2));
		}
		if("0".equals(issueDateChi.substring(2, 3))){
			irc8433Data.setChiIssueMon(issueDateChi.substring(3, 4));
		}else{
			irc8433Data.setChiIssueMon(issueDateChi.substring(2, 4));
		}
		irc8433Data.setChiIssueYr(issueDateChi.substring(4, 8));
		
		
		if(tc0178.getChargeabilityInd()){
			irc8433Data.setType("1");
		}
		else{
			irc8433Data.setType("2");
		}
		

		try {
			PenrenamBean penrenamBean = retrievePEName(tc0178.getPrn());
			PenfonamBean penfonamBean = formatPEName(penrenamBean);
			
//			PenreadrBean penreadrBean = penreadr.execute(PeConstant.CORRESPONDENCE_ADDRESS_TYPE, tc0178.getPrn());		
//			PenfoadrBean penfoadrBean = formatPEAddress(penreadrBean);
			PenfoadrBean penfoadrBean = formatPEAddress(penpradsBean);
			
			Penfoadr.setAddrIndToSpaceForEmptyLine(penfoadrBean);
			
			String[] nameArr = new String[] {penfonamBean.getoName1(), penfonamBean.getoName2(), penfonamBean.getoName3()};
			String[] addrLineArr = new String[] {penfoadrBean.getAddrLine1(),penfoadrBean.getAddrLine2(),penfoadrBean.getAddrLine3(),penfoadrBean.getAddrLine4(),
					                             penfoadrBean.getAddrLine5(),penfoadrBean.getAddrLine6(),penfoadrBean.getAddrLine7()};
			String[] addrIndArr =new String[]{penfoadrBean.getAddrInd1(),penfoadrBean.getAddrInd2(),penfoadrBean.getAddrInd3(),penfoadrBean.getAddrInd4(),
			                                  penfoadrBean.getAddrInd5(),penfoadrBean.getAddrInd6(),penfoadrBean.getAddrInd7()};			
			PenfmadrBean penfmadrBean = penfmadr.execute(1, false, MAX_COL,MAX_ROW, nameArr, penpradsBean.getNameChi(), addrLineArr,addrIndArr);
			
			
			if (penfmadrBean.getOnameAddr6lpiLine().length+penfmadrBean.getOnameAddrLargeLine().length>0 && penfmadrBean.getOnameAddr8lpiLine().length+penfmadrBean.getOnameAddrSmallLine().length==0) {
				mergeAddress(penfmadrBean.getOnameAddrLargeLine(), penfmadrBean.getOnameAddr6lpiLine(),addrList, 7);
				irc8433Data.setChiName(penfmadrBean.getOnameLarge());
				irc8433Data.setAddrPanel(addrPanel);
				irc8433Data.getAddrPanel().setAddrType("2");
				irc8433Data.getAddrPanel().setAddrList(addrList);
				
			}else {
				mergeAddress(penfmadrBean.getOnameAddrSmallLine(), penfmadrBean.getOnameAddr8lpiLine(),addrList, 10);
				irc8433Data.setChiName(penfmadrBean.getOnameSmall());
				irc8433Data.setAddrPanel(addrPanel);
				irc8433Data.getAddrPanel().setAddrType("1");
				irc8433Data.getAddrPanel().setAddrList(addrList);
			}
			irc8433DataList.add(irc8433Data);
			irc8433Root.setData(irc8433DataList);
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return irc8433Root;
	}

	private void mergeAddress(String[] chiAddr, String[] engAddr,List<Irc8433AddrList> addrList, int lineLimit) {
		for (int i = 0; i < chiAddr.length && i < lineLimit; i++) {
			if (StringUtils.isEmpty((chiAddr[i])) == false) {
				Irc8433AddrList addr = new Irc8433AddrList();
				addr.setNameAddr(chiAddr[i]);
				addr.setNameAddrLangInd("C");
				addrList.add(addr);
			} else if (StringUtils.isEmpty((engAddr[i])) == false) {
				Irc8433AddrList addr = new Irc8433AddrList();
				addr.setNameAddr(engAddr[i]);
				addr.setNameAddrLangInd("E");
				addrList.add(addr);
			}
		}
	}
}
