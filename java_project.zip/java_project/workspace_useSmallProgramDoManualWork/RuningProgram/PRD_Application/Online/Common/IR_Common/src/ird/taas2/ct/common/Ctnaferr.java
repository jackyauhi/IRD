//Check in version of WAS_PRD,08-10-20,yswong:4:AFXLBu4jDv/0MQvEPtUqGH5iMoGcrJmk6HVM6jhRWOc=
//Check in version of WAS_PRD,09-04-18,kclai:3:QA1oAoNPPAEtVIz58Fk9LH5iMoGcrJmk6HVM6jhRWOc=
//Check in version of WAS_PRD,04-02-17,bhssham:2:b6FSZEylfgaB51tfumzI735iMoGcrJmk6HVM6jhRWOc=
//Check in version of WAS_PRD,02-02-17,jwccheung:1:Co3cZKvzl8SUrcSUmCqsoH5iMoGcrJmk6HVM6jhRWOc=
package ird.taas2.ct.common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Component;

import ird.taas2.ct.common.model.Ctaaferr;

/**
 * Creation date: 14 April, 2017
 * @author 
 * 
 * 	Program Name: CTNAFERR
 * 
 *	Program Description: 
 *	Return the error message from input error code used in input validation, 
 *	DB validation and suspend criteria for the job CTDAF
 *
 *	Database Action:
 *
 *	Table				Action (R/I/U/D)
 *	--------------		----------------
 *	Nil
 *
 *	Report:
 *	---------------
 *	Nil
 *
 *	Output File:
 *	---------------
 *	Nil
 *
 ******************************************************************************
 * Amendment log
 * -------------
 * 
 * Ref no.    	Date       	Amended by     	Description
 * ----------	----------  ----------     	----------------------------------
 *    			14/04/2017   		   		MMP initial version
 *          							
 *
 ******************************************************************************
 */

@Component("ctnaferr")
public class Ctnaferr {
	
	public final HashMap<String, String> reasonMap = new HashMap<String, String>() {
		{
		put("0001","INV PRINTED PRN");
		put("0002","SELF AND SPOUSE PRN IDENTICAL");
		put("0003","INV SPOUSE PRN");
		put("0004","INV TRAN FOR/WITH NON-RESID FOR BRN1");
		put("0005","INV TAX REP IND MARKED");
		put("0006","INV TRAN FOR/WITH NON-RESID FOR BRN2");
		put("0007","INV ADVANCE RULING IND MARKED");
		put("0008","INV TAX CREDIT IND MARKED");
		put("0009","INV LANGUAGE IND MARKED");
		put("0010","DED FOR PTY LET > 0 BUT PTY LET = 0");
		put("0011","AV FOR PTY LET > 0 BUT PTY LET = 0");
		put("0012","SELF PRN AND PRINTED PRN NOT MATCHED");
		put("0013","INV SEE RECEIPT IND");
		put("0014","INV ST DONATION RECEIPT IND");
		put("0015","INV PA DONATION RECEIPT IND");
		put("0016","INV ENCLOSURE IND");
		put("0017","INV ERCE RECEIPT IND");
		put("0018","INV MORT INT RECEIPT IND");
		put("0019","INV HLI RECEIPT IND");
		put("0020","INV HLI NOM RECEIPT IND");
		put("0021","ST GRAND TOT = 0 BUT SHARE OPT > 0");
		put("0022","ST GRAND TOT = 0 BUT LUMP SUM > 0");
		put("0023","ST GRAND TOT = 0 BUT COMMISSION > 0");
		put("0024","SHARE OPT+LUMP SUM+COMM>ST GRAND TOT");
		put("0025","AMOUNT EXCLUDED > ST GRAND TOTAL");
		put("0026","ST GRAND TOT = 0 BUT OS INC IND ON");
		put("0027","TAX BORNE CASE BUT ST GRAND TOT = 0");
		put("0028","ST GRAND TOT = 0 BUT QTR VALUE > 0");
		put("0030","OUTGOINGS > ST GRAND TOTAL");
		put("0031","NET PROFIT > GROSS INCOME FOR BRN 1");
		put("0032","SEE = 0 BUT RECEIPT IND IS ON");
		put("0034","INCON HLI 1 AND FULL YR RES IND 2");
		put("0035","DONATION = 0 BUT RECEIPT IND IS ON");
		put("0036","ST TOT = 0 BUT CRRS > 0");
		put("0037","INV JA ELECTION IND MARKED");
		put("0038","INV BRN 1");
		put("0039","BRN 1 = 0 BUT SP GROSS INCOME 1 > 0");
		put("0040","TURNOVER > GROSS INCOME FOR BRN 1");
		put("0041","GROSS PROFIT > TURNOVER FOR BRN 1");
		put("0042","INV SPOUSE HAS INCOME IND MARKED");
		put("0043","ASS PROFIT > GROSS INCOME FOR BRN 1");
		put("0044","INCON HLI-N 1 AND FULL YR RES IND 2");
		put("0045","HAD DEEMED PROFITS IN OFFSHORE FUND");
		put("0046","INV BRN 2");
		put("0047","SP BRN 1 = SP BRN 2");
		put("0048","BRN 2 = 0 BUT SP GROSS INCOME 2 > 0");
		put("0049","TURNOVER > GROSS INCOME FOR BRN 2");
		put("0050","GROSS PROFIT > TURNOVER FOR BRN 2");
		put("0052","ASS PROFIT > GROSS INCOME FOR BRN 2");
		put("0053","INCON MI, HLI AND SHARE FOR PTY 1");
		put("0055","PA NOT ELECT BUT JPT COUNT > 0");
		put("0056","PA NOT ELECT BUT PA DONATION > 0");
		put("0057","PA DONATION = 0  BUT RECEIPT IND ON");
		put("0058","INV SELF PTY SHARE 1");
		put("0059","PA NOT ELECT BUT MORT INT PAID 1 > 0");
		put("0060","NO PT LET BUT MORT INT PAID 1 > 0");
		put("0061","INV SPA IND MARKED");
		put("0062","SHARE = 0 BUT MI PAID > 0 FOR PTY 1");
		put("0063","INCON HLI AND SHARE FOR PROPERTY 1");
		put("0064","NET PROFIT > GROSS INCOME FOR BRN 2");
		put("0065","INV SPOUSE HLI PTY SHARE 1");
		put("0066","INCON HLI AND RE-MORT IND FOR PTY 1");
		put("0067","INCON HLI-N AND SPSE SHARE FOR PTY 1");
		put("0068","INCON HLI-N AND SPSE SHARE FOR PTY 1");
		put("0069","HLI 1 = 0 BUT FULL YEAR RESID IND ON");
		put("0070","INV SELF PTY SHARE 2");
		put("0071","PA NOT ELECT BUT MORT INT PAID 2 > 0");
		put("0072","NO PT LET BUT MORT INT PAID 2 > 0");
		put("0073","BOTH FULL YR RES IND 2 AND 3 ARE ON");
		put("0074","SHARE = 0 BUT MI PAID > 0 FOR PTY 2");
		put("0075","INCON HLI AND SHARE FOR PROPERTY 2");
		put("0076","INCON HLI 1 AND FULL YR RES IND 3");
		put("0077","INCON HLI 2 AND FULL YR RES IND 1");
		put("0078","INV SPOUSE HLI PTY SHARE 2");
		put("0079","INCON HLI AND RE-MORT IND FOR PTY 2");
		put("0080","INCON HLI-N AND SPSE SHARE FOR PTY 2");
		put("0081","INCON HLI-N 1 AND FULL YR RES IND 3");
		put("0082","INCON HLI-N 2 AND FULL YR RES IND 1");
		put("0083","HLI 2 = 0 BUT FULL YR RESID IND 2 ON");
		put("0084","BOTH FULL YR RES IND 1 AND 2 ARE ON");
		put("0085","INV SELF PTY SHARE 3");
		put("0086","PA NOT ELECT BUT MORT INT PAID 3 > 0");
		put("0087","NO PT COUNT BUT MORT INT PAID 3 > 0");
		put("0088","M-INT PAID = 0 BUT MI RECEIPT IND ON");
		put("0089","PT SHARE 3 = 0 BUT INT PAID 3 > 0");
		put("0090","INCON HLI AND SHARE FOR PROPERTY 3");
		put("0091","NO HLI CLAIM BUT HLI RECEIPT IND ON");
		put("0092","INCON HLI 3 & FULL YR RES IND 1 OR 2");
		put("0093","INV SPOUSE HLI PTY SHARE 3");
		put("0094","INCON HLI AND RE-MORT IND FOR PTY 3");
		put("0095","INCON HLI-N AND SPSE SHARE FOR PTY 3");
		put("0096","HLI-N = 0 BUT HLI-N RECEIPT IND ON");
		put("0097","INCON HLI-N 3 & FULL YR RES IND 1/2");
		put("0098","HLI 3 = 0 BUT FULL YR RESID IND 3 ON");
		put("0099","BOTH FULL YR RES IND 1 AND 3 ARE ON");
		put("0101","INVALID DATE OF BIRTH FOR DC/DBS 1");
		put("0102","INCON DOB AND RELATION FOR DC/DBS 1");
		put("0103","INCON DOB AND AGE IND FOR DC/DBS 1");
		put("0104","INCON DDA, DOB & RELATION OF DC/DBS1");
		put("0105","INVALID DATE OF BIRTH FOR DC/DBS 2");
		put("0106","INCON DOB AND RELATION FOR DC/DBS 2");
		put("0107","INCON DOB AND AGE IND FOR DC/DBS 2");
		put("0108","INCON DDA, DOB & RELATION OF DC/DBS2");
		put("0109","INVALID DATE OF BIRTH FOR DC/DBS 3");
		put("0110","INCON DOB AND RELATION FOR DC/DBS 3");
		put("0111","INCON DOB AND AGE IND FOR DC/DBS 3");
		put("0112","INCON DDA, DOB & RELATION OF DC/DBS3");
		put("0113","INV PARENT I/C NO.1 FOR DBSA");
		put("0114","INCON DBSA CLAIM & PARENT I/C NO 1");
		put("0115","PARENT I/C NO.1 = SELF PRN");
		put("0116","PARENT I/C NO.1 = SPOUSE PRN");
		put("0117","INV PARENT I/C NO.2 FOR DBSA");
		put("0118","INCON DBSA CLAIM & PARENT I/C NO 2");
		put("0119","PARENT I/C NO.2 = SELF PRN");
		put("0120","PARENT I/C NO.2 = SPOUSE PRN");
		put("0121","PARENT I/C NO.1 = PARENT I/C NO.2");
		put("0122","INCON SPA IND AND SPOUSE PRN[removed-CTC1031]");
		put("0123","INCON SPA IND AND CA CLAIM");
		put("0124","INVALID I/C NO. FOR DP/DG 1");
		put("0125","DP/DG I/C NO.1 = SELF PRN");
		put("0126","DP/DG I/C NO.1 = SPOUSE PRN");
		put("0127","INVALID DATE OF BIRTH FOR DP/DG 1");
		put("0128","INCON DOB AND I/C NO. FOR DP/DG 1");
		put("0129","INCON DOB AND RELATION FOR DP/DG 1");
		put("0130","INCON RES IND & RELATION FOR DP/DG 1");
		put("0131","INCON CON IND & RELATION FOR DP/DG 1");
		put("0132","INCON ERCE AND RELATION FOR DP/DG 1");
		put("0133","NO ERCE OR DP/DGA CLAIM FOR DP/DG 1");
		put("0135","INCON DDA AND RELATION FOR DP/DG 1");
		put("0136","INVALID I/C NO. FOR DP/DG 2");
		put("0137","DP/DG I/C NO.2 = SELF PRN");
		put("0138","DP/DG I/C NO.2 = SPOUSE PRN");
		put("0139","DP/DG I/C NO.1 = DP/DG I/C NO.2");
		put("0140","INVALID DATE OF BIRTH FOR DP/DG 2");
		put("0141","INCON DOB AND I/C NO. FOR DP/DG 2");
		put("0142","INCON DOB AND RELATION FOR DP/DG 2");
		put("0143","INCON RES IND & RELATION FOR DP/DG 2");
		put("0144","INCON CON IND & RELATION FOR DP/DG 2");
		put("0145","INCON ERCE AND RELATION FOR DP/DG 2");
		put("0146","NO ERCE OR DP/DGA CLAIM FOR DP/DG 2");
		put("0148","INCON DDA AND RELATION FOR DP/DG 2");
		put("0149","INVALID I/C NO. FOR DP/DG 3");
		put("0150","DP/DG I/C NO.3 = SELF PRN");
		put("0151","DP/DG I/C NO.3 = SPOUSE PRN");
		put("0152","DP/DG I/C NO.1 = DP/DG I/C NO.3");
		put("0153","DP/DG I/C NO.2 = DP/DG I/C NO.3");
		put("0154","INVALID DATE OF BIRTH FOR DP/DG 3");
		put("0155","INCON DOB AND I/C NO. FOR DP/DG 3");
		put("0156","INCON DOB AND RELATION FOR DP/DG 3");
		put("0157","INCON RES IND & RELATION FOR DP/DG 3");
		put("0158","INCON CON IND & RELATION FOR DP/DG 3");
		put("0159","INCON ERCE AND RELATION FOR DP/DG 3");
		put("0160","NO ERCE OR DP/DGA CLAIM FOR DP/DG 3");
		put("0162","ERCE NOT CLAIM BUT RECEIPT IND ON");
		put("0163","INCON DDA AND RELATION FOR DP/DG 3");
		put("0165","INVALID IND OF GROSS LOSS FOR BRN 1");
		put("0169","INV TOT SOLE OWN PROPERTIES COUNT");
		put("0175","INV OVERSEAS INCOME IND MARKED");
		put("0176","INV TAX BORNE IND MARKED");
		put("0180","INVALID GROSS LOSS FOR BRN 1");
		put("0181","INVALID IND OF NET LOSS FOR BRN 1");
		put("0183","INVALID NET LOSS FOR BRN 1");
		put("0184","INV IND OF ADJUSTED LOSSES FOR BRN 1");
		put("0186","INVALID ADJUSTED LOSSES FOR BRN 1");
		put("0191","INVALID IND OF GROSS LOSS FOR BRN 2");
		put("0193","INVALID GROSS LOSS FOR BRN 2");
		put("0194","INVALID IND OF NET LOSS FOR BRN 2");
		put("0196","INVALID NET LOSS FOR BRN 2");
		put("0197","INV IND OF ADJUSTED LOSSES FOR BRN 2");
		put("0199","INVALID ADJUSTED LOSSES FOR BRN 2");
		put("0202","INV PA ELECTION MARKED");
		put("0205","INV RE-MORTGAGE LOAN IND 1 MARKED");
		put("0208","INV HLI-N IND 1 MARKED");
		put("0210","INV FULL YEAR RESID IND 1 MARKED");
		put("0211","INV RE-MORTGAGE LOAN IND 2 MARKED");
		put("0214","INV HLI-N IND 2 MARKED");
		put("0216","INV FULL YEAR RESID IND 2 MARKED");
		put("0217","INV RE-MORTGAGE LOAN IND 3 MARKED");
		put("0220","INV HLI-N IND 3 MARKED");
		put("0222","INV FULL YEAR RESID IND 3 MARKED");
		put("0223","INV SPSE NO INCOME IND MARKED");
		put("0224","INV SPSE LIVE APART IND MARKED");
		put("0225","INV SPSE DDA CLAIM MARKED");
		put("0226","INV DC/DBSA RELATION 1");
		put("0227","INV DC/DBSA RELATION 2");
		put("0228","INV DC/DBSA RELATION 3");
		put("0229","INVALID AGE INDICATOR FOR DC/DBS 1");
		put("0230","INVALID AGE INDICATOR FOR DC/DBS 2");
		put("0231","INVALID AGE INDICATOR FOR DC/DBS 3");
		put("0232","INVALID DDA INDICATOR FOR DC/DBS 1");
		put("0233","INVALID DDA INDICATOR FOR DC/DBS 2");
		put("0234","INVALID DDA INDICATOR FOR DC/DBS 3");
		put("0235","INVALID RELATIONSHIP FOR DP/DG 1");
		put("0236","INVALID RELATIONSHIP FOR DP/DG 2");
		put("0237","INVALID RELATIONSHIP FOR DP/DG 3");
		put("0238","INVALID RESIDED-WITH IND FOR DP/DG 1");
		put("0239","INVALID RESIDED-WITH IND FOR DP/DG 2");
		put("0240","INVALID RESIDED-WITH IND FOR DP/DG 3");
		put("0241","INVALID CONTRIBUTION IND FOR DP/DG 1");
		put("0242","INVALID CONTRIBUTION IND FOR DP/DG 2");
		put("0243","INVALID CONTRIBUTION IND FOR DP/DG 3");
		put("0247","INVALID DDA INDICATOR FOR DP/DG 1");
		put("0248","INVALID DDA INDICATOR FOR DP/DG 2");
		put("0249","INVALID DDA INDICATOR FOR DP/DG 3");
		put("0250","INCON HLI 2 AND FULL YR RES IND 3");
		put("0251","INCON HLI-N 2 AND FULL YR RES IND 3");
		put("0252","INCON HLI-N IND, SHARE & AMT OF PTY1");
		put("0253","INCON MI, HLI AND SHARE FOR PTY 2");
		put("0254","INCON HLI-N AND SPSE SHARE FOR PTY 2");
		put("0255","INCON HLI-N IND, SHARE & AMT OF PTY2");
		put("0256","INCON MI, HLI AND SHARE FOR PTY 3");
		put("0257","INCON HLI-N AND SPSE SHARE FOR PTY 3");
		put("0258","INCON HLI-N IND, SHARE & AMT OF PTY3");
		put("0259","INVALID BATCH DATE ");
		put("0260","INVALID INPUT SECTION");
		put("0261","INVALID INPUT BATCH YEAR");
		put("0262","INVALID ASSR NOTE 1");
		put("0263","INVALID ASSR NOTE 2");
		put("0264","INV DEEMED PROFITS IND MARKED");
		put("0265","INVALID ORD-RESIDED IND FOR DP/DG 1");
		put("0266","INVALID ORD-RESIDED IND FOR DP/DG 2");
		put("0267","INVALID ORD-RESIDED IND FOR DP/DG 3");
		put("0268","INPUT SP NOTE CODE with 2 BRNs");
		put("0269","F7/F8 is manual input for 2011/12");
		put("0270","Only full exemption claim can be released");
		put("0271","Invalid I/C No. for DP/DG 4");
		put("0272","DP/DG I/C No.4 = Self PRN");
		put("0273","DP/DG I/C No.4 = Spouse PRN");
		put("0274","DP/DG I/C No.1 = DP/DG I/C No.4");
		put("0275","DP/DG I/C No.2 = DP/DG I/C No.4");
		put("0276","DP/DG I/C No.3 = DP/DG I/C No.4");
		put("0277","Invalid Date Of Birth for DP/DG 4");
		put("0278","Incon DOB and I/C No. for DP/DG 4");
		put("0279","Incon DOB and Relation for DP/DG 4");
		put("0280","Incon Res Ind & Relation for DP/DG 4");
		put("0281","Incon Con Ind & Relation for DP/DG 4");
		put("0282","Incon ERCE and Relation for DP/DG 4");
		put("0283","No ERCE or DP/DGA claim for DP/DG 4");
		put("0285","Incon DDA and Relation for DP/DG 4");
		put("0286","Invalid Relationship for DP/DG 4");
		put("0287","Invalid Resided-with Ind for DP/DG 4");
		put("0288","Invalid Contribution Ind for DP/DG 4");
		put("0289","Invalid DDA Indicator for DP/DG 4");
		put("0290","Invalid Ord-Resided Ind For DP/DG 4");
		// MMP-CT022 start
		put("0291","INV SP PROG RATE IND-SP1");
		put("0292","INV SP PROG RATE IND-SP2");
		put("0293","INCON SP PROG RATE IND FOR SP1 & SP2");
		// MMP-CT022 end
//		CT050 Start
		put("0294","INVALID VHIS SELF");
		put("0295","INVALID VHIS PRN 1");
		put("0296","VHIS PRN 1 = SELF PRN                "); 
		put("0297","INVALID DATE OF BIRTH FOR VHIS 1     "); 
		put("0300","INVALID VHIS RELATION 1              "); 
		put("0301","VHIS PRN 1 NOT = SPSE PRN            "); 
		put("0302","VHIS PRN 1 MUST NOT BLANK            "); 
		put("0303","INCON VHIS PRN 1 & VHIS RELATION 1   "); 
		put("0304","INVALID VHIS 18-25 IND 1             "); 
		put("0305","INCON VHIS 18-25 IND 1 & VHIS RELATION 1"); 
		put("0306","INVALID VHIS PARENT PRN 1            "); 
		put("0307","VHIS PARENT PRN 1 SHOULD NOT BE BLANK"); 
		put("0308","VHIS PARENT PRN 1 = VHIS PRN 1       "); 
		put("0309","INVALID VHIS DISABLE IND 1           "); 
		put("0310","INCON VHIS DISABLE IND 1 & VHIS RELATION 1"); 		
		put("0311","INV VHIS CLAIM 1                     "); 
		put("0312","VHIS DOB 1 SHOULD NOT BE BLANK       "); 
		put("0313","VHIS RELATION 1 SHOULD NOT BE BLANK  ");
		put("0314","INVALID VHIS PRN 2                   "); 
		put("0315","VHIS PRN 2 = SELF PRN                "); 
		put("0316","VHIS PRN 1 = VHIS PRN 2              "); 
		put("0317","INVALID DATE OF BIRTH FOR VHIS 2     "); 
		put("0318","INVALID VHIS RELATION 2              "); 
		put("0319","VHIS PRN 2 NOT = SPSE PRN            "); 
		put("0320","VHIS PRN 2 MUST NOT BLANK            "); 
		put("0321","INCON VHIS PRN 2 & VHIS RELATION 2   "); 
		put("0322","INVALID VHIS 18-25 IND 2             "); 
		put("0323","INCON VHIS 18-25 IND 2 & VHIS RELATION 2"); 
		put("0324","INVALID VHIS PARENT PRN 2            "); 
		put("0325","VHIS PARENT PRN 2 SHOULD NOT BE BLANK"); 
		put("0326","VHIS PARENT PRN 2 = VHIS PRN 2       "); 
		put("0327","INVALID VHIS DISABLE 2 IND           "); 
		put("0328","INCON VHIS DISABLE IND 2 & VHIS RELATION 2"); 
//		put("0329","     "); 	
		put("0330","INV VHIS CLAIM 2                     "); 
		put("0331","VHIS DOB 2 SHOULD NOT BE BLANK       "); 
		put("0332","VHIS RELATION 2 SHOULD NOT BE BLANK  "); 
		put("0333","INVALID VHIS PRN 3                   "); 
		put("0334","VHIS PRN 3 = SELF PRN                "); 
		put("0335","VHIS PRN 1 = VHIS PRN 3              "); 
		put("0336","VHIS PRN 2 = VHIS PRN 3              "); 
		put("0337","INVALID DATE OF BIRTH FOR VHIS 3     "); 		
		put("0338","INVALID VHIS RELATION 3              "); 
		put("0339","VHIS PRN 3 NOT = SPSE PRN            "); 
		put("0340","VHIS PRN 3 MUST NOT BLANK            ");
		put("0341","INCON VHIS PRN 3 & VHIS RELATION 3   "); 
		put("0342","INVALID VHIS 18-25 IND 3             "); 
		put("0343","INCON VHIS 18-25 IND 3 & VHIS RELATION 3"); 
		put("0344","INVALID VHIS PARENT PRN 3            "); 
		put("0345","VHIS PARENT PRN 3 SHOULD NOT BE BLANK"); 
		put("0346","VHIS PARENT PRN 3 = VHIS PRN 3       "); 
		put("0347","INVALID VHIS DISABLE 3 IND           "); 
		put("0348","INCON VHIS DISABLE IND 3 & VHIS RELATION 3"); 
//		put("0349","      "); 
		put("0350","INV VHIS CLAIM 3                     "); 
		put("0351","VHIS DOB 3 SHOULD NOT BE BLANK       "); 
		put("0352","VHIS RELATION 3 SHOULD NOT BE BLANK  "); 		
		put("0353","INVALID SP R&D EPF IP EXP 1");
		put("0354","INVALID SP R&D EPF IP EXP 2");
		put("0355","INVALID SEP PA IND");
		put("0356","INCON PA ELECTION");
		put("0357","INCON PA ELECTION AND MS");
		put("0358","INV SP GROSS INCOME 1");
		put("0359","INV SP TURNOVER 1");
		put("0360","SPSE HAS ST INCOME FOR PA");
		put("0361","INV SP GROSS INCOME 2");
		put("0362","INV SP TURNOVER 2");
		put("0363","INVALID PDA IND");
		put("0385","INVALID VHIS PRN 4                   "); 
		put("0386","VHIS PRN 4 = SELF PRN                "); 
		put("0387","VHIS PRN 1 = VHIS PRN 4              "); 
		put("0388","VHIS PRN 2 = VHIS PRN 4              "); 
		put("0389","VHIS PRN 3 = VHIS PRN 4              "); 
		put("0390","INVALID DATE OF BIRTH FOR VHIS 4     "); 		
		put("0391","INVALID VHIS RELATION 4              "); 
		put("0392","VHIS PRN 4 NOT = SPSE PRN            "); 
		put("0393","VHIS PRN 4 MUST NOT BLANK            ");
		put("0394","INCON VHIS PRN 4 & VHIS RELATION 4   "); 
		put("0395","INVALID VHIS 18-25 IND 4             "); 
		put("0396","INCON VHIS 18-25 IND 4 & VHIS RELATION 4"); 
		put("0397","INVALID VHIS PARENT PRN 4            "); 
		put("0398","VHIS PARENT PRN 4 SHOULD NOT BE BLANK"); 
		put("0399","VHIS PARENT PRN 4 = VHIS PRN 4       "); 
		put("0400","INVALID VHIS DISABLE 4 IND           "); 
		put("0401","INCON VHIS DISABLE IND 4 & VHIS RELATION 4"); 
//		put("0402","      "); 
		put("0403","INV VHIS CLAIM 4                     "); 
		put("0404","VHIS DOB 4 SHOULD NOT BE BLANK       "); 
		put("0405","VHIS RELATION 4 SHOULD NOT BE BLANK  "); 
		
		put("0406","INCON ST VHIS PARENT PRN 1 & VHIS RELATION 1");
		put("0407","INCON ST VHIS PARENT PRN 2 & VHIS RELATION 2");
		put("0408","INCON ST VHIS PARENT PRN 3 & VHIS RELATION 3");
		put("0409","INCON ST VHIS PARENT PRN 4 & VHIS RELATION 4"); 
//		CT050 End
		
		put("0410","PA INTENDED NOT ALLOWED");
		// TAAS - CT116 start
		put("0411", "INV QV ASSD IND");
		put("0412", "INV VHIS RECEIPT IND");
		put("0413", "VHIS NOT CLAIM BUT RECEIPT IND ON");
		put("0414", "VHIS 1 UNDER 36 YR OLD FOR DP/DG");
		put("0415", "VHIS 2 UNDER 36 YR OLD FOR DP/DG");
		put("0416", "VHIS 3 UNDER 36 YR OLD FOR DP/DG");
		put("0417", "SPOUSE UNDER VHIS 1 UNDER 16 YR OLD");
		put("0418", "SPOUSE UNDER VHIS 2 UNDER 16 YR OLD");
		put("0419", "SPOUSE UNDER VHIS 3 UNDER 16 YR OLD");
		put("0420", "INCON VHIS DOB 1 AND VHIS 18-25 IND 1");
		put("0421", "INCON VHIS DOB 2 AND VHIS 18-25 IND 2");
		put("0422", "INCON VHIS DOB 3 AND VHIS 18-25 IND 3");
		put("0423", "INV QAP RECEIPT IND");
		put("0424", "QAP NOT CLAIM BUT RECEIPT IND ON");
		put("0425", "INV TVC RECEIPT IND");
		put("0426", "TVC NOT CLAIM BUT RECEIPT IND ON");
		put("0427", "INV TVC");
		put("0428", "INV QAP SELF");
		put("0429", "INV QAP SPSE");
		put("0430", "INCON QAP SPSE CLAIM AND MS");
		put("0431", "INVALID YEAR FOR VHIS/QAP/TVC INPUT");
		put("0432", "RND/EPF EXPENSE CLAIMED 1");
		put("0433", "VHIS 4 UNDER 36 YR OLD FOR DP/DG");
		put("0436", "RND/EPF EXPENSE CLAIMED 2");
		// TAAS - CT116 end
		}
	};
	
	public final HashMap<String, String> k02ErrMsg = new HashMap<String, String>() {
		{
		put("1001","");
		put("1002","INV ASSESSMENT YEAR");
		put("1003","NO FILE/RETURN RECORD");
		put("1004","RETURN NOT MARKED RECEIVED");
		put("1005","RETURN ALREADY ASSESSED");
		put("1006","SUSPEND ASST ALREADY EXIST");
		put("1007","SELF PE RECORD NOT FOUND");
		put("1008","MS STATUS/SPOUSE PRN INCONSISTENT");
		put("1009","POSSIBLE MULTIPLE CA CLAIM");
		put("1010","CA CLAIM > DC RECORD FOR SINGLE TP");
		put("1011","NO DC RECORD IN CURR YR CONTROL");
		put("1012","CA CLAIM > DC RECORD FOR WIDOWED TP");
		put("1013","NO DC RECORD & INPUT DOB < MS DATE");
		put("1014","");
		put("1015","");
		put("1016","AGE OF DC > AGE OF YOUNGEST DC IN DB");
		put("1017","AGE OF DC > AGE OF YOUNGEST DC IN DB");
		put("1018","CA CLAIM-18 COUNT > DB DC-18 COUNT");
		put("1019","CA CLAIM-25 COUNT > DB DC-25 COUNT");
		put("1020","DBSA CLAIM WITHOUT PARENT I/C NO.");
		put("1021","NO PARENT REC FOR INPUT DBSA");
		put("1022","NO DOB RECORD FOR INPUT DBSA");
		put("1023","NO DC RECORD FOR INPUT DBSA");
		put("1024","DBSA CLAIM-18 CNT > DB DBSA-18 CNT");
		put("1025","DBSA CLAIM-25 CNT > DB DBSA-25 CNT");
		put("1026","INCAP DBS CLAIMED > NO. OF INCAP CNT");
		put("1027","DBSA-18 CNT > DB DBSA-18 CNT (SPSE)");
		put("1028","DBSA-25 CNT > DB DBSA-25 CNT (SPSE)");
		put("1029","INCAP DBS CLAIMED > INCAP CNT (SPSE)");
		put("1030","TP SINGLE BUT CLAIM SPOUSE DBSA");
		put("1031","TAXPAYER ALREADY DECEASED");// TAAS - CT116
		}
	};
	
	public final HashMap<String, Integer> k02AuthLevel = new HashMap<String, Integer>() {
		{
		put("1001",0);
		put("1002",0);
		put("1003",0);
		put("1004",0);
		put("1005",0);
		put("1006",0);
		put("1007",0);
		put("1008",0);
		put("1009",0);
		put("1010",0);
		put("1011",0);
		put("1012",0);
		put("1013",0);
		put("1014",0);
		put("1015",0);
		put("1016",0);
		put("1017",0);
		put("1018",0);
		put("1019",0);
		put("1020",0);
		put("1021",0);
		put("1022",0);
		put("1023",0);
		put("1024",0);
		put("1025",0);
		put("1026",0);
		put("1027",0);
		put("1028",0);
		put("1029",0);
		put("1030",0);
		put("1031",0);
		}
	};
	
	public final HashMap<String, String> k03ErrMsg = new HashMap<String, String>() {
		{
		put("2001","TP EMPLOYMENT TYPE = \"C\"");
		put("2002","TP AUTO-ASST IND ON");
		put("2003","ADVANCE RULING IND ON");
		put("2004","TAX CREDIT IND ON");
		put("2005","CODE 2005");
		put("2006","MI 1 > 0 FOR JPT BUT JPT LET = 0");
		put("2007","AV = 0 BUT TOTAL NO OF PTY LET > 0");
		put("2008","PT LARGE INCOME CASE");
		put("2009","POSSIBLE EXCESS DEDUCTION CLAIM(PT)");
		put("2010","CODE 2010");
		put("2011","ENCLOSURE SUBMIT TOGETHER WITH CTR");
		put("2012","ST LARGE INCOME CASE");
		put("2013","INCOME EXEMPTION CLAIM-NON LI");
		put("2014","OVERSEAS INCOME RECEIVED");
		put("2015","TAX BORNE CASE & EMPLOYMENT CEASED");
		put("2016","QV > 0 WITH SHARE OPTION GAIN RECD");
		put("2017","QV > 0 WITH LUMP SUM PAYMENT RECD");
		put("2018","QV EXCEEDS MAX VALUE");
		put("2019","POSSIBLE QV DISCREPANCY CASE");
		put("2020","EXCESS O/E FOR NON-COMMISSION EARNER"); //2020 LEVEL
		put("2021","EXCESSIVE O/E FOR COMMISSION EARNER");
		put("2022","O/E > ALLOWABLE AMT FOR SPECIAL ER");
		put("2023","O/E CLAIM INVOLVES SPECIAL ER");
		put("2024","EXCESSIVE ST CRRS CLAIM");
		put("2025","JA ELECTED BUT SPOUSE PRN IS BLANK");
		put("2026","SP 1 GROSS INC > LIMIT & AAI NOT=A/S");
		put("2027","SP 1 LARGE TURNOVER CASE");
		put("2028","SP 1 GROSS INC > 0 BUT TURNOVER = 0");
		put("2029","SP 1 GROSS LOSS");
		put("2030","SP 1 EXCESS EXP CLAIM (PROFIT)");
		put("2031","SP 1 EXCESS EXP CLAIM (TURNOVER)");
		put("2032","SP 1 GROSS P/L NOT=0 BUT NET P/L=0");
		put("2033","SP 1 LARGE PROFIT CASE");
		put("2034","SP 1 NET P/L NOT=0 BUT ASS P/L=0");
		put("2035","SP1 POSSIBLE EXCESSIVE ADJUSTMENT");
		put("2036","SP 2 GROSS INC > LIMIT & AAI NOT=A/S");
		put("2037","SP 2 GROSS INC > 0 BUT TURNOVER = 0");
		put("2038","SP 2 GROSS LOSS");
		put("2039","SP 2 EXCESS EXP CLAIM (PROFIT)");
		put("2040","SP 2 EXCESS EXP CLAIM (TURNOVER)"); //2040 LEVEL
		put("2041","SP 2 GROSS P/L NOT=0 BUT NET P/L=0");
		put("2042","SP 2 LARGE PROFIT CASE");
		put("2043","SP 2 NET P/L NOT=0 BUT ASS P/L=0");
		put("2044","LARGE INCOME CASE (ALL SOURCES)");
		put("2045","SP 2 POSSIBLE EXCESSIVE ADJUSTMENT");
		put("2046","TOTAL CMPF OR CRRS + CMPF > LIMIT");
		put("2047","SPOUSE INC IND ON BUT NO SPOUSE PRN");
		put("2048","POSSIBLE DOUBLE DON CLAIM (PA = ST)");
		put("2049","HLI/MI 1 RE-MORTGAGE LOAN INVOLVED");
		put("2050","HLI-N 1 IND ON BUT SPSE PRN IS BLANK");
		put("2051","HLI 1 SELF + SPOUSE SHARE > 100");
		put("2052","HLI 1 SELF AMT = SPSE AMT BUT % DIFF");
		put("2053","HLI 1 SELF % = SPSE % BUT AMT DIFF");
		put("2054","HLI/MI 2 RE-MORTGAGE LOAN INVOLVED");
		put("2055","HLI-N 2 IND ON BUT SPSE PRN IS BLANK");
		put("2056","HLI 2 SELF + SPOUSE SHARE > 100");
		put("2057","HLI 2 SELF AMT = SPSE AMT BUT % DIFF");
		put("2058","HLI 2 SELF % = SPSE % BUT AMT DIFF");
		put("2059","HLI/MI 3 RE-MORTGAGE LOAN INVOLVED");
		put("2060","HLI-N 3 IND ON BUT SPSE PRN IS BLANK"); //2060 LEVEL
		put("2061","HLI 3 SELF + SPOUSE SHARE > 100");
		put("2062","HLI 3 SELF AMT = SPSE AMT BUT % DIFF");
		put("2063","HLI 3 SELF % = SPSE % BUT AMT DIFF");
		put("2064","SPSE NO INC IND ON WITH NO SPSE PRN");
		put("2065","SPOUSE WAS LIVING APART");
		put("2066","SPSE DDA CLAIMED BUT SPSE PRN BLANK");
		put("2067","SPSE DDA WITH JA/PA/SPSE INC IND ON");
		put("2068","DOB OF DC/DBS 1 > RTN RECEIVED DATE");
		put("2069","AGE OF DC/DBS 1 > 40 YEARS OLD");
		put("2070","NO DDA CLAIM FOR INCAP DC 1 AGED< 25");
		put("2071","NO DDA CLAIM FOR INCAP DC 1 AGED>=25");
		put("2072","DOB OF DC/DBS 2 > RTN RECEIVED DATE");
		put("2073","AGE OF DC/DBS 2 > 40 YEARS OLD");
		put("2074","NO DDA CLAIM FOR INCAP DC 2 AGED< 25");
		put("2075","NO DDA CLAIM FOR INCAP DC 2 AGED>=25");
		put("2076","T/P CLAIM DBSA FOR OWN & SPSE DBS");
		put("2077","DOB OF DC/DBS 3 > RTN RECEIVED DATE");
		put("2078","AGE OF DC/DBS 3 > 40 YEARS OLD");
		put("2079","NO DDA CLAIM FOR INCAP DC 3 AGED< 25");
		put("2080","NO DDA CLAIM FOR INCAP DC 3 AGED>=25"); //2080 LEVEL
		put("2081","NO SPA CLAIM FOR SINGLE T/P WITH CA");
		put("2082","SPA CLAIMED FOR PART YEAR");
		put("2083","DP/DG 1 > 100 YEARS OLD");
		put("2084","BOTH ERCE & DP/DGA CLAIM FOR DP/DG 1");
		put("2085","DP/DG 2 > 100 YEARS OLD");
		put("2086","BOTH ERCE & DP/DGA CLAIM FOR DP/DG 2");
		put("2087","DP/DG 3 > 100 YEARS OLD");
		put("2088","MORE THAN 2 ERCE CLAIMS");
		put("2089","BOTH ERCE & DP/DGA CLAIM FOR DP/DG 3");
		put("2090","UNSETTLED BACK YEAR OBJECTION(ST)");
		put("2091","SP 2 LARGE TURNOVER CASE");
		put("2092","SP 1 NET PF/LOSS > GROSS PF/LOSS");
		put("2093","SP 2 NET PF/LOSS > GROSS PF/LOSS");
		put("2094","UNSETTLED BACK YEAR OBJECTION(PT)");
		put("2095","UNSETTLED BACK YEAR OBJECTION(SP)");
		put("2096","MI 2 > 0 FOR JPT BUT JPT LET = 0");
		put("2097","MI 3 > 0 FOR JPT BUT JPT LET = 0");
		put("2098","NO DDA CLAIM FOR INCAP DBS 1 < 25");
		put("2099","NO DDA CLAIM FOR INCAP DBS 1 >= 25");
		put("2100","NO DDA CLAIM FOR INCAP DBS 2 < 25"); //2100 LEVEL
		put("2101","NO DDA CLAIM FOR INCAP DBS 2 >= 25");
		put("2102","NO DDA CLAIM FOR INCAP DBS 3 < 25");
		put("2103","NO DDA CLAIM FOR INCAP DBS 3 >= 25");
		put("2104","MI 1 > 0 FOR SPT BUT SPT LET = 0");
		put("2105","MI 2 > 0 FOR SPT BUT SPT LET = 0");
		put("2106","MI 3 > 0 FOR SPT BUT SPT LET = 0");
		put("2107","AP/AL 1=0/BLANK BUT GROSS INCOME > 0");
		put("2108","AP/AL 2=0/BLANK BUT GROSS INCOME > 0");
		put("2109","SP1 ASSESSED LOSS WITH GROSS INC = 0");
		put("2110","SP2 ASSESSED LOSS WITH GROSS INC = 0");
		put("2111","SPS NO INC IND BLANK BUT HLI-N CLAIM");
		put("2112","HLI-N IND 1 ON BUT SPSE HAS INCOME");
		put("2113","HLI-N IND 2 ON BUT SPSE HAS INCOME");
		put("2114","HLI-N IND 3 ON BUT SPSE HAS INCOME");
		put("2115","POSSIBLE EXCESS LUMP SUM PAYMENT");
		put("2116","LARGE SIS/INPUT INCOME DISCREPANCY");
		put("2117","POSSIBLE SIS/INPUT INCOME ERROR");
		put("2118","QUARTERS PROVIDED IS 1 OR 2 ROOM(S)");
		put("2119","MANUAL COMPUTATION OF QV IS REQUIRED");
		put("2120","PA WITH NO SPSE\"S SIGNATURE"); //2120 LEVEL
		put("2121","JA WITH NO SPSE\"S SIGNATURE");
		put("2122","HLI-N IND 1 WITH NO SPSE\"S SIGNATURE");
		put("2123","HLI-N IND 2 WITH NO SPSE\"S SIGNATURE");
		put("2124","HLI-N IND 3 WITH NO SPSE\"S SIGNATURE");
		put("2125","SP 1 SMALL TURNOVER & LARGE ADJ LOSS");
		put("2126","SP 2 SMALL TURNOVER & LARGE ADJ LOSS");
		put("2127","INCOME SUPPLEMENTARY INFORMATION");
		put("2128","HAD DEEMED PROFITS IN OFFSHORE FUND");
		put("2129","INCON HLI 2 AND FULL YR RES IND 1");
		put("2130","INCON HLI-N 2 AND FULL YR RES IND 1");
		put("2131","INCON HLI 1 AND FULL YR RES IND 2");
		put("2132","INCON HLI-N 1 AND FULL YR RES IND 2");
		put("2133","INCOME EXEMPTION CLAIM-LI");
		put("2134","DP/DG 4 > 120 YEARS OLD");
		put("2135","INCON PA ELECTION WITH SELF/SPSE"); //CT050
		put("2136","DEPENDANT FOR VHIS 1 OVER 120 YRS OLD"); //CT050
		put("2137","DEPENDANT FOR VHIS 2 OVER 120 YRS OLD"); //CT050
		put("2138","DEPENDANT FOR VHIS 3 OVER 120 YRS OLD"); //CT050
		put("2139","DEPENDANT FOR VHIS 4 OVER 120 YRS OLD"); //CT050
		
		put("2140","FIRST YR PENSIONER ADJUST PROV AI"); //CT060
		
		put("2141","SPSE PRN FOR VHIS 1 NOT MATCH WITH PE"); // TAAS - CT116
		put("2142","SPSE PRN FOR VHIS 2 NOT MATCH WITH PE"); // TAAS - CT116
		put("2143","SPSE PRN FOR VHIS 3 NOT MATCH WITH PE"); // TAAS - CT116
		put("2144","SPSE PRN FOR VHIS 4 NOT MATCH WITH PE"); // TAAS - CT116
		put("2145","INCON QAP SPSE CLAIM AND MS"); // TAAS - CT116
		
		}
	};
	
	public final HashMap<String, Integer> k03AuthLevel = new HashMap<String, Integer>() {
		{
		put("2001",2);
		put("2002",0);
		put("2003",2);
		put("2004",1);
		put("2005",0);
		put("2006",0);
		put("2007",0);
		put("2008",0);
		put("2009",0);
		put("2010",0);
		put("2011",0);
		put("2012",3);
		put("2013",1);
		put("2014",0);
		put("2015",1);
		put("2016",0);
		put("2017",0);
		put("2018",0);
		put("2019",0);
		put("2020",0); //2020 LEVEL
		put("2021",0);
		put("2022",1);
		put("2023",1);
		put("2024",0);
		put("2025",0);
		put("2026",1);
		put("2027",1);
		put("2028",1);
		put("2029",1);
		put("2030",1);
		put("2031",1);
		put("2032",1);
		put("2033",3);
		put("2034",1);
		put("2035",1);
		put("2036",1);
		put("2037",1);
		put("2038",1);
		put("2039",1);
		put("2040",1); //2040 LEVEL
		put("2041",1);
		put("2042",3);
		put("2043",1);
		put("2044",2);
		put("2045",1);
		put("2046",1);
		put("2047",0);
		put("2048",0);
		put("2049",0);
		put("2050",0);
		put("2051",0);
		put("2052",0);
		put("2053",0);
		put("2054",0);
		put("2055",0);
		put("2056",0);
		put("2057",0);
		put("2058",0);
		put("2059",0);
		put("2060",0); //2060 LEVEL
		put("2061",0);
		put("2062",0);
		put("2063",0);
		put("2064",0);
		put("2065",0);
		put("2066",0);
		put("2067",0);
		put("2068",0);
		put("2069",0);
		put("2070",0);
		put("2071",0);
		put("2072",0);
		put("2073",0);
		put("2074",0);
		put("2075",0);
		put("2076",0);
		put("2077",0);
		put("2078",0);
		put("2079",0);
		put("2080",0); //2080 LEVEL
		put("2081",0);
		put("2082",0);
		put("2083",0);
		put("2084",0);
		put("2085",0);
		put("2086",0);
		put("2087",0);
		put("2088",0);
		put("2089",0);
		put("2090",1);
		put("2091",1);
		put("2092",1);
		put("2093",1);
		put("2094",1);
		put("2095",1);
		put("2096",0);
		put("2097",0);
		put("2098",0);
		put("2099",0);
		put("2100",0); //2100 LEVEL
		put("2101",0);
		put("2102",0);
		put("2103",0);
		put("2104",0);
		put("2105",0);
		put("2106",0);
		put("2107",0);
		put("2108",0);
		put("2109",0);
		put("2110",0);
		put("2111",0);
		put("2112",0);
		put("2113",0);
		put("2114",0);
		put("2115",0);
		put("2116",0);
		put("2117",0);
		put("2118",0);
		put("2119",0);
		put("2120",0); //2020 LEVEL
		put("2121",0);
		put("2122",0);
		put("2123",0);
		put("2124",0);
		put("2125",1);
		put("2126",1);
		put("2127",0);
		put("2128",2);
		put("2129",0);
		put("2130",0);
		put("2131",0);
		put("2132",0);
		put("2133",2);
		put("2134",0);
		put("2135",0); //CT050
		put("2136",0); //CT050
		put("2137",0); //CT050
		put("2138",0); //CT050
		put("2139",0); //CT050
		put("2140",0); //CT060
		put("2141",0);
		put("2142",0);
		put("2143",0);
		put("2144",0);
		put("2145",0);
		}
	};
	
	public String getErrorMsg(String errCode) {
		String errMsg = this.reasonMap.get(errCode);
		if (errMsg != null) {
			return errMsg;
		} else {
			errMsg = this.k02ErrMsg.get(errCode);
			if (errMsg != null) {
				return errMsg;
			} else {
				return this.k03ErrMsg.get(errCode);
			}
		}
	}
	
	public void execute(Ctaaferr ctaaferr) throws Exception{
		List<String> errMsg = new ArrayList<String>();
		List<String> susMsg = new ArrayList<String>();
		int maxAuthLevel = -1;
		String n01J = null;
		String n01K = null;
		
		for (int n01I = 1; n01I <= 10; n01I++) {
			if (ctaaferr.getErrCode().size() >= n01I) {
				String errCode = ctaaferr.getErrCode().get(n01I - 1);
				if (CommonUtils.isStringGtZero(errCode)) {
					if (Integer.parseInt(errCode) >= 1000) {
						n01J = errCode;
						errMsg.add(this.k02ErrMsg.get(n01J));
						if (this.k02AuthLevel.get(n01J) > maxAuthLevel) {
							maxAuthLevel = this.k02AuthLevel.get(n01J);
						}
					} else {
						n01J = errCode;
						errMsg.add(this.reasonMap.get(n01J));
					}
				}
			}
			if (ctaaferr.getSusCode().size() >= n01I) {
				String susCode = ctaaferr.getSusCode().get(n01I - 1);
				if (CommonUtils.isStringGtZero(susCode)) {
					n01K = susCode;
					susMsg.add(this.k03ErrMsg.get(n01K));
					if (this.k03AuthLevel.get(n01K) > maxAuthLevel) {
						maxAuthLevel = this.k03AuthLevel.get(n01K);
					}
				}
			}
		}
		
		ctaaferr.setErrMsg(errMsg);
		ctaaferr.setSusMsg(susMsg);
		ctaaferr.setMaxAuthLevel(maxAuthLevel);
		
	}
	
}
