//Check in version of WAS_PRD,22-10-20,itang:6:6plDI/hEqpqyQ0BFH0lqhMKIpa4YlVlqHLG/VC/tqHo=
//Check in version of WAS_PRD,20-07-18,clchen:5:Bj8BUNR85DXXXJTkB/JJ68KIpa4YlVlqHLG/VC/tqHo=
//Check in version of WAS_PRD,08-12-17,yswong:4:WHARwwnmEsBP0xkiv6yjCcKIpa4YlVlqHLG/VC/tqHo=
//Check in version of WAS_PRD,20-03-17,clchen:3:4/M/ApH2VxBjHjiLzIclA8KIpa4YlVlqHLG/VC/tqHo=
//Check in version of WAS_PRD,04-02-17,bhssham:2:QZRo/6YAUlsxcqC4EKQLLMKIpa4YlVlqHLG/VC/tqHo=
package ird.taas2.pt.common.service.impl;

import ird.taas2.br.dao.BrbpbrinfDao;
import ird.taas2.br.model.Brbpbrinf;
import ird.taas2.common.utils.DateUtils;
import ird.taas2.core.enums.TaasSystem;
import ird.taas2.ct.utils.Irncttd;
import ird.taas2.ct.utils.Irnndbc;
import ird.taas2.ct.utils.model.Irandbc;
import ird.taas2.pe.dao.PepeinfomDao;
import ird.taas2.pe.model.Pepeinfom;
import ird.taas2.pe.utils.Penfoadr;
import ird.taas2.pe.utils.model.PenfoadrBean;
import ird.taas2.pt.common.Ptncolr;
import ird.taas2.pt.common.Ptndecen;
import ird.taas2.pt.common.Ptndedue;
import ird.taas2.pt.common.Ptndesta;
import ird.taas2.pt.common.Ptnfonam;
import ird.taas2.pt.common.Ptnprscl;
import ird.taas2.pt.common.Ptnupcfl;
import ird.taas2.pt.common.Ptnupcof;
import ird.taas2.pt.common.Ptnuppay;
import ird.taas2.pt.common.param.PtnprsclParam;
import ird.taas2.pt.common.param.PtnupcofParam;
import ird.taas2.pt.common.result.PtadedueResult;
import ird.taas2.pt.common.result.PtncolrResult;
import ird.taas2.pt.common.result.PtndecenResult;
import ird.taas2.pt.common.result.PtndestaResult;
import ird.taas2.pt.common.result.PtnfonamResult;
import ird.taas2.pt.common.result.PtnupcofResult;
import ird.taas2.pt.common.result.PtnuppayResult;
import ird.taas2.pt.common.service.Ptn624cOnline;
import ird.taas2.pt.common.service.Ptn624uOnline;
import ird.taas2.pt.common.service.result.Ptn624cResult;
import ird.taas2.pt.dao.PtchchrgaDao;
import ird.taas2.pt.dao.PtchdcolfDao;
import ird.taas2.pt.dao.PtchkaoffDao;
import ird.taas2.pt.dao.PtchrefunDao;
import ird.taas2.pt.dao.Ptcncon60Dao;	// TAAS-PT-085
import ird.taas2.pt.dao.Ptcncon61Dao;
import ird.taas2.pt.dao.PtptassmtDao;
import ird.taas2.pt.dao.PtptoshipDao;
import ird.taas2.pt.dao.PtptownerDao;
import ird.taas2.pt.dao.UCommonDao;
import ird.taas2.pt.exception.PTException;
import ird.taas2.pt.model.Ptchchrga;
import ird.taas2.pt.model.Ptchdcolf;
import ird.taas2.pt.model.Ptchhflup;
import ird.taas2.pt.model.Ptchhsttm;
import ird.taas2.pt.model.Ptchkaoff;
import ird.taas2.pt.model.Ptchrchqe;
import ird.taas2.pt.model.Ptchrefun;
import ird.taas2.pt.model.Ptchrsoff;
import ird.taas2.pt.model.Ptcncon60;	// TAAS-PT-085
import ird.taas2.pt.model.Ptcncon61;
import ird.taas2.pt.model.Ptflmlhis;
import ird.taas2.pt.model.Ptpoacmvt;
import ird.taas2.pt.model.Ptpokchmo;
import ird.taas2.pt.model.Ptptassmt;
import ird.taas2.pt.model.Ptptoship;
import ird.taas2.pt.model.Ptptowner;
import ird.taas2.pt.model.constmaint.Ptchacmv1DetailJsonModel;
import ird.taas2.pt.model.constmaint.Ptchacmv4DetailJsonModel;
import ird.taas2.pt.model.constmaint.Ptchacmv5DetailJsonModel;
import ird.taas2.pt.model.constmaint.Ptchacmv7DetailJsonModel;
import ird.taas2.pt.model.constmaint.PtfcolmtTc5624DetailsJsonModel;
import ird.taas2.pt.model.constmaint.PtfoprnpTc5624DetailsJsonModel;
import ird.taas2.pt.model.constmaint.PtfprrnlJsonModel;
import ird.taas2.pt.model.constmaint.PtfpscrnJsonModel;
import ird.taas2.pt.model.constmaint.PtfsoffrJsonModel;
import ird.taas2.pt.model.constmaint.PtfsoravJsonModel;
import ird.taas2.pt.model.constmaint.SetoffChargeModel;
import ird.taas2.pt.model.tc.tc5624.TC5624;
import ird.taas2.pt.model.tc.tc5624.PTM6242;
import ird.taas2.pt.model.tc.tc5624.PTM6243;
import ird.taas2.pt.model.tc.tc5624.PTM6244;
import ird.taas2.pt.model.tc.tc5624.PTM6244Record;
import ird.taas2.pt.model.tc.tc5624.PTM6245;
import ird.taas2.pt.model.tc.tc5624.PTM6246;
import ird.taas2.pt.model.tc.tc5624.PTM6249;
import ird.taas2.pt.model.tc.tc5624.Ptn624uInput;
import ird.taas2.pt.utils.PtUtils;
import ird.taas2.report.enums.RptFileExtension;
import ird.taas2.report.service.IrdReportService;
import ird.taas2.utils.EpsReport;
import ird.taas2.utils.JsonUtil;
import ird.taas2.utils.SystemConfig;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Ptn624uImpl implements Ptn624uOnline {

	@Autowired
	private Irnndbc irnndbc;
	@Autowired
	private Irncttd irncttd;
	@Autowired
	private Ptncolr ptncolr;
	@Autowired
	private Ptnfonam ptnfonam;
	@Autowired
	private Ptndesta ptndesta;
	@Autowired
	private Ptnupcof ptnupcof;
	@Autowired
	private Ptnupcfl ptnupcfl;
	@Autowired
	private Ptnuppay ptnuppay;
	@Autowired
	private Ptnprscl ptnprscl;
	@Autowired private Ptndedue ptndedue;
	@Autowired
	private Ptn624cOnline ptn624c;
	@Autowired
	private IrdReportService irdReportService;
	@Autowired
	private UCommonDao uCommonDao;
	@Autowired
	private BrbpbrinfDao brbpbrinfDao;
	@Autowired
	private PepeinfomDao pepeinfomDao;
	@Autowired
	private PtptoshipDao ptptoshipDao;
	@Autowired
	private PtptownerDao ptptownerDao;
	@Autowired							// TAAS-PT-085
	private Ptcncon60Dao ptcncon60Dao;	// TAAS-PT-085
	@Autowired
	private Ptcncon61Dao ptcncon61Dao;
	@Autowired
	private PtchkaoffDao ptchkaoffDao;
	@Autowired
	private PtchchrgaDao ptchchrgaDao;
	@Autowired
	private PtchrefunDao ptchrefunDao;
	@Autowired
	private PtptassmtDao ptptassmtDao;
	@Autowired 
	private PtchdcolfDao ptchdcolfDao;
	@Autowired
	private SystemConfig systemConfig;

	private static Logger logger = Logger.getLogger(Ptn624uImpl.class);

	private long millSec = 0;

	/********************************************************************
	 * Common Functions
	 *******************************************************************/
	private Ptn624uInput getValidAndUnprotectedFieldsForInternalProcess(PTM6242 ptm6242, PTM6243 ptm6243, PTM6244 ptm6244, PTM6246 ptm6246, PTM6249 ptm6249)
			throws Exception {

		List<PTM6244Record> setOffChrgList = new ArrayList<PTM6244Record>();

		// Get the Nominated Set-Off Detail Information
		if (StringUtils.equals("Y", ptm6243.getSetOff())) {
			if (ptm6244.getRecordList() != null && ptm6244.getRecordList().size() > 0) {
				for (PTM6244Record inputSetOffChrg : ptm6244.getRecordList()) {
					// Get the Valid Set-Off Charge Records
					if (StringUtils.isNotBlank(inputSetOffChrg.getDbChrgInd())) {
						PTM6244Record setOffChrg = (PTM6244Record) BeanUtils.cloneBean(inputSetOffChrg);
						if (StringUtils.equalsIgnoreCase("Y", inputSetOffChrg.getDbChrgInd())) {
							setOffChrg.setType(StringUtils.EMPTY);
							setOffChrg.setChargeNo(StringUtils.EMPTY);
							setOffChrg.setBalancePayable(StringUtils.EMPTY);
							//PT021 <start>
							PtndecenResult ptadecen = Ptndecen.execute("0101" + setOffChrg.getAssYr());
							if (ptadecen != null && StringUtils.equalsIgnoreCase(PtndecenResult.NORMAL, ptadecen.getReturnCode())) {
								Ptchchrga chrgaDb = ptchchrgaDao.getRecordByAssYrChrgNum(new Short(ptadecen.getOutputYr()), Integer.valueOf(setOffChrg.getSerialNo()));
								setOffChrg.setAssType(chrgaDb != null ? chrgaDb.getAssType() : StringUtils.EMPTY);
							}
							//PT021 <end>
						} else {
							setOffChrg.setTaxCode(StringUtils.EMPTY);
							setOffChrg.setSerialNo(StringUtils.EMPTY);
							setOffChrg.setAssYr(StringUtils.EMPTY);
							setOffChrg.setCheckDigit(StringUtils.EMPTY);
						}
						setOffChrgList.add(setOffChrg);
					}
				}
			}
		}

		boolean isChiAddr = StringUtils.equals("C", ptm6246.getMailAddrOption());
		boolean isEngAddr = StringUtils.equals("E", ptm6246.getMailAddrOption());

		List<String> engAddrList = new ArrayList<String>();
		List<String> chiAddrList = new ArrayList<String>();
		if (isChiAddr && StringUtils.isNotBlank(ptm6246.getChiMailAddrLine1()))
			chiAddrList.add(PtUtils.removeChiLeadingSpace(ptm6246.getChiMailAddrLine1()));
		if (isChiAddr && StringUtils.isNotBlank(ptm6246.getChiMailAddrLine2()))
			chiAddrList.add(PtUtils.removeChiLeadingSpace(ptm6246.getChiMailAddrLine2()));
		if (isChiAddr && StringUtils.isNotBlank(ptm6246.getChiMailAddrLine3()))
			chiAddrList.add(PtUtils.removeChiLeadingSpace(ptm6246.getChiMailAddrLine3()));

		if (isEngAddr && StringUtils.isNotBlank(ptm6246.getEngMailAddrLine1()))
			engAddrList.add(PtUtils.removeEngLeadingSpace(ptm6246.getEngMailAddrLine1()));
		if (isEngAddr && StringUtils.isNotBlank(ptm6246.getEngMailAddrLine2()))
			engAddrList.add(PtUtils.removeEngLeadingSpace(ptm6246.getEngMailAddrLine2()));
		if (isEngAddr && StringUtils.isNotBlank(ptm6246.getEngMailAddrLine3()))
			engAddrList.add(PtUtils.removeEngLeadingSpace(ptm6246.getEngMailAddrLine3()));
		if (isEngAddr && StringUtils.isNotBlank(ptm6246.getEngMailAddrLine4()))
			engAddrList.add(PtUtils.removeEngLeadingSpace(ptm6246.getEngMailAddrLine4()));
		if (isEngAddr && StringUtils.isNotBlank(ptm6246.getEngMailAddrLine5()))
			engAddrList.add(PtUtils.removeEngLeadingSpace(ptm6246.getEngMailAddrLine5()));

		Ptn624uInput input = new Ptn624uInput();
		input.setSetOffChrgList(setOffChrgList);

		for (int index = 0; index < chiAddrList.size(); index++) {
			input.getClass().getMethod("setAddrChiLine" + (index + 1), String.class).invoke(input, chiAddrList.get(index));
		}
		for (int index = 0; index < engAddrList.size(); index++) {
			input.getClass().getMethod("setAddrEngLine" + (index + 1), String.class).invoke(input, engAddrList.get(index));
		}

		for (int index = chiAddrList.size(); index < 3; index++) {
			input.getClass().getMethod("setAddrChiLine" + (index + 1), String.class).invoke(input, "");
		}
		for (int index = engAddrList.size(); index < 5; index++) {
			input.getClass().getMethod("setAddrEngLine" + (index + 1), String.class).invoke(input, "");
		}

//		input.setFinalScPayable5(ptm6242.getFinalScPayable5());
//		input.setFinalScPayable10(ptm6242.getFinalScPayable10());
		input.setFinalScPayable5(ptm6243.getFinalScPayable5());
		input.setFinalScPayable10(ptm6243.getFinalScPayable10());
		input.setCancelLetter(ptm6243.getCancelLetter());
		input.setChqeIssOpt(ptm6243.getRefundNotice());
		input.setChqeIssDate(ptm6243.getRefundIssueDate());
		input.setNominatedChrgSetOffInd(ptm6243.getSetOff());
		input.setAddrType(ptm6246.getMailAddrOption());
		input.setAreaCode(isEngAddr || isChiAddr ? ptm6246.getAreaCode() : "");
		input.setSysDate(ptm6249.getSysDate());
		input.setUid(ptm6249.getUid());
		input.setUserSection(ptm6249.getUserSection());
		
		return input;
	}

	//
	private PenfoadrBean retrieveFormatMailingAddressBasedOnInputValue(Ptn624uInput input) {
		// 2.2.1
		// Retrieve the formatted Address
		boolean hasChiAddr = StringUtils.equals(Ptn624uInput.ADDR_TYPE_NEW_CHI, input.getAddrType()) && StringUtils.isNotBlank(input.getAddrChiLine1());
		boolean hasEngAddr = StringUtils.equals(Ptn624uInput.ADDR_TYPE_NEW_ENG, input.getAddrType()) && StringUtils.isNotBlank(input.getAddrEngLine1());
		String format = "2";
		String areaCode = input.getAreaCode();
		String source = "5";
		String addrFlat = " ";
		String addrBlk = " ";
		String addrFlr = " ";
		String addrLangInd = hasEngAddr ? "E" : (hasChiAddr ? "C" : "");
		String addrLine1 = hasEngAddr ? input.getAddrEngLine1() : (hasChiAddr ? input.getAddrChiLine1() : "");
		String addrLine2 = hasEngAddr ? input.getAddrEngLine2() : (hasChiAddr ? input.getAddrChiLine2() : "");
		String addrLine3 = hasEngAddr ? input.getAddrEngLine3() : (hasChiAddr ? input.getAddrChiLine3() : "");
		String addrLine4 = hasEngAddr ? input.getAddrEngLine4() : "";
		String addrLine5 = hasEngAddr ? input.getAddrEngLine5() : "";
		String coLangInd = " ";
		String coDetailsLine1 = "";
		String coDetailsLine2 = "";
		String coDetailsLine3 = "";
		PenfoadrBean foadrRslt = Penfoadr.execute(format, areaCode, source, addrLangInd, addrFlat, addrBlk, addrFlr, addrLine1, addrLine2, addrLine3,
				addrLine4, addrLine5, coLangInd, coDetailsLine1, coDetailsLine2, coDetailsLine3);
		return foadrRslt;
	}

	private PtnfonamResult retrieveFormatOwnerNameBaseOnInputValue(Ptn624cResult pta624c) {
		// Ptn624cResult.Ptn624OwnerDetail ownerDtl = pta624c.getOwnerDtl();
		int numOwner = pta624c.getNumOwner();
		char nameType1 = pta624c.getNameType1();
		char nameInd1 = pta624c.getNameInd1();
		char nameType2 = pta624c.getNameType2();
		char nameInd2 = pta624c.getNameInd2();
		PtnfonamResult fNameRslt = ptnfonam.execute(numOwner, nameType1, nameInd1, pta624c.getName1(), nameType2, nameInd2, pta624c.getName2(),
				pta624c.getNameChi());
		return fNameRslt;
	}

	private BigDecimal retrieveSumOfSetoffAmount(Ptn624uInput input) {
		BigDecimal sumSetOffAmt = BigDecimal.ZERO;
		if (StringUtils.equals(Ptn624uInput.NOMINATED_CHRG_SET_OFF_YES, input.getNominatedChrgSetOffInd()) && input.getSetOffChrgList() != null) {
			for (PTM6244Record setOffChrg : input.getSetOffChrgList()) {
				if (StringUtils.isNotBlank(setOffChrg.getSetOffAmt()))
					sumSetOffAmt = sumSetOffAmt.add(new BigDecimal(setOffChrg.getSetOffAmt()));
			}
			// input.retrieveTotalSetoffChargeAmt();
		}
		return sumSetOffAmt;
	}

	private PtfoprnpTc5624DetailsJsonModel.Tc5624OwnerInfo retrieveOwnerInfoForReport(String ownerId) throws Exception {
		PtfoprnpTc5624DetailsJsonModel.Tc5624OwnerInfo owner = null;
		if (StringUtils.isNotBlank(ownerId)) {
			owner = new PtfoprnpTc5624DetailsJsonModel.Tc5624OwnerInfo();
			if (StringUtils.isNumeric(ownerId)) {
				Brbpbrinf brinfDb = brbpbrinfDao.selectByPrimaryKey(new Integer(ownerId));
				if (brinfDb != null) {
					owner.setTc5624OwnerName(brinfDb.getNameLine1());
					owner.setTc5624OwnerNameChi(brinfDb.getNameChi());
					owner.setTc5624DcInd("0");
				}
			} else {
				Pepeinfom infomDb = pepeinfomDao.getPepeinfomByPrn(ownerId);
				if (infomDb != null) {
					owner.setTc5624OwnerName(infomDb.getName());
					owner.setTc5624OwnerNameChi(infomDb.getNameChi());
					owner.setTc5624DcInd(infomDb.getDeceaseInd());
				}
			}
		}
		return owner;
	}

	/********************************************************************
	 * DB Operation (Insert/Update/Delete)
	 *******************************************************************/
	@Override
	public void execute(TC5624 ptm6241, PTM6242 ptm6242, PTM6243 ptm6243, PTM6244 ptm6244, PTM6245 ptm6245, PTM6246 ptm6246, PTM6249 ptm6249,
			Ptn624cResult pta624c) throws Exception {

		String chargNo = ptm6241.getSerialNo();
		String inputAssYr = ptm6241.getAssYr();
		long createTs = systemConfig.getSystemTimestamp().getTime();
		// all input value
		Ptn624uInput finalInput = getValidAndUnprotectedFieldsForInternalProcess(ptm6242, ptm6243, ptm6244, ptm6246, ptm6249);

		// Add DB validation repeat check - Added by Travis Li 20Jul2015 <START>
		Ptn624cResult dbVal = ptn624c.execute(Integer.parseInt(chargNo), Short.parseShort(inputAssYr));
		this.repeatDbValidation(dbVal.getStatus(), ptm6243);
		// Add DB validation repeat check - Added by Travis Li 20Jul2015 <END>

		if (!dbVal.equals(pta624c)) {
			throw new PTException(new String[] { "hiddenErrorPtm6241" }, "message.3999");
		}

		validateDatabaseForNominatedChargeBeforeUpdate(finalInput, pta624c);

//		ptm6244.setRecordList(finalInput.getSetOffChrgList());
		ptm6249.setNoOfCharges(String.valueOf(finalInput.getSetOffChrgList().size()));
		PtndecenResult cntyRslt = Ptndecen.execute("0101" + inputAssYr);
		String pun = pta624c.getPun();
		Short oc = pta624c.getOc();
		Short assYr = Short.parseShort(cntyRslt.getOutputYr());
		Ptchchrga chrgaDb = ptchchrgaDao.getRecordByAssYrChrgNum(assYr, Integer.valueOf(chargNo));

		BigDecimal newChrgeBalance = chrgaDb.getBalance().subtract(new BigDecimal(ptm6243.getDischarged5()))
				.subtract(new BigDecimal(ptm6243.getDischarged10()));
		// 2.2.1.1.1
		if (new BigDecimal(ptm6243.getDischarged5()).compareTo(BigDecimal.ZERO) > 0
				|| new BigDecimal(ptm6243.getDischarged10()).compareTo(BigDecimal.ZERO) > 0) {

			PtndestaResult destaRslt = ptndesta.execute(assYr, Integer.valueOf(chargNo), "P", pta624c.getStatus(), newChrgeBalance.floatValue());
			if (destaRslt.getReturnCode() != 0) {
				logger.debug("destaRslt(),getReturnCode = " + destaRslt.getReturnCode());
				throw new PTException(new String[] { "hiddenErrorPtm6246" }, "message.10053", new String[] { destaRslt == null ? "" : destaRslt.getReturnCode()
						+ "" });
			}

			// Update Charge Details (PTCHCHRGA)
			Ptchchrga chrgaNew = (Ptchchrga) BeanUtils.cloneBean(chrgaDb);
			String[] updateList = new String[] { "assYr", "chrgNum", "status", "balance", "lastUpdDate", "a_5pcDo", "a_10pcDo" };
			chrgaNew.setStatus(destaRslt.getNewChrgStatus());
			chrgaNew.setBalance(newChrgeBalance);
			chrgaNew.setLastUpdDate(ptm6249.getSysDate());
			chrgaNew.setA_5pcDo(chrgaDb.getA_5pcDo().add(new BigDecimal(ptm6243.getDischarged5())));
			chrgaNew.setA_10pcDo(chrgaDb.getA_10pcDo().add(new BigDecimal(ptm6243.getDischarged10())));
			chrgaDb.setUpdateList(updateList);
			chrgaNew.setUpdateList(updateList);
			int updCnt = uCommonDao.doUpdate(chrgaDb, chrgaNew);
			if (updCnt <= 0) {
				throw new PTException(new String[] { "hiddenErrorPtm6241" }, "message.3999");
			}
			logger.debug("update Collection File");
			// update Collection File
			if ((chrgaDb.getDefStatus() != null && !" ".equals(chrgaDb.getDefStatus())) || StringUtils.equalsIgnoreCase(pta624c.getStatus(), "G")) {
				PtnupcofParam param = new PtnupcofParam();
				param.setPun(pta624c.getPun());
				param.setOshipCode(pta624c.getOc());
				param.setOldChrgStatus(chrgaDb.getStatus());
				param.setNewChrgStatus(destaRslt.getNewChrgStatus());
				param.setOldChrgBalance(chrgaDb.getBalance());
				param.setNewChrgBalance(chrgaNew.getBalance());
				param.setSysdate(new Timestamp(systemConfig.getSystemTimestamp().getTime()));
				PtnupcofResult upcoffResult = ptnupcof.execute(param);
				if (upcoffResult.getReturnCode() != 0) {
					logger.debug("upcoffResult().getReturnCode = " + upcoffResult.getReturnCode());
					throw new PTException(new String[] { "hiddenErrorPtm6246" }, "message.10056", new String[] { upcoffResult.getReturnCode() + "" });
				}
			}
			logger.debug("Create PT Charge Follow-up History (PTCHHFLUP)");
			// Create PT Charge Follow-up History (PTCHHFLUP)
			if (StringUtils.equalsIgnoreCase(destaRslt.getNewChrgStatus(), "A") || StringUtils.equalsIgnoreCase(destaRslt.getNewChrgStatus(), "Q")) {
				Ptchhflup ptchhflup = new Ptchhflup();
				ptchhflup.setPun(pta624c.getPun());
				ptchhflup.setOshipCode(pta624c.getOc());
				ptchhflup.setAssYr(assYr);
				ptchhflup.setChrgNum(Integer.valueOf(chargNo));
				ptchhflup.setCreateTs(new Timestamp(createTs + (++millSec)));
				ptchhflup.setCreateDate(finalInput.getSysDate());
				String type = "";
				if (StringUtils.equalsIgnoreCase(destaRslt.getNewChrgStatus(), "A")) {
					type = "33";
				} else if (StringUtils.equalsIgnoreCase(destaRslt.getNewChrgStatus(), "Q")) {
					type = "34";
				}
				ptchhflup.setType(type);
				ptchhflup.setStatus(pta624c.getStatus());
				ptchhflup.setEnfDate(null);
				ptchhflup.setDefStatus(" ");
				ptchhflup.setSupp5pcscInd(" ");
				ptchhflup.setSuppWarnInd(" ");
				ptchhflup.setSupp10pcscInd(" ");
				ptchhflup.setGuaranteeInd(" ");
				ptchhflup.setPodInd(" ");
				ptchhflup.setRewriteInd(" ");
				uCommonDao.doInsert(ptchhflup);
			}
		}
		logger.debug("//2.2.1.1.2");
		// 2.2.1.1.2
		BigDecimal toBeRefunded5 = new BigDecimal(ptm6243.getRefunded5());
		BigDecimal toBeRefunded10 = new BigDecimal(ptm6243.getRefunded10());
		BigDecimal toBeDischarge5 = new BigDecimal(ptm6243.getDischarged5());
		BigDecimal toBeDischarge10 = new BigDecimal(ptm6243.getDischarged10());
		if (toBeRefunded5.compareTo(BigDecimal.ZERO) > 0 || toBeRefunded10.compareTo(BigDecimal.ZERO) > 0) {
			// update ptchchrga
			chrgaDb = ptchchrgaDao.getRecordByAssYrChrgNum(assYr, Integer.valueOf(chargNo));
			Ptchchrga newChrga = (Ptchchrga) BeanUtils.cloneBean(chrgaDb);
			String[] updList = new String[] { "assYr", "chrgNum", "a_5pcDo", "a_10pcDo", "sc_5pcPaid", "sc_10pcPaid", "lastUpdDate" };
			logger.debug(toBeRefunded5);
			logger.debug(toBeRefunded10);
			newChrga.setA_5pcDo(chrgaDb.getA_5pcDo().add(toBeRefunded5));
			newChrga.setA_10pcDo(chrgaDb.getA_10pcDo().add(toBeRefunded10));
			newChrga.setSc_5pcPaid(chrgaDb.getSc_5pcPaid().subtract(toBeRefunded5));
			newChrga.setSc_10pcPaid(chrgaDb.getSc_10pcPaid().subtract(toBeRefunded10));
			newChrga.setLastUpdDate(finalInput.getSysDate());
			chrgaDb.setUpdateList(updList);
			newChrga.setUpdateList(updList);
			uCommonDao.doUpdate(chrgaDb, newChrga);
		}
		logger.debug("//2.2.1.2.1a");
		// 2.2.1.2.1a
		if (StringUtils.equalsIgnoreCase(pta624c.getStatus(), "H") || StringUtils.equalsIgnoreCase(pta624c.getStatus(), "P")) {
			// Create Settlement Record (PTCHHSTTM)
			insertChargeSettlementHistory(assYr, Integer.valueOf(chargNo), ptm6243, finalInput, pta624c, createTs);

			// Create Account Movement Online Transaction record (PTPOACMVT)
			insertAccountMovementOnlineTransaction(assYr, Integer.valueOf(chargNo), chrgaDb, finalInput, ptm6243);
		}
		logger.debug("//2.2.1.2.1--4");
		// 2.2.1.2.1--4
		// create settlement record (PTCHHSTTM)
		insertChargeSettlementRecords(assYr, Integer.valueOf(chargNo), ptm6243, finalInput, pta624c, createTs);
		logger.debug("//2.2.1.3");
		// 2.2.1.3
		if (StringUtils.equals(chrgaDb.getColAcType(), "01") || StringUtils.equals(chrgaDb.getColAcType(), "02")
				|| StringUtils.equals(chrgaDb.getColAcType(), "03") || StringUtils.equals(chrgaDb.getColAcType(), "04")
				|| StringUtils.equals(chrgaDb.getColAcType(), "05") || StringUtils.equals(chrgaDb.getColAcType(), "06")) {
			Ptptassmt oldPtptassmt = ptptassmtDao.getLatestPtptassmt(pun, oc, assYr);
			if (toBeDischarge5.compareTo(BigDecimal.ZERO) > 0 || toBeDischarge10.compareTo(BigDecimal.ZERO) > 0) {
				if (oldPtptassmt != null) {
					Ptptassmt newPtptassmt = (Ptptassmt) BeanUtils.cloneBean(oldPtptassmt);
					// Update assessment history record (PTPTASSMT)
					String[] theUpdateList = new String[] { "pun", "oshipCode", "assYr", "seqNum", "aSc" };
					newPtptassmt.setaSc(oldPtptassmt.getaSc().subtract(toBeDischarge5).subtract(toBeDischarge10));
					oldPtptassmt.setUpdateList(theUpdateList);
					newPtptassmt.setUpdateList(theUpdateList);
					uCommonDao.doUpdate(oldPtptassmt, newPtptassmt);
				}
			}

			if (toBeRefunded5.compareTo(BigDecimal.ZERO) > 0 || toBeRefunded10.compareTo(BigDecimal.ZERO) > 0) {
				oldPtptassmt = ptptassmtDao.getLatestPtptassmt(pun, oc, assYr);
				if (oldPtptassmt != null) {
					Ptptassmt newPtptassmt = (Ptptassmt) BeanUtils.cloneBean(oldPtptassmt);
					// Update assessment history record (PTPTASSMT)
					String[] updateList = new String[] { "pun", "oshipCode", "assYr", "seqNum", "aSc", "paidSc" };
					newPtptassmt.setaSc(oldPtptassmt.getaSc().subtract(toBeRefunded5).subtract(toBeRefunded10));
					newPtptassmt.setPaidSc(oldPtptassmt.getPaidSc().subtract(toBeRefunded5).subtract(toBeRefunded10));
					oldPtptassmt.setUpdateList(updateList);
					newPtptassmt.setUpdateList(updateList);
					uCommonDao.doUpdate(oldPtptassmt, newPtptassmt);
				}
			}
		}
		logger.debug("//2.2.1.4");
		// 2.2.1.4.1--6
		// Create or Update Refund Charge Information (PTCHREFUN)
		Ptchrefun refunDb = insertOrUpdateRefundChargeInformation(assYr, Integer.valueOf(chargNo), ptm6243, ptm6244, ptm6245, ptm6246, chrgaDb, finalInput, pta624c,
				createTs);
		logger.debug("//2.2.1.5");
		// 2.2.1.5
		// Create Account Movement Information (PTPOACMVT)
		createsAccountMovementInformation(assYr, ptm6241, chrgaDb, finalInput, ptm6243, createTs);
		logger.debug("//2.2.1.6");
		// 2.2.1.6
		createsAccountMovementOnlineTransaction(assYr, ptm6241, ptm6243, chrgaDb, finalInput, pta624c, createTs);

		/*****************************************************
		 * Insert Report Records
		 *****************************************************/

		Ptcncon60 con60Db = ptcncon60Dao.getRecord();	// TAAS-PT-085
		Ptcncon61 con61Db = ptcncon61Dao.getAllField();
		logger.debug("//2.3.1");
		// 2.3.1
		PtnfonamResult ptafonamRslt = retrieveFormatOwnerNameBaseOnInputValue(pta624c);
		PenfoadrBean penfoadrRslt = retrieveFormatMailingAddressBasedOnInputValue(finalInput);
		logger.debug("//2.3.2");
		// 2.3.2
		// Generate of Collection Online Maintenance Transaction Print File
		// Record (PTFCOLMT)
		PtfcolmtTc5624DetailsJsonModel ptfcolmt = insertCollectionOnlineMaintenanceForReport(ptm6241, ptm6243, ptm6245, ptm6246, finalInput, chrgaDb,
				penfoadrRslt, pta624c, createTs);
		logger.debug("//2.3.3");
		// 2.3.3
		// Generate of Overpayment Refund Print File Record (PTFOPRNP)
		insertOverpaymentRefundForReport(ptm6241, ptm6243, ptm6245, refunDb.getLatestRefundNum(), ptfcolmt, ptafonamRslt, finalInput, pta624c, con61Db,
				new Timestamp(createTs + (++millSec)));
		logger.debug("//2.3.4");
		// 2.3.4
		// Generate of Refund Notice Print File Record (PTFPRRNL)
		BigDecimal chqAmt = PtUtils.convertStringToBigDecimal(ptm6243.getRefundedTotal()).subtract(retrieveSumOfSetoffAmount(finalInput));
		insertRefundNoticeForReport(ptm6241, ptm6243, ptm6245, ptm6246, finalInput, pta624c, ptafonamRslt, penfoadrRslt, con61Db, new Timestamp(createTs
				+ (++millSec)), chqAmt, con60Db);	// TAAS-PT-085
//				+ (++millSec)), chqAmt);	// TAAS-PT-085
		logger.debug("//2.3.5");
		// 2.3.5
		// Generate of Refund Set-off Advice Print File Record (PTFSORAV)
		insertRefundSetoffAdviceForReport(ptm6241, ptm6245, finalInput, pta624c, ptafonamRslt, new Timestamp(createTs + (++millSec)), chqAmt);
		logger.debug("//2.3.6");
		// 2.3.6
		// Generate of Daily Journal for Set-off Settlement Created and Summary
		// Print File (PTFSOFFR)
		insertDailyJournalForReport(ptm6241, finalInput, pta624c, new Timestamp(createTs));
		logger.debug("//2.3.8");
		// 2.3.8
		// instant print
//		createInstantPrintRecord(ptm6241, ptm6243, ptm6245, ptm6246, finalInput, pta624c, penfoadrRslt, ptfcolmt);	// TAAS-PT-085
		createInstantPrintRecord(ptm6241, ptm6243, ptm6245, ptm6246, finalInput, pta624c, penfoadrRslt, ptfcolmt, con60Db);	// TAAS-PT-085

		//PT021 print the cases with refund cheque amount = 0 <start>
//		insertRefundOfOverpaymentForReport(ptm6241, ptm6243, ptm6244, ptm6245, ptm6246, finalInput, pta624c, ptafonamRslt, penfoadrRslt, chqAmt, refunDb.getLatestRefundNum(), con61Db, new Timestamp(createTs + (++millSec)));	// TAAS-PT-085
		insertRefundOfOverpaymentForReport(ptm6241, ptm6243, ptm6244, ptm6245, ptm6246, finalInput, pta624c, ptafonamRslt, penfoadrRslt, chqAmt, refunDb.getLatestRefundNum(), con61Db, new Timestamp(createTs + (++millSec)), con60Db);	// TAAS-PT-085
		//PT021 <end>
	}

	private void insertChargeSettlementHistory(Short assYr, Integer chrgNum, PTM6243 ptm6243, Ptn624uInput input, Ptn624cResult pta624c, long createTs)
			throws Exception {

		Ptchhsttm sttmNew = new Ptchhsttm();
		sttmNew.setPun(pta624c.getPun());
		sttmNew.setOshipCode(pta624c.getOc());
		sttmNew.setAssYr(assYr);
		sttmNew.setChrgNum(chrgNum);
		sttmNew.setSetmDate(input.getSysDate());
		sttmNew.setSetmUpdDate(input.getSysDate());
		sttmNew.setSetmReceiptNum(new Integer("624000000"));
		sttmNew.setRewriteInd(" ");

		if ((new BigDecimal(ptm6243.getDischarged5())).compareTo(BigDecimal.ZERO) > 0) {
			sttmNew.setSetmType(new Short("580"));
			sttmNew.setCreateTs(new Timestamp(createTs + (++millSec)));
			sttmNew.setSetmAmt(new BigDecimal(ptm6243.getDischarged5()));
			uCommonDao.doInsert(sttmNew);
		}
		if ((new BigDecimal(ptm6243.getDischarged10())).compareTo(BigDecimal.ZERO) > 0) {
			Ptchhsttm newSttm = (Ptchhsttm) BeanUtils.cloneBean(sttmNew);
			newSttm.setCreateTs(new Timestamp(createTs + (++millSec)));
			newSttm.setSetmType(new Short("581"));
			newSttm.setSetmAmt(new BigDecimal(ptm6243.getDischarged10()));
			uCommonDao.doInsert(newSttm);
		}
	}

	private void insertChargeSettlementRecords(Short assYr, Integer chrgNum, PTM6243 ptm6243, Ptn624uInput input, Ptn624cResult pta624c, long createTs)
			throws Exception {
		logger.debug("//2.2.1.2.1");
		// 2.2.1.2.1
		Ptchhsttm newRecord = new Ptchhsttm();
		newRecord.setPun(pta624c.getPun());
		newRecord.setOshipCode(pta624c.getOc());
		newRecord.setAssYr(assYr);
		newRecord.setChrgNum(chrgNum);
		newRecord.setSetmDate(input.getSysDate());
		newRecord.setSetmUpdDate(input.getSysDate());
		newRecord.setSetmReceiptNum(new Integer("624000000"));
		newRecord.setRewriteInd(" ");
		if ((new BigDecimal(ptm6243.getDischarged5())).compareTo(BigDecimal.ZERO) > 0) {
			Ptchhsttm discharged5pcSc = (Ptchhsttm) BeanUtils.cloneBean(newRecord);
			discharged5pcSc.setCreateTs(new Timestamp(createTs + (++millSec)));
			discharged5pcSc.setSetmType(Short.valueOf("571"));
			discharged5pcSc.setSetmAmt((new BigDecimal(ptm6243.getDischarged5())));
			uCommonDao.doInsert(discharged5pcSc);
		}
		logger.debug("//2.2.1.2.2");
		// 2.2.1.2.2
		if ((new BigDecimal(ptm6243.getDischarged10())).compareTo(BigDecimal.ZERO) > 0) {
			Ptchhsttm discharged10pcSc = (Ptchhsttm) BeanUtils.cloneBean(newRecord);
			discharged10pcSc.setCreateTs(new Timestamp(createTs + (++millSec)));
			discharged10pcSc.setSetmType(Short.valueOf("572"));
			discharged10pcSc.setSetmAmt(new BigDecimal(ptm6243.getDischarged10()));
			uCommonDao.doInsert(discharged10pcSc);
		}
		logger.debug("//2.2.1.2.3");
		// 2.2.1.2.3
		if ((new BigDecimal(ptm6243.getRefunded5())).compareTo(BigDecimal.ZERO) > 0) {
			Ptchhsttm refunded5pcSc = (Ptchhsttm) BeanUtils.cloneBean(newRecord);
			refunded5pcSc.setCreateTs(new Timestamp(createTs + (++millSec)));
			refunded5pcSc.setSetmType(Short.valueOf("571"));
			if (StringUtils.equalsIgnoreCase(input.getChqeIssOpt(), "B") || StringUtils.equalsIgnoreCase(input.getChqeIssOpt(), "O")) {
				refunded5pcSc.setSetmDate(input.retrieveChqeIssDate());
			}
			refunded5pcSc.setSetmAmt(new BigDecimal(ptm6243.getRefunded5()));
			uCommonDao.doInsert(refunded5pcSc);

			Ptchhsttm refunded5pcScRecord = (Ptchhsttm) BeanUtils.cloneBean(refunded5pcSc);
			refunded5pcScRecord.setCreateTs(new Timestamp(createTs + (++millSec)));
			refunded5pcScRecord.setSetmType(Short.valueOf("624"));
			refunded5pcScRecord.setSetmAmt(new BigDecimal(ptm6243.getRefunded5()));
			uCommonDao.doInsert(refunded5pcScRecord);
		}
		logger.debug("//2.2.1.2.4");
		// 2.2.1.2.4
		if ((new BigDecimal(ptm6243.getRefunded10())).compareTo(BigDecimal.ZERO) > 0) {
			Ptchhsttm refunded10pcSc = (Ptchhsttm) BeanUtils.cloneBean(newRecord);
			refunded10pcSc.setCreateTs(new Timestamp(createTs + (++millSec)));
			refunded10pcSc.setSetmType(Short.valueOf("572"));
			if (StringUtils.equalsIgnoreCase(input.getChqeIssOpt(), "B") || StringUtils.equalsIgnoreCase(input.getChqeIssOpt(), "O")) {
				refunded10pcSc.setSetmDate(input.retrieveChqeIssDate());
			}
			refunded10pcSc.setSetmAmt(new BigDecimal(ptm6243.getRefunded10()));
			uCommonDao.doInsert(refunded10pcSc);

			Ptchhsttm refunded10pcScRecord = (Ptchhsttm) BeanUtils.cloneBean(refunded10pcSc);
			refunded10pcScRecord.setSetmType(Short.valueOf("625"));
			refunded10pcScRecord.setCreateTs(new Timestamp(createTs + (++millSec)));
			refunded10pcScRecord.setSetmAmt(new BigDecimal(ptm6243.getRefunded10()));
			uCommonDao.doInsert(refunded10pcScRecord);

		}
	}

	private Ptchrefun insertOrUpdateRefundChargeInformation(Short assYr, Integer chrgNum, PTM6243 ptm6243, PTM6244 ptm6244, PTM6245 ptm6245, PTM6246 ptm6246, Ptchchrga chrgaDb,
			Ptn624uInput finalInput, Ptn624cResult pta624c, long createTs) throws Exception {
		Ptchrefun refunNew = new Ptchrefun();
		BigDecimal toBeRefunded5 = new BigDecimal(ptm6243.getRefunded5());
		BigDecimal toBeRefunded10 = new BigDecimal(ptm6243.getRefunded10());
		if (toBeRefunded5.compareTo(BigDecimal.ZERO) > 0 || toBeRefunded10.compareTo(BigDecimal.ZERO) > 0) {
			// 2.2.1.4.1
			Ptchrefun refunDb = ptchrefunDao.getRecordByAssYrChrgNumPunAndOc(assYr, chrgNum, pta624c.getPun(), pta624c.getOc());
			if (refunDb != null) {
				// 2.2.1.4.3
				String[] updList = new String[] { "assYr", "chrgNum", "latestRefundNum" };
				refunNew = (Ptchrefun) BeanUtils.cloneBean(refunDb);
				logger.debug("refunNew.getLatestRefundNum() " + refunNew.getLatestRefundNum());
				refunNew.setLatestRefundNum((short) (refunNew.getLatestRefundNum().shortValue() + 1));
				refunDb.setUpdateList(updList);
				refunNew.setUpdateList(updList);

				uCommonDao.doUpdate(refunDb, refunNew);
			} else {
				// 2.2.1.4.2
				refunNew.setPun(pta624c.getPun());
				refunNew.setOshipCode(pta624c.getOc());
				refunNew.setAssYr(assYr);
				refunNew.setChrgNum(chrgNum);
				refunNew.setSeqNum(new Short("0"));
				refunNew.setAssType(chrgaDb.getAssType());
				refunNew.setColAcType(" ");
				refunNew.setLatestRefundNum(new Short("01"));
				refunNew.setRewriteInd(" ");
				uCommonDao.doInsert(refunNew);
			}

			Ptchrchqe cheqDB = null;

			// 2.2.1.4.4
			// Create Refund Cheque Detail (PTCHRCHQE)
			cheqDB = createRefundChequeDetail(assYr, chrgNum, refunNew.getLatestRefundNum(), ptm6243, ptm6245, finalInput, pta624c, createTs);

			logger.debug("//2.2.1.4.5");
			// 2.2.1.4.5
			// Create PT Mailing History (PTFLMLHIS)
			createPtMailingHistory(assYr, chrgNum, refunNew.getLatestRefundNum(), ptm6246, cheqDB, finalInput, pta624c);
			logger.debug("//2.2.1.4.6");
			// 2.2.1.4.6
			// Create or Update PT Set-Off Receipt (PTCHKAOFF) and Create Refund
			// Set-off Information (PTCHRSOFF)
			BigDecimal chqAmt = PtUtils.convertStringToBigDecimal(ptm6243.getRefundedTotal()).subtract(retrieveSumOfSetoffAmount(finalInput));
			insertOrUpdatePtSetOffReceiptNumber(assYr, chrgNum, refunNew.getLatestRefundNum(), finalInput, pta624c, createTs, chqAmt, ptm6244);

		}
		return refunNew;
	}

	private Ptchrchqe createRefundChequeDetail(Short assYr, Integer chrgNum, Short latestRefundNum, PTM6243 ptm6243, PTM6245 ptm6245, Ptn624uInput input,
			Ptn624cResult pta624c, long createTs) throws Exception {

		BigDecimal sumSetOfAmt = retrieveSumOfSetoffAmount(input);

		Ptchrchqe chqeNew = new Ptchrchqe();
		chqeNew.setPun(pta624c.getPun());
		chqeNew.setOshipCode(pta624c.getOc());
		chqeNew.setChrgNum(chrgNum);
		chqeNew.setAssYr(assYr);
		chqeNew.setCreateTs(new Timestamp(createTs + (++millSec)));
		chqeNew.setCreateDate(input.getSysDate());
		chqeNew.setRefundAmt(new BigDecimal(ptm6243.getRefundedTotal()));
		BigDecimal chqAmt = BigDecimal.ZERO;
		if (StringUtils.equalsIgnoreCase(input.getNominatedChrgSetOffInd(), "N")) {
			chqAmt = new BigDecimal(ptm6243.getRefundedTotal());
		} else if (StringUtils.equalsIgnoreCase(input.getNominatedChrgSetOffInd(), "Y")) {
			chqAmt = new BigDecimal(ptm6243.getRefundedTotal()).subtract(sumSetOfAmt);
		}
		chqeNew.setChqAmt(chqAmt);
		chqeNew.setChqIssDate(input.getSysDate());
		chqeNew.setCurrStatusDate(input.getSysDate());
		if (StringUtils.equals(Ptn624uInput.CHQE_ISS_OPT_BACKDATED, input.getChqeIssOpt())
				|| StringUtils.equals(Ptn624uInput.CHQE_ISS_OPT_OTHERS, input.getChqeIssOpt())) {
			chqeNew.setChqIssDate(input.retrieveChqeIssDate());
			chqeNew.setCurrStatusDate(input.retrieveChqeIssDate());
		}
		chqeNew.setCurrStatus(chqeNew.getChqAmt().compareTo(BigDecimal.ZERO) > 0 ? "U" : "N");
		chqeNew.setPrevStatus(" ");
		chqeNew.setRefundType("3");
		chqeNew.setType("0");
		logger.debug("latestRefundNum " + latestRefundNum);
		chqeNew.setRefundNum(latestRefundNum);
		chqeNew.setPayeeNameChi(ptm6245.getPayeeNameChi());
		chqeNew.setPayeeNameLn1(ptm6245.getPayeeName1());
		chqeNew.setPayeeNameLn2(ptm6245.getPayeeName2());
		chqeNew.setPayeeNameLn3(ptm6245.getPayeeName3());
		chqeNew.setPayeeNameLn4(ptm6245.getPayeeName4());
		chqeNew.setChequeNumPrev(" ");
		chqeNew.setRewriteInd(" ");
		uCommonDao.doInsert(chqeNew);

		return chqeNew;

	}

	private void createPtMailingHistory(Short assYr, Integer chrgNum, Short latestRefundNum, PTM6246 ptm6246, Ptchrchqe cheqDb, Ptn624uInput input,
			Ptn624cResult pta624c) throws Exception {

		PenfoadrBean foadrRslt = retrieveFormatMailingAddressBasedOnInputValue(input);
		boolean isMailAddr = StringUtils.equals(Ptn624uInput.ADDR_TYPE_MAILING, input.getAddrType());

		Ptflmlhis mlhisNew = new Ptflmlhis();
		mlhisNew.setPun(pta624c.getPun());
		mlhisNew.setOshipCode(pta624c.getOc());
		mlhisNew.setAssYr(assYr);
		mlhisNew.setNoticeType("F");
		mlhisNew.setChrgNum(chrgNum);
		mlhisNew.setCreateTs(cheqDb.getCreateTs());
		mlhisNew.setIssDate(input.getSysDate());
		if (StringUtils.equals(Ptn624uInput.CHQE_ISS_OPT_BACKDATED, input.getChqeIssOpt())
				|| StringUtils.equals(Ptn624uInput.CHQE_ISS_OPT_OTHERS, input.getChqeIssOpt())) {
			mlhisNew.setIssDate(input.retrieveChqeIssDate());
		}
		mlhisNew.setUndelieverdInd("");
		mlhisNew.setRefundNum(latestRefundNum);
		mlhisNew.setAddrLine1(retrieveAddrOrBlankLineForMailingHistory(isMailAddr, ptm6246.getMailAddrLine1(), foadrRslt.getAddrLine1()));
		mlhisNew.setAddrLine2(retrieveAddrOrBlankLineForMailingHistory(isMailAddr, ptm6246.getMailAddrLine2(), foadrRslt.getAddrLine2()));
		mlhisNew.setAddrLine3(retrieveAddrOrBlankLineForMailingHistory(isMailAddr, ptm6246.getMailAddrLine3(), foadrRslt.getAddrLine3()));
		mlhisNew.setAddrLine4(retrieveAddrOrBlankLineForMailingHistory(isMailAddr, ptm6246.getMailAddrLine4(), foadrRslt.getAddrLine4()));
		mlhisNew.setAddrLine5(retrieveAddrOrBlankLineForMailingHistory(isMailAddr, ptm6246.getMailAddrLine5(), foadrRslt.getAddrLine5()));
		mlhisNew.setAddrLine6(retrieveAddrOrBlankLineForMailingHistory(isMailAddr, ptm6246.getMailAddrLine6(), foadrRslt.getAddrLine6()));
		mlhisNew.setAddrLine7(retrieveAddrOrBlankLineForMailingHistory(isMailAddr, ptm6246.getMailAddrLine7(), foadrRslt.getAddrLine7()));
		//
		mlhisNew.setSource("5624");
		mlhisNew.setCreateDate(input.getSysDate());
		uCommonDao.doInsert(mlhisNew);

	}

	private String retrieveAddrOrBlankLineForMailingHistory(boolean isMailAddr, String mailAddrLine, String inputAddrLine) {
		if (isMailAddr) {
			if (mailAddrLine == null)
				return "";
			else
				return mailAddrLine;
		} else {
			if (inputAddrLine == null)
				return "";
			else
				return inputAddrLine;
		}
	}

	private void insertOrUpdatePtSetOffReceiptNumber(Short assYr, Integer chrgNum, Short latestRefundNum, Ptn624uInput input, Ptn624cResult pta624c,
			long createTs, BigDecimal chqAmt, PTM6244 ptm6244) throws Exception {

		boolean isOnSameDate = StringUtils.equals(Ptn624uInput.CHQE_ISS_OPT_ON_SAME_DATE, input.getChqeIssOpt());
		boolean isOthers = StringUtils.equals(Ptn624uInput.CHQE_ISS_OPT_OTHERS, input.getChqeIssOpt());
		boolean isNominated = StringUtils.equals(Ptn624uInput.NOMINATED_CHRG_SET_OFF_YES, input.getNominatedChrgSetOffInd());

		if ((!isOnSameDate && !isOthers) || !isNominated) {
			return;
		}

		Date payDate = input.getSysDate();
		if (StringUtils.equals(Ptn624uInput.CHQE_ISS_OPT_OTHERS, input.getChqeIssOpt())) {
			payDate = DateUtils.parseDDMMYYYYToDate(input.getChqeIssDate());
		}
		for (PTM6244Record setOffChrg : input.getSetOffChrgList()) {

			boolean isDbCharge = setOffChrg.isDbCharge();
			Short setOffChrgAssYr = new Short("0");
			String receiptNum = "";

			if (isDbCharge) {

				PtndecenResult cntyRslt = Ptndecen.execute("0101" + setOffChrg.getAssYr());
				setOffChrgAssYr = Short.parseShort(cntyRslt.getOutputYr());

				Ptchkaoff aoffDb = ptchkaoffDao.getRecordByTransCode(new Short("624"));
				if (aoffDb == null) {
					aoffDb = new Ptchkaoff();
					aoffDb.setRecNum(new Integer("0"));
					aoffDb.setTranCode(new Short("624"));
					uCommonDao.doInsert(aoffDb);
				}
				Ptchkaoff aoffNew = (Ptchkaoff) BeanUtils.cloneBean(aoffDb);
				receiptNum = aoffDb.getRecNum().intValue() == 999999 ? "000000" : StringUtils.leftPad(String.valueOf(aoffDb.getRecNum() + 1), 6, "0");

				PtnuppayResult payRslt = ptnuppay.execute("O", input.getUid(), setOffChrg.getTaxCode(), setOffChrgAssYr,
						Integer.valueOf(setOffChrg.getSerialNo()), "710", payDate, new BigDecimal(setOffChrg.getSetOffAmt()), new Integer("624" + receiptNum),
						input.getSysDate());
				if (payRslt.getRtnCode() != 0) {
					logger.debug("payRslt.getRtnCode() = " + payRslt.getRtnCode());
					throw new PTException(new String[] { "hiddenErrorPtm6246" }, "message.10055", new String[] { payRslt == null ? "" : payRslt.getRtnCode()
							+ "" });
				}

				String[] updList = new String[] { "recNum", "tranCode" };
				aoffDb.setUpdateList(updList);
				aoffNew.setUpdateList(updList);
				aoffNew.setRecNum(new Integer(receiptNum));
				int updCnt = uCommonDao.doUpdate(aoffDb, aoffNew);
				if (updCnt <= 0)
					throw new PTException(new String[] { "hiddenErrorPtm6241" }, "message.3999");
				
				//PT021 <start>
				if (isOthers) {
					if (chqAmt.signum() == 0 && StringUtils.equalsIgnoreCase("Y", ptm6244.getOsChargeInd())
							&& StringUtils.equalsIgnoreCase(setOffChrg.getSerialNo(), ptm6244.getOsChargeNo().substring(1, 8))) {
						Ptchchrga oldPtchrga = ptchchrgaDao.getRecordByAssYrChrgNum(setOffChrgAssYr, Integer.valueOf(setOffChrg.getSerialNo()));
						Ptchchrga newPtchrga = (Ptchchrga) BeanUtils.cloneBean(oldPtchrga);
						PtadedueResult dedueRslt = new PtadedueResult();
						dedueRslt.setChrgNum(Integer.parseInt(setOffChrg.getSerialNo()));
						dedueRslt.setAssYr(Short.valueOf(setOffChrgAssYr));
						dedueRslt = ptndedue.execute(dedueRslt);
						Date truncSysDate = org.apache.commons.lang.time.DateUtils.truncate(input.getSysDate(), Calendar.DATE);
						//(vii)&(viii)
						if (("3".equalsIgnoreCase(dedueRslt.getCaseType()) || "4A".equalsIgnoreCase(dedueRslt.getCaseType())
								|| "6A".equalsIgnoreCase(dedueRslt.getCaseType()) || "6B".equalsIgnoreCase(dedueRslt.getCaseType()))
								&& newPtchrga.getEnfDate() != null && newPtchrga.getEnfDate().before(truncSysDate)) {
							ptnupcfl.execute(newPtchrga.getPun(), newPtchrga.getOshipCode(), newPtchrga.getAssYr(), newPtchrga.getChrgNum(), input.getSysDate(), "23", " ", " ", 
									input.getSysDate(), newPtchrga.getEnfDate(), " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ");
							newPtchrga.setEnfDate(input.getSysDate());
							updCnt = uCommonDao.doUpdate(oldPtchrga, newPtchrga);
							if(updCnt<=0){
								throw new PTException(new String[]{"hiddenErrorPtm6241"}, "message.3999");
							}
						}
					}
				}
				//PT021 <end>
			}

			// 2.2.1.4.6(b) Create Refund Set-off Information (PTCHRSOFF)
			Ptchrsoff soffNew = new Ptchrsoff();
			soffNew.setPun(pta624c.getPun());
			soffNew.setOshipCode(pta624c.getOc());
			soffNew.setAssYr(assYr);
			soffNew.setChrgNum(chrgNum);
			soffNew.setCreateTs(new Timestamp(createTs + (++millSec)));
			soffNew.setRefundNum(latestRefundNum);
			soffNew.setSetOffAmt(new BigDecimal(setOffChrg.getSetOffAmt()));
			soffNew.setSetOffType(isDbCharge ? "D" : setOffChrg.getType());

			soffNew.setSetOffDetails(" ");
			if (setOffChrg.isNonDbCharge()) {
				Irandbc nndbc = irnndbc.execute(setOffChrg.getType(), setOffChrg.getChargeNo());
				soffNew.setSetOffDetails(nndbc.getResString());
			}

			soffNew.setSetOffChrgNum(isDbCharge ? Integer.valueOf(setOffChrg.getSerialNo()) : new Integer(0));
			soffNew.setSetOffAssYr(isDbCharge ? setOffChrgAssYr : new Short("0"));
			soffNew.setSetOffReceiptNum(isDbCharge ? new Integer(("624" + receiptNum)) : new Integer(0));
			uCommonDao.doInsert(soffNew);
			setOffChrg.setReceiptNum(soffNew.getSetOffReceiptNum() == 0 ? "" : String.valueOf(soffNew.getSetOffReceiptNum()));
		}
	}

	private void createsAccountMovementInformation(Short assYr, TC5624 ptm6241, Ptchchrga chrgaDb, Ptn624uInput input, PTM6243 ptm6243, long createTs)
			throws Exception {
		if ((new BigDecimal(ptm6243.getRefunded5())).compareTo(BigDecimal.ZERO) > 0
				|| (new BigDecimal(ptm6243.getRefunded10())).compareTo(BigDecimal.ZERO) > 0) {
			// Collection & Assessment Payment & Overpayment
			Ptpoacmvt ptpoacmvt1 = new Ptpoacmvt();
			ptpoacmvt1.setUid(input.getUid());
			ptpoacmvt1.setUpdateTs(new Timestamp(createTs + (++millSec)));
			ptpoacmvt1.setTaxType("5");
			ptpoacmvt1.setChrgNum(Integer.valueOf(ptm6241.getSerialNo()));
			ptpoacmvt1.setAssYr(assYr);
			if (StringUtils.isBlank(input.getChqeIssOpt())) {
				ptpoacmvt1.setMovementDate(null);
			} else if (StringUtils.equals(Ptn624uInput.CHQE_ISS_OPT_BACKDATED, input.getChqeIssOpt())
					|| StringUtils.equals(Ptn624uInput.CHQE_ISS_OPT_OTHERS, input.getChqeIssOpt())) {
				ptpoacmvt1.setMovementDate(input.retrieveChqeIssDate());
			} else if (StringUtils.equals(Ptn624uInput.CHQE_ISS_OPT_ON_SAME_DATE, input.getChqeIssOpt())) {
				ptpoacmvt1.setMovementDate(input.getSysDate());
			}
			ptpoacmvt1.setCreationDate(input.getSysDate());
			ptpoacmvt1.setArrearInd(Short.toString(chrgaDb.getArrYrCnt()));
			ptpoacmvt1.setColAcType(chrgaDb.getColAcType());
			ptpoacmvt1.setEaInd(chrgaDb.getEaInd());
			ptpoacmvt1.setAssType(chrgaDb.getAssType());
			ptpoacmvt1.setMovementType("1");
			Ptchacmv1DetailJsonModel cmv1Json = new Ptchacmv1DetailJsonModel();
			cmv1Json.setTaxWoReopenPaymt(BigDecimal.ZERO);
			cmv1Json.setSc5WoReopenPaymt(BigDecimal.ZERO);
			cmv1Json.setSc10WoReopenPaymt(BigDecimal.ZERO);
			cmv1Json.setTaxPayment(BigDecimal.ZERO);
			cmv1Json.setSc5Payment((new BigDecimal(ptm6243.getRefunded5())).negate());
			cmv1Json.setSc10Payment((new BigDecimal(ptm6243.getRefunded10())).negate());
			cmv1Json.setOverpaymentRcvd(BigDecimal.ZERO);
			ptpoacmvt1.setDetails(JsonUtil.convertObjectToJson(cmv1Json, Ptchacmv1DetailJsonModel.class));
			uCommonDao.doInsert(ptpoacmvt1);

			// Collection Surcharge Discharge
			Ptpoacmvt ptpoacmvt4 = (Ptpoacmvt) BeanUtils.cloneBean(ptpoacmvt1);
			ptpoacmvt4.setUpdateTs(new Timestamp(createTs + (++millSec)));
			Ptchacmv4DetailJsonModel cmv4Json = new Ptchacmv4DetailJsonModel();
			cmv4Json.setSc5DoManual(new BigDecimal(ptm6243.getRefunded5()));
			cmv4Json.setSc10DoManual(new BigDecimal(ptm6243.getRefunded10()));
			ptpoacmvt4.setMovementType("4");
			ptpoacmvt4.setDetails(JsonUtil.convertObjectToJson(cmv4Json, Ptchacmv4DetailJsonModel.class));
			uCommonDao.doInsert(ptpoacmvt4);

			// Collection Surcharge & Overpayment Refund
			Ptpoacmvt ptpoacmvt5 = (Ptpoacmvt) BeanUtils.cloneBean(ptpoacmvt1);
			ptpoacmvt5.setUpdateTs(new Timestamp(createTs + (++millSec)));
			Ptchacmv5DetailJsonModel cmv5Json = new Ptchacmv5DetailJsonModel();
			cmv5Json.setOpRefundSetOff(BigDecimal.ZERO);
			cmv5Json.setOpRefundCheque(BigDecimal.ZERO);
			BigDecimal sumSetOffAmt = retrieveSumOfSetoffAmount(input);
			cmv5Json.setSc5RefundSetOff(sumSetOffAmt.compareTo(new BigDecimal(ptm6243.getRefunded5())) >= 0 ? (new BigDecimal(ptm6243.getRefunded5()))
					: sumSetOffAmt);
			cmv5Json.setSc5RefundCheque(sumSetOffAmt.compareTo(new BigDecimal(ptm6243.getRefunded5())) >= 0 ? BigDecimal.ZERO : (new BigDecimal(ptm6243
					.getRefunded5())).subtract(sumSetOffAmt));
			cmv5Json.setSc10RefundSetOff(sumSetOffAmt.compareTo(new BigDecimal(ptm6243.getRefunded5())) >= 0 ? sumSetOffAmt.subtract(new BigDecimal(ptm6243
					.getRefunded5())) : BigDecimal.ZERO);
			cmv5Json.setSc10RefundCheque(sumSetOffAmt.compareTo(new BigDecimal(ptm6243.getRefunded5())) >= 0 ? (new BigDecimal(ptm6243.getRefundedTotal()))
					.subtract(sumSetOffAmt) : new BigDecimal(ptm6243.getRefunded10()));
			ptpoacmvt5.setMovementType("5");
			ptpoacmvt5.setDetails(JsonUtil.convertObjectToJson(cmv5Json, Ptchacmv5DetailJsonModel.class));
			uCommonDao.doInsert(ptpoacmvt5);
		}
	}

	private void insertAccountMovementOnlineTransaction(Short assYr, Integer chrgNum, Ptchchrga chrgaDb, Ptn624uInput input, PTM6243 ptm6243) throws Exception {

		// Create Account Movement Online Transaction (PTPOACMVT)
		Ptchacmv7DetailJsonModel cmv7JsonModel = new Ptchacmv7DetailJsonModel();
		cmv7JsonModel.setTaxWoReopen(BigDecimal.ZERO);
		cmv7JsonModel.setSc5WoReopen(new BigDecimal(ptm6243.getDischarged5()));
		cmv7JsonModel.setSc10WoReopen(new BigDecimal(ptm6243.getDischarged10()));
		cmv7JsonModel.setTaxSoo(BigDecimal.ZERO);
		cmv7JsonModel.setTaxSooUplifted(BigDecimal.ZERO);
		cmv7JsonModel.setSc5DoSystem(BigDecimal.ZERO);
		cmv7JsonModel.setSc10DoSystem(BigDecimal.ZERO);
		cmv7JsonModel.setTaxDoRevisedAss(BigDecimal.ZERO);
		cmv7JsonModel.setTaxDoHeldOver(BigDecimal.ZERO);
		cmv7JsonModel.setTaxDoPaElected(BigDecimal.ZERO);

		Ptpoacmvt cmvtNew = new Ptpoacmvt();
		cmvtNew.setUid(input.getUid());
		cmvtNew.setUpdateTs(input.getSysDate());
		cmvtNew.setTaxType("5");
		cmvtNew.setChrgNum(chrgNum);
		cmvtNew.setAssYr(assYr);
		cmvtNew.setMovementDate(input.getSysDate());
		cmvtNew.setCreationDate(input.getSysDate());
		cmvtNew.setArrearInd(Short.toString(chrgaDb.getArrYrCnt()));
		cmvtNew.setColAcType(chrgaDb.getColAcType());
		cmvtNew.setEaInd(chrgaDb.getEaInd());
		cmvtNew.setAssType(chrgaDb.getAssType());
		cmvtNew.setMovementType("7");
		cmvtNew.setDetails(JsonUtil.convertObjectToJson(cmv7JsonModel, Ptchacmv7DetailJsonModel.class));
		uCommonDao.doInsert(cmvtNew);
	}

	private void createsAccountMovementOnlineTransaction(Short assYr, TC5624 ptm6241, PTM6243 ptm6243, Ptchchrga chrgaDb, Ptn624uInput input,
			Ptn624cResult pta624c, long createTs) throws Exception {
		if ((new BigDecimal(ptm6243.getDischarged5())).compareTo(BigDecimal.ZERO) > 0
				|| (new BigDecimal(ptm6243.getDischarged10())).compareTo(BigDecimal.ZERO) > 0) {
			Ptpoacmvt ptpoacmvt4 = new Ptpoacmvt();
			ptpoacmvt4.setUid(input.getUid());
			ptpoacmvt4.setUpdateTs(new Timestamp(createTs + (++millSec)));
			ptpoacmvt4.setTaxType("5");
			ptpoacmvt4.setChrgNum(Integer.valueOf(ptm6241.getSerialNo()));
			ptpoacmvt4.setAssYr(assYr);
			ptpoacmvt4.setMovementDate(input.getSysDate());
			ptpoacmvt4.setCreationDate(input.getSysDate());
			ptpoacmvt4.setArrearInd(Short.toString(chrgaDb.getArrYrCnt()));
			ptpoacmvt4.setColAcType(chrgaDb.getColAcType());
			ptpoacmvt4.setEaInd(chrgaDb.getEaInd());
			ptpoacmvt4.setAssType(chrgaDb.getAssType());
			ptpoacmvt4.setMovementType("4");
			Ptchacmv4DetailJsonModel cmv4Json = new Ptchacmv4DetailJsonModel();
			cmv4Json.setSc5DoManual(new BigDecimal(ptm6243.getDischarged5()));
			cmv4Json.setSc10DoManual(new BigDecimal(ptm6243.getDischarged10()));
			ptpoacmvt4.setDetails(JsonUtil.convertObjectToJson(cmv4Json, Ptchacmv4DetailJsonModel.class));
			uCommonDao.doInsert(ptpoacmvt4);
		}
	}

	private PtfcolmtTc5624DetailsJsonModel insertCollectionOnlineMaintenanceForReport(TC5624 ptm6241, PTM6243 ptm6243, PTM6245 ptm6245, PTM6246 ptm6246,
			Ptn624uInput input, Ptchchrga chrgaDb, PenfoadrBean foadrRslt, Ptn624cResult pta624c, long createTs) throws Exception {

		BigDecimal sumSetOffAmt = retrieveSumOfSetoffAmount(input);
		boolean hasNominated = StringUtils.equals(Ptn624uInput.NOMINATED_CHRG_SET_OFF_YES, input.getNominatedChrgSetOffInd());
		boolean isMailAddr = StringUtils.equals(Ptn624uInput.ADDR_TYPE_MAILING, input.getAddrType());

		PtfcolmtTc5624DetailsJsonModel json = new PtfcolmtTc5624DetailsJsonModel();
		json.setSection(input.getUserSection());
		json.setTc("5624");
		json.setUid(input.getUid());
		json.setTime(new SimpleDateFormat(PtfcolmtTc5624DetailsJsonModel.TIME_FORMAT).format(input.getSysDate()));
		json.setPun(pta624c.getPun());
		json.setChargeNo("5" + "-" + ptm6241.getSerialNo() + "-" + ptm6241.getAssYr() + "-" + ptm6241.getCheckDigit());
		json.setTc5624DbSect(pta624c.getDbUnit() + pta624c.getDbSect());
		json.setTc5624Oc(pta624c.getOc());
		json.setTc5624IssueCheque(input.getChqeIssOpt());
		if (StringUtils.equals(Ptn624uInput.CHQE_ISS_OPT_BACKDATED, input.getChqeIssOpt())
				|| StringUtils.equals(Ptn624uInput.CHQE_ISS_OPT_OTHERS, input.getChqeIssOpt())) {
			json.setTc5624IssueDate(new SimpleDateFormat(PtfcolmtTc5624DetailsJsonModel.DATE_FORMAT).format(input.retrieveChqeIssDate()));
		} else if (StringUtils.equals(Ptn624uInput.CHQE_ISS_OPT_ON_SAME_DATE, input.getChqeIssOpt())) {
			json.setTc5624IssueDate(new SimpleDateFormat(PtfcolmtTc5624DetailsJsonModel.DATE_FORMAT).format(input.getSysDate()));
		}
		json.setTc5624IssueLtr(input.getCancelLetter());
		json.setTc5624IssueLtrDate(new SimpleDateFormat(PtfcolmtTc5624DetailsJsonModel.DATE_FORMAT).format(input.getSysDate()));
		json.setTc56245pcPayable(new BigDecimal(input.getFinalScPayable5()));
		json.setTc56245pcDo(new BigDecimal(ptm6243.getDischarged5()));
		json.setTc56245pcRefund(new BigDecimal(ptm6243.getRefunded5()));
		json.setTc562410pcPayable(new BigDecimal(input.getFinalScPayable10()));
		json.setTc562410pcDo(new BigDecimal(ptm6243.getDischarged10()));
		json.setTc562410pcRefund(new BigDecimal(ptm6243.getRefunded10()));
		if (!hasNominated) {
			json.setTc5624ChequeAmount(new BigDecimal(ptm6243.getRefundedTotal()));
			json.setTc5624ChargeCnt(new Integer(0));
		} else {
			json.setTc5624ChequeAmount((new BigDecimal(ptm6243.getRefundedTotal())).subtract(sumSetOffAmt));
			json.setTc5624ChargeCnt(input.getSetOffChrgList() != null ? input.getSetOffChrgList().size() : 0);
		}
		List<SetoffChargeModel> setoffChargeModels = new ArrayList<SetoffChargeModel>();
		for (PTM6244Record setoffChrg : input.getSetOffChrgList()) {
			SetoffChargeModel model = new SetoffChargeModel();
			model.setSetoffTaxCode(setoffChrg.getTaxCode());
			model.setSetoffChgNo(setoffChrg.getSerialNo());
			model.setSetoffAssYr(setoffChrg.getAssYr());
			model.setSetoffChkDigit(setoffChrg.getCheckDigit());
			model.setSetoffType(setoffChrg.getType());
			model.setSetoffRef(setoffChrg.getChargeNo());
			model.setSetoffAmt(setoffChrg.getSetOffAmt());
			setoffChargeModels.add(model);
		}

		json.setSetOffCharge(input.getSetOffChrgList() != null ? setoffChargeModels : null);
		json.setTc5624NameLine1(ptm6245.getOwnerName1());
		json.setTc5624NameLine2(ptm6245.getOwnerName2());
		json.setTc5624NameLine3(ptm6245.getOwnerName3());
		json.setTc5624NameLine4(ptm6245.getOwnerName4());
		json.setTc5624NameChi(ptm6245.getOwnerNameChi());
		json.setTc5624OaddrLangInd(isMailAddr ? pta624c.getAddrLangInd() : input.getAddrType());
		json.setTc5624OaddrLine1(isMailAddr ? ptm6246.getMailAddrLine1() : foadrRslt.getAddrLine1());
		json.setTc5624OaddrLine2(isMailAddr ? ptm6246.getMailAddrLine2() : foadrRslt.getAddrLine2());
		json.setTc5624OaddrLine3(isMailAddr ? ptm6246.getMailAddrLine3() : foadrRslt.getAddrLine3());
		json.setTc5624OaddrLine4(isMailAddr ? ptm6246.getMailAddrLine4() : foadrRslt.getAddrLine4());
		json.setTc5624OaddrLine5(isMailAddr ? ptm6246.getMailAddrLine5() : foadrRslt.getAddrLine5());
		json.setTc5624OaddrLine6(isMailAddr ? ptm6246.getMailAddrLine6() : foadrRslt.getAddrLine6());
		json.setTc5624OaddrLine7(isMailAddr ? ptm6246.getMailAddrLine7() : foadrRslt.getAddrLine7());
		json.setTc5624OaddrLangInd1(isMailAddr ? ptm6246.getMailAddrLineInd1() : foadrRslt.getAddrInd1());
		json.setTc5624OaddrLangInd2(isMailAddr ? ptm6246.getMailAddrLineInd2() : foadrRslt.getAddrInd2());
		json.setTc5624OaddrLangInd3(isMailAddr ? ptm6246.getMailAddrLineInd3() : foadrRslt.getAddrInd3());
		json.setTc5624OaddrLangInd4(isMailAddr ? ptm6246.getMailAddrLineInd4() : foadrRslt.getAddrInd4());
		json.setTc5624OaddrLangInd5(isMailAddr ? ptm6246.getMailAddrLineInd5() : foadrRslt.getAddrInd5());
		json.setTc5624OaddrLangInd6(isMailAddr ? ptm6246.getMailAddrLineInd6() : foadrRslt.getAddrInd6());
		json.setTc5624OaddrLangInd7(isMailAddr ? ptm6246.getMailAddrLineInd7() : foadrRslt.getAddrInd7());
		if (StringUtils.isNotBlank(chrgaDb.getPrecOwnerId())) {
			json.setTc5624PrecOwnerId(chrgaDb.getPrecOwnerId());
		} else {
			Ptptoship oship = ptptoshipDao.getRecordByKey(pta624c.getPun(), pta624c.getOc());
			json.setTc5624PrecOwnerId(oship != null ? oship.getPrecOwnerId() : "");
		}
		if (StringUtils.equalsIgnoreCase(ptm6245.getWithoutPayeeName(), " ")) {
			json.setTc5624ManualChequeInd("");
		} else if (StringUtils.equalsIgnoreCase(ptm6245.getWithoutPayeeName(), "Y") || StringUtils.equalsIgnoreCase(input.getChqeIssOpt(), "B")) {
			json.setTc5624ManualChequeInd("Y");
		} else {
			json.setTc5624ManualChequeInd("N");
		}
		Ptpokchmo chmoNew = new Ptpokchmo();
		chmoNew.setUid(input.getUid());
		chmoNew.setCreateTs(new Timestamp(createTs + (++millSec)));
		chmoNew.setTranCode(new Short("5624"));
		chmoNew.setFileCode("U5624");
		chmoNew.setDetails(JsonUtil.convertObjectToJson(json, PtfcolmtTc5624DetailsJsonModel.class));
		uCommonDao.doInsert(chmoNew);

		return json;
	}

	private void insertOverpaymentRefundForReport(TC5624 ptm6241, PTM6243 ptm6243, PTM6245 ptm6245, Short latestRefundNum,
			PtfcolmtTc5624DetailsJsonModel ptfcolmt, PtnfonamResult ptafonamRslt, Ptn624uInput input, Ptn624cResult pta624c, Ptcncon61 con61Db,
			Timestamp createTs) throws Exception {

		BigDecimal sumSetOffAmt = retrieveSumOfSetoffAmount(input);
		boolean hasNominated = StringUtils.equals(Ptn624uInput.NOMINATED_CHRG_SET_OFF_YES, input.getNominatedChrgSetOffInd());
		PtndecenResult cntyRslt = Ptndecen.execute("0101" + ptm6241.getAssYr());
		String assYr = cntyRslt.getOutputYr();

		PtfoprnpTc5624DetailsJsonModel json = new PtfoprnpTc5624DetailsJsonModel();
		json.setSection(input.getUserSection());
		json.setTc("5624");
		json.setUid(input.getUid());
		json.setCreateTs(new SimpleDateFormat(PtfoprnpTc5624DetailsJsonModel.TS_FORMAT).format(input.getSysDate()));
		json.setDbSec(pta624c.getDbUnit() + pta624c.getDbSect());
		json.setPun(pta624c.getPun());
		json.setOc(pta624c.getOc());
		json.setChargeNo("5-" + ptm6241.getSerialNo() + "-" + ptm6241.getAssYr() + "-" + ptm6241.getCheckDigit());
		json.setTc5624PrecOwnerId(pta624c.getPrecOwnerId());
		json.setAssYr(assYr);
		if (StringUtils.equals(Ptn624uInput.CHQE_ISS_OPT_BACKDATED, input.getChqeIssOpt())
				|| StringUtils.equals(Ptn624uInput.CHQE_ISS_OPT_OTHERS, input.getChqeIssOpt())) {
			json.setTc5624IssueDate(new SimpleDateFormat(PtfoprnpTc5624DetailsJsonModel.DATE_FORMAT).format(input.retrieveChqeIssDate()));
		} else if (StringUtils.equals(Ptn624uInput.CHQE_ISS_OPT_ON_SAME_DATE, input.getChqeIssOpt())) {
			json.setTc5624IssueDate(new SimpleDateFormat(PtfoprnpTc5624DetailsJsonModel.DATE_FORMAT).format(input.getSysDate()));
		}

		json.setTc5624RefundNum(latestRefundNum);
		json.setTc5624ChargeCnt(hasNominated && input.getSetOffChrgList() != null ? input.getSetOffChrgList().size() : 0);
		List<SetoffChargeModel> setoffChargeModels = new ArrayList<SetoffChargeModel>();
		if (input.getSetOffChrgList() != null) {
			for (PTM6244Record setoffChrg : input.getSetOffChrgList()) {
				SetoffChargeModel model = new SetoffChargeModel();
				model.setDbChrgInd(setoffChrg.getDbChrgInd());
				model.setSetoffTaxCode(setoffChrg.getTaxCode());
				model.setSetoffChgNo(setoffChrg.getSerialNo());
				model.setSetoffAssYr(setoffChrg.getAssYr());
				model.setSetoffChkDigit(setoffChrg.getCheckDigit());
				model.setSetoffType(setoffChrg.getType());
				model.setSetoffRef(setoffChrg.getChargeNo());
				model.setSetoffBalancePayable(setoffChrg.getBalancePayable());
				model.setSetoffAmt(setoffChrg.getSetOffAmt());
				model.setSetoffReceiptNum(setoffChrg.getReceiptNum());
				//PT021 <start>
				model.setSetoffAssType(setoffChrg.getAssType());
				//PT021 <end>
				setoffChargeModels.add(model);
			}
		}
		json.setSetOffCharge(hasNominated ? setoffChargeModels : null);
		if (StringUtils.equalsIgnoreCase(input.getNominatedChrgSetOffInd(), Ptn624uInput.NOMINATED_CHRG_SET_OFF_NO)) {
			json.setTc5624ChequeAmt(new BigDecimal(ptm6243.getRefundedTotal()));
		} else if (StringUtils.equalsIgnoreCase(input.getNominatedChrgSetOffInd(), Ptn624uInput.NOMINATED_CHRG_SET_OFF_YES)) {
			json.setTc5624ChequeAmt((new BigDecimal(ptm6243.getRefundedTotal())).subtract(sumSetOffAmt));
		}
		json.setPrintSign(" ");
		if (json.getTc5624ChequeAmt().compareTo(con61Db.getMachineChqLimit()) < 0) {
			json.setPrintSign("Y");
		}
		if (StringUtils.equalsIgnoreCase(ptm6245.getWithoutPayeeName(), "N")) {
			json.setTc5624PayeeNameChi(ptm6245.getPayeeNameChi());
			json.setTc5624PayeeNameLn1(ptm6245.getPayeeName1());
			json.setTc5624PayeeNameLn2(ptm6245.getPayeeName2());
			json.setTc5624PayeeNameLn3(ptm6245.getPayeeName3());
			json.setTc5624PayeeNameLn4(ptm6245.getPayeeName4());
		}

		json.setTc5624NameLine1(ptafonamRslt.getNameLine1());
		json.setTc5624NameLine2(ptafonamRslt.getNameLine2());
		json.setTc5624NameLine3(ptafonamRslt.getNameLine3());
		json.setTc5624NameLine4(ptafonamRslt.getNameLine4());
		json.setTc5624NameChi(ptafonamRslt.getNameChi());
		json.setTc5624OwnerNum(pta624c.getNumOwner().intValue());
		json.setTc5624PrecOwnerId(ptfcolmt.getTc5624PrecOwnerId());
		if (StringUtils.equalsIgnoreCase(ptm6245.getWithoutPayeeName(), "Y")) {
			List<PtfoprnpTc5624DetailsJsonModel.Tc5624OwnerInfo> ownerInfoList = new ArrayList<PtfoprnpTc5624DetailsJsonModel.Tc5624OwnerInfo>();
			if (StringUtils.isNotBlank(ptfcolmt.getTc5624PrecOwnerId())) {
				PtfoprnpTc5624DetailsJsonModel.Tc5624OwnerInfo ownerInfo = retrieveOwnerInfoForReport(ptfcolmt.getTc5624PrecOwnerId());
				if (ownerInfo != null) {
					ownerInfoList.add(ownerInfo);
				}
			}

			if (ownerInfoList.size() == 0) {
				ownerInfoList.add(new PtfoprnpTc5624DetailsJsonModel.Tc5624OwnerInfo());
			}

			List<Ptptowner> ownerList = ptptownerDao.getNonPrecOwners(pta624c.getPun(), pta624c.getOc(), ptfcolmt.getTc5624PrecOwnerId());
			if (ownerList != null) {
				for (int i = 0; i < ownerList.size(); i++) {
					PtfoprnpTc5624DetailsJsonModel.Tc5624OwnerInfo ownerInfo = retrieveOwnerInfoForReport(ownerList.get(i).getOwnerId());
					if (ownerInfo != null) {
						ownerInfoList.add(ownerInfo);
					}
					if (i == 3) {
						break;
					}
				}
			}
			json.setOwnerInfoList(ownerInfoList);
		}
		json.setTc56245pcRefund(new BigDecimal(ptm6243.getRefunded5()));
		json.setTc562410pcRefund(new BigDecimal(ptm6243.getRefunded10()));
		json.setTc5624IssueCheque(input.getChqeIssOpt());
		json.setTc5624IssueLtr(input.getCancelLetter());
		json.setTc5624IssueLtrDate(new SimpleDateFormat(PtfoprnpTc5624DetailsJsonModel.DATE_FORMAT).format(input.getSysDate()));
		json.setTc5624RefundAmt(new BigDecimal(ptm6243.getRefundedTotal()));
		json.setTc5624RefundType("3");
		json.setTc5624RefundNum(latestRefundNum);
		json.setTc5624WithoutPayeeInd(ptm6245.getWithoutPayeeName());

		Ptpokchmo chmoNew = new Ptpokchmo();
		chmoNew.setUid(input.getUid());
		chmoNew.setCreateTs(createTs);
		chmoNew.setTranCode(new Short("5624"));
		chmoNew.setFileCode("R5593");
		chmoNew.setDetails(JsonUtil.convertObjectToJson(json, PtfoprnpTc5624DetailsJsonModel.class));
		uCommonDao.doInsert(chmoNew);
	}

	private void insertRefundNoticeForReport(TC5624 ptm6241, PTM6243 ptm6243, PTM6245 ptm6245, PTM6246 ptm6246, Ptn624uInput input, Ptn624cResult pta624c,
			PtnfonamResult ptafonam, PenfoadrBean peafoadr, Ptcncon61 con61Db, Timestamp createTs, BigDecimal chqAmt, Ptcncon60 con60Db) throws Exception {	// TAAS-PT-085
//			PtnfonamResult ptafonam, PenfoadrBean peafoadr, Ptcncon61 con61Db, Timestamp createTs, BigDecimal chqAmt) throws Exception {	// TAAS-PT-085
		
		if (!StringUtils.equals(Ptn624uInput.CHQE_ISS_OPT_OTHERS, input.getChqeIssOpt()) || chqAmt.signum() <= 0) {
			return;
		}

		boolean isMailAddr = StringUtils.equals(Ptn624uInput.ADDR_TYPE_MAILING, input.getAddrType());
		BigDecimal sumSetoffChrg = retrieveSumOfSetoffAmount(input);

		PtfprrnlJsonModel json = new PtfprrnlJsonModel();
		json.setTc("5624");
		json.setSect(pta624c.getDbUnit() + pta624c.getDbSect());
		json.setPun(pta624c.getPun());
		json.setOc(pta624c.getOc());
		json.setPayeeNameLine1(StringUtils.equalsIgnoreCase(ptm6245.getWithoutPayeeName(), "N") ? ptm6245.getPrtPayeeName1() : "");
		json.setPayeeNameLine2(StringUtils.equalsIgnoreCase(ptm6245.getWithoutPayeeName(), "N") ? ptm6245.getPrtPayeeName2() : "");
		json.setPayeeNameLine3(StringUtils.equalsIgnoreCase(ptm6245.getWithoutPayeeName(), "N") ? ptm6245.getPrtPayeeName3() : "");
		json.setPayeeNameLine4(StringUtils.equalsIgnoreCase(ptm6245.getWithoutPayeeName(), "N") ? ptm6245.getPrtPayeeName4() : "");
		json.setPayeeNameLine1LangInd("");
		if (StringUtils.equalsIgnoreCase(ptm6245.getWithoutPayeeName(), "N")) {
			if (StringUtils.isNotBlank(ptm6245.getPayeeNameChi())) {
				json.setPayeeNameLine1LangInd("C");
			} else {
				json.setPayeeNameLine1LangInd("E");
			}
		} else {
			json.setPayeeNameLine1LangInd("");
		}
		json.setNameLine1(ptm6245.getOwnerName1());
		json.setNameLine2(ptm6245.getOwnerName2());
		json.setNameLine3(ptm6245.getOwnerName3());
		json.setNameLine4(ptm6245.getOwnerName4());
		json.setNameChi(ptm6245.getOwnerNameChi());

		json.setOaddrLine1(isMailAddr ? ptm6246.getMailAddrLine1() : peafoadr.getAddrLine1());
		json.setOaddrLine2(isMailAddr ? ptm6246.getMailAddrLine2() : peafoadr.getAddrLine2());
		json.setOaddrLine3(isMailAddr ? ptm6246.getMailAddrLine3() : peafoadr.getAddrLine3());
		json.setOaddrLine4(isMailAddr ? ptm6246.getMailAddrLine4() : peafoadr.getAddrLine4());
		json.setOaddrLine5(isMailAddr ? ptm6246.getMailAddrLine5() : peafoadr.getAddrLine5());
		json.setOaddrLine6(isMailAddr ? ptm6246.getMailAddrLine6() : peafoadr.getAddrLine6());
		json.setOaddrLine7(isMailAddr ? ptm6246.getMailAddrLine7() : peafoadr.getAddrLine7());
		json.setOaddrInd1(isMailAddr ? ptm6246.getMailAddrLineInd1() : peafoadr.getAddrInd1());
		json.setOaddrInd2(isMailAddr ? ptm6246.getMailAddrLineInd2() : peafoadr.getAddrInd2());
		json.setOaddrInd3(isMailAddr ? ptm6246.getMailAddrLineInd3() : peafoadr.getAddrInd3());
		json.setOaddrInd4(isMailAddr ? ptm6246.getMailAddrLineInd4() : peafoadr.getAddrInd4());
		json.setOaddrInd5(isMailAddr ? ptm6246.getMailAddrLineInd5() : peafoadr.getAddrInd5());
		json.setOaddrInd6(isMailAddr ? ptm6246.getMailAddrLineInd6() : peafoadr.getAddrInd6());
		json.setOaddrInd7(isMailAddr ? ptm6246.getMailAddrLineInd7() : peafoadr.getAddrInd7());

		json.setAreaCode(isMailAddr ? pta624c.getAreaCode() : ptm6246.getAreaCode());
		json.setAssType(pta624c.getAssType());
		json.setTaxCode("5");
		json.setChargeNo(ptm6241.getSerialNo());
		json.setAssYr(ptm6241.getAssYr());
		json.setCheckDigit(ptm6241.getCheckDigit());
		json.setOpAmt(new BigDecimal(ptm6243.getRefundedTotal()));
		List<SetoffChargeModel> setoffChargeModels = new ArrayList<SetoffChargeModel>();
		for (PTM6244Record setoffChrg : input.getSetOffChrgList()) {
			SetoffChargeModel model = new SetoffChargeModel();
			model.setDbChrgInd(setoffChrg.getDbChrgInd());
			model.setSetoffTaxCode(setoffChrg.getTaxCode());
			model.setSetoffChgNo(setoffChrg.getSerialNo());
			model.setSetoffAssYr(setoffChrg.getAssYr());
			model.setSetoffChkDigit(setoffChrg.getCheckDigit());
			model.setSetoffType(setoffChrg.getType());
			model.setSetoffRef(setoffChrg.getChargeNo());
			model.setSetoffBalancePayable(setoffChrg.getBalancePayable());
			model.setSetoffAmt(setoffChrg.getSetOffAmt());
			//PT021 year of assessment should be charge assyr + 1 if Ass type = 2
			model.setSetoffAssType(setoffChrg.getAssType());
//			boolean isDbCharge = StringUtils.equalsIgnoreCase(SetoffChargeModel.DB_CHRG_IND_YES, setoffChrg.getDbChrgInd());
//			if (isDbCharge) {
//				PtndecenResult ptadecen = Ptndecen.execute("0101" + setoffChrg.getAssYr());
//				if (ptadecen != null && StringUtils.equalsIgnoreCase(PtndecenResult.NORMAL, ptadecen.getReturnCode())) {
//					Ptchchrga chrgaDb = ptchchrgaDao.getRecordByAssYrChrgNum(new Short(ptadecen.getOutputYr()), Integer.valueOf(setoffChrg.getSerialNo()));
//					model.setSetoffAssType(chrgaDb != null ? chrgaDb.getAssType() : StringUtils.EMPTY);
//				}
//			}
			//PT021
			setoffChargeModels.add(model);
		}
		json.setSetoffChargeList(setoffChargeModels);

		json.setChequeAmount(StringUtils.equalsIgnoreCase(input.getNominatedChrgSetOffInd(), "N") ? json.getOpAmt() : json.getOpAmt().subtract(sumSetoffChrg));
		json.setIssueDate(new SimpleDateFormat(PtfprrnlJsonModel.DATE_FORMAT).format(input.retrieveChqeIssDate()));

		json.setAssrName("");
		json.setAssrNameChi("");
		PtncolrResult colrRslt = ptncolr.execute(pta624c.getPrecOwnerId(), "AA", input.retrieveChqeIssDate());
		if (colrRslt.getReturnCode() == 0) {
			json.setAssrName(colrRslt.getName());
			json.setAssrNameChi(colrRslt.getNameChi());
		}

//		json.setTelNo("183 5312");	// TAAS-PT-085
		json.setTelNo(con60Db.getTelNo());	// TAAS-PT-085
		json.setFaxNo(con61Db.getFaxNo1());
		json.setEmailAddr(con61Db.getEmailAddr());
		json.setPrintSign(json.getChequeAmount().compareTo(con61Db.getMachineChqLimit()) < 0 ? "Y" : " ");

		Ptpokchmo chmoNew = new Ptpokchmo();
		chmoNew.setUid(input.getUid());
		chmoNew.setCreateTs(createTs);
		chmoNew.setTranCode(new Short("5624"));
		chmoNew.setFileCode("R5761");
		chmoNew.setDetails(JsonUtil.convertObjectToJson(json, PtfprrnlJsonModel.class));
		uCommonDao.doInsert(chmoNew);
	}

	private void insertRefundSetoffAdviceForReport(TC5624 ptm6241, PTM6245 ptm6245, Ptn624uInput input, Ptn624cResult pta624c, PtnfonamResult ptafonam,
			Timestamp createTs, BigDecimal chequeAmt) throws Exception {

		if (!StringUtils.equals(Ptn624uInput.CHQE_ISS_OPT_OTHERS, input.getChqeIssOpt())
				|| !StringUtils.equals(Ptn624uInput.NOMINATED_CHRG_SET_OFF_YES, input.getNominatedChrgSetOffInd())
				|| chequeAmt.signum() <= 0) {
			return;
		}

		BigDecimal ttlSoAmt = retrieveSumOfSetoffAmount(input);
		PtncolrResult colrRslt = ptncolr.execute(pta624c.getPrecOwnerId(), "OP", input.retrieveChqeIssDate());

		PtfsoravJsonModel json = new PtfsoravJsonModel();
		json.setTc("5624");
		json.setDbSec(pta624c.getDbUnit() + pta624c.getDbSect());
		json.setPun(pta624c.getPun());
		json.setOc(pta624c.getOc());
		json.setNameLine1(ptm6245.getOwnerName1());
		json.setNameLine2(ptm6245.getOwnerName2());
		json.setNameLine3(ptm6245.getOwnerName3());
		json.setNameLine4(ptm6245.getOwnerName4());
		json.setNameChi(ptm6245.getOwnerNameChi());
		json.setIssDate(new SimpleDateFormat(PtfsoravJsonModel.DATE_FORMAT).format(input.retrieveChqeIssDate()));
		json.setRfndChrgNo(ptm6241.getSerialNo());
		json.setRfndTaxType("5");
		json.setRfndAssYr(ptm6241.getAssYr());
		json.setRfndCd(ptm6241.getCheckDigit());
		json.setTotSoAmt(ttlSoAmt);
		json.setAssType(pta624c.getAssType());
		json.setCllrTelNo("");
		json.setCllrName("");
		json.setCllrNameChi("");
		if (colrRslt != null && colrRslt.getReturnCode() == 0) {
			json.setCllrTelNo(colrRslt.getTelNo());
			json.setCllrName(colrRslt.getName());
			json.setCllrNameChi(colrRslt.getNameChi());
		}
		json.setSoDate(new SimpleDateFormat(PtfsoravJsonModel.DATE_FORMAT).format(input.retrieveChqeIssDate()));
		List<SetoffChargeModel> setoffChargeModels = new ArrayList<SetoffChargeModel>();
		for (PTM6244Record setoffChrg : input.getSetOffChrgList()) {
			SetoffChargeModel model = new SetoffChargeModel();
			model.setSetoffTaxCode(setoffChrg.getTaxCode());
			model.setSetoffChgNo(setoffChrg.getSerialNo());
			model.setSetoffAssYr(setoffChrg.getAssYr());
			model.setSetoffChkDigit(setoffChrg.getCheckDigit());
			model.setSetoffType(setoffChrg.getType());
			model.setSetoffRef(setoffChrg.getChargeNo());
			model.setSetoffAmt(setoffChrg.getSetOffAmt());
			model.setSetoffReceiptNum(setoffChrg.getReceiptNum());
			//PT021 <start>
			model.setSetoffAssType(setoffChrg.getAssType());
			//PT021 <end>
			setoffChargeModels.add(model);
		}
		json.setSoChrgList(setoffChargeModels);

		// for (SetoffChargeModel model : input.getSetOffChrgList()) {
		// System.out.println("receipt number : " +
		// model.getSetoffReceiptNum());
		// }

		Ptpokchmo chmoNew = new Ptpokchmo();
		chmoNew.setUid(input.getUid());
		chmoNew.setCreateTs(createTs);
		chmoNew.setTranCode(new Short("5624"));
		chmoNew.setFileCode("R5764");
		chmoNew.setDetails(JsonUtil.convertObjectToJson(json, PtfsoravJsonModel.class));
		uCommonDao.doInsert(chmoNew);
	}

	private void insertDailyJournalForReport(TC5624 ptm6241, Ptn624uInput input, Ptn624cResult pta624c, Timestamp createTs) throws Exception {

		if ((!StringUtils.equals(Ptn624uInput.CHQE_ISS_OPT_ON_SAME_DATE, input.getChqeIssOpt())
				&& !StringUtils.equals(Ptn624uInput.CHQE_ISS_OPT_OTHERS, input.getChqeIssOpt()))
				|| !StringUtils.equals(Ptn624uInput.NOMINATED_CHRG_SET_OFF_YES, input.getNominatedChrgSetOffInd())) {
			return;
		}
		//
		if (input.getSetOffChrgList() != null) {
			for (int i = 0; i < input.getSetOffChrgList().size(); i++) {

				PTM6244Record setoffChrg = input.getSetOffChrgList().get(i);

				if (setoffChrg.isDbCharge()) {
					PtfsoffrJsonModel json = new PtfsoffrJsonModel();
					json.setTc("5624");
					json.setDbSec(pta624c.getDbUnit() + pta624c.getDbSect());
					json.setPun(pta624c.getPun());
					json.setOc(pta624c.getOc());
					json.setRfndTaxType("5");
					json.setRfndCd(ptm6241.getCheckDigit());
					json.setRfndChargeNum(ptm6241.getSerialNo());
					json.setRfndAssYr(ptm6241.getAssYr());
					json.setSoTaxType(setoffChrg.getTaxCode());
					json.setSoChrgNo(setoffChrg.getSerialNo());
					json.setSoAssYr(setoffChrg.getAssYr());
					json.setSoCd(setoffChrg.getCheckDigit());
					if (StringUtils.equals(Ptn624uInput.CHQE_ISS_OPT_OTHERS, input.getChqeIssOpt())) {
						json.setSoDate(new SimpleDateFormat(PtfsoffrJsonModel.DATE_FORMAT).format(input.retrieveChqeIssDate()));
					} else if (StringUtils.equals(Ptn624uInput.CHQE_ISS_OPT_ON_SAME_DATE, input.getChqeIssOpt())) {
						json.setSoDate(new SimpleDateFormat(PtfsoffrJsonModel.DATE_FORMAT).format(input.getSysDate()));
					} else {
						json.setSoDate("");
					}
					json.setSoReceiptNum(setoffChrg.getReceiptNum());
					json.setSoAmount(setoffChrg.getSetOffAmt());

					Ptpokchmo chmoNew = new Ptpokchmo();
					chmoNew.setUid(input.getUid());
					chmoNew.setCreateTs(new Timestamp(createTs.getTime() + (++millSec)));
					chmoNew.setTranCode(new Short("5624"));
					chmoNew.setFileCode("R5772");
					chmoNew.setDetails(JsonUtil.convertObjectToJson(json, PtfsoffrJsonModel.class));
					uCommonDao.doInsert(chmoNew);
				}
			}
		}

	}

	private void createInstantPrintRecord(TC5624 ptm6241, PTM6243 ptm6243, PTM6245 ptm6245, PTM6246 ptm6246, Ptn624uInput input, Ptn624cResult pta624c,
			PenfoadrBean peafoard, PtfcolmtTc5624DetailsJsonModel ptfcolmt, Ptcncon60 con60Db) throws Exception {	// TAAS-PT-085
//			PenfoadrBean peafoard, PtfcolmtTc5624DetailsJsonModel ptfcolmt) throws Exception {	// TAAS-PT-085
		if (!StringUtils.equalsIgnoreCase(input.getCancelLetter(), "true")) {
			return;
		}
		boolean isMailAddr = StringUtils.equals(Ptn624uInput.ADDR_TYPE_MAILING, input.getAddrType());
		logger.debug("pta624c.getPrecOwnerId() = " + pta624c.getPrecOwnerId());
		logger.debug("input.getSysDate() = " + input.getSysDate());
		PtncolrResult colrRslt = ptncolr.execute(pta624c.getPrecOwnerId(), "AA", input.getSysDate());
		PtnprsclParam prsclParam = new PtnprsclParam();
		prsclParam.setSect(pta624c.getDbUnit() + pta624c.getDbSect());
		prsclParam.setPun(pta624c.getPun());
		prsclParam.setOc(Short.toString(pta624c.getOc()));
		prsclParam.setNameLine1(ptm6245.getOwnerName1());
		prsclParam.setNameLine2(ptm6245.getOwnerName2());
		prsclParam.setNameLine3(ptm6245.getOwnerName3());
		prsclParam.setNameLine4(ptm6245.getOwnerName4());
		prsclParam.setNameChi(ptm6245.getOwnerNameChi());
		prsclParam.setoAddrLine1(isMailAddr ? ptm6246.getMailAddrLine1() : peafoard.getAddrLine1());
		prsclParam.setoAddrLine2(isMailAddr ? ptm6246.getMailAddrLine2() : peafoard.getAddrLine2());
		prsclParam.setoAddrLine3(isMailAddr ? ptm6246.getMailAddrLine3() : peafoard.getAddrLine3());
		prsclParam.setoAddrLine4(isMailAddr ? ptm6246.getMailAddrLine4() : peafoard.getAddrLine4());
		prsclParam.setoAddrLine5(isMailAddr ? ptm6246.getMailAddrLine5() : peafoard.getAddrLine5());
		prsclParam.setoAddrLine6(isMailAddr ? ptm6246.getMailAddrLine6() : peafoard.getAddrLine6());
		prsclParam.setoAddrLine7(isMailAddr ? ptm6246.getMailAddrLine7() : peafoard.getAddrLine7());
		prsclParam.setoAddrInd1(isMailAddr ? (ptm6246.getMailAddrLineInd1() != null ? ptm6246.getMailAddrLineInd1() : " ") : peafoard.getAddrInd1());
		prsclParam.setoAddrInd2(isMailAddr ? (ptm6246.getMailAddrLineInd2() != null ? ptm6246.getMailAddrLineInd2() : " ") : peafoard.getAddrInd2());
		prsclParam.setoAddrInd3(isMailAddr ? (ptm6246.getMailAddrLineInd3() != null ? ptm6246.getMailAddrLineInd3() : " ") : peafoard.getAddrInd3());
		prsclParam.setoAddrInd4(isMailAddr ? (ptm6246.getMailAddrLineInd4() != null ? ptm6246.getMailAddrLineInd4() : " ") : peafoard.getAddrInd4());
		prsclParam.setoAddrInd5(isMailAddr ? (ptm6246.getMailAddrLineInd5() != null ? ptm6246.getMailAddrLineInd5() : " ") : peafoard.getAddrInd5());
		prsclParam.setoAddrInd6(isMailAddr ? (ptm6246.getMailAddrLineInd6() != null ? ptm6246.getMailAddrLineInd6() : " ") : peafoard.getAddrInd6());
		prsclParam.setoAddrInd7(isMailAddr ? (ptm6246.getMailAddrLineInd7() != null ? ptm6246.getMailAddrLineInd7() : " ") : peafoard.getAddrInd7());
		prsclParam.setChargeNum("5" + "-" + ptm6241.getSerialNo() + "-" + ptm6241.getAssYr() + "-" + ptm6241.getCheckDigit());
		prsclParam.setScAmt((new BigDecimal(ptm6243.getDischargedTotal())).add(new BigDecimal(ptm6243.getRefundedTotal())).toString());
		prsclParam.setIssueDate(DateUtils.dateToString(input.getSysDate(), PtnprsclParam.DATE_FORMAT));
		prsclParam.setAssrName("");
		prsclParam.setAssrNameChi("");
		prsclParam.setFaxNo("");
		logger.debug("colrRslt.getReturnCode() = " + colrRslt.getReturnCode());
		if (colrRslt.getReturnCode() == 0) {
			prsclParam.setAssrName(colrRslt.getName());
			prsclParam.setAssrNameChi(colrRslt.getNameChi());
			prsclParam.setFaxNo(colrRslt.getFaxNo());
		}
//		prsclParam.setTelNo("183 5312");	// TAAS-PT-085
		prsclParam.setTelNo(con60Db.getTelNo());	// TAAS-PT-085
		prsclParam.setSc5OnlyInd("0");
		prsclParam.setSc10OnlyInd("0");
		prsclParam.setTemplateNo("2");
		if ((new BigDecimal(ptm6243.getRefunded10())).compareTo(BigDecimal.ZERO) == 0
				&& (new BigDecimal(ptm6243.getDischarged10())).compareTo(BigDecimal.ZERO) == 0) {
			prsclParam.setSc5OnlyInd("1");
		}
		if ((new BigDecimal(ptm6243.getRefunded5())).compareTo(BigDecimal.ZERO) == 0
				&& (new BigDecimal(ptm6243.getDischarged5())).compareTo(BigDecimal.ZERO) == 0) {
			prsclParam.setSc10OnlyInd("1");
		}
		if ((new BigDecimal(ptm6243.getRefunded5())).compareTo(BigDecimal.ZERO) > 0
				|| (new BigDecimal(ptm6243.getRefunded10())).compareTo(BigDecimal.ZERO) > 0) {
			prsclParam.setTemplateNo("1");
		}
		prsclParam.setPrecOwnerId(ptfcolmt.getTc5624PrecOwnerId());

		List<EpsReport> report = ptnprscl.generateReportIRC3760(prsclParam);
		List<List<EpsReport>> eps = new ArrayList<List<EpsReport>>();
		eps.add(report);
		irdReportService.generateAndSubmitReports("3760", "5624", TaasSystem.PT, RptFileExtension.XML, eps);
		eps.get(0).clear();
		eps.clear();
	}

	private void validateDatabaseForNominatedChargeBeforeUpdate(Ptn624uInput input, Ptn624cResult pta624c) throws Exception {

		boolean isNominated = StringUtils.equals(Ptn624uInput.NOMINATED_CHRG_SET_OFF_YES, input.getNominatedChrgSetOffInd());
		boolean isSameOrOtherIssOpt = StringUtils.equals(Ptn624uInput.CHQE_ISS_OPT_ON_SAME_DATE, input.getChqeIssOpt())
				|| StringUtils.equals(Ptn624uInput.CHQE_ISS_OPT_OTHERS, input.getChqeIssOpt());

		if (isNominated && isSameOrOtherIssOpt) {

			if (input.getSetOffChrgList() != null && input.getSetOffChrgList().size() > 0) {
				for (int i = 0; i < input.getSetOffChrgList().size(); i++) {

					// For DB Change
					PTM6244Record setOffChrg = input.getSetOffChrgList().get(i);
					if (setOffChrg.isDbCharge()) {

						PtndecenResult cntyRslt = Ptndecen.execute("0101" + setOffChrg.getAssYr());
						Short assYr = Short.parseShort(cntyRslt.getOutputYr());
						Ptchchrga chrgaDb = ptchchrgaDao.getRecordByAssYrChrgNum(assYr, Integer.valueOf(setOffChrg.getSerialNo()));
						if (chrgaDb == null) {
							throw new PTException(
									new String[] { "hiddenErrorPtm6244", "ptm6244.recordList[" + i + "].taxCode", "ptm6244.recordList[" + i + "].serialNo",
											"ptm6244.recordList[" + i + "].assYr", "ptm6244.recordList[" + i + "].checkDigit" }, "message.3736");
						}

						if (StringUtils.equals("A", chrgaDb.getStatus()) || StringUtils.equalsIgnoreCase("Q", chrgaDb.getStatus())) {
							throw new PTException(
									new String[] { "hiddenErrorPtm6244", "ptm6244.recordList[" + i + "].taxCode", "ptm6244.recordList[" + i + "].serialNo",
											"ptm6244.recordList[" + i + "].assYr", "ptm6244.recordList[" + i + "].checkDigit" }, "message.4426");
						}

						if (StringUtils.equalsIgnoreCase("R", chrgaDb.getStatus()) || StringUtils.equalsIgnoreCase("U", chrgaDb.getStatus())
								|| StringUtils.equalsIgnoreCase("V", chrgaDb.getStatus()) || StringUtils.equalsIgnoreCase("W", chrgaDb.getStatus())
								|| StringUtils.equalsIgnoreCase("X", chrgaDb.getStatus()) || StringUtils.equalsIgnoreCase("Y", chrgaDb.getStatus())) {
							throw new PTException(
									new String[] { "hiddenErrorPtm6244", "ptm6244.recordList[" + i + "].taxCode", "ptm6244.recordList[" + i + "].serialNo",
											"ptm6244.recordList[" + i + "].assYr", "ptm6244.recordList[" + i + "].checkDigit" }, "message.4427");
						}

						if (StringUtils.equalsIgnoreCase("J", chrgaDb.getStatus())) {
							throw new PTException(
									new String[] { "hiddenErrorPtm6244", "ptm6244.recordList[" + i + "].taxCode", "ptm6244.recordList[" + i + "].serialNo",
											"ptm6244.recordList[" + i + "].assYr", "ptm6244.recordList[" + i + "].checkDigit" }, "message.7714");
						}
						
						if (StringUtils.isNotBlank(chrgaDb.getDefStatus())) {
							Ptchdcolf colfDb = ptchdcolfDao.getRecordByPunOship(pta624c.getPun(), pta624c.getOc());
							if (colfDb == null) {
								throw new PTException(
										new String[] { "hiddenErrorPtm6244", "ptm6244.recordList[" + i + "].taxCode", "ptm6244.recordList[" + i + "].serialNo",
												"ptm6244.recordList[" + i + "].assYr", "ptm6244.recordList[" + i + "].checkDigit" }, "message.6000");							
							}
						}
						
						if (StringUtils.equals("S", chrgaDb.getStatus()) || StringUtils.equalsIgnoreCase("T", chrgaDb.getStatus())
								|| StringUtils.equalsIgnoreCase("Z", chrgaDb.getStatus())) {
							throw new PTException(
									new String[] { "hiddenErrorPtm6244", "ptm6244.recordList[" + i + "].taxCode", "ptm6244.recordList[" + i + "].serialNo",
											"ptm6244.recordList[" + i + "].assYr", "ptm6244.recordList[" + i + "].checkDigit" }, "message.6069");
						}

						if (chrgaDb.getBalance() == null || chrgaDb.getBalance().compareTo(new BigDecimal(setOffChrg.getSetOffAmt())) < 0) {
							throw new PTException(
									new String[] { "hiddenErrorPtm6244", "ptm6244.recordList[" + i + "].taxCode", "ptm6244.recordList[" + i + "].serialNo",
											"ptm6244.recordList[" + i + "].assYr", "ptm6244.recordList[" + i + "].checkDigit" }, "message.6480");
						}
					}
				}
			}
		}
	}

	// Add DB validation repeat check - Added by Travis Li 20Jul2015 <START>
	private void repeatDbValidation(String status, PTM6243 p3) throws PTException {
		// 2.1.2.5 Database Validation
		// PTCHCHRGA.STATUS

		BigDecimal dischargedTotal = new BigDecimal(p3.getDischargedTotal());

		if (dischargedTotal.compareTo(BigDecimal.ZERO) > 0) {

			if ("A".equals(status) || "Q".equals(status)) {
				throw new PTException(new String[] { "tc5624.serialNo", "tc5624.assYr", "tc5624.checkDigit" }, "message.4426");
			}

			if ("R".equals(status) || "U".equals(status) || "V".equals(status) || "W".equals(status) || "X".equals(status) || "Y".equals(status)) {
				throw new PTException(new String[] { "tc5624.serialNo", "tc5624.assYr", "tc5624.checkDigit" }, "message.4427");
			}

		}

		// Total To be refunded;
		// 5% S/C To be refunded;
		// 10% S/C To be refunded;
		// 5% S/C O/S;
		// 10% S/C O/S
		BigDecimal refunded5 = new BigDecimal(p3.getRefunded5());
		BigDecimal refunded10 = new BigDecimal(p3.getRefunded10());
		BigDecimal refundedTotal = new BigDecimal(p3.getRefundedTotal());
		BigDecimal outstanding5 = new BigDecimal(p3.getNetScOutstanding5());
		BigDecimal outstanding10 = new BigDecimal(p3.getNetScOutstanding10());

		if (refundedTotal.compareTo(BigDecimal.ZERO) > 0) {
			if (refunded5.compareTo(BigDecimal.ZERO) > 0) {
				if (outstanding10.compareTo(BigDecimal.ZERO) != 0) {
					throw new PTException(new String[] { "tc5624.serialNo", "tc5624.assYr", "tc5624.checkDigit" }, "message.3728");
				}
			}

			if (refunded10.compareTo(BigDecimal.ZERO) > 0) {
				if (outstanding5.compareTo(BigDecimal.ZERO) != 0) {
					throw new PTException(new String[] { "tc5624.serialNo", "tc5624.assYr", "tc5624.checkDigit" }, "message.3729");
				}
			}
		}
	}
	// Add DB validation repeat check - Added by Travis Li 20Jul2015 <END>

	//PT021 start 
//	private void insertRefundOfOverpaymentForReport(TC5624 tc5624, PTM6243 ptm6243, PTM6244 ptm6244, PTM6245 ptm6245, PTM6246 ptm6246, Ptn624uInput input, Ptn624cResult pta624c, PtnfonamResult ptafonam, PenfoadrBean peafoadr, BigDecimal chqAmt, Short latestRefundNum, Ptcncon61 con61Db, Timestamp createTs) throws Exception {	// TAAS-PT-085
	private void insertRefundOfOverpaymentForReport(TC5624 tc5624, PTM6243 ptm6243, PTM6244 ptm6244, PTM6245 ptm6245, PTM6246 ptm6246, Ptn624uInput input, Ptn624cResult pta624c, PtnfonamResult ptafonam, PenfoadrBean peafoadr, BigDecimal chqAmt, Short latestRefundNum, Ptcncon61 con61Db, Timestamp createTs, Ptcncon60 con60Db) throws Exception {	// TAAS-PT-085
		
		if (StringUtils.equalsIgnoreCase(Ptn624uInput.NOMINATED_CHRG_SET_OFF_NO, input.getNominatedChrgSetOffInd())) {
			return;
		}
		if (StringUtils.equalsIgnoreCase(Ptn624uInput.CHQE_ISS_OPT_OTHERS, input.getChqeIssOpt()) && chqAmt.signum() == 0) {
			Date setoffDate = DateUtils.parseDDMMYYYYToDate(input.getChqeIssDate());
			
			PtfpscrnJsonModel json = new PtfpscrnJsonModel();
			json.setTc("5624");
			json.setJobName("TC5624");
			json.setSect("5" + pta624c.getDbSect());
			json.setPun(pta624c.getPun());
			json.setOc(pta624c.getOc());
			json.setPrecOwnerId(pta624c.getPrecOwnerId());
			json.setNameLine1(ptafonam.getNameLine1());
			json.setNameLine2(ptafonam.getNameLine2());
			json.setNameLine3(ptafonam.getNameLine3());
			json.setNameLine4(ptafonam.getNameLine4());
			json.setNameChi(ptafonam.getNameChi());
			boolean isMailAddr = StringUtils.equals(Ptn624uInput.ADDR_TYPE_MAILING, input.getAddrType());
			json.setOaddrLine1(isMailAddr ? ptm6246.getMailAddrLine1() : peafoadr.getAddrLine1());
			json.setOaddrLine2(isMailAddr ? ptm6246.getMailAddrLine2() : peafoadr.getAddrLine2());
			json.setOaddrLine3(isMailAddr ? ptm6246.getMailAddrLine3() : peafoadr.getAddrLine3());
			json.setOaddrLine4(isMailAddr ? ptm6246.getMailAddrLine4() : peafoadr.getAddrLine4());
			json.setOaddrLine5(isMailAddr ? ptm6246.getMailAddrLine5() : peafoadr.getAddrLine5());
			json.setOaddrLine6(isMailAddr ? ptm6246.getMailAddrLine6() : peafoadr.getAddrLine6());
			json.setOaddrLine7(isMailAddr ? ptm6246.getMailAddrLine7() : peafoadr.getAddrLine7());
			json.setOaddrInd1(isMailAddr ? (StringUtils.isNotBlank(ptm6246.getMailAddrLineInd1()) ? ptm6246.getMailAddrLineInd1() : " ") : peafoadr.getAddrInd1());
			json.setOaddrInd2(isMailAddr ? (StringUtils.isNotBlank(ptm6246.getMailAddrLineInd2()) ? ptm6246.getMailAddrLineInd2() : " ") : peafoadr.getAddrInd2());
			json.setOaddrInd3(isMailAddr ? (StringUtils.isNotBlank(ptm6246.getMailAddrLineInd3()) ? ptm6246.getMailAddrLineInd3() : " ") : peafoadr.getAddrInd3());
			json.setOaddrInd4(isMailAddr ? (StringUtils.isNotBlank(ptm6246.getMailAddrLineInd4()) ? ptm6246.getMailAddrLineInd4() : " ") : peafoadr.getAddrInd4());
			json.setOaddrInd5(isMailAddr ? (StringUtils.isNotBlank(ptm6246.getMailAddrLineInd5()) ? ptm6246.getMailAddrLineInd5() : " ") : peafoadr.getAddrInd5());
			json.setOaddrInd6(isMailAddr ? (StringUtils.isNotBlank(ptm6246.getMailAddrLineInd6()) ? ptm6246.getMailAddrLineInd6() : " ") : peafoadr.getAddrInd6());
			json.setOaddrInd7(isMailAddr ? (StringUtils.isNotBlank(ptm6246.getMailAddrLineInd7()) ? ptm6246.getMailAddrLineInd7() : " ") : peafoadr.getAddrInd7());
			json.setAreaCode(isMailAddr ? pta624c.getAreaCode() : input.getAreaCode());
			json.setAssType(pta624c.getAssType());
			json.setTaxCode("5");
			json.setChrgNo(tc5624.getSerialNo());
			json.setAssYr(tc5624.getAssYr());
			json.setCheckDigit(tc5624.getCheckDigit());
			json.setAmtRepayable(ptm6243.getRefundedTotal());   //refund total in ptm6243
			json.setSetoffDate(setoffDate);
			json.setSc5pcAmt(ptm6243.getRefunded5());
			json.setSc10pcAmt(ptm6243.getRefunded10());
			List<SetoffChargeModel> setoffChargeModels = null;
			String osChargeNo = StringUtils.EMPTY;
			if (input.getSetOffChrgList().size() > 0) {
				setoffChargeModels = new ArrayList<SetoffChargeModel>();
				for (PTM6244Record setoffchrg : input.getSetOffChrgList()) {
					SetoffChargeModel model = new SetoffChargeModel();
					model.setDbChrgInd(setoffchrg.getDbChrgInd());
					model.setSetoffAmt(setoffchrg.getSetOffAmt());
					model.setSetoffReceiptNum(setoffchrg.getReceiptNum());
					if (StringUtils.equalsIgnoreCase(setoffchrg.getDbChrgInd(), SetoffChargeModel.DB_CHRG_IND_YES)) {
						PtndecenResult cntyRslt = Ptndecen.execute("0101" + setoffchrg.getAssYr());
						Ptchchrga chrgaDb = ptchchrgaDao.getRecordByAssYrChrgNum(Short.parseShort(cntyRslt.getOutputYr()), Integer.valueOf(setoffchrg.getSerialNo()));
						model.setSetoffAssType(chrgaDb.getAssType());
						model.setSetoffBalancePayable(chrgaDb.getBalance().toString());
						model.setSetoffTaxCode(setoffchrg.getTaxCode());
						model.setSetoffChgNo(setoffchrg.getSerialNo());
						model.setSetoffAssYr(setoffchrg.getAssYr());
						model.setSetoffChkDigit(setoffchrg.getCheckDigit());
//						if (ptm6244.getOsAmt().signum() > 0) {
//							osChargeNo = ptm6244.getOsChargeNo();
//						}
					} else if (StringUtils.equalsIgnoreCase(setoffchrg.getDbChrgInd(), SetoffChargeModel.DB_CHRG_IND_NO)) {
						BigDecimal newBalancePayable = new BigDecimal(setoffchrg.getBalancePayable()).subtract(new BigDecimal(setoffchrg.getSetOffAmt()));
						model.setSetoffBalancePayable(newBalancePayable.toString());
						model.setSetoffType(setoffchrg.getType());
						model.setSetoffRef(setoffchrg.getChargeNo());
//						if (newBalancePayable.signum() > 0) {
//							osChargeNo = ptm6244.getOsChargeNo();
//						}
					}
					setoffChargeModels.add(model);
				}
			}
			json.setSetoffChargeList(setoffChargeModels);
			if (StringUtils.isNotBlank(ptm6244.getOsChargeInd())) {
				osChargeNo = ptm6244.getOsChargeNo();
				if (StringUtils.equalsIgnoreCase("Y", ptm6244.getOsChargeInd())) {
					json.setChargeTaxCode(osChargeNo.substring(0, 1));
					json.setChargeChgNo(osChargeNo.substring(1, 8));
					json.setChargeAssYr(osChargeNo.substring(8, 10));
					json.setChargeChkDigit(osChargeNo.substring(10));
					
					PtadedueResult dedueRslt = new PtadedueResult();
					dedueRslt.setChrgNum(Integer.parseInt(osChargeNo.substring(1,8)));
					PtndecenResult osChargecntyRslt = Ptndecen.execute("0101" + osChargeNo.substring(8, 10));
					Short osChargeassYr = Short.parseShort(osChargecntyRslt.getOutputYr());
					dedueRslt.setAssYr(Short.valueOf(osChargeassYr));
					dedueRslt = ptndedue.execute(dedueRslt);
					json.setDd1Ind(dedueRslt.getDd1Ind());
					json.setDd1(dedueRslt.getDd1());
					json.setDd2Ind(dedueRslt.getDd2Ind());
					json.setDd2(dedueRslt.getDd2());
					json.setAmt1Ind(dedueRslt.getAmt1Ind());
					json.setAmt1(dedueRslt.getAmt1());
					json.setAmt2Ind(dedueRslt.getAmt2Ind());
					json.setAmt2(dedueRslt.getAmt2());
				} else if (StringUtils.equalsIgnoreCase("N", ptm6244.getOsChargeInd())) {
					json.setChargeType(osChargeNo.substring(0, 1));
					json.setChargeRef(osChargeNo.substring(1));
					
					json.setDd1Ind("");
					json.setDd1(null);
					json.setDd2Ind("");
					json.setDd2(null);
					json.setAmt1Ind("");
					json.setAmt1(ptm6244.getOsAmt());
					json.setAmt2Ind("");
					json.setAmt2(BigDecimal.ZERO);
				}
			} else {
				json.setDd1Ind("");
				json.setDd1(null);
				json.setDd2Ind("");
				json.setDd2(null);
				json.setAmt1Ind("");
				json.setAmt1(BigDecimal.ZERO);
				json.setAmt2Ind("");
				json.setAmt2(BigDecimal.ZERO);
			}
			json.setIssueDate(input.retrieveChqeIssDate());
			json.setAssrName("");
			json.setAssrNameChi("");
			if (StringUtils.isNotBlank(pta624c.getPrecOwnerId())) {
				PtncolrResult colrRslt = ptncolr.execute(pta624c.getPrecOwnerId(), "AA", input.retrieveChqeIssDate());
				if (colrRslt.getReturnCode() == 0) {
					json.setAssrName(colrRslt.getName());
					json.setAssrNameChi(colrRslt.getNameChi());
				}
			}
//			json.setTelNo("183 5312");	// TAAS-PT-085
			json.setTelNo(con60Db.getTelNo());	// TAAS-PT-085
			json.setFaxNo(con61Db.getFaxNo1());
			json.setEmailAddr(con61Db.getEmailAddr());
			json.setLatestRefundNum(latestRefundNum); //from Ptchrefun
			json.setCrc("");
			if (StringUtils.isNotBlank(ptm6244.getOsChargeInd())) {
				json.setCrc(ptm6245.getCrcCode());
				if (StringUtils.isNotBlank(json.getChargeType())) {
					if ("ABCEFGKLMQRSTU".indexOf(json.getChargeType()) >= 0) {
						json.setCrc("207");
					} else if ("IJ".indexOf(json.getChargeType()) >= 0) {
						json.setCrc("211");
					} else if ("X".equalsIgnoreCase(json.getChargeType())) {
						json.setCrc("201C");
					} else if ("W".equalsIgnoreCase(json.getChargeType())) {
						json.setCrc("201A");
					}					
				}
			}
			json.setNonDbInd(" ");
			if(setoffChargeModels != null){
				for(SetoffChargeModel setoffModel : setoffChargeModels){					
					if (StringUtils.equals(setoffModel.getDbChrgInd(), SetoffChargeModel.DB_CHRG_IND_NO)) {
						json.setNonDbInd("Y");
						break;
					}
				}
			} // whether need to separate db and non-db
			json.setChqIssueOption(input.getChqeIssOpt());
			
			Ptpokchmo chmoNew = new Ptpokchmo();
			chmoNew.setUid(input.getUid());
			chmoNew.setCreateTs(new Timestamp(createTs.getTime()));
			chmoNew.setTranCode(new Short("5624"));
			chmoNew.setFileCode("R5624");
			chmoNew.setDetails(JsonUtil.convertObjectToJson(json, PtfpscrnJsonModel.class));
			uCommonDao.doInsert(chmoNew);
		}
	}
	//PT021 end
}
