//Check in version of WAS_PRD,04-02-17,bhssham:2:dR94Xk2ihPCQa/XckkevDoZ7Kc9F90877ijeOsH1ZhM=
//Check in version of WAS_PRD,02-02-17,jwccheung:1:BBvQaCKxS3kSkjyz6O4Ak4Z7Kc9F90877ijeOsH1ZhM=
package ird.taas2.ct.common;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import ird.taas2.ct.common.model.CtcnxcolrPrn;
import ird.taas2.ct.common.param.Cta011c;
import ird.taas2.ct.common.result.Ctn011cResult;
import ird.taas2.ct.dao.CtcnxcolrDao;
import ird.taas2.ct.dao.CtcnxprnrDao;
import ird.taas2.ct.model.Ctcnxcolr;
import ird.taas2.ct.model.Ctcnxprnr;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Ctn011c {
	@Autowired CtcnxcolrDao ctcnxcolrDao;

	@Autowired CtcnxprnrDao ctcnxprnrDao;
	
	
	private final Logger logger = Logger.getLogger(this.getClass());

	public Ctn011cResult execute(Cta011c cta011c) throws Exception
	{
		Ctn011cResult ctn011cResult = new Ctn011cResult();
		
		String actionCode = cta011c.getActionCode();
		
		
		String recordType = cta011c.getRecordType();
		String officerCode = cta011c.getOfficerCode();
		
		
		String prn1 = cta011c.getPrn1();
		String prn2 = cta011c.getPrn2();
		
		Date refDate = this.removeTime(cta011c.getCurrTimestamp());
		
		char charActionCode = actionCode.charAt(0);
		
		List<Ctcnxcolr> existCtcnxcolrList = new ArrayList<Ctcnxcolr>();
		List<Ctcnxprnr> ctcnxprnrList =  null;
		
		List<CtcnxcolrPrn> ctcnxcolrPrnList = new ArrayList<CtcnxcolrPrn>();;
		
		List<List<Ctcnxcolr>> allCtcnxcolrList =  new ArrayList<List<Ctcnxcolr>>();
		
		
		 switch(charActionCode)
	      {
	         case '1' :
	        	 Ctcnxcolr previousRecord = ctcnxcolrDao.selectPreviousRecord(recordType,officerCode, refDate);
	        	 
	        	 if(previousRecord == null){
	        		 ctn011cResult.addFieldErrorMap("tc00111.recordType", "message.3087");
	        		 ctn011cResult.addFieldErrorMap("tc00111.officerCode", "message.3087");
	        		 return ctn011cResult;
	        	 }
	        	 existCtcnxcolrList.add(previousRecord);
	        	 
	        	 List<Ctcnxcolr>  nextRecordList =  ctcnxcolrDao.selectNextRecordList(recordType,officerCode, refDate);	        	 
	        		        	 
	        	 for(Ctcnxcolr ctcnxcolr: nextRecordList){
	        		 existCtcnxcolrList.add(ctcnxcolr);
	        	 }
	        	 
	        	 ctn011cResult.setCtcnxcolrList(existCtcnxcolrList);

	        	 break;
	         case '2' :
	        	 
	        	 
	        	 if("AS".equals(recordType)){
	        		 ctcnxprnrList = ctcnxprnrDao.searchByPrnDigit(prn1,"");
	        	 }else if("AA".equals(recordType)){
	        		 ctcnxprnrList = ctcnxprnrDao.searchByPrnDigit(prn1,prn2);
	        	 }
	        	
	        	 if(ctcnxprnrList != null && ctcnxprnrList.size() > 0){
	        		 ctn011cResult.addFieldErrorMap("tc00111.prn1", "message.6019");
	        		 if("AA".equals(recordType)){
	        			 ctn011cResult.addFieldErrorMap("tc00111.prn2", "message.6019");
	        		 }
	        	 }else{
	        		 
	        		 Ctcnxcolr ctcnxcolr = ctcnxcolrDao.selectLatestByRecTypeOfficeCodeEffDate(recordType,officerCode, refDate);
	        		 
	        		 if(ctcnxcolr == null){
	        			 ctn011cResult.addFieldErrorMap("tc00111.recordType", "message.3087");
		        		 ctn011cResult.addFieldErrorMap("tc00111.officerCode", "message.3087");
	        		 }else{
	        			 existCtcnxcolrList = new ArrayList<Ctcnxcolr>(); 
		        		 existCtcnxcolrList.add(ctcnxcolr);	        		 
		        		 
		        		 ctn011cResult.setCtcnxcolrList(existCtcnxcolrList);
	        		 }
	        		 
	        	 }
	        	 

	        	 break;
	         case '3' :

	        	 if("AS".equals(recordType)){
	        		 ctcnxprnrList = ctcnxprnrDao.searchByRecTypeOfficerCodePrnDigit(recordType,officerCode,prn1,"");
	        	 }else if("AA".equals(recordType)){
	        		 ctcnxprnrList = ctcnxprnrDao.searchByRecTypeOfficerCodePrnDigit(recordType,officerCode,prn1,prn2);
	        	 }
	        	 
	        	
	        	 if( ctcnxprnrList == null || ctcnxprnrList.size() <= 0){
	        		 ctn011cResult.addFieldErrorMap("tc00111.prn1", "message.6017");
	        		 
	        		 if("AA".equals(recordType)){
	        			 ctn011cResult.addFieldErrorMap("tc00111.prn2", "message.6017");
	        		 }
	        		
	        	 }else{
	        		
        			 Ctcnxcolr ctcnxcolr = ctcnxcolrDao.selectLatestByRecTypeOfficeCodeEffDate(recordType,officerCode, refDate);
	        		 
	        		 if(ctcnxcolr == null){
	        			 ctn011cResult.addFieldErrorMap("tc00111.recordType", "message.3087");
		        		 ctn011cResult.addFieldErrorMap("tc00111.officerCode", "message.3087");
	        		 }else{
	        			 existCtcnxcolrList = new ArrayList<Ctcnxcolr>(); 
		        		 existCtcnxcolrList.add(ctcnxcolr);	        		 
		        		 
		        		 ctn011cResult.setCtcnxcolrList(existCtcnxcolrList);
	        		 }
	        		 
	        		 ctn011cResult.setCtcnxprnrList(ctcnxprnrList);
	        	 }

	            break;
	         case '4' :        	 
	        	 allCtcnxcolrList =  new ArrayList<List<Ctcnxcolr>>();   	
	        	 
	        	 existCtcnxcolrList =  ctcnxcolrDao.listAllCtcnxcolr(recordType, refDate);
	        	 
	        	 if(existCtcnxcolrList != null){
	        		 for(Ctcnxcolr ctcnxcolr : existCtcnxcolrList){
	        			 CtcnxcolrPrn ctcnxcolrPrn = new CtcnxcolrPrn();
	        			 ctcnxcolrPrn.setAgInd(ctcnxcolr.getAgInd());
	        			 ctcnxcolrPrn.setEffDate(ctcnxcolr.getEffDate());     			 
	        			 ctcnxcolrPrn.setName(ctcnxcolr.getName());
	        			 ctcnxcolrPrn.setNameChi(ctcnxcolr.getNameChi());
	        			 ctcnxcolrPrn.setOfficerCode(ctcnxcolr.getOfficerCode());
	        			 ctcnxcolrPrn.setRecType(ctcnxcolr.getRecType());
	        			 ctcnxcolrPrn.setTelNum(ctcnxcolr.getTelNum());
	        			 ctcnxcolrPrn.setPrnDigit1("");
	        			 ctcnxcolrPrn.setPrnDigit2("");
	        			 ctcnxcolrPrnList.add(ctcnxcolrPrn);
	        		 }
	        	 }	      
	        	 ctn011cResult.setCtcnxcolrPrnList(ctcnxcolrPrnList); 
	        	

		         break;
	         case '5' :
	        	
	        	 ctcnxcolrPrnList = new ArrayList<CtcnxcolrPrn>();
	        	 
	        	 CtcnxcolrPrn ctcnxcolrPrn = null;
	        	 
	        	 if("AA".equals(recordType) || "AS".equals(recordType)){
	        		 
	        		 ctcnxprnrList = ctcnxprnrDao.searchByRecType(recordType);
		        	 
		        	 if(ctcnxprnrList != null){
		        		 
		        		 for(Ctcnxprnr ctcnxprnr : ctcnxprnrList){
		        			  
		        			 ctcnxcolrPrn = new CtcnxcolrPrn();
		        			 ctcnxcolrPrn.setPrnDigit1(ctcnxprnr.getPrnDigit1());
		        			 ctcnxcolrPrn.setPrnDigit2(ctcnxprnr.getPrnDigit2());
		        			 
		        			 Ctcnxcolr ctcnxcolr =  ctcnxcolrDao.selectLatestByRecTypeOfficeCodeEffDate(ctcnxprnr.getRecType(),ctcnxprnr.getOfficerCode(), refDate);
		        			 
		        			 if(ctcnxcolr != null){
		        				 ctcnxcolrPrn.setRecType(ctcnxcolr.getRecType());
		        				 ctcnxcolrPrn.setOfficerCode(ctcnxcolr.getOfficerCode());
		        				 ctcnxcolrPrn.setName(ctcnxcolr.getName());
		        				 ctcnxcolrPrn.setNameChi(ctcnxcolr.getNameChi());
		        				 ctcnxcolrPrn.setAgInd(ctcnxcolr.getAgInd());
		        				 ctcnxcolrPrn.setEffDate(ctcnxcolr.getEffDate());
		        				 ctcnxcolrPrn.setTelNum(ctcnxcolr.getTelNum());
		        			 }
		        			 ctcnxcolrPrnList.add(ctcnxcolrPrn);	 
		        		 }
		        		
		        	 }
    	 
	        	 }else{
	        		 ctn011cResult.addFieldErrorMap("tc00111.actionCode", "message.1110");	 
	        	 }
	        	 ctn011cResult.setCtcnxcolrPrnList(ctcnxcolrPrnList);       	

		         break;


	         default :
	        	 ctn011cResult.addFieldErrorMap("tc00111.actionCode", "message.1087");
	      }

		
		
		
		return ctn011cResult;
		
	}
	
	private Date removeTime(Date inputDate) {
		Calendar cal = Calendar.getInstance();

		if (inputDate == null)
			return null;
		
		cal.setTime(inputDate);
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		
		return cal.getTime();
	}
}
