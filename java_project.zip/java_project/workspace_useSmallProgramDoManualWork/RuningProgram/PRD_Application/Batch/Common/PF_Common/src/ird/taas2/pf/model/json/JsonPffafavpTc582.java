//Check in version of BAT_PRD,23-02-18,wwypang:3:v1O8Xe4SonrzYfHWrSt12i/QVU/8efc9jpC7UmpLdDaMrZg3du3a4hxN09LewLHl
//Check in version of BAT_PRD,07-02-17,bhssham:2:JpfuoCXPcAdLPZ8FYMLD6y/QVU/8efc9jpC7UmpLdDaMrZg3du3a4hxN09LewLHl

package ird.taas2.pf.model.json;

public class JsonPffafavpTc582 {
	private String t582TradeCat;
	private String t582Brn;
	private String t582AssYr;
	private String t582RetTp;
	private String t582Ap;
	private String t582Al;
	private String t582PrtEmolumentInd;
	private String t582PrtEmolumentAdjInd;
	private String t582DateLeft1;
	private String t582DateLeft2;
	private String t582DateLeft3;
	private String t582DateLeft4;
	private String t582Prn1;
	private String t582Prn1PaInd;
	private String t582Prn1ShrPaAl;
	private String t582Prn2;
	private String t582Prn2PaInd;
	private String t582Prn2ShrPaAl;
	private String t582Prn3;
	private String t582Prn3PaInd;
	private String t582Prn3ShrPaAl;
	private String t582Prn4;
	private String t582Prn4PaInd;
	private String t582Prn4ShrPaAl;
	private String t582AcctDateInd;
	private String t582PtyPurchaseInd;
	private String t582ForeCurrencyInd;
	private String t582BusCommInd;
	private String t582BusCeaseInd;
	private String t582CeaseByDeathInd;
	private String t582BusTransferInd;
	private String t582NrSellGoodInd;
	private String t582NrIncomeRcvInd;
	private String t582NrPayForPtyInd;
	private String t582NrCarryBusInd;
	private String t582AssPftInd;
	private String t582QualifyDebtInd;
	private String t582TaxCreditClmInd;
	private String t582ArObtainInd;
	private String t582NetOsProfit;
	private String t582InternetOsProfit;
	private String t582PayToConnNr;
	private String t582CapAssetProfit;
	private String t582Donation;
	private String t582InterestIncome;
	private String t582ExpPrescribMach;
	private String t582ExpComHwSw;
	private String t582EnvProMach;
	private String t582EnvProInst;
	private String t582TaxCreditClm;
	private String t582MpfContribution;
	private String t582Turnover;
	private String t582OpenInventory;
	private String t582Purchase;
	private String t582CloseInventory;
	private String t582GrossProfit;
	private String t582GrossLoss;
	private String t582AllInterestIncome;
	private String t582InterestExpense;
	private String t582EmpRemuneration;
	private String t582CommissionPay;
	private String t582RoyaltyPay;
	private String t582MgtConsultFee;
	private String t582ContractorChrg;
	private String t582BadDebt;
	private String t582NetProfitPerAcct;
	private String t582NetLossPerAcct;
	private String t582AcctReceivable;
	private String t582AcctPayable;
	private String t582NrPayProfFee;
	private String t582NrHireCharge;
	private String t582GrossIncExceedInd;
	private String t582GrossIncome;
	private String t582DividendIncome;
	private String t582BusActivityLangInd;
	private String t582BusActivity;
	private String t582BasisPeriodSt;
	private String t582BasisPeriodEd;
	private String t582LandPtyProfit;
	private String t582EnvFriendlyVeh;
	private String t582ExpPatentRights;
	private String t582ExpCopyrights;
	private String t582AltBondInd;
	private String t582ProgRateElectInd; // MMP-PF022
	private String t582Filler;
	
	@Override
	public String toString() {
		return "JsonPffafavpTc582 [t582TradeCat=" + t582TradeCat + ", t582Brn=" + t582Brn + ", t582AssYr=" + t582AssYr + ", t582RetTp=" + t582RetTp + ", t582Ap="
				+ t582Ap + ", t582Al=" + t582Al + ", t582PrtEmolumentInd=" + t582PrtEmolumentInd + ", t582PrtEmolumentAdjInd=" + t582PrtEmolumentAdjInd
				+ ", t582DateLeft1=" + t582DateLeft1 + ", t582DateLeft2=" + t582DateLeft2 + ", t582DateLeft3=" + t582DateLeft3 + ", t582DateLeft4=" + t582DateLeft4
				+ ", t582Prn1=" + t582Prn1 + ", t582Prn1PaInd=" + t582Prn1PaInd + ", t582Prn1ShrPaAl=" + t582Prn1ShrPaAl + ", t582Prn2=" + t582Prn2
				+ ", t582Prn2PaInd=" + t582Prn2PaInd + ", t582Prn2ShrPaAl=" + t582Prn2ShrPaAl + ", t582Prn3=" + t582Prn3 + ", t582Prn3PaInd=" + t582Prn3PaInd
				+ ", t582Prn3ShrPaAl=" + t582Prn3ShrPaAl + ", t582Prn4=" + t582Prn4 + ", t582Prn4PaInd=" + t582Prn4PaInd + ", t582Prn4ShrPaAl=" + t582Prn4ShrPaAl
				+ ", t582AcctDateInd=" + t582AcctDateInd + ", t582PtyPurchaseInd=" + t582PtyPurchaseInd + ", t582ForeCurrencyInd=" + t582ForeCurrencyInd
				+ ", t582BusCommInd=" + t582BusCommInd + ", t582BusCeaseInd=" + t582BusCeaseInd + ", t582CeaseByDeathInd=" + t582CeaseByDeathInd
				+ ", t582BusTransferInd=" + t582BusTransferInd + ", t582NrSellGoodInd=" + t582NrSellGoodInd + ", t582NrIncomeRcvInd=" + t582NrIncomeRcvInd
				+ ", t582NrPayForPtyInd=" + t582NrPayForPtyInd + ", t582NrCarryBusInd=" + t582NrCarryBusInd + ", t582AssPftInd=" + t582AssPftInd
				+ ", t582QualifyDebtInd=" + t582QualifyDebtInd + ", t582TaxCreditClmInd=" + t582TaxCreditClmInd + ", t582ArObtainInd=" + t582ArObtainInd
				+ ", t582NetOsProfit=" + t582NetOsProfit + ", t582InternetOsProfit=" + t582InternetOsProfit + ", t582PayToConnNr=" + t582PayToConnNr
				+ ", t582CapAssetProfit=" + t582CapAssetProfit + ", t582Donation=" + t582Donation + ", t582InterestIncome=" + t582InterestIncome
				+ ", t582ExpPrescribMach=" + t582ExpPrescribMach + ", t582ExpComHwSw=" + t582ExpComHwSw + ", t582EnvProMach=" + t582EnvProMach + ", t582EnvProInst="
				+ t582EnvProInst + ", t582TaxCreditClm=" + t582TaxCreditClm + ", t582MpfContribution=" + t582MpfContribution + ", t582Turnover=" + t582Turnover
				+ ", t582OpenInventory=" + t582OpenInventory + ", t582Purchase=" + t582Purchase + ", t582CloseInventory=" + t582CloseInventory
				+ ", t582GrossProfit=" + t582GrossProfit + ", t582GrossLoss=" + t582GrossLoss + ", t582AllInterestIncome=" + t582AllInterestIncome
				+ ", t582InterestExpense=" + t582InterestExpense + ", t582EmpRemuneration=" + t582EmpRemuneration + ", t582CommissionPay=" + t582CommissionPay
				+ ", t582RoyaltyPay=" + t582RoyaltyPay + ", t582MgtConsultFee=" + t582MgtConsultFee + ", t582ContractorChrg=" + t582ContractorChrg
				+ ", t582BadDebt=" + t582BadDebt + ", t582NetProfitPerAcct=" + t582NetProfitPerAcct + ", t582NetLossPerAcct=" + t582NetLossPerAcct
				+ ", t582AcctReceivable=" + t582AcctReceivable + ", t582AcctPayable=" + t582AcctPayable + ", t582NrPayProfFee=" + t582NrPayProfFee
				+ ", t582NrHireCharge=" + t582NrHireCharge + ", t582GrossIncExceedInd=" + t582GrossIncExceedInd + ", t582GrossIncome=" + t582GrossIncome
				+ ", t582DividendIncome=" + t582DividendIncome + ", t582BusActivityLangInd=" + t582BusActivityLangInd + ", t582BusActivity=" + t582BusActivity
				+ ", t582BasisPeriodSt=" + t582BasisPeriodSt + ", t582BasisPeriodEd=" + t582BasisPeriodEd + ", t582LandPtyProfit=" + t582LandPtyProfit
				+ ", t582EnvFriendlyVeh=" + t582EnvFriendlyVeh + ", t582ExpPatentRights=" + t582ExpPatentRights + ", t582ExpCopyrights=" + t582ExpCopyrights
				+ ", t582AltBondInd=" + t582AltBondInd + ", t582ProgRateElectInd=" + t582ProgRateElectInd + ", t582Filler=" + t582Filler + "]";
	}

	public String getT582TradeCat() {
		return t582TradeCat;
	}

	public void setT582TradeCat(String t582TradeCat) {
		this.t582TradeCat = t582TradeCat;
	}

	public String getT582Brn() {
		return t582Brn;
	}

	public void setT582Brn(String t582Brn) {
		this.t582Brn = t582Brn;
	}

	public String getT582AssYr() {
		return t582AssYr;
	}

	public void setT582AssYr(String t582AssYr) {
		this.t582AssYr = t582AssYr;
	}

	public String getT582RetTp() {
		return t582RetTp;
	}

	public void setT582RetTp(String t582RetTp) {
		this.t582RetTp = t582RetTp;
	}

	public String getT582Ap() {
		return t582Ap;
	}

	public void setT582Ap(String t582Ap) {
		this.t582Ap = t582Ap;
	}

	public String getT582Al() {
		return t582Al;
	}

	public void setT582Al(String t582Al) {
		this.t582Al = t582Al;
	}

	public String getT582PrtEmolumentInd() {
		return t582PrtEmolumentInd;
	}

	public void setT582PrtEmolumentInd(String t582PrtEmolumentInd) {
		this.t582PrtEmolumentInd = t582PrtEmolumentInd;
	}

	public String getT582PrtEmolumentAdjInd() {
		return t582PrtEmolumentAdjInd;
	}

	public void setT582PrtEmolumentAdjInd(String t582PrtEmolumentAdjInd) {
		this.t582PrtEmolumentAdjInd = t582PrtEmolumentAdjInd;
	}

	public String getT582DateLeft1() {
		return t582DateLeft1;
	}

	public void setT582DateLeft1(String t582DateLeft1) {
		this.t582DateLeft1 = t582DateLeft1;
	}

	public String getT582DateLeft2() {
		return t582DateLeft2;
	}

	public void setT582DateLeft2(String t582DateLeft2) {
		this.t582DateLeft2 = t582DateLeft2;
	}

	public String getT582DateLeft3() {
		return t582DateLeft3;
	}

	public void setT582DateLeft3(String t582DateLeft3) {
		this.t582DateLeft3 = t582DateLeft3;
	}

	public String getT582DateLeft4() {
		return t582DateLeft4;
	}

	public void setT582DateLeft4(String t582DateLeft4) {
		this.t582DateLeft4 = t582DateLeft4;
	}

	public String getT582Prn1() {
		return t582Prn1;
	}

	public void setT582Prn1(String t582Prn1) {
		this.t582Prn1 = t582Prn1;
	}

	public String getT582Prn1PaInd() {
		return t582Prn1PaInd;
	}

	public void setT582Prn1PaInd(String t582Prn1PaInd) {
		this.t582Prn1PaInd = t582Prn1PaInd;
	}

	public String getT582Prn1ShrPaAl() {
		return t582Prn1ShrPaAl;
	}

	public void setT582Prn1ShrPaAl(String t582Prn1ShrPaAl) {
		this.t582Prn1ShrPaAl = t582Prn1ShrPaAl;
	}

	public String getT582Prn2() {
		return t582Prn2;
	}

	public void setT582Prn2(String t582Prn2) {
		this.t582Prn2 = t582Prn2;
	}

	public String getT582Prn2PaInd() {
		return t582Prn2PaInd;
	}

	public void setT582Prn2PaInd(String t582Prn2PaInd) {
		this.t582Prn2PaInd = t582Prn2PaInd;
	}

	public String getT582Prn2ShrPaAl() {
		return t582Prn2ShrPaAl;
	}

	public void setT582Prn2ShrPaAl(String t582Prn2ShrPaAl) {
		this.t582Prn2ShrPaAl = t582Prn2ShrPaAl;
	}

	public String getT582Prn3() {
		return t582Prn3;
	}

	public void setT582Prn3(String t582Prn3) {
		this.t582Prn3 = t582Prn3;
	}

	public String getT582Prn3PaInd() {
		return t582Prn3PaInd;
	}

	public void setT582Prn3PaInd(String t582Prn3PaInd) {
		this.t582Prn3PaInd = t582Prn3PaInd;
	}

	public String getT582Prn3ShrPaAl() {
		return t582Prn3ShrPaAl;
	}

	public void setT582Prn3ShrPaAl(String t582Prn3ShrPaAl) {
		this.t582Prn3ShrPaAl = t582Prn3ShrPaAl;
	}

	public String getT582Prn4() {
		return t582Prn4;
	}

	public void setT582Prn4(String t582Prn4) {
		this.t582Prn4 = t582Prn4;
	}

	public String getT582Prn4PaInd() {
		return t582Prn4PaInd;
	}

	public void setT582Prn4PaInd(String t582Prn4PaInd) {
		this.t582Prn4PaInd = t582Prn4PaInd;
	}

	public String getT582Prn4ShrPaAl() {
		return t582Prn4ShrPaAl;
	}

	public void setT582Prn4ShrPaAl(String t582Prn4ShrPaAl) {
		this.t582Prn4ShrPaAl = t582Prn4ShrPaAl;
	}

	public String getT582AcctDateInd() {
		return t582AcctDateInd;
	}

	public void setT582AcctDateInd(String t582AcctDateInd) {
		this.t582AcctDateInd = t582AcctDateInd;
	}

	public String getT582PtyPurchaseInd() {
		return t582PtyPurchaseInd;
	}

	public void setT582PtyPurchaseInd(String t582PtyPurchaseInd) {
		this.t582PtyPurchaseInd = t582PtyPurchaseInd;
	}

	public String getT582ForeCurrencyInd() {
		return t582ForeCurrencyInd;
	}

	public void setT582ForeCurrencyInd(String t582ForeCurrencyInd) {
		this.t582ForeCurrencyInd = t582ForeCurrencyInd;
	}

	public String getT582BusCommInd() {
		return t582BusCommInd;
	}

	public void setT582BusCommInd(String t582BusCommInd) {
		this.t582BusCommInd = t582BusCommInd;
	}

	public String getT582BusCeaseInd() {
		return t582BusCeaseInd;
	}

	public void setT582BusCeaseInd(String t582BusCeaseInd) {
		this.t582BusCeaseInd = t582BusCeaseInd;
	}

	public String getT582CeaseByDeathInd() {
		return t582CeaseByDeathInd;
	}

	public void setT582CeaseByDeathInd(String t582CeaseByDeathInd) {
		this.t582CeaseByDeathInd = t582CeaseByDeathInd;
	}

	public String getT582BusTransferInd() {
		return t582BusTransferInd;
	}

	public void setT582BusTransferInd(String t582BusTransferInd) {
		this.t582BusTransferInd = t582BusTransferInd;
	}

	public String getT582NrSellGoodInd() {
		return t582NrSellGoodInd;
	}

	public void setT582NrSellGoodInd(String t582NrSellGoodInd) {
		this.t582NrSellGoodInd = t582NrSellGoodInd;
	}

	public String getT582NrIncomeRcvInd() {
		return t582NrIncomeRcvInd;
	}

	public void setT582NrIncomeRcvInd(String t582NrIncomeRcvInd) {
		this.t582NrIncomeRcvInd = t582NrIncomeRcvInd;
	}

	public String getT582NrPayForPtyInd() {
		return t582NrPayForPtyInd;
	}

	public void setT582NrPayForPtyInd(String t582NrPayForPtyInd) {
		this.t582NrPayForPtyInd = t582NrPayForPtyInd;
	}

	public String getT582NrCarryBusInd() {
		return t582NrCarryBusInd;
	}

	public void setT582NrCarryBusInd(String t582NrCarryBusInd) {
		this.t582NrCarryBusInd = t582NrCarryBusInd;
	}

	public String getT582AssPftInd() {
		return t582AssPftInd;
	}

	public void setT582AssPftInd(String t582AssPftInd) {
		this.t582AssPftInd = t582AssPftInd;
	}

	public String getT582QualifyDebtInd() {
		return t582QualifyDebtInd;
	}

	public void setT582QualifyDebtInd(String t582QualifyDebtInd) {
		this.t582QualifyDebtInd = t582QualifyDebtInd;
	}

	public String getT582TaxCreditClmInd() {
		return t582TaxCreditClmInd;
	}

	public void setT582TaxCreditClmInd(String t582TaxCreditClmInd) {
		this.t582TaxCreditClmInd = t582TaxCreditClmInd;
	}

	public String getT582ArObtainInd() {
		return t582ArObtainInd;
	}

	public void setT582ArObtainInd(String t582ArObtainInd) {
		this.t582ArObtainInd = t582ArObtainInd;
	}

	public String getT582NetOsProfit() {
		return t582NetOsProfit;
	}

	public void setT582NetOsProfit(String t582NetOsProfit) {
		this.t582NetOsProfit = t582NetOsProfit;
	}

	public String getT582InternetOsProfit() {
		return t582InternetOsProfit;
	}

	public void setT582InternetOsProfit(String t582InternetOsProfit) {
		this.t582InternetOsProfit = t582InternetOsProfit;
	}

	public String getT582PayToConnNr() {
		return t582PayToConnNr;
	}

	public void setT582PayToConnNr(String t582PayToConnNr) {
		this.t582PayToConnNr = t582PayToConnNr;
	}

	public String getT582CapAssetProfit() {
		return t582CapAssetProfit;
	}

	public void setT582CapAssetProfit(String t582CapAssetProfit) {
		this.t582CapAssetProfit = t582CapAssetProfit;
	}

	public String getT582Donation() {
		return t582Donation;
	}

	public void setT582Donation(String t582Donation) {
		this.t582Donation = t582Donation;
	}

	public String getT582InterestIncome() {
		return t582InterestIncome;
	}

	public void setT582InterestIncome(String t582InterestIncome) {
		this.t582InterestIncome = t582InterestIncome;
	}

	public String getT582ExpPrescribMach() {
		return t582ExpPrescribMach;
	}

	public void setT582ExpPrescribMach(String t582ExpPrescribMach) {
		this.t582ExpPrescribMach = t582ExpPrescribMach;
	}

	public String getT582ExpComHwSw() {
		return t582ExpComHwSw;
	}

	public void setT582ExpComHwSw(String t582ExpComHwSw) {
		this.t582ExpComHwSw = t582ExpComHwSw;
	}

	public String getT582EnvProMach() {
		return t582EnvProMach;
	}

	public void setT582EnvProMach(String t582EnvProMach) {
		this.t582EnvProMach = t582EnvProMach;
	}

	public String getT582EnvProInst() {
		return t582EnvProInst;
	}

	public void setT582EnvProInst(String t582EnvProInst) {
		this.t582EnvProInst = t582EnvProInst;
	}

	public String getT582TaxCreditClm() {
		return t582TaxCreditClm;
	}

	public void setT582TaxCreditClm(String t582TaxCreditClm) {
		this.t582TaxCreditClm = t582TaxCreditClm;
	}

	public String getT582MpfContribution() {
		return t582MpfContribution;
	}

	public void setT582MpfContribution(String t582MpfContribution) {
		this.t582MpfContribution = t582MpfContribution;
	}

	public String getT582Turnover() {
		return t582Turnover;
	}

	public void setT582Turnover(String t582Turnover) {
		this.t582Turnover = t582Turnover;
	}

	public String getT582OpenInventory() {
		return t582OpenInventory;
	}

	public void setT582OpenInventory(String t582OpenInventory) {
		this.t582OpenInventory = t582OpenInventory;
	}

	public String getT582Purchase() {
		return t582Purchase;
	}

	public void setT582Purchase(String t582Purchase) {
		this.t582Purchase = t582Purchase;
	}

	public String getT582CloseInventory() {
		return t582CloseInventory;
	}

	public void setT582CloseInventory(String t582CloseInventory) {
		this.t582CloseInventory = t582CloseInventory;
	}

	public String getT582GrossProfit() {
		return t582GrossProfit;
	}

	public void setT582GrossProfit(String t582GrossProfit) {
		this.t582GrossProfit = t582GrossProfit;
	}

	public String getT582GrossLoss() {
		return t582GrossLoss;
	}

	public void setT582GrossLoss(String t582GrossLoss) {
		this.t582GrossLoss = t582GrossLoss;
	}

	public String getT582AllInterestIncome() {
		return t582AllInterestIncome;
	}

	public void setT582AllInterestIncome(String t582AllInterestIncome) {
		this.t582AllInterestIncome = t582AllInterestIncome;
	}

	public String getT582InterestExpense() {
		return t582InterestExpense;
	}

	public void setT582InterestExpense(String t582InterestExpense) {
		this.t582InterestExpense = t582InterestExpense;
	}

	public String getT582EmpRemuneration() {
		return t582EmpRemuneration;
	}

	public void setT582EmpRemuneration(String t582EmpRemuneration) {
		this.t582EmpRemuneration = t582EmpRemuneration;
	}

	public String getT582CommissionPay() {
		return t582CommissionPay;
	}

	public void setT582CommissionPay(String t582CommissionPay) {
		this.t582CommissionPay = t582CommissionPay;
	}

	public String getT582RoyaltyPay() {
		return t582RoyaltyPay;
	}

	public void setT582RoyaltyPay(String t582RoyaltyPay) {
		this.t582RoyaltyPay = t582RoyaltyPay;
	}

	public String getT582MgtConsultFee() {
		return t582MgtConsultFee;
	}

	public void setT582MgtConsultFee(String t582MgtConsultFee) {
		this.t582MgtConsultFee = t582MgtConsultFee;
	}

	public String getT582ContractorChrg() {
		return t582ContractorChrg;
	}

	public void setT582ContractorChrg(String t582ContractorChrg) {
		this.t582ContractorChrg = t582ContractorChrg;
	}

	public String getT582BadDebt() {
		return t582BadDebt;
	}

	public void setT582BadDebt(String t582BadDebt) {
		this.t582BadDebt = t582BadDebt;
	}

	public String getT582NetProfitPerAcct() {
		return t582NetProfitPerAcct;
	}

	public void setT582NetProfitPerAcct(String t582NetProfitPerAcct) {
		this.t582NetProfitPerAcct = t582NetProfitPerAcct;
	}

	public String getT582NetLossPerAcct() {
		return t582NetLossPerAcct;
	}

	public void setT582NetLossPerAcct(String t582NetLossPerAcct) {
		this.t582NetLossPerAcct = t582NetLossPerAcct;
	}

	public String getT582AcctReceivable() {
		return t582AcctReceivable;
	}

	public void setT582AcctReceivable(String t582AcctReceivable) {
		this.t582AcctReceivable = t582AcctReceivable;
	}

	public String getT582AcctPayable() {
		return t582AcctPayable;
	}

	public void setT582AcctPayable(String t582AcctPayable) {
		this.t582AcctPayable = t582AcctPayable;
	}

	public String getT582NrPayProfFee() {
		return t582NrPayProfFee;
	}

	public void setT582NrPayProfFee(String t582NrPayProfFee) {
		this.t582NrPayProfFee = t582NrPayProfFee;
	}

	public String getT582NrHireCharge() {
		return t582NrHireCharge;
	}

	public void setT582NrHireCharge(String t582NrHireCharge) {
		this.t582NrHireCharge = t582NrHireCharge;
	}

	public String getT582GrossIncExceedInd() {
		return t582GrossIncExceedInd;
	}

	public void setT582GrossIncExceedInd(String t582GrossIncExceedInd) {
		this.t582GrossIncExceedInd = t582GrossIncExceedInd;
	}

	public String getT582GrossIncome() {
		return t582GrossIncome;
	}

	public void setT582GrossIncome(String t582GrossIncome) {
		this.t582GrossIncome = t582GrossIncome;
	}

	public String getT582DividendIncome() {
		return t582DividendIncome;
	}

	public void setT582DividendIncome(String t582DividendIncome) {
		this.t582DividendIncome = t582DividendIncome;
	}

	public String getT582BusActivityLangInd() {
		return t582BusActivityLangInd;
	}

	public void setT582BusActivityLangInd(String t582BusActivityLangInd) {
		this.t582BusActivityLangInd = t582BusActivityLangInd;
	}

	public String getT582BusActivity() {
		return t582BusActivity;
	}

	public void setT582BusActivity(String t582BusActivity) {
		this.t582BusActivity = t582BusActivity;
	}

	public String getT582BasisPeriodSt() {
		return t582BasisPeriodSt;
	}

	public void setT582BasisPeriodSt(String t582BasisPeriodSt) {
		this.t582BasisPeriodSt = t582BasisPeriodSt;
	}

	public String getT582BasisPeriodEd() {
		return t582BasisPeriodEd;
	}

	public void setT582BasisPeriodEd(String t582BasisPeriodEd) {
		this.t582BasisPeriodEd = t582BasisPeriodEd;
	}

	public String getT582LandPtyProfit() {
		return t582LandPtyProfit;
	}

	public void setT582LandPtyProfit(String t582LandPtyProfit) {
		this.t582LandPtyProfit = t582LandPtyProfit;
	}

	public String getT582EnvFriendlyVeh() {
		return t582EnvFriendlyVeh;
	}

	public void setT582EnvFriendlyVeh(String t582EnvFriendlyVeh) {
		this.t582EnvFriendlyVeh = t582EnvFriendlyVeh;
	}

	public String getT582ExpPatentRights() {
		return t582ExpPatentRights;
	}

	public void setT582ExpPatentRights(String t582ExpPatentRights) {
		this.t582ExpPatentRights = t582ExpPatentRights;
	}

	public String getT582ExpCopyrights() {
		return t582ExpCopyrights;
	}

	public void setT582ExpCopyrights(String t582ExpCopyrights) {
		this.t582ExpCopyrights = t582ExpCopyrights;
	}

	public String getT582AltBondInd() {
		return t582AltBondInd;
	}

	public void setT582AltBondInd(String t582AltBondInd) {
		this.t582AltBondInd = t582AltBondInd;
	}

	public String getT582ProgRateElectInd() {
		return t582ProgRateElectInd;
	}

	public void setT582ProgRateElectInd(String t582ProgRateElectInd) {
		this.t582ProgRateElectInd = t582ProgRateElectInd;
	}

	public String getT582Filler() {
		return t582Filler;
	}

	public void setT582Filler(String t582Filler) {
		this.t582Filler = t582Filler;
	}

	
	
}
