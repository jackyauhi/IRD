
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.FileUtils;

public class FindWrongToken {
	
	public static void main(String[] args) throws IOException{
		String dirStr = "D:\\ccshare\\jyyau_view_ClearCase_MTN\\TAAS2_UAT\\CloudMigration\\Application";
		
		List<String> fileList = Files.readAllLines(new File("version_list.txt").toPath(), Charset.defaultCharset());
		fileList.removeIf(s -> !s.startsWith("Batch")&&!s.startsWith("Online"));
		
		HashMap<String, String> map = new HashMap<String, String>();
		
		
		for(String str : fileList) {
			String[] a = str.split("\\s+");
			map.put(a[1], a[0]);
		}
		
		
		
		for(String key : map.keySet()){
			String path = dirStr + key;
			String def = map.get(key);
			
			// System.out.println(path);
			
			
			// System.out.println(BatchOrOnline(path));
			String fDef = BatchOrOnline(path);
			if(fDef == null) continue;
			
			if(!def.equals(fDef)){
				
				
				String slash = "";
				String srcpath = "D:\\ccshare\\jyyau_view_ClearCase_PRD\\TAAS2_DEV\\PRD_Application\\" + map.get(key) + slash +key;
				//srcpath = srcpath + "\\"+key+"\\";
				
				String despath = srcpath.replace("D:\\ccshare\\jyyau_view_ClearCase_PRD\\TAAS2_DEV\\", "");
				System.out.println("" + srcpath);
				System.out.println("" + despath);
				
				System.out.println("" + def);
				System.out.println("" + fDef);
				
				File f1 = new File(srcpath);
				File f2 = new File(despath);
				copyFileUsingApacheCommonsIO(f1, f2);
				
				
				System.out.println("================================");
			}
				
			
		}
		
		
	}
	
	
	static String BatchOrOnline(String fileStr) {
		try{
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(fileStr), "UTF-8"));
			String sCurrentLine;
			while ((sCurrentLine = br.readLine()) != null) {
				if(sCurrentLine.contains("BAT_PRD")) return "Batch";
				if(sCurrentLine.contains("WAS_PRD")) return "Online";
			}
			return null;
		}catch(Exception e){
			System.out.println(e);
			return null;
		}
	}
	
	private static void copyFileUsingApacheCommonsIO(File source, File dest) throws IOException {
	    FileUtils.copyFile(source, dest);
	}

}
