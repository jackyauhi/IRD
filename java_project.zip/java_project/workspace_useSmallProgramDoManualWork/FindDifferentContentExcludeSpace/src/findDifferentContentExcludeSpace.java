import java.io.BufferedReader;

import java.io.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class findDifferentContentExcludeSpace {
	public static ArrayList<String> inputFileList = new ArrayList<String>();
	public static ArrayList<String> outputFileList = new ArrayList<String>();
	public static List<String> batchFileList = new ArrayList<String>();
	public static List<String> onlineFileList = new ArrayList<String>();
	public static String batchContent = "";
	public static String onlineContent = "";
	public static List<String> result = new ArrayList<String>();
	public static void main(String[] args) throws Exception{
//		checkCorrectFormal = checkCorrectFormal.replaceAll("\\s*", "");
    	 try (Stream<Path> walk = Files.walk(Paths.get("D:\\Alex_things\\TAAS2_DEV (BAT_PRD)\\TAAS2_DEV\\PRD_Application\\Batch"))) {

    		List<String> result = walk.filter(Files::isRegularFile)
    				.map(x -> x.toString()).collect(Collectors.toList());

//    		result.forEach(System.out::println);
    		batchFileList=result;
    	} catch (IOException e) {
    		e.printStackTrace();
    	}
    	 try (Stream<Path> walk = Files.walk(Paths.get("D:\\Alex_things\\TAAS2_DEV (WAS_PRD)\\TAAS2_DEV\\PRD_Application\\Online"))) {

    		List<String> result = walk.filter(Files::isRegularFile)
    				.map(x -> x.toString()).collect(Collectors.toList());

//    		result.forEach(System.out::println);
    		onlineFileList=result;
    	} catch (IOException e) {
    		e.printStackTrace();
    	}
    	 for (int i = 0; i < batchFileList.size(); i++) {
    		 String[] batchFolderPath = batchFileList.get(i).toString().split(Pattern.quote("\\Batch"),2);
    		 for (int j = 0; j < onlineFileList.size(); j++) {
    			 String[] onlineFolderPath = onlineFileList.get(j).toString().split(Pattern.quote("\\Online"),2);
    			 if(batchFolderPath[1].equals(onlineFolderPath[1])) {
    					String batchContent = "";
    					String onlineContent = "";
    					String batchContentWithoutAllSpace = "";
    					String onlineContentWithoutAllSpace = "";
    				 try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(batchFileList.get(i).toString()), "UTF-8"))) {	
    			            // read line by line
    			            String line;
    			            while ((line = br.readLine()) != null) {
    			            	batchContent=batchContent+line+System.lineSeparator();  	                      
    			            }

    			        } catch (IOException e) {
    			            System.err.format("IOException: %s%n", e);
    			        }
    				 try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(onlineFileList.get(j).toString()), "UTF-8"))) {	
 			            // read line by line
 			            String line;
 			            while ((line = br.readLine()) != null) {
 			            	onlineContent=onlineContent+line+System.lineSeparator();  	                      
 			            }

 			        } catch (IOException e) {
 			            System.err.format("IOException: %s%n", e);
 			        }
//    				 batchContentWithoutAllSpace=batchContent;
//    				 onlineContentWithoutAllSpace=onlineContent;
    				 File savepath = new File(batchFileList.get(i).toString());
    				 String fileName = savepath.getName();
    				 String splitContent="";
    				 if(fileName.toLowerCase().contains(".xml")) {
    					 splitContent="<!DOCTYPE";
    				 }
    				 else if(fileName.toLowerCase().contains(".java")){
    					 splitContent="import";
    				 }
    				 String[] RemoveBatchFrontContent = batchContent.split(Pattern.quote(splitContent),2);
    				 String RealBatchContent="";
    				 String RealOnlineContent="";
    				 if(RemoveBatchFrontContent.length==2) {
    					 RealBatchContent=RemoveBatchFrontContent[1];
    		       		}
    				 else {
    					 System.out.println("BBBBBB ="+batchFileList.get(i).toString());
    					 RemoveBatchFrontContent=batchContent.split("package",2);
    					 RealBatchContent=RemoveBatchFrontContent[1];
    				 }
    				 String[] RemoveOnlineFrontContent= onlineContent.split(Pattern.quote(splitContent),2);
//    					checkCorrectFormal = checkCorrectFormal.replaceAll("\\s*", "");
       				 if(RemoveOnlineFrontContent.length==2) {
       					RealOnlineContent=RemoveOnlineFrontContent[1];
    		       		}
       				 else {
       					System.out.println("AAAAAA ="+onlineFileList.get(j).toString());
       					RemoveOnlineFrontContent=onlineContent.split("package",2);
       					RealOnlineContent=RemoveOnlineFrontContent[1];
       				 }
       				batchContentWithoutAllSpace=RealBatchContent;
       				onlineContentWithoutAllSpace=RealOnlineContent;
       				
       				batchContentWithoutAllSpace=batchContentWithoutAllSpace.replaceAll("\\s*", "");
       				onlineContentWithoutAllSpace=onlineContentWithoutAllSpace.replaceAll("\\s*", "");
       				
       				if(batchContentWithoutAllSpace.equals(onlineContentWithoutAllSpace)) {
       					File onlineSourceFile = new File(onlineFileList.get(j).toString());
       					File batchSourceFile = new File(batchFileList.get(i).toString());
       					File fileToSave = new File("T:\\jackyau\\onlineDifferent"+onlineFolderPath[1]);
       					File fileToSaveParent=new File(fileToSave.getParent());
       					if (!fileToSaveParent.exists()) {
       						fileToSaveParent.mkdirs();
       					}
       					fileToSave = new File("T:\\jackyau\\batchDifferent"+batchFolderPath[1]);
       					fileToSaveParent=new File(fileToSave.getParent());
       					if (!fileToSaveParent.exists()) {
       						fileToSaveParent.mkdirs();
       					}
       					File onlineTargetFile = new File("T:\\jackyau\\onlineDifferent"+onlineFolderPath[1]);
       					File batchTargetFile = new File("T:\\jackyau\\batchDifferent"+batchFolderPath[1]);
       					result.add(batchFileList.get(i).toString()+","+onlineFileList.get(j).toString()+","+fileName+","+"Yes");
       					transform(onlineSourceFile,"UTF-8",onlineTargetFile,"UTF-8");
       					transform(batchSourceFile,"UTF-8",batchTargetFile,"UTF-8");
       				}
       				else {
       					result.add(batchFileList.get(i).toString()+","+onlineFileList.get(j).toString()+","+fileName);
       				}
       				
    			 }
    		 } 
    	 }
			try {
			FileWriter fileWriter = new FileWriter("T:\\jackyau\\Non-DifferentList.csv");
			fileWriter.write("Batch Path"+","+"Online Path"+","+"File Name"+","+"False Alarm?"+System.lineSeparator());
			for (int j = 0; j < result.size(); j++) {
			fileWriter.write(result.get(j).toString()+System.lineSeparator());
			}
			fileWriter.close();
		} catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data in BeforeConversion");
		}
//		try {
//			FileWriter fileWriter = new FileWriter("T:\\jackyau\\testingResult\\result.txt");
//			for (int j = 0; j < fileList.size(); j++) {
//			fileWriter.write(fileList.get(j).toString()+System.lineSeparator());
//			}
//			fileWriter.close();
//		} catch (IOException iox) {
//			iox.printStackTrace();
//			System.out.println("File can not save any data in BeforeConversion");
//		}
		
	}
	public static void transform(File source, String srcEncoding, File target, String tgtEncoding) throws IOException {
	    BufferedReader br = null;
	    BufferedWriter bw = null;
	    try{
	        br = new BufferedReader(new InputStreamReader(new FileInputStream(source),srcEncoding));
	        bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(target), tgtEncoding));
	        char[] buffer = new char[16384];
	        int read;
	        while ((read = br.read(buffer)) != -1)
	            bw.write(buffer, 0, read);
	    } finally {
	        try {
	            if (br != null)
	                br.close();
	        } finally {
	            if (bw != null)
	                bw.close();
	        }
	    }
	}
}
	