import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream;

public class CheckGzipLog {
	public static List<String> tsit0383JobSample = new ArrayList<String>();
	public static List<String> tsit0410JobSample = new ArrayList<String>();
	public static List<String> removeJobList = new ArrayList<String>();
	private static String path;
	private static String[] jobs;
	private static HashMap<String, String> failJobLogFile = new HashMap<String, String>();
	private static Boolean jobIsPostOnline(String name) {
		for(String job:jobs) {
			if(name.contains(job))
				return true;
		}
		return false;
	}
	
	private static HashMap<String, Boolean> checkLog(File file) {
		TarArchiveInputStream tarInput;
		HashMap<String, Boolean> result = new HashMap<String, Boolean>();
		HashMap<String, String> fileLog = new HashMap<String, String>();
		failJobLogFile.clear();
		boolean failJobName=false;
		boolean successJobName=false;
	    String checkJobName="";
	    String currentJobName="";
		try {
			tarInput = new TarArchiveInputStream(new GzipCompressorInputStream(new FileInputStream(file)));
			TarArchiveEntry currentEntry = tarInput.getNextTarEntry();
			BufferedReader br = null;
//			boolean jobNameReferenceDetermind=false;
			String jobNameReference="";
		    String requiredJobName = "";
			int count=0;
			while (currentEntry != null) {
			    br = new BufferedReader(new InputStreamReader(tarInput)); // Read directly from tarInput
			    String jobName = currentEntry.getName().split("\\.")[0];
			    String jobFullName = currentEntry.getName();
			    if(!checkJobName.equals(jobName)) {
//			    	System.out.println("checkJobName="+checkJobName);
			    	if(count>0) {
			    		if(!failJobName) {
			    			if(successJobName) {
			    				result.replace(checkJobName, true);
			    			}
			    		}
			    	}
			    	checkJobName=jobName;
			    	count++;
			    }
				if(!jobName.equals(jobNameReference)) {
					jobNameReference=jobName;
					failJobName=false;
					successJobName=false;
				}
			    if(jobIsPostOnline(jobName)) {
				    if(!result.containsKey(jobName)) {
				    	result.put(jobName, false);
				    }			    
				    String line;
					String contentLowerCase="";
				    while ((line = br.readLine()) != null) {
				    	if(line.contains(" completed successfully")&&line.contains(jobName.substring(0, 6))) {
//				    		if(jobFullName.contains("ERDOL0.17.LOG.20211021090115")) {
//				    			System.out.println("Here");
//				    		}
				    		successJobName=true;
				    	}	
				    	contentLowerCase=line.toLowerCase();
				    	if(contentLowerCase.contains("exit status")) {
//				    		if(jobFullName.contains("ERDOL0.17.LOG.20211021223609")) {
//				    			System.out.println("Here");
//				    		}
				    		if(contentLowerCase.contains("failed")) {
				    			requiredJobName=currentEntry.getName();
				    			failJobName=true;
				    		}
				    		if(contentLowerCase.contains("error")) {
				    			requiredJobName=currentEntry.getName();
				    			failJobName=true;
				    		}
				    	}
//				    	else if(line.contains("ERROR")) {
//				    			failJobName=true;
//				    			System.out.println("jobFullName = "+jobFullName);
//				    	}    	
				    }
			    }
//			    System.out.println("jobName="+jobName);
			    if(failJobName) {
			    	fileLog.put(jobName,requiredJobName);
			    }
			    else {
			    	fileLog.put(jobName,currentEntry.getName());
			    }
//			    currentJobName=currentEntry.getName();
			    currentEntry = tarInput.getNextTarEntry(); // You forgot to iterate to the next file
			}
//			for(String key:result.keySet()) {
//				System.out.println(key+": "+result.get(key));
//			}
    		if(!failJobName) {
    			if(successJobName) {
    				result.replace(checkJobName, true);
    			}
    		}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			tarInput = new TarArchiveInputStream(new GzipCompressorInputStream(new FileInputStream(file)));
			String fileName = file.getName().split("\\.")[0];
//			System.out.println("file =" +fileName);

			TarArchiveEntry currentEntry = tarInput.getNextTarEntry();
			BufferedReader br = null;
			while (currentEntry != null) {
				br = new BufferedReader(new InputStreamReader(tarInput)); // Read directly from tarInput
				String jobNameReal = currentEntry.getName();
//		    	System.out.println("jobNameReal="+jobNameReal);
				String jobName = currentEntry.getName().split("\\.")[0];
				for(String value: fileLog.values()) {
					if(jobNameReal.equals(value)) {
						String content="";
						String line;
					    while ((line = br.readLine()) != null) {
					    	content=content+line+System.lineSeparator();
					    }
					    failJobLogFile.put(jobNameReal, content);
					}
				}
				currentEntry = tarInput.getNextTarEntry(); // You forgot to iterate to the next file
			}
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;

	}

	public static void main(String[] args) throws Exception {
		
		//String urlPath = CheckGzipLog.class.getProtectionDomain().getCodeSource().getLocation().getPath();
		//path = URLDecoder.decode(urlPath, "UTF-8");
		path=args[0]+"\\gz";

		System.out.println(path);
		File folder = new File(path);
		File[] listOfFiles = folder.listFiles();
		
		PrintStream writer = new PrintStream(args[0]+"\\result.txt", "UTF-8");
		
		try (InputStream input = new FileInputStream(args[0]+"\\config.properties")) {

            Properties prop = new Properties();

            // load a properties file
            prop.load(input);

            // get the property value and print it out
            jobs = prop.getProperty("jobs").split(",");

        } catch (IOException ex) {
            ex.printStackTrace();
        }
//		String tsit0410SampleResult = new String();
//		String tsit0383SampleResult = new String();
//		 try {
//			 tsit0383SampleResult = new String(Files.readAllBytes(Paths.get(args[0]+"\\tsit0383SampleResult.txt")));
//			 tsit0410SampleResult = new String(Files.readAllBytes(Paths.get(args[0]+"\\tsit0410SampleResult.txt")));
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
			try {
				BufferedReader fileReader = new BufferedReader(new FileReader(args[0]+"\\tsit0383SampleResult.txt"));
				String line=null;
			    try {
					while ((line = fileReader.readLine()) != null)
					{	
						tsit0383JobSample.add(line);
					}
					fileReader.close();
					fileReader= new BufferedReader(new FileReader(args[0]+"\\tsit0410SampleResult.txt"));
					while ((line = fileReader.readLine()) != null)
					{	
						tsit0410JobSample.add(line);
					}
					fileReader.close();
				} 
			    catch (IOException e1) {
					e1.printStackTrace();
				}
				} 
		   	catch (FileNotFoundException e1) {
					e1.printStackTrace();
				}
		 String systemSection ="";
		for(File file:listOfFiles) {
			if(file.getName().endsWith(".tar.gz")) {
//				System.out.println("filePath = "+file.getName());
				System.out.println("filePathName = "+file.getName().split("\\.")[0]);
				HashMap<String, Boolean> result = checkLog(file);
				writer.println("-----------------"+file.getName()+"-----------------");
				for(String key:result.keySet()) {
					if(result.get(key)) {
//						System.out.println("key!!!! = "+key);
						writer.println(key+": success");
						removeJobList.add(key);
						if(file.getName().split("\\.")[0].toLowerCase().contains("tsit0383")) {
							tsit0383JobSample.removeAll(removeJobList);
						}
						else {
							tsit0410JobSample.removeAll(removeJobList);
						}
					}else {
						writer.println(key+": failed-----------------------------------");
						for(String keyValue: failJobLogFile.keySet()) {
							String jobName = keyValue.split("\\.")[0];
							String folderName = file.getName().split("\\.")[0];
							if(jobName.equals(key)) {
//								System.out.println("key = "+keyValue);
//								System.out.println("jobName = "+jobName);
								removeJobList.add(jobName);
								if(file.getName().split("\\.")[0].toLowerCase().contains("tsit0383")) {
									tsit0383JobSample.removeAll(removeJobList);
								}
								else {
									tsit0410JobSample.removeAll(removeJobList);
								}
								try {												
									File fileToSave = new File(path+"\\"+folderName+"\\"+keyValue);
									File fileToSaveParent=new File(fileToSave.getParent());
									if (!fileToSaveParent.exists()) {
										fileToSaveParent.mkdirs();
									}
//									System.out.println(" failJobLogFile.size() ="+ failJobLogFile.size());
									FileWriter fileWriter = new FileWriter(path+"\\"+folderName+"\\"+keyValue);
									for (int j = 0; j < failJobLogFile.size(); j++) {
										fileWriter.write(failJobLogFile.get(keyValue)+ System.lineSeparator());
									}
									fileWriter.close();
								} catch (IOException iox) {
									iox.printStackTrace();
									System.out.println("File can not save any data in inputFileList");
									}
							}
						}
					}
					removeJobList.clear();
				}
				if(file.getName().split("\\.")[0].toLowerCase().contains("tsit0383")) {
					for (int j = 0; j < tsit0383JobSample.size(); j++) {
						writer.println(tsit0383JobSample.get(j).toString()+": not run this job-----------------------------------");
					}
				}
				else {
					for (int j = 0; j < tsit0410JobSample.size(); j++) {
						writer.println(tsit0410JobSample.get(j).toString()+": not run this job-----------------------------------");
					}
				}
				writer.println();
				writer.println();
			}
		}
		writer.close();

	}
}