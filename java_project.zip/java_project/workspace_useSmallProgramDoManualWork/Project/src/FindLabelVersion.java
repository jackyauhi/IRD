import java.io.BufferedReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class FindLabelVersion {
	public static ArrayList<String> inputFileList = new ArrayList<String>();
	public static ArrayList<String> inputFileNameList = new ArrayList<String>();
	public static ArrayList<String> inputFileProjectNameList = new ArrayList<String>();
	public static ArrayList<String> inputFilePathList = new ArrayList<String>();
	public static ArrayList<String> inputFileInformationList = new ArrayList<String>();
	public static ArrayList<String> outputFileList = new ArrayList<String>();
	
	public static void main(String[] args) {
		int count=0;
		String inputPath="D:\\User\\marklabel_cloud\\marklabel\\checkLabel.txt";
		String outputPath="T:\\jackyau\\checkLabel.txt";
		String storeVarible =null;
		String fullPath =null;
		String nextfullPath =null;
		String versionNum =null;
		String labelDetail =null;
		int start =0;

		int latestVersion = 0;
		
		int BAT_CUAT_Version=0;
		int BAT_CDEV_Version=0;
		int WAS_CUAT_Version=0;
		int WAS_CDEV_Version=0;
		
		boolean patternMatch = false;
		boolean latestPath = false;
		boolean BAT_CUAT_Exist = false;
		boolean BAT_CDEV_Exist = false;
		boolean WAS_CUAT_Exist = false;
		boolean WAS_CDEV_Exist = false;

		try {
			BufferedReader fileReader = new BufferedReader(new FileReader(inputPath));
			String line=null;
		    try {
				while ((line = fileReader.readLine()) != null)
				{	

					Pattern pattern = Pattern.compile("([:a-zA-Z0-9._\\\\]+)@@\\\\main\\\\([0-9]+)\\s*([a-zA-Z0-9._(), ]*)");
					Matcher patternMatcher=pattern.matcher(line);
					if (patternMatcher.find()){
						patternMatch=true;
						storeVarible = patternMatcher.group();
						nextfullPath = patternMatcher.group(1);
						versionNum = patternMatcher.group(2);
						labelDetail = patternMatcher.group(3);
//						System.out.println("storeVarible ="+ storeVarible);
//						System.out.println("fullPath ="+ fullPath);
//						System.out.println("versionNum ="+ versionNum);
//						System.out.println("labelDetail ="+ labelDetail);
						if(!nextfullPath.equals(fullPath)&& start!=0) {
							if(BAT_CUAT_Exist && BAT_CDEV_Exist && WAS_CUAT_Exist && WAS_CDEV_Exist) {
								if(BAT_CUAT_Version==WAS_CUAT_Version) {
									outputFileList.add(System.lineSeparator());
									outputFileList.add("ALL Label version equal --> ("+fullPath+"@@\\main\\"+BAT_CUAT_Version+")");
									if(latestVersion>BAT_CUAT_Version) {
										outputFileList.add("Latest Version Path : "+fullPath+"@@\\main\\"+latestVersion);
//										System.out.println("Latest Version Path : "+fullPath+"@@\\main\\"+latestVersion);
									}
								}
								else {
									outputFileList.add(System.lineSeparator());
									outputFileList.add("ALL Label version not equal --> ("+fullPath+")");
									outputFileList.add("BAT_CUAT version Path --> ("+fullPath+"@@\\main\\"+BAT_CUAT_Version+")");
									outputFileList.add("WAS_CUAT version Path --> ("+fullPath+"@@\\main\\"+WAS_CUAT_Version+")");
									if(WAS_CUAT_Version>BAT_CUAT_Version) { 
										if(latestVersion>WAS_CUAT_Version) {
											outputFileList.add("Latest Version Path : "+fullPath+"@@\\main\\"+latestVersion);
										}
									}
									else if(BAT_CUAT_Version>WAS_CUAT_Version) {
										if(latestVersion>BAT_CUAT_Version) {
											outputFileList.add("Latest Version Path : "+fullPath+"@@\\main\\"+latestVersion);
										}
									}
								}
							}
							else if(BAT_CUAT_Exist && BAT_CDEV_Exist) {
								if(BAT_CUAT_Version==BAT_CDEV_Version) {
									outputFileList.add(System.lineSeparator());
									outputFileList.add("BAT_CUAT Label version BAT_CDEV Label equal --> ("+fullPath+"@@\\main\\"+BAT_CUAT_Version+")");
//									System.out.println("Batch cloud Label version equal --> ("+fullPath+"@@\\main\\"+BAT_CUAT_Version+")");
									if(latestVersion>BAT_CUAT_Version) {
										outputFileList.add("Latest Version Path : "+fullPath+"@@\\main\\"+latestVersion);
//										System.out.println("Latest Version Path : "+fullPath+"@@\\main\\"+latestVersion);
									}
								}
								else {
									outputFileList.add(System.lineSeparator());
									outputFileList.add("BAT_CUAT Label version BAT_CDEV Label not equal --> ("+fullPath+")");
									if(BAT_CUAT_Version>BAT_CDEV_Version) { 
										if(latestVersion>BAT_CUAT_Version) {
											outputFileList.add("Latest Version Path : "+fullPath+"@@\\main\\"+latestVersion);
										}
									}
									else if(BAT_CDEV_Version>BAT_CUAT_Version) {
										if(latestVersion>BAT_CDEV_Version) {
											outputFileList.add("Latest Version Path : "+fullPath+"@@\\main\\"+latestVersion);
										}
									}
								}
							}
//							else {
////								outputFileList.add("Batch cloud Label version not Exist --> ("+fullPath+")");
//								System.out.println("Batch cloud Label version not Exist --> ("+fullPath+")");
//							}
							else if(WAS_CUAT_Exist && WAS_CDEV_Exist) {
								if(WAS_CUAT_Version==WAS_CDEV_Version) {
									outputFileList.add(System.lineSeparator());
									outputFileList.add("WAS_CUAT Label version WAS_CDEV Label equal  --> ("+fullPath+"@@\\main\\"+BAT_CUAT_Version+")");
//									System.out.println("WAS cloud Label version equal --> ("+fullPath+"@@\\main\\"+BAT_CUAT_Version+")");
									if(latestVersion>BAT_CUAT_Version) {
										outputFileList.add("Latest Version Path : "+fullPath+"@@\\main\\"+latestVersion);
//										System.out.println("Latest Version Path : "+fullPath+"@@\\main\\"+latestVersion);
									}
								}
								else {
									outputFileList.add(System.lineSeparator());
									outputFileList.add("WAS_CUAT Label version WAS_CDEV Label not equal --> ("+fullPath+")");
									if(WAS_CUAT_Version>WAS_CDEV_Version) { 
										if(latestVersion>WAS_CUAT_Version) {
											outputFileList.add("Latest Version Path : "+fullPath+"@@\\main\\"+latestVersion);
										}
									}
									else if(WAS_CDEV_Version>WAS_CUAT_Version) {
										if(latestVersion>WAS_CDEV_Version) {
											outputFileList.add("Latest Version Path : "+fullPath+"@@\\main\\"+latestVersion);
										}
									}
								}
							}
							else {
								System.out.println("--> ("+fullPath+")");
								outputFileList.add(System.lineSeparator());
								outputFileList.add("Latest Version Path : "+fullPath+"@@\\main\\"+latestVersion);
							}
							
							BAT_CUAT_Exist = false;
							BAT_CDEV_Exist = false;
							WAS_CUAT_Exist = false;
							WAS_CDEV_Exist = false;
							latestVersion = 0;
						}

							if(Integer.parseInt(versionNum)>latestVersion) {
								latestVersion=Integer.parseInt(versionNum);
							}
							if(line.contains("BAT_CUAT")) {
								BAT_CUAT_Version=Integer.parseInt(versionNum);
								BAT_CUAT_Exist=true;
							}
							if(line.contains("BAT_CDEV")) {
								BAT_CDEV_Version=Integer.parseInt(versionNum);
								BAT_CDEV_Exist = true;
							}
							if(line.contains("WAS_CUAT")) {
								
								WAS_CUAT_Version=Integer.parseInt(versionNum);
								WAS_CUAT_Exist=true;
							}
							if(line.contains("WAS_CDEV")) {
								WAS_CDEV_Version=Integer.parseInt(versionNum);
								WAS_CDEV_Exist = true;
							}
							
						fullPath=nextfullPath;
//						System.out.println(line);
						start++;
						
					}
					
//					if(patternMatch) {
//						outputFileList.add("--------------------"+fullPath+"--------------------");
//					}
//					if(latestPath) {
//						outputFileList.add("Latest Version Path : "+fullPath+"@@\\main\\"+latestVersion);
//					}
//					if(BAT_CUAT_Exist) {
//						outputFileList.add("BAT_CUAT Label Version Path : "+fullPath+"@@\\main\\"+BAT_CUAT_Version);
//					}
//					if(BAT_CDEV_Exist) {
//						outputFileList.add("BAT_CDEV Label Version Path : "+fullPath+"@@\\main\\"+BAT_CDEV_Version);
//					}
//					if(WAS_CDEV_Exist) {
//						outputFileList.add("WAS_CDEV Label Version Path : "+fullPath+"@@\\main\\"+WAS_CDEV_Version);
//					}
//					if(WAS_CUAT_Exist) {
//						outputFileList.add("WAS_CUAT Label Version Path : "+fullPath+"@@\\main\\"+WAS_CUAT_Version);
//					}
//					if(patternMatch) {
//						outputFileList.add("=========================================================================================================");
//					}
				}
				fileReader.close();
			} 
		    catch (IOException e1) {
				e1.printStackTrace();
			}
			} 
	   	catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
		if(nextfullPath.equals(fullPath)) {
			if(BAT_CUAT_Exist && BAT_CDEV_Exist && WAS_CUAT_Exist && WAS_CDEV_Exist) {
				if(BAT_CUAT_Version==WAS_CUAT_Version) {
					outputFileList.add(System.lineSeparator());
					outputFileList.add("ALL Label version equal --> ("+fullPath+"@@\\main\\"+BAT_CUAT_Version+")");
					if(latestVersion>BAT_CUAT_Version) {
						outputFileList.add("Latest Version Path : "+fullPath+"@@\\main\\"+latestVersion);
//						System.out.println("Latest Version Path : "+fullPath+"@@\\main\\"+latestVersion);
					}
				}
				else {
					outputFileList.add(System.lineSeparator());
					outputFileList.add("ALL Label version not equal --> ("+fullPath+")");
					outputFileList.add("BAT_CUAT version Path --> ("+fullPath+"@@\\main\\"+BAT_CUAT_Version+")");
					outputFileList.add("WAS_CUAT version Path --> ("+fullPath+"@@\\main\\"+WAS_CUAT_Version+")");
					if(WAS_CUAT_Version>BAT_CUAT_Version) { 
						if(latestVersion>WAS_CUAT_Version) {
							outputFileList.add("Latest Version Path : "+fullPath+"@@\\main\\"+latestVersion);
						}
					}
					else if(BAT_CUAT_Version>WAS_CUAT_Version) {
						if(latestVersion>BAT_CUAT_Version) {
							outputFileList.add("Latest Version Path : "+fullPath+"@@\\main\\"+latestVersion);
						}
					}
				}
			}
			else if(BAT_CUAT_Exist && BAT_CDEV_Exist) {
				if(BAT_CUAT_Version==BAT_CDEV_Version) {
					outputFileList.add(System.lineSeparator());
					outputFileList.add("BAT_CUAT Label version BAT_CDEV Label equal --> ("+fullPath+"@@\\main\\"+BAT_CUAT_Version+")");
//					System.out.println("Batch cloud Label version equal --> ("+fullPath+"@@\\main\\"+BAT_CUAT_Version+")");
					if(latestVersion>BAT_CUAT_Version) {
						outputFileList.add("Latest Version Path : "+fullPath+"@@\\main\\"+latestVersion);
//						System.out.println("Latest Version Path : "+fullPath+"@@\\main\\"+latestVersion);
					}
				}
				else {
					outputFileList.add(System.lineSeparator());
					outputFileList.add("BAT_CUAT Label version BAT_CDEV Label not equal --> ("+fullPath+")");
					if(BAT_CUAT_Version>BAT_CDEV_Version) { 
						if(latestVersion>BAT_CUAT_Version) {
							outputFileList.add("Latest Version Path : "+fullPath+"@@\\main\\"+latestVersion);
						}
					}
					else if(BAT_CDEV_Version>BAT_CUAT_Version) {
						if(latestVersion>BAT_CDEV_Version) {
							outputFileList.add("Latest Version Path : "+fullPath+"@@\\main\\"+latestVersion);
						}
					}
				}
			}
//			else {
////				outputFileList.add("Batch cloud Label version not Exist --> ("+fullPath+")");
//				System.out.println("Batch cloud Label version not Exist --> ("+fullPath+")");
//			}
			else if(WAS_CUAT_Exist && WAS_CDEV_Exist) {
				if(WAS_CUAT_Version==WAS_CDEV_Version) {
					outputFileList.add(System.lineSeparator());
					outputFileList.add("WAS_CUAT Label version WAS_CDEV Label equal  --> ("+fullPath+"@@\\main\\"+BAT_CUAT_Version+")");
//					System.out.println("WAS cloud Label version equal --> ("+fullPath+"@@\\main\\"+BAT_CUAT_Version+")");
					if(latestVersion>BAT_CUAT_Version) {
						outputFileList.add("Latest Version Path : "+fullPath+"@@\\main\\"+latestVersion);
//						System.out.println("Latest Version Path : "+fullPath+"@@\\main\\"+latestVersion);
					}
				}
				else {
					outputFileList.add(System.lineSeparator());
					outputFileList.add("WAS_CUAT Label version WAS_CDEV Label not equal --> ("+fullPath+")");
					if(WAS_CUAT_Version>WAS_CDEV_Version) { 
						if(latestVersion>WAS_CUAT_Version) {
							outputFileList.add("Latest Version Path : "+fullPath+"@@\\main\\"+latestVersion);
						}
					}
					else if(WAS_CDEV_Version>WAS_CUAT_Version) {
						if(latestVersion>WAS_CDEV_Version) {
							outputFileList.add("Latest Version Path : "+fullPath+"@@\\main\\"+latestVersion);
						}
					}
				}
			}
			else {
				System.out.println("--> ("+fullPath+")");
				outputFileList.add("Latest Version Path : "+fullPath+"@@\\main\\"+latestVersion);
			}
		}
		try {
		FileWriter fileWriter = new FileWriter(outputPath);
		for (int i = 0; i < outputFileList.size(); i++) {
			fileWriter.write(outputFileList.get(i).toString()+System.lineSeparator());
		}
		fileWriter.close();
	} catch (IOException iox) {
		iox.printStackTrace();
		System.out.println("File can not save any data in outputPathList");
	}
	}
}