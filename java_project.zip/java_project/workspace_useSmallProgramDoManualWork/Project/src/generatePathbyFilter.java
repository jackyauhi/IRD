import java.io.BufferedReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class generatePathbyFilter {
	public static ArrayList<String> inputFileList = new ArrayList<String>();
	public static ArrayList<String> outputFileList = new ArrayList<String>();
	public static HashMap<String, String> inputFileMap = new HashMap<String, String>();
	public static void main(String[] args) {
		int count=0;
		String inputPath="D:\\ccshare\\jyyau_view_ClearCase_PRD\\TAAS2_DEV";
		String outputPath="T:\\jackyau\\checkingMissingFile\\PRD_Application_File.txt";
		String inputCloudPath="D:\\ccshare\\jyyau_view_checking\\TAAS2_UAT\\CloudMigration";
		String outputCloudPath="T:\\jackyau\\checkingMissingFile\\CloudMigration_File.txt";
//		String folderPath="D:\\User\\jackyau1";
//		String requiredPartOfContent=" ";
//		String outputPath="D:\\User\\jackyau1\\1.GerLabelVesionPath.bat";
//		String resultBat="D:\\User\\jackyau1\\output.bat";
		try (Stream<Path> walk = Files.walk(Paths.get(inputCloudPath))) {

			List<String> result = walk.filter(f -> Files.isRegularFile(f))
					.map(x -> x.toString())
//					.filter(s -> !s.toLowerCase().contains(".log4j.properties"))
//					.filter(s -> !s.toLowerCase().contains(".keep"))
					.collect(Collectors.toList());
			walk.close();
				for (int j = 0; j < result.size(); j++) {
					File file = new File(result.get(j).toString());
					if(file.isFile()) {
						String[] splitApplicationPath = result.get(j).toString().split(Pattern.quote("\\CloudMigration\\Application"),2);
						String[] splitPath = result.get(j).toString().split(Pattern.quote("\\TAAS2_UAT\\CloudMigration"),2);
						if(splitApplicationPath.length==2)
							inputFileList.add(splitApplicationPath[1]);
						else if(splitPath.length==2)
							inputFileList.add(splitPath[1]);
						else
							System.out.println("Path = "+result.get(j).toString());
					}
				  }
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try (Stream<Path> walk = Files.walk(Paths.get(inputPath))) {

//			List<String> result = walk.map(x -> x.toString())
//					.filter(f -> f.contains("\\misc\\")).collect(Collectors.toList());
//			List<String> result = walk.filter(Files::isRegularFile)
//					.map(x -> x.toString()).collect(Collectors.toList());
			List<String> result = walk.filter(f -> Files.isRegularFile(f))
					.map(x -> x.toString())
//					.filter(s -> s.toLowerCase().contains("validator")||s.toLowerCase().contains("worker"))
					.filter(s -> !s.toLowerCase().contains(".log4j.properties"))
					.filter(s -> !s.toLowerCase().contains(".keep"))
//					.filter(s -> !s.toLowerCase().contains("daoimpl"))
					.collect(Collectors.toList());
			walk.close();
				for (int j = 0; j < result.size(); j++) {
					File file = new File(result.get(j).toString());
					if(file.isFile()) {
						String[] splitBatchPath = result.get(j).toString().split(Pattern.quote("\\PRD_Application\\Batch"),2);
						String[] splitOnlinePath = result.get(j).toString().split(Pattern.quote("\\PRD_Application\\Online"),2);
						String[] splitPath = result.get(j).toString().split(Pattern.quote("\\TAAS2_DEV"),2);
//						System.out.println("Path = "+result.get(j).toString());
//						System.out.println("splitBatchPath = "+splitBatchPath.length);
//						System.out.println("splitOnlinePath = "+splitOnlinePath.length);
						if(splitBatchPath.length==2)
							inputFileMap.put(splitBatchPath[1],"Batch");
						else if(splitOnlinePath.length==2)
							inputFileMap.put(splitOnlinePath[1],"Online");
						else if(splitPath.length==2)
							inputFileMap.put(splitPath[1],"splitPath");
						else
							System.out.println("Path = "+result.get(j).toString());
					}
				  }
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			FileWriter fileWriter = new FileWriter(outputCloudPath);
			for (int i = 0; i < inputFileList.size(); i++) {
				fileWriter.write(inputFileList.get(i).toString()+System.lineSeparator());
			}
			fileWriter.close();
		} catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data in outputPathList");
		}
		try {
		FileWriter fileWriter = new FileWriter(outputPath);
        for(String key: inputFileMap.keySet()) {
            System.out.print(key+System.lineSeparator());
            fileWriter.write(key+System.lineSeparator());
          }
		fileWriter.close();
	} catch (IOException iox) {
		iox.printStackTrace();
		System.out.println("File can not save any data in outputPathList");
	}
		
//		try{    
//		    ProcessBuilder pbuilder = new ProcessBuilder(resultBat);
//		    
//		    pbuilder.directory(new File(folderPath) ); // this is where you set the root folder for the executable to run with
//		    pbuilder.redirectErrorStream(true);
//		    Process process =  pbuilder.start();
//
//		    Scanner s = new Scanner(process.getInputStream());
//		    StringBuilder text = new StringBuilder();
//		    System.out.println(System.lineSeparator());
//		    while (s.hasNextLine()) {
//		      System.out.println(s.nextLine());
//		    }
//		    s.close();
//		    int result1 = process.waitFor();
//		    
//		}catch( Exception e) {
//			e.printStackTrace();
//		}	
//		try {
//		FileWriter fileWriter = new FileWriter(outputPath);
//		for (int i = 0; i < inputFileList.size(); i++) {
//			if(count==0) {
//				fileWriter.write(inputFileList.get(i).toString()+System.lineSeparator());
//				count++;
//			}
//			else {
//				count=0;
//				}
//		}
//		fileWriter.close();
//	} catch (IOException iox) {
//		iox.printStackTrace();
//		System.out.println("File can not save any data in outputPathList");
//	}
//		try {
//			BufferedReader fileReader = new BufferedReader(new FileReader(inputPath));
//			String line=null;
//		    try {
//				while ((line = fileReader.readLine()) != null)
//				{	
//					if(line.contains(requiredPartOfContent)) {
//						inputFileList.add(line);
//					}
//				}
//				fileReader.close();
//			} 
//		    catch (IOException e1) {
//				e1.printStackTrace();
//			}
//			} 
//	   	catch (FileNotFoundException e1) {
//				e1.printStackTrace();
//			}
//		int count=0;
//		try {
//			FileWriter fileWriter = new FileWriter(outputPath);
//			for (int i = 0; i < inputFileList.size(); i++) {
//				if(count==0) {
//					fileWriter.write(inputFileList.get(i).toString()+System.lineSeparator());
//					count++;
//				}
//				else {
//					count=0;
//					}
//			}
//			fileWriter.close();
//		} catch (IOException iox) {
//			iox.printStackTrace();
//			System.out.println("File can not save any data in outputPathList");
//		}
	}
}