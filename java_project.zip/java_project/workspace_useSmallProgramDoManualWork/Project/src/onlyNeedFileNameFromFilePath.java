import java.io.BufferedReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class onlyNeedFileNameFromFilePath {
	public static List<String> inputPathList = new ArrayList<String>();
	public static List<String> functionNameList = new ArrayList<String>();
	public static List<String> outputInputPathList = new ArrayList<String>();
	public static List<String> outputFunctionNameList = new ArrayList<String>();
	public static Map<String, String> functionName = new HashMap<String, String>();
	public static Map<String, String> resultMap = new HashMap<String, String>();
	
	public static void main(String[] args) {

		String inputList="T:\\jackyau\\filePath222.txt";
		String outputInputPath="T:\\jackyau\\FileName111.txt";

		String storeVarible1 =null;
		try {
			BufferedReader fileReader = new BufferedReader(new FileReader(inputList));
			String line=null;
		    try {
				while ((line = fileReader.readLine()) != null)
				{	
					File fileToSave = new File(line);
					inputPathList.add(fileToSave.getName());

				}
				fileReader.close();
			} 
		    catch (IOException e1) {
				e1.printStackTrace();
			}
			} 
	   	catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}

		try {
		FileWriter fileWriter = new FileWriter(outputInputPath);
		for (int i = 0; i < inputPathList.size(); i++) {
			fileWriter.write(inputPathList.get(i).toString()+System.lineSeparator());
		}
		fileWriter.close();			
	} catch (IOException iox) {
		iox.printStackTrace();
		System.out.println("File can not save any data in outputPathList");
	}
//		try {
//		FileWriter fileWriter = new FileWriter(outputFunctionName);
//		for (int i = 0; i < outputFunctionNameList.size(); i++) {
//			fileWriter.write(outputFunctionNameList.get(i).toString());
//		}
//		fileWriter.close();			
//	} catch (IOException iox) {
//		iox.printStackTrace();
//		System.out.println("File can not save any data in outputPathList");
//	}
	}
}