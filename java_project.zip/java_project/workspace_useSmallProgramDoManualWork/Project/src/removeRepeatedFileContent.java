import java.io.BufferedReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class removeRepeatedFileContent {
	public static ArrayList<String> outputFirstFileList = new ArrayList<String>();
	public static ArrayList<String> outputSecondFileList = new ArrayList<String>();

	public static void main(String[] args) {
		int count=0;

		String inputFirstFile="T:\\jackyau\\checkingMissingFile\\PRD_Application_File.txt";
		String inputSecondFile="T:\\jackyau\\checkingMissingFile\\CloudMigration_File.txt";
		String outputPath="T:\\jackyau\\checkingMissingFile\\resultMain.txt";
		try {
			BufferedReader firstFileReader = new BufferedReader(new FileReader(inputFirstFile));
			BufferedReader secondFileReader = new BufferedReader(new FileReader(inputSecondFile));
			String firstFileLine=null;
			String secondFileLine=null;
		    try {
				while ((firstFileLine = firstFileReader.readLine()) != null)
				{	
					outputFirstFileList.add(firstFileLine);
				}
				firstFileReader.close();
				while ((secondFileLine = secondFileReader.readLine()) != null)
				{	
					outputSecondFileList.add(secondFileLine);
				}
				secondFileReader.close();
			} 
		    catch (IOException e1) {
				e1.printStackTrace();
			}
			} 
	   	catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
		outputFirstFileList.removeAll(outputSecondFileList);

		try {
			FileWriter fileWriter = new FileWriter(outputPath);
			for (int i = 0; i < outputFirstFileList.size(); i++) {
				fileWriter.write(outputFirstFileList.get(i).toString()+System.lineSeparator());
			}
			fileWriter.close();
		} catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data in outputPathList");
		}

		
	}
}