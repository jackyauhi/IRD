import java.io.BufferedReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class FindrequiredFilesIndrive {
	public static List<String> inputDriveList = new ArrayList<String>();
	public static List<String> folderList = new ArrayList<String>();
	public static List<String> functionList = new ArrayList<String>();
	public static List<String> pathList = new ArrayList<String>();
	public static List<String> outputCSV = new ArrayList<String>();
	public static List<String> errorFunctionName = new ArrayList<String>();
	public static HashMap<String, String> inputFileMap = new HashMap<String, String>();
	public static void main(String[] args) {
		String inputPath="D:\\User\\searchPath\\H_dirve_PROD.txt";
		String inputPath1="D:\\User\\searchPath\\H_dirve_DEV.txt";
		String inputPath2="D:\\User\\searchPath\\K_dirve_CLD_UAT.txt";
		String inputPath3="D:\\User\\searchPath\\K_dirve_TAAS.txt";
		
		String inputFunctionListPath="D:\\User\\searchPath\\functionList.txt";
		
		String outputCSVPath="D:\\User\\searchPath\\result\\outputFileList6.csv";
		String outputNotFindResultPath="D:\\User\\searchPath\\result\\outputErrorPath6.txt";
		folderList.add(inputPath);
		folderList.add(inputPath1);
		folderList.add(inputPath2);
		folderList.add(inputPath3);
		try {
		BufferedReader fileReader = new BufferedReader(new FileReader(inputFunctionListPath));
		String line=null;
	    try {
				while ((line = fileReader.readLine()) != null)
				{	
					functionList.add(line);
				}
				fileReader.close();
		    } 
		    catch (IOException e1) {
				e1.printStackTrace();
			}
		} 
	   	catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
		for (int i = 0; i < folderList.size(); i++) {
			try {
			BufferedReader fileReader = new BufferedReader(new FileReader(folderList.get(i).toString()));
			String line=null;
		    try {
					while ((line = fileReader.readLine()) != null)
					{	
						if(line.contains("."))
						inputDriveList.add(line);
					}
					fileReader.close();
			    } 
			    catch (IOException e1) {
					e1.printStackTrace();
				}
			} 
		   	catch (FileNotFoundException e1) {
					e1.printStackTrace();
				}
		}
		for (int i = 0; i < functionList.size(); i++) {
			String functionName = functionList.get(i).toString();
//			Pattern pattern = Pattern.compile("([a-zA-Z]+)");
//			Matcher patternMatcher=pattern.matcher(functionName);
//			if (!patternMatcher.find()){
//				System.out.println(functionName);
//			}
			int countTestCond=0;
			int countAcceptance=0;
			int countUatLog=0;
			int countZip=0;
			int countFunctionName=0;
			String testCond ="";
			String acceptance ="";
			String uatLog ="";
			String zip ="";
			
			for (int j = 0; j < inputDriveList.size(); j++) {
				File file = new File(inputDriveList.get(j).toString());
				if(file.getName().contains(functionName)) {
//					System.out.println(file.getName());
					countFunctionName++;
					if(inputDriveList.get(j).toString().toLowerCase().contains("test cond")) {
						
			    		  if(countTestCond==0) 
			    			  testCond=inputDriveList.get(j).toString();
			    		  else 
			    			  testCond=testCond+System.lineSeparator()+inputDriveList.get(j).toString();
			    		  
			    		  countTestCond++;
					}
					else if(inputDriveList.get(j).toString().toLowerCase().contains("test_cond")) {
						
			    		  if(countTestCond==0) 
			    			  testCond=inputDriveList.get(j).toString();
			    		  else 
			    			  testCond=testCond+System.lineSeparator()+inputDriveList.get(j).toString();
			    		  
			    		  countTestCond++;
					}
					else if(inputDriveList.get(j).toString().toLowerCase().contains("test-cond")) {
						
			    		  if(countTestCond==0) 
			    			  testCond=inputDriveList.get(j).toString();
			    		  else 
			    			  testCond=testCond+System.lineSeparator()+inputDriveList.get(j).toString();
			    		  
			    		  countTestCond++;
					}
					if(file.getName().toLowerCase().contains("acceptance")) {
						if(file.getName().endsWith(".pdf")) {
			    		  if(countAcceptance==0) 
			    			  acceptance=inputDriveList.get(j).toString();
			    		  else 
			    			  acceptance=acceptance+System.lineSeparator()+inputDriveList.get(j).toString();
			    		  
			    		  countAcceptance++;
						}
					}
					if(inputDriveList.get(j).toString().toLowerCase().contains("uat log")) {
						
			    		  if(countUatLog==0) 
			    			  uatLog=inputDriveList.get(j).toString();
			    		  else 
			    			  uatLog=uatLog+System.lineSeparator()+inputDriveList.get(j).toString();
			    		  
			    		  countUatLog++;
					}
					else if(inputDriveList.get(j).toString().toLowerCase().contains("uat_log")) {
						
			    		  if(countUatLog==0) 
			    			  uatLog=inputDriveList.get(j).toString();
			    		  else 
			    			  uatLog=uatLog+System.lineSeparator()+inputDriveList.get(j).toString();
			    		  
			    		  countUatLog++;
					}
					else if(inputDriveList.get(j).toString().toLowerCase().contains("uat-log")) {
						
			    		  if(countUatLog==0) 
			    			  uatLog=inputDriveList.get(j).toString();
			    		  else 
			    			  uatLog=uatLog+System.lineSeparator()+inputDriveList.get(j).toString();
			    		  
			    		  countUatLog++;
					}
					if(file.getName().toLowerCase().endsWith(".zip")) {
						
			    		  if(countZip==0) 
			    			  zip=inputDriveList.get(j).toString();
			    		  else 
			    			  zip=zip+System.lineSeparator()+inputDriveList.get(j).toString();
			    		  
			    		  countZip++;
					}
				}
			}
			outputCSV.add(functionName+","+"\""+testCond+"\""+","+"\""+acceptance+"\""+","+"\""+uatLog+"\""+","+"\""+zip+"\"");
			System.out.println(functionName+","+"\""+testCond+"\""+","+"\""+acceptance+"\""+","+"\""+uatLog+"\""+","+"\""+zip+"\"");
			if(countFunctionName==0) {
				errorFunctionName.add(functionName);
			}			
		}
		try {
			FileWriter fileWriter = new FileWriter(outputCSVPath);
			fileWriter.write("Search Key"+","+"Test Cond"+","+"Acceptance"+","+"Uat Log"+","+"Zip File"+System.lineSeparator());
			for (int j = 0; j < outputCSV.size(); j++) {
				fileWriter.write(outputCSV.get(j).toString()+System.lineSeparator());
	          }
			fileWriter.close();
		} catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data in outputPathList");
		}
		
		
		try {
			FileWriter fileWriter = new FileWriter(outputNotFindResultPath);
			for (int j = 0; j < errorFunctionName.size(); j++) {
				fileWriter.write(errorFunctionName.get(j).toString()+System.lineSeparator());
	          }
			fileWriter.close();
		} catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data in outputPathList");
		}
		
		}
//	public static String generateCSVFile(String contentForFind, String findName) {
//		if(contentForFind.contains(contentForFind)) {
//			int count =0;
//			String storeAfterFind="";
//    		  if(count==0) 
//    			  storeAfterFind=contentForFind;
//    		  else 
//    			  storeAfterFind=storeAfterFind+System.lineSeparator()+contentForFind;
//    		  
//    		  count++;
//		}
//	}
}