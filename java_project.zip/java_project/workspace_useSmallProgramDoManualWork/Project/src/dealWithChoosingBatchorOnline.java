import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class dealWithChoosingBatchorOnline {

	public static String openingPath = new String();
	public static String versionListPath = new String();
	public static String outputPath = new String();
	public static List<String> pathList = new ArrayList<String>();
	public static List<String> savePathList = new ArrayList<String>();
	public static List<String> errorPathList = new ArrayList<String>();
	public static String folderPath = "";
	public static HashMap<String, String> inputFileMap = new HashMap<String, String>();
	
	public static void main(String[] args) {
		versionListPath="D:\\helper_tmp\\version_list.txt";
		openingPath="D:\\helper_tmp\\Result\\output\\PRD_Application";
		outputPath="T:\\jackyau\\output_File";
		try {
			BufferedReader fileReader = new BufferedReader(new FileReader(versionListPath));
			String line=null;
		    try {
				while ((line = fileReader.readLine()) != null)
				{	
					line=line.replaceAll("\\s", "");
					System.out.println("line.trim() = "+line.trim());
					pathList.add(line);
				}
				fileReader.close();
			} 
		    catch (IOException e1) {
				e1.printStackTrace();
			}
			} 
	   	catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
		try (Stream<Path> walk = Files.walk(Paths.get(openingPath))) {
			List<String> result = walk.filter(f -> Files.isRegularFile(f))
					.map(x -> x.toString())
					.filter(s -> !s.toLowerCase().contains(".log4j.properties"))
					.filter(s -> !s.toLowerCase().contains(".keep"))
					.collect(Collectors.toList());
			walk.close();
				for (int i = 0; i < result.size(); i++) {
					File file = new File(result.get(i).toString());
					if(file.isFile()) {
						for (int j = 0; j < pathList.size(); j++) {
							if (result.get(i).toString().contains(pathList.get(j).toString())) {
								System.out.println("Path = "+result.get(i).toString());
								String[] inputSplit = result.get(i).toString().toString().split(":",2);
								folderPath=inputSplit[1];
								
								File fileToSave = new File(outputPath+"\\"+folderPath);
								File fileToSaveParent=new File(fileToSave.getParent());
								if (!fileToSaveParent.exists()) {
									fileToSaveParent.mkdirs();
								}
								File sourceFile = new File(result.get(i).toString());
								File targetFile = new File(outputPath+"\\"+folderPath);
								
								try {
									transform(sourceFile,"UTF-8",targetFile,"UTF-8");
									System.out.println("transform from:"+sourceFile.getAbsolutePath() + System.lineSeparator());
									System.out.println("To:"+targetFile.getAbsolutePath() + System.lineSeparator());
									savePathList.add(sourceFile.getAbsolutePath());
								} catch (IOException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
						}
//						String[] splitBatchPath = result.get(j).toString().split(Pattern.quote("\\PRD_Application\\Batch"),2);
//						String[] splitOnlinePath = result.get(j).toString().split(Pattern.quote("\\PRD_Application\\Online"),2);
//						String batchpath=null;
//						String onlinepath=null;
//						if(splitBatchPath.length==2)
//							batchpath=splitBatchPath[1].trim();
//						if(splitOnlinePath.length==2)
//							onlinepath=splitOnlinePath[1].trim();
//						String[] splitPath = result.get(j).toString().split(Pattern.quote("\\TAAS2_DEV"),2);
//						System.out.println("Path = "+result.get(i).toString());
//						boolean retvalBatch = pathList.contains(batchpath);
//						boolean retvalOnline = pathList.contains(onlinepath);

//						if (retvalBatch== true)
//						System.out.println("splitBatchPath = "+batchpath);
//						System.out.println("splitOnlinePath = "+splitOnlinePath.length);
//						if (inputFileMap.containsKey("BrapapsupDao.java"))
//							savePathList.add(splitBatchPath[1]);
//						else if(inputFileMap.containsKey(onlinepath))
//							savePathList.add(splitOnlinePath[1]);
//						else if(splitBatchPath.length==2)
//							savePathList.add(splitBatchPath[1]);
//						else if(splitOnlinePath.length==2)
//							savePathList.add(splitOnlinePath[1]);						
//						else
//							System.out.println("Path = "+result.get(j).toString());
					}
				  }
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		boolean errorContains=false;
//
//		for (int i = 0; i < pathList.size(); i++) {
//			String[] inputSplit = pathList.get(i).toString().split(":",2);
//			folderPath=inputSplit[1];
//			
//			File fileToSave = new File(outputPath+"\\"+folderPath);
//			File fileToSaveParent=new File(fileToSave.getParent());
//			if (!fileToSaveParent.exists()) {
//				fileToSaveParent.mkdirs();
//			}
//			File sourceFile = new File(pathList.get(i).toString());
//			File targetFile = new File(outputPath+"\\"+folderPath);
//			
//			try {
//				transform(sourceFile,"UTF-8",targetFile,"UTF-8");
//				System.out.println("transform from:"+sourceFile.getAbsolutePath() + System.lineSeparator());
//				System.out.println("To:"+targetFile.getAbsolutePath() + System.lineSeparator());
//				savePathList.add(sourceFile.getAbsolutePath());
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//				errorContains=true;
//				errorPathList.add(sourceFile.getAbsolutePath());
//			}			
//		}
//		try {
//			FileWriter fileWriter = new FileWriter(outputPath+"\\FilePath.txt");
//			for (int j = 0; j < savePathList.size(); j++) {
//				fileWriter.write(savePathList.get(j).toString()+ System.lineSeparator());
//			}
//			fileWriter.close();
//		} catch (IOException iox) {
//			iox.printStackTrace();
//			System.out.println("File can not save any data in inputFileList");
//			}
//		if(errorContains) {
//		try {
//			FileWriter fileWriter = new FileWriter(outputPath+"\\ErrorFilePath.txt");
//			for (int j = 0; j < errorPathList.size(); j++) {
//				fileWriter.write(errorPathList.get(j).toString()+ System.lineSeparator());
//			}
//			fileWriter.close();
//		} catch (IOException iox) {
//			iox.printStackTrace();
//			System.out.println("File can not save any data in inputFileList");
//			}
//		}
	
	}
	public static void transform(File source, String srcEncoding, File target, String tgtEncoding) throws IOException {
	    BufferedReader br = null;
	    BufferedWriter bw = null;
	    try{
	        br = new BufferedReader(new InputStreamReader(new FileInputStream(source),srcEncoding));
	        bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(target), tgtEncoding));
	        char[] buffer = new char[16384];
	        int read;
	        while ((read = br.read(buffer)) != -1)
	            bw.write(buffer, 0, read);
	    } finally {
	        try {
	            if (br != null)
	                br.close();
	        } finally {
	            if (bw != null)
	                bw.close();
	        }
	    }
	}
}