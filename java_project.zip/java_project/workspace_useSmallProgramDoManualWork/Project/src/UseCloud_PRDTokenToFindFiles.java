import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class UseCloud_PRDTokenToFindFiles {

	public static String PRD_Application_After_Converted_Path = new String();
	public static String cloudPath = new String();
	public static String outputPath = new String();
	public static List<String> pathList = new ArrayList<String>();
	public static List<String> savePathList = new ArrayList<String>();
	public static List<String> remainPathList = new ArrayList<String>();
	public static List<String> gerBatPathList = new ArrayList<String>();
	public static List<String> errorPathList = new ArrayList<String>();
	public static String folderPath = "";
	public static HashMap<String, String> inputFileMap = new HashMap<String, String>();
	
	public static void main(String[] args) {
		String doubleCheckListPath = "T:\\jackyau\\doubleCheckListPath.txt";
		cloudPath="D:\\ccshare\\jyyau_view_ClearCase_MTN\\TAAS2_UAT\\CloudMigration\\Application";
		PRD_Application_After_Converted_Path="D:\\helper_tmp\\Result\\PRD_Application";
		String PRD_Application_Before_Converted_Path="D:\\ccshare\\jyyau_view_ClearCase_UAT\\TAAS2_DEV\\PRD_Application";
		outputPath="D:\\User\\jackyau1\\output_File313";
		String outputremainPathList = "T:\\jackyau\\remainPathList.txt";
		String gerBatOutput = "T:\\jackyau\\gerBatOutput.bat";
		try (Stream<Path> walk = Files.walk(Paths.get(cloudPath))) {
			List<String> result = walk.filter(f -> Files.isRegularFile(f))
					.map(x -> x.toString())
					.filter(s -> !s.toLowerCase().contains(".log4j.properties"))
					.filter(s -> !s.toLowerCase().contains(".keep"))
					.collect(Collectors.toList());
			walk.close();
			for (int i = 0; i < result.size(); i++) {
				File file = new File(result.get(i).toString());
				if(file.isFile()) {
//					savePathList.add(result.get(i).toString());
					remainPathList.add(result.get(i).toString());
					try {
						String content = new String(Files.readAllBytes(Paths.get(result.get(i).toString())));
						Pattern pattern = Pattern.compile("Check in version of ([a-zA-Z0-9]+)_PRD([a-zA-Z0-9,-]+):([0-9]+):");
						//Check in version of WAS_PRD,16-11-20,ckyeung:13:
						Matcher patternMatcher=pattern.matcher(content);
						if (patternMatcher.find())
							pathList.add(result.get(i).toString());
					}catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		remainPathList.removeAll(pathList);
		try {
		FileWriter fileWriter = new FileWriter(outputremainPathList);
		for (int i = 0; i < remainPathList.size(); i++) {
			fileWriter.write(remainPathList.get(i).toString()+System.lineSeparator());
		}
		fileWriter.close();
	} catch (IOException iox) {
		iox.printStackTrace();
		System.out.println("File can not save any data in outputPathList");
	}
		try {
//			savePathList.clear();
			BufferedReader fileReader = new BufferedReader(new FileReader(doubleCheckListPath));
			String line=null;
		    try {
				while ((line = fileReader.readLine()) != null)
				{	
					savePathList.add(line);
				}
				fileReader.close();
			} 
		    catch (IOException e1) {
				e1.printStackTrace();
			}
			} 
	   	catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
		for (int i = 0; i < savePathList.size(); i++) {
			File file = new File(savePathList.get(i).toString());
			if(file.isFile()) {
				try {
					String content = new String(Files.readAllBytes(Paths.get(savePathList.get(i).toString())));
//					Pattern pattern = Pattern.compile("([:a-zA-Z0-9._\\\\]+)@@\\\\main\\\\([0-9]+)\\s*([a-zA-Z0-9._(), ]*)");
					Pattern pattern = Pattern.compile("Check in version of ([a-zA-Z0-9]+)_PRD([a-zA-Z0-9,-]+):([0-9]+):");
					//Check in version of WAS_PRD,16-11-20,ckyeung:13:
					Matcher patternMatcher=pattern.matcher(content);
					if (patternMatcher.find()){
						String storeVarible = patternMatcher.group();
						String section = patternMatcher.group(1);
						String dateAndPerson = patternMatcher.group(2);
						String versionNum = patternMatcher.group(3);
						String[] splitPath = savePathList.get(i).toString().split(Pattern.quote("\\Application"),2);
//						System.out.println("result.get(i).toString() = "+ savePathList.get(i).toString());
//						System.out.println(PRD_Application_After_Converted_Path+"\\Online"+splitPath[1]);
//						System.out.println("section = "+ section);
//						System.out.println("versionNum = "+ versionNum);
						File sourceFile;
						File targetFile;
						if(section.equals("WAS")) {
							sourceFile = new File(PRD_Application_After_Converted_Path+"\\Online"+splitPath[1]);
							targetFile = new File(outputPath+splitPath[1]);
							File fileToSave = new File(outputPath+splitPath[1]);
							File fileToSaveParent=new File(fileToSave.getParent());
							if (!fileToSaveParent.exists()) {
								fileToSaveParent.mkdirs();
							}							
//							transform(sourceFile,"UTF-8",targetFile,"UTF-8");
//							cleartool get �Vto C:\build\foo.c.temp \dev\hello_world\foo.c@@\main\2
							File seefile = new File(PRD_Application_Before_Converted_Path+"\\Online"+splitPath[1]);
							if(seefile.isFile()) 
							gerBatPathList.add("cleartool get �Vto \""+targetFile+"\" \""+seefile.getAbsolutePath()+"@@\\main\\"+versionNum+"\"");
							
							else
								System.out.println("problem happened in " +seefile.getAbsolutePath()); 
						}
						else if(section.equals("BAT")) {
							sourceFile = new File(PRD_Application_After_Converted_Path+"\\Batch"+splitPath[1]);
							targetFile = new File(outputPath+splitPath[1]);
							File fileToSave = new File(outputPath+splitPath[1]);
							File fileToSaveParent=new File(fileToSave.getParent());
							if (!fileToSaveParent.exists()) {
								fileToSaveParent.mkdirs();
							}
//							transform(sourceFile,"UTF-8",targetFile,"UTF-8");
							File seefile = new File(PRD_Application_Before_Converted_Path+"\\Batch"+splitPath[1]);
							if(seefile.isFile()) 
							gerBatPathList.add("cleartool get �Vto \""+targetFile+"\" \""+seefile.getAbsolutePath()+"@@\\main\\"+versionNum+"\"");
							
							else
								System.out.println("problem happened in " +seefile.getAbsolutePath()); 
						}
						
					}
					else {
						System.out.println("savePathList.get(i).toString() = "+ savePathList.get(i).toString());
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println("savePathList.get(i).toString() = "+ savePathList.get(i).toString());
				}

			}
		  }
		try {
		FileWriter fileWriter = new FileWriter(gerBatOutput);
		for (int i = 0; i < gerBatPathList.size(); i++) {
			fileWriter.write(gerBatPathList.get(i).toString()+System.lineSeparator());
		}
		fileWriter.close();
	} catch (IOException iox) {
		iox.printStackTrace();
		System.out.println("File can not save any data in outputPathList");
	}
	
	}
	public static void transform(File source, String srcEncoding, File target, String tgtEncoding) throws IOException {
	    BufferedReader br = null;
	    BufferedWriter bw = null;
	    try{
	        br = new BufferedReader(new InputStreamReader(new FileInputStream(source),srcEncoding));
	        bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(target), tgtEncoding));
	        char[] buffer = new char[16384];
	        int read;
	        while ((read = br.read(buffer)) != -1)
	            bw.write(buffer, 0, read);
	    } finally {
	        try {
	            if (br != null)
	                br.close();
	        } finally {
	            if (bw != null)
	                bw.close();
	        }
	    }
	}
}