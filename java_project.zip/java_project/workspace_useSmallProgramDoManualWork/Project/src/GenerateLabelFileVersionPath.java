import java.io.BufferedReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class GenerateLabelFileVersionPath {
	public static ArrayList<String> BAT_CUAT_FileList = new ArrayList<String>();
	public static ArrayList<String> BAT_CDEV_FileList = new ArrayList<String>();
	public static ArrayList<String> WAS_CUAT_FileList = new ArrayList<String>();
	public static ArrayList<String> WAS_CDEV_FileList = new ArrayList<String>();
	public static ArrayList<String> LatestVersionFileList = new ArrayList<String>();
	public static ArrayList<String> backupList = new ArrayList<String>();
	public static ArrayList<String> LogList = new ArrayList<String>();
	public static ArrayList<String> FileList2 = new ArrayList<String>();
	public static void main(String[] args) {
		int count=0;
		String inputPath="D:\\User\\marklabel_cloud\\marklabel\\checkLabel.txt";
		String outputPath="T:\\jackyau\\LatestVersionList.txt";
		String outputPath2="T:\\jackyau\\FileList_real.txt";
		String outputPath3="T:\\jackyau\\LogList.txt";
		String inputPath1="T:\\jackyau\\hihi.txt";
		
		String outputBAT_CUAT_FileList="T:\\jackyau\\BAT_CUAT_FileList1.txt";
		String outputBAT_CDEV_FileList="T:\\jackyau\\BAT_CDEV_FileList1.txt";
		String outputWAS_CUAT_FileList="T:\\jackyau\\WAS_CUAT_FileList1.txt";
		String outputWAS_CDEV_FileList="T:\\jackyau\\WAS_CDEV_FileList1.txt";
		
		String FileLsitPath="T:\\jackyau\\FileList.txt";
		String storeVarible =null;
		String fullPath =null;
		String nextfullPath =null;
		String versionNum =null;
		String versionNum1 =null;
		String labelDetail =null;
		int start =0;

		int latestVersion = 0;
		
		int BAT_CUAT_Version=0;
		int BAT_CDEV_Version=0;
		int WAS_CUAT_Version=0;
		int WAS_CDEV_Version=0;
		
		boolean patternMatch = false;
		boolean latestPath = false;
		boolean BAT_CUAT_Exist = false;
		boolean BAT_CDEV_Exist = false;
		boolean WAS_CUAT_Exist = false;
		boolean WAS_CDEV_Exist = false;
		try {
			BufferedReader fileReader = new BufferedReader(new FileReader(inputPath));
			String line=null;
		    try {
				while ((line = fileReader.readLine()) != null)
				{	

					Pattern pattern = Pattern.compile("([:a-zA-Z0-9._\\\\-]+)@@\\\\main\\\\([0-9]+)\\s*([a-zA-Z0-9._(), ]*)");
					Matcher patternMatcher=pattern.matcher(line);
					if (patternMatcher.find()){
						patternMatch=true;
						storeVarible = patternMatcher.group();
						nextfullPath = patternMatcher.group(1);
						versionNum = patternMatcher.group(2);
						labelDetail = patternMatcher.group(3);

						if(!nextfullPath.equals(fullPath)&& start!=0) {

							LatestVersionFileList.add(fullPath+"@@\\main\\"+latestVersion);
							LogList.add("Latest Version Path : "+fullPath+"@@\\main\\"+latestVersion);
//							System.out.println("Latest Version Path : "+fullPath+"@@\\main\\"+latestVersion);
//							System.out.println("storeVarible : "+storeVarible);
							BAT_CUAT_Exist = false;
							BAT_CDEV_Exist = false;
							WAS_CUAT_Exist = false;
							WAS_CDEV_Exist = false;
							latestVersion = 0;
						}
						fullPath=nextfullPath;
						start++;
							if(Integer.parseInt(versionNum)>latestVersion) {
								latestVersion=Integer.parseInt(versionNum);
//								System.out.println("Latest Version: "+latestVersion);
							}
							if(line.contains("BAT_CUAT")) {
								BAT_CUAT_Version=Integer.parseInt(versionNum);
								BAT_CUAT_Exist=true;
								if(!fullPath.contains("\\Online")) 
								BAT_CUAT_FileList.add(fullPath+"@@\\main\\"+BAT_CUAT_Version);
								LogList.add("BAT_CUAT_Version Path : "+fullPath+"@@\\main\\"+latestVersion);
							}
							if(line.contains("BAT_CDEV")) {
								BAT_CDEV_Version=Integer.parseInt(versionNum);
								BAT_CDEV_Exist = true;
								if(!fullPath.contains("\\Online"))
								BAT_CDEV_FileList.add(fullPath+"@@\\main\\"+BAT_CDEV_Version);
								LogList.add("BAT_CDEV_Version Path : "+fullPath+"@@\\main\\"+latestVersion);
							}
							if(line.contains("WAS_CUAT")) {								
								WAS_CUAT_Version=Integer.parseInt(versionNum);
								WAS_CUAT_Exist=true;
								if(!fullPath.contains("\\Batch"))
								WAS_CUAT_FileList.add(fullPath+"@@\\main\\"+WAS_CUAT_Version);
								LogList.add("WAS_CUAT_Version Path : "+fullPath+"@@\\main\\"+latestVersion);
							}
							if(line.contains("WAS_CDEV")) {
								WAS_CDEV_Version=Integer.parseInt(versionNum);
								WAS_CDEV_Exist = true;
								if(!fullPath.contains("\\Batch"))
								WAS_CDEV_FileList.add(fullPath+"@@\\main\\"+WAS_CDEV_Version);
								LogList.add("WAS_CDEV_Version Path : "+fullPath+"@@\\main\\"+latestVersion);
							}
						
					}


				}
				fileReader.close();
			} 
		    catch (IOException e1) {
				e1.printStackTrace();
			}
			} 
	   	catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
		if(nextfullPath.equals(fullPath)) {
			LatestVersionFileList.add(fullPath+"@@\\main\\"+latestVersion);
		}
//		for (int i = 0; i < LatestVersionFileList.size(); i++) {
//		backupList.add(LatestVersionFileList.get(i).toString());
//	}
//	LatestVersionFileList.removeAll(FileList2);
//	FileList2.removeAll(backupList);
		
//		WAS_CDEV_FileList.removeAll(LatestVersionFileList);
//		WAS_CDEV_FileList.removeAll(BAT_CUAT_FileList);
//		LatestVersionFileList.removeAll(WAS_CDEV_FileList);
//		LatestVersionFileList.removeAll(WAS_CUAT_FileList);
//		LatestVersionFileList.removeAll(BAT_CUAT_FileList);
//		LatestVersionFileList.removeAll(BAT_CDEV_FileList);
		
		
		
//		BAT_CUAT_FileList.removeAll(LatestVersionFileList);
//		WAS_CUAT_FileList.removeAll(LatestVersionFileList);		
//		for (int i = 0; i < BAT_CUAT_FileList.size(); i++) {
//			if(BAT_CUAT_FileList.get(i).toString().contains("\\Common\\")) {
//			Pattern pattern = Pattern.compile("([:a-zA-Z0-9._\\\\]+)@@\\\\main\\\\([0-9]+)\\s*([a-zA-Z0-9._(), ]*)");
//			Matcher patternMatcher=pattern.matcher(BAT_CUAT_FileList.get(i).toString());
//				if (patternMatcher.find()){
//					patternMatch=true;
//					storeVarible = patternMatcher.group();
//					fullPath = patternMatcher.group(1);
//					versionNum = patternMatcher.group(2);
//					labelDetail = patternMatcher.group(3);
//					BAT_CUAT_Version=Integer.parseInt(versionNum);
//					for (int j = 0; j < WAS_CUAT_FileList.size(); j++) {
//						if (WAS_CUAT_FileList.get(j).toString().contains(fullPath)){
//							Pattern pattern1 = Pattern.compile("([:a-zA-Z0-9._\\\\]+)@@\\\\main\\\\([0-9]+)\\s*([a-zA-Z0-9._(), ]*)");
//							Matcher patternMatcher1=pattern1.matcher(WAS_CUAT_FileList.get(j).toString());
//								if (patternMatcher1.find()){
//									versionNum1 = patternMatcher1.group(2);
//									WAS_CUAT_Version=Integer.parseInt(versionNum1);
////									System.out.println("BAT_CUAT_FileList = "+BAT_CUAT_FileList.get(i).toString());
////									System.out.println("WAS_CUAT_FileList = "+WAS_CUAT_FileList.get(j).toString());
//									if(BAT_CUAT_Version>WAS_CUAT_Version)
//										FileList2.add(BAT_CUAT_FileList.get(i).toString());
//									else if(BAT_CUAT_Version<WAS_CUAT_Version)
//										FileList2.add(WAS_CUAT_FileList.get(j).toString());
//									else
//										FileList2.add(BAT_CUAT_FileList.get(i).toString());
//								}
//						}
//					}
//				}
//			}
//		}
//		try {
//		FileWriter fileWriter = new FileWriter(outputWAS_CUAT_FileList);
//		for (int i = 0; i < WAS_CUAT_FileList.size(); i++) {
//			fileWriter.write(WAS_CUAT_FileList.get(i).toString()+System.lineSeparator());
//		}
//		fileWriter.close();
//	} catch (IOException iox) {
//		iox.printStackTrace();
//		System.out.println("File can not save any data in outputPathList");
//	}
//		try {
//		FileWriter fileWriter = new FileWriter(outputBAT_CUAT_FileList);
//		for (int i = 0; i < BAT_CUAT_FileList.size(); i++) {
//			fileWriter.write(BAT_CUAT_FileList.get(i).toString()+System.lineSeparator());
//		}
//		fileWriter.close();
//	} catch (IOException iox) {
//		iox.printStackTrace();
//		System.out.println("File can not save any data in outputPathList");
//	}
//		try {
//		FileWriter fileWriter = new FileWriter(outputPath2);
//		for (int i = 0; i < FileList2.size(); i++) {
//			fileWriter.write(FileList2.get(i).toString()+System.lineSeparator());
//		}
//		fileWriter.close();
//	} catch (IOException iox) {
//		iox.printStackTrace();
//		System.out.println("File can not save any data in outputPathList");
//	}
		
		
		try {
		FileWriter fileWriter = new FileWriter(outputPath);
		for (int i = 0; i < LatestVersionFileList.size(); i++) {
			fileWriter.write(LatestVersionFileList.get(i).toString()+System.lineSeparator());
		}
		fileWriter.close();
	} catch (IOException iox) {
		iox.printStackTrace();
		System.out.println("File can not save any data in outputPathList");
	}
		
		try {
		FileWriter fileWriter = new FileWriter(outputPath3);
		for (int i = 0; i < LogList.size(); i++) {
			fileWriter.write(LogList.get(i).toString()+System.lineSeparator());
		}
		fileWriter.close();
	} catch (IOException iox) {
		iox.printStackTrace();
		System.out.println("File can not save any data in outputPathList");
	}
	}
}