import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class dealWithNonImportantStatements {
	public static List<String> inputPathList = new ArrayList<String>();
	public static List<String> functionNameList = new ArrayList<String>();
	public static List<String> BatchOnlineList = new ArrayList<String>();
	public static List<String> filePathList = new ArrayList<String>();
	public static List<String> statementList = new ArrayList<String>();
	public static List<String> statementNotFindPatternList = new ArrayList<String>();
	public static List<String> statementResultList = new ArrayList<String>();
	public static List<String> notRelatedList = new ArrayList<String>();
	public static List<String> notFindPatternList = new ArrayList<String>();
	public static List<String> outputInputPathList = new ArrayList<String>();
	public static List<String> outputFunctionNameList = new ArrayList<String>();
	public static Map<String, String> functionName = new HashMap<String, String>();
	public static Map<String, String> resultMap = new HashMap<String, String>();
	public static boolean relatedStatement=false;
//	public static boolean result=false;
	public static void main(String[] args) throws Exception{

		String inputCsvFilePath="T:\\jackyau\\PE_main.csv";
		String inputStatementTextPath="T:\\jackyau\\PE_Statement.txt";
		
		String outputResultPath="T:\\jackyau\\statement_PE1.csv";
		String statementResultTextPath = "T:\\jackyau\\Textstatement_PE1.txt";

		
		
		
//		String notRelatedPath="T:\\jackyau\\notRelated_CT.csv";
//		String notFindPatternPath="T:\\jackyau\\notFindPattern_CT2.csv";
//		String[] functionName;
//		String[] BatchOnline;
//		String[] filePath;
		String storeVarible1 =null;
		String storeVarible2 =null;
		String patternMatcherGroup =null;
		String patternMatcherAllGroup =null;
		int count=0;
		try {
			BufferedReader fileReader = new BufferedReader(new FileReader(inputCsvFilePath));
			String line=null;
		    try {
				while ((line = fileReader.readLine()) != null)
				{	
//					line.replaceAll("	", "");
//					line.replaceAll("  ", " ");
						String[] functionName=line.split(",",2);
						functionNameList.add(functionName[0]);
						String[] BatchOnline=functionName[1].split(",",2);
						BatchOnlineList.add(BatchOnline[0]);
						String[] filePath=BatchOnline[1].split(",",2);
						filePathList.add(filePath[0]);
//						System.out.println("filePath[1] =" +filePath[1]);
//						statementList.add(filePath[1]);

				}
				fileReader.close();
			} 
		    catch (IOException e1) {
				e1.printStackTrace();
			}
			} 
	   	catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
		BufferedReader fileReader = new BufferedReader(new InputStreamReader(new FileInputStream(inputStatementTextPath),"UTF-8"));
		String bufferedReaderline;
        while ((bufferedReaderline = fileReader.readLine()) != null) {
        	statementList.add(bufferedReaderline);
        }
        fileReader.close();
        
		System.out.println("statementList.size() = "+statementList.size());
		String patternRepeated="[a-zA-Z0-9_+:,.!~`;?���������V{}&#%@()='><\" ]*";
		String patternRepeated1="[a-zA-Z0-9_:,.!~`;?���������V{}&#%@()='><\" ]*";
		int patternSize=1;
		String storePattern="";
		for (int j = 0; j < patternSize; j++) {
			if(j==0) {//+"[+]*
				storePattern="("+patternRepeated1+")";
				patternRepeated1=storePattern;
//			System.out.println("patternRepeated = "+patternRepeated);
			}
			else {
				patternRepeated1=patternRepeated1+"[+]"+storePattern;
			}
		}
		for (int i = 0; i < statementList.size(); i++) {
			if(!statementList.get(i).toString().contains("/*")) {
				if(!statementList.get(i).toString().contains("*/")) {
			count++;
			relatedStatement=false;
			String canNotusePatternFind;
			canNotusePatternFind=statementList.get(i).toString().replaceAll("-", "12332112344321");
			canNotusePatternFind=canNotusePatternFind.replaceAll(Pattern.quote("["), "09876540987654");
			canNotusePatternFind=canNotusePatternFind.replaceAll(Pattern.quote("]"), "67890098761");
			canNotusePatternFind=canNotusePatternFind.replaceAll(Pattern.quote("*"), "989898998785");
			canNotusePatternFind=canNotusePatternFind.replaceAll(Pattern.quote("\\"), "08907605403");
			canNotusePatternFind=canNotusePatternFind.replaceAll(Pattern.quote("/"), "07890678903456");
			canNotusePatternFind=canNotusePatternFind.replaceAll(Pattern.quote("|"), "098098089076543");
//			Pattern pattern = Pattern.compile("[lL]ogger.info[a-zA-Z0-9_+:,.!?&#%()='><\" 	]*;");
			Pattern pattern = Pattern.compile("[lL]ogger.info"+patternRepeated+";");
//			Pattern pattern = Pattern.compile("[lL]ogger.info[a-zA-Z0-9_+:,.!()'-=><\" 	]*;");
			Matcher patternMatcher=pattern.matcher(canNotusePatternFind);
//			System.out.println("canNotusePatternFind =" +canNotusePatternFind);
			if (patternMatcher.find()){
				storeVarible1= patternMatcher.group();
//				System.out.println("patternMatcher1.groupCount() =" +patternMatcher.groupCount());
//				System.out.println("storeVarible1 = "+storeVarible1);
//				if(storeVarible1.contains("logger.info(\"1 aBInput\"")) {
//					System.out.println("storeVarible1 = "+storeVarible1);
//				}
				Pattern patternNotVarible = Pattern.compile("[+]");
				Matcher patternNotVaribleMatcher=patternNotVarible.matcher(storeVarible1);
				if (!patternNotVaribleMatcher.find()){
//					patternNotVaribleMatcher.group();
					if(!storeVarible1.contains("\"")) {
						relatedStatement=true;
					}
//					System.out.println("!patternNotVaribleMatcher = "+storeVarible1);
				}
				else {
//					Pattern pattern1 = Pattern.compile("[lL]ogger.info([a-zA-Z0-9_:,.!\\(\\)\\-\\'=><\" 	]*)[+]*([a-zA-Z0-9_:,!\\(\\)\\-\\'=><\" 	]*)[+]*([a-zA-Z0-9_:,!\\(\\)\\-\\'=><\" 	]*)[+]*([a-zA-Z0-9_:,!\\(\\)\\-\\'=><\" 	]*);");
//					Pattern pattern1 = Pattern.compile("[lL]ogger.info([a-zA-Z0-9_:,.!()'-=><\" 	]*)[+]*([a-zA-Z0-9_:,!()-=><\" 	]*)[+]*([a-zA-Z0-9_:,!()'-=><\" 	]*)[+]*([a-zA-Z0-9_:,!()'-=><\" 	]*);");
//					Pattern pattern1 = Pattern.compile("[lL]ogger.info([a-zA-Z0-9_:,.!\\[\\]\\(\\)\\-'=><\" 	]*)[+]*([a-zA-Z0-9_:,!\\[\\]\\(\\)\\-'=><\" 	]*)[+]*([a-zA-Z0-9_:,!\\[\\]\\(\\)\\-'=><\" 	]*)[+]*([a-zA-Z0-9_:,!\\[\\]\\(\\)\\-'=><\" 	]*);");
//					Pattern pattern1 = Pattern.compile("[lL]ogger.info[(]\"([a-zA-Z0-9_:,.!()\\-'=><\" 	]*)[+]*([a-zA-Z0-9_:,!()\\-'=><\" 	]*)[+]*([a-zA-Z0-9_:,!()\\-'=><\" 	]*)[+]*([a-zA-Z0-9_:,!()\\-'=><\" 	]*);");
//					System.out.println("patternRepeated = "+patternRepeated1);
//					Pattern pattern1 = Pattern.compile("[lL]ogger.info([a-zA-Z0-9_:,.!?&#%()'=><\" 	]*)[+]*([a-zA-Z0-9_:,.!?&#%()'=><\" 	]*)[+]*([a-zA-Z0-9_:,.!?&#%()'=><\" 	]*)[+]*([a-zA-Z0-9_:,.!?&#%()'=><\" 	]*);");
					System.out.println("statementList.get(i).toString() = "+statementList.get(i).toString());
					Pattern patternFirstPart = Pattern.compile("[lL]ogger.info"+storePattern);
					Matcher patternFirstPartMatcher=patternFirstPart.matcher(storeVarible1);
					relatedStatement=false;
					boolean group=true;
					if(patternFirstPartMatcher.find()) {
						patternMatcherAllGroup=patternFirstPartMatcher.group();
						group=removeStatementKeywords(patternMatcherAllGroup);
						if(group) {
							relatedStatement=true;
						}
						System.out.println("patternMatcherAllGroup1 = "+patternMatcherAllGroup);
					}
					Pattern patternSecondPart = Pattern.compile("[+]"+storePattern);
//					System.out.println("pattern2 = "+pattern1);
					Matcher patternMatcher1=patternSecondPart.matcher(storeVarible1);
//					System.out.println("storeVarible1 = "+storeVarible1);
					while (patternMatcher1.find()){
						patternMatcherAllGroup=patternMatcher1.group();
						String allgroupBoolean="";
						for (int j = 0; j < patternSize; j++) {
//							patternMatcherGroup=patternMatcher1.group(j+1);
							group=removeStatementKeywords(patternMatcherAllGroup);
							if(group) {
								relatedStatement=true;
							}
							System.out.println("patternMatcherAllGroup2 = "+patternMatcherAllGroup);
//							patternMatcherGroup=patternMatcher1.group(2);
//							boolean group2=removeStatementKeywords(patternMatcherGroup);
//							patternMatcherGroup=patternMatcher1.group(3);
//							boolean group3=removeStatementKeywords(patternMatcherGroup);
//							patternMatcherGroup=patternMatcher1.group(4);
//							boolean group4=removeStatementKeywords(patternMatcherGroup);
						}
						
//						if(group1||group2||group3||group4) {
//							relatedStatement=true;
//						}
//						else {
//							relatedStatement=false;
//						}
						
//						System.out.println("patternMatcherAllGroup =" +patternMatcherAllGroup);
//						System.out.println("inner-class1 =" +patternMatcher1.group(1));
//						System.out.println("inner-class2 =" +patternMatcher1.group(2));
//						System.out.println("inner-class3 =" +patternMatcher1.group(3));
//						System.out.println("inner-class4 =" +patternMatcher1.group(4));
					}
//					else {
//						System.out.println(count+"not find pattern1 : "+ statementList.get(i).toString());
////						notFindPatternList.add(functionNameList.get(i).toString()+","+BatchOnlineList.get(i).toString()+","+filePathList.get(i).toString()+","+statementList.get(i).toString());
//						notFindPatternList.add(functionNameList.get(i).toString()+","+BatchOnlineList.get(i).toString()+","+filePathList.get(i).toString());
//						//						relatedStatement=true;
//						statementNotFindPatternList.add(statementList.get(i).toString());
//					}
				}
			}
			else {
				System.out.println(count+"not find pattern2 : "+ statementList.get(i).toString());
//				notFindPatternList.add(functionNameList.get(i).toString()+","+BatchOnlineList.get(i).toString()+","+filePathList.get(i).toString()+","+statementList.get(i).toString());
				notFindPatternList.add(functionNameList.get(i).toString()+","+BatchOnlineList.get(i).toString()+","+filePathList.get(i).toString());
				statementNotFindPatternList.add(statementList.get(i).toString());
			}
			canNotusePatternFind=canNotusePatternFind.replaceAll("12332112344321","-");
			canNotusePatternFind=canNotusePatternFind.replaceAll("09876540987654","[");
			canNotusePatternFind=canNotusePatternFind.replaceAll("67890098761","]");
			canNotusePatternFind=canNotusePatternFind.replaceAll("989898998785","*");
			canNotusePatternFind=canNotusePatternFind.replaceAll("08907605403",Matcher.quoteReplacement("\\"));
			canNotusePatternFind=canNotusePatternFind.replaceAll("07890678903456",Matcher.quoteReplacement("/"));
			canNotusePatternFind=canNotusePatternFind.replaceAll("098098089076543",Matcher.quoteReplacement("|"));
//			canNotusePatternFind=canNotusePatternFind.replaceAll(Pattern.quote("\"\""),Matcher.quoteReplacement("\""));
			if(relatedStatement) {
//				inputPathList.add(functionNameList.get(i).toString()+","+BatchOnlineList.get(i).toString()+","+filePathList.get(i).toString()+","+canNotusePatternFind);
				inputPathList.add(functionNameList.get(i).toString()+","+BatchOnlineList.get(i).toString()+","+filePathList.get(i).toString());
				statementResultList.add(statementList.get(i).toString());
			}
			else {
				notRelatedList.add(functionNameList.get(i).toString()+","+BatchOnlineList.get(i).toString()+","+filePathList.get(i).toString()+","+canNotusePatternFind);
			}
////			statementList.get(i).toString();
////			Pattern pattern1 = Pattern.compile("[lL]ogger.info[(]\"([a-zA-Z0-9_:,!()><\" 	]*)+([a-zA-Z0-9_:,!()><\" 	]*)+([a-zA-Z0-9_:,!()><\" 	]*);");
////			Pattern pattern1 = Pattern.compile("[lL]ogger.info[(]\"[a-zA-Z0-9_:,.!()><\" 	]*[+]*[a-zA-Z0-9_:,!()><\" 	]*[+]*[a-zA-Z0-9_:,!()><\" 	]*;");
//			Pattern pattern1 = Pattern.compile("[lL]ogger.info[(]\"[a-zA-Z0-9_:,.!()><\" 	]*\\s*[+]*\\s*[a-zA-Z0-9_:,.!()><\" 	]*\\s*[+]*\\s*[a-zA-Z0-9_:,.!()><\" 	]*\\s*;");
//			Matcher patternMatcher1=pattern1.matcher(statementList.get(i).toString());
//			if (patternMatcher1.find()){
//				storeVarible1= patternMatcher1.group();
//				//System.out.println(count+"storeVarible1 : "+storeVarible1);
//				if(!storeVarible1.contains(";")) {
//					//System.out.println(count+"problem path : "+statementList.get(i).toString());
//				}
//				else {
//					//System.out.println(count+"problem path2 : "+storeVarible1);
//				}
//					
//			}
//			else {
////				System.out.println(count+"not find pattern : "+ statementList.get(i).toString());
//			}
				}
			}
		}
		try {
		FileWriter fileWriter = new FileWriter(outputResultPath);
		//Function name	Batch/Online	Files	Statements
		fileWriter.write("Function name,Batch/Online,Files,Statements"+System.lineSeparator());
		for (int i = 0; i < inputPathList.size(); i++) {
			fileWriter.write(inputPathList.get(i).toString()+System.lineSeparator());
		}
		//notFindPatternList
//		fileWriter.write("Not Find Pattern List!,,,"+System.lineSeparator());
		for (int i = 0; i < notFindPatternList.size(); i++) {
			fileWriter.write(notFindPatternList.get(i).toString()+System.lineSeparator());
		}
		fileWriter.close();			
	} catch (IOException iox) {
		iox.printStackTrace();
		System.out.println("File can not save any data in outputPathList");
	}
		
//		try {
//		FileWriter fileWriter = new FileWriter(notFindPatternPath);
//		//notFindPatternList
////		fileWriter.write("Not Find Pattern List!,,,"+System.lineSeparator());
//		fileWriter.write("Function name,Batch/Online,Files,Statements"+System.lineSeparator());
//		for (int i = 0; i < notFindPatternList.size(); i++) {
//			fileWriter.write(notFindPatternList.get(i).toString()+System.lineSeparator());
//		}
//		fileWriter.close();			
//	} catch (IOException iox) {
//		iox.printStackTrace();
//		System.out.println("File can not save any data in outputPathList");
//	}
		
//		try {
//		FileWriter fileWriter = new FileWriter(notRelatedPath);
//		fileWriter.write("Function name,Batch/Online,Files,Statements"+System.lineSeparator());
//		for (int i = 0; i < notRelatedList.size(); i++) {
//			fileWriter.write(notRelatedList.get(i).toString()+System.lineSeparator());
//		}
//		fileWriter.close();			
//	} catch (IOException iox) {
//		iox.printStackTrace();
//		System.out.println("File can not save any data in outputPathList");
//	}
		
		try {
			BufferedWriter fileWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(statementResultTextPath), StandardCharsets.UTF_8));
			for (int i = 0; i < statementResultList.size(); i++) {
				fileWriter.write(statementResultList.get(i).toString()+System.lineSeparator());
			}
			for (int i = 0; i < statementNotFindPatternList.size(); i++) {
				fileWriter.write(statementNotFindPatternList.get(i).toString()+System.lineSeparator());
			}
				fileWriter.close();
		} catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data in outputPathList");
		}
	}
	public static boolean removeStatementContainsKeywords(String patternMatcherGroup,String keyWords) {
		boolean result=patternMatcherGroup.contains(keyWords);
		return result;		
	}
	public static boolean removeStatementEqualKeywords(String patternMatcherGroup,String keyWords) {
		boolean result=patternMatcherGroup.contains(keyWords);
		return result;		
	}
	public static boolean removeStatementKeywords(String patternMatcherGroup) {
//		Pattern patternVarible1 = Pattern.compile("([^a-zA-Z0-9]+)");
//		Matcher patternVaribleMatcher1=patternVarible1.matcher(patternMatcherGroup);
//		boolean isNotVariable=false;
//		boolean returnRelatedStatement=false;
//		if (patternVaribleMatcher1.find()){
//			System.out.println("patternMatcherAllGroup 11111=" +patternVaribleMatcher1.group());
//			isNotVariable=patternVaribleMatcher1.group().contains("\"");
//			System.out.println("isNotVariable =" +isNotVariable);
//		}
//		if(!patternMatcherGroup.contains("\"")) {
		boolean isNotVariable=false;
		boolean returnRelatedStatement=false;
		patternMatcherGroup=patternMatcherGroup.replaceAll(Pattern.quote("logger.info( "), "");
		patternMatcherGroup=patternMatcherGroup.replaceAll(Pattern.quote("logger.info("), "");
		patternMatcherGroup=patternMatcherGroup.replaceAll(Pattern.quote("Logger.info( "), "");
		patternMatcherGroup=patternMatcherGroup.replaceAll(Pattern.quote("Logger.info("), "");
		patternMatcherGroup=patternMatcherGroup.replaceAll(Pattern.quote(" + "), "");
		patternMatcherGroup=patternMatcherGroup.replaceAll(Pattern.quote(" +"), "");
		patternMatcherGroup=patternMatcherGroup.replaceAll(Pattern.quote("+ "), "");
		patternMatcherGroup=patternMatcherGroup.replaceAll(Pattern.quote("+"), "");
//		patternMatcherGroup=patternMatcherGroup.replaceAll(Pattern.quote(""), "");
		isNotVariable=patternMatcherGroup.startsWith("\"");
		System.out.println("patternMatcherGroup_main =" +patternMatcherGroup);
		System.out.println("isNotVariable boolean=" +isNotVariable);
		if(isNotVariable==false) {
			if(!patternMatcherGroup.contains("'")){
			if(!patternMatcherGroup.trim().equals("")) {
			Pattern patternVarible = Pattern.compile("([a-zA-Z0-9]+)");
			Matcher patternVaribleMatcher=patternVarible.matcher(patternMatcherGroup);
			System.out.println("patternMatcherGroup4444 =" +patternMatcherGroup);	
//			removeStatementContainsKeywords(patternMatcherGroup,"Step");
			boolean StepOrNot=patternMatcherGroup.contains("Step");
			boolean getAbsolutePathOrNot=patternMatcherGroup.contains(".getAbsolutePath()");
			boolean listSizeOrNot=patternMatcherGroup.contains(".size()");
			boolean countOrNot=patternMatcherGroup.contains("Count");
			boolean count1OrNot=patternMatcherGroup.contains("COUNT");
			Pattern patternCount = Pattern.compile("count[A-Z]");
			Matcher patternCountMatcher=patternCount.matcher(patternMatcherGroup);
			boolean count2OrNot=false;
			if (patternCountMatcher.find()){
				count2OrNot=patternMatcherGroup.contains("count");
			}
			boolean getClassOrNot=patternMatcherGroup.contains("getClass");
			boolean getTimeOrNot=patternMatcherGroup.contains(".getTime");
			boolean getSystemOrNot=patternMatcherGroup.contains(".getSystem");
			boolean getFileNameOrNot=patternMatcherGroup.contains("FileName");
			boolean getFile1NameOrNot=patternMatcherGroup.contains("fileName");
			boolean getFilePathOrNot=patternMatcherGroup.contains("FilePath");
			boolean getFilePath1OrNot=patternMatcherGroup.contains("filePath");
			boolean getCreateTsOrNot=patternMatcherGroup.contains("CreateTs");
			boolean getCreateTs1OrNot=patternMatcherGroup.contains("createTs");
			boolean getCreateTs2OrNot=patternMatcherGroup.contains("CREATE_TS");
//			boolean getBasePathOrNot=patternMatcherGroup.contains("[bB]asePath");
			boolean pathOrNot=patternMatcherGroup.contains("Path");
			boolean DateOrNot=patternMatcherGroup.contains("Date");
			boolean Date1OrNot=patternMatcherGroup.contains("date");
			boolean getcurrentTimeOrNot=patternMatcherGroup.contains("currentTime");
			boolean getcurrentTime1OrNot=patternMatcherGroup.contains("CurrentTime");
			boolean systemTsTimeOrNot=patternMatcherGroup.contains("SystemTs");
			boolean systemTsTime1OrNot=patternMatcherGroup.contains("systemTs");
			boolean TimestampOrNot=patternMatcherGroup.contains("timeStamp");
			boolean Timestamp1OrNot=patternMatcherGroup.contains("timestamp");
			boolean Timestamp2OrNot=patternMatcherGroup.contains("TimeStamp");
			boolean Timestamp3OrNot=patternMatcherGroup.contains("Timestamp");
			boolean reportDirOrNot=patternMatcherGroup.contains("eportDir");
			boolean reportIdOrNot=patternMatcherGroup.contains("eportId");
			boolean jobNameOrNot=patternMatcherGroup.contains("JobName");
			boolean jobName1OrNot=patternMatcherGroup.contains("jobName");
			boolean jobRunOrNot=patternMatcherGroup.contains("JobRun");
			boolean jobRun1OrNot=patternMatcherGroup.contains("jobRun");
			boolean assYearOrNot=patternMatcherGroup.contains("AssYear");
			boolean assYear1OrNot=patternMatcherGroup.contains("assYear");
			boolean cntOrNot=patternMatcherGroup.contains("Cnt");
			boolean cnt1OrNot=patternMatcherGroup.contains("cnt");
			boolean timeOrNot=patternMatcherGroup.contains("Time");
			boolean time1OrNot=patternMatcherGroup.contains("time");
			boolean lengthOrNot=patternMatcherGroup.contains("Length");
			boolean length1OrNot=patternMatcherGroup.contains("length");
//			boolean DateOrNot=patternMatcherGroup.contains("Date");
			//.getTime()//fileName//fromPeriod //toPeriod
//			boolean successOrNot=patternMatcherGroup.contains("success");
			if(StepOrNot||getAbsolutePathOrNot||listSizeOrNot||
					countOrNot||getClassOrNot||count2OrNot||getTimeOrNot||
					getSystemOrNot||getFileNameOrNot||getFilePathOrNot||
					getCreateTsOrNot||getFile1NameOrNot||DateOrNot||getcurrentTimeOrNot||systemTsTimeOrNot||TimestampOrNot||reportDirOrNot||
					reportIdOrNot||jobNameOrNot||jobRunOrNot||assYearOrNot||count1OrNot||pathOrNot||cntOrNot||timeOrNot||lengthOrNot||
					getFilePath1OrNot||getCreateTs1OrNot||Date1OrNot||getcurrentTime1OrNot||systemTsTime1OrNot||Timestamp1OrNot||Timestamp2OrNot||
					Timestamp3OrNot||jobName1OrNot||jobRun1OrNot||assYear1OrNot||cnt1OrNot||time1OrNot||length1OrNot||getCreateTs2OrNot) {
				returnRelatedStatement=false;
			}
//				System.out.println("patternMatcher1.group(1) =" +patternMatcher1.group(1));	
			else if (patternVaribleMatcher.find()){
				
//				System.out.println("patternVaribleMatcher.group() equal =" +patternVaribleMatcher.group());	
				boolean countEqualorNot=patternVaribleMatcher.group().equalsIgnoreCase("count");
				boolean successEqualorNot=patternVaribleMatcher.group().equalsIgnoreCase("success");
				boolean startEqualorNot=patternVaribleMatcher.group().equalsIgnoreCase("start");
//				boolean ReportIDOrNot=patternVaribleMatcher.group().equalsIgnoreCase("reportId");
				boolean tcNoOrNot=patternVaribleMatcher.group().equalsIgnoreCase("tcNo");
				boolean fileNameOrNot=patternVaribleMatcher.group().equalsIgnoreCase("filename");
				boolean createTsOrNot=patternVaribleMatcher.group().equalsIgnoreCase("createTs");//createTs
				boolean fromPeriodOrNot=patternVaribleMatcher.group().equalsIgnoreCase("fromPeriod");
				boolean toPeriodOrNot=patternVaribleMatcher.group().equalsIgnoreCase("toPeriod");
				boolean assYrOrNot=patternVaribleMatcher.group().equalsIgnoreCase("assYr");
				boolean filePathOrNot=patternVaribleMatcher.group().equalsIgnoreCase("filepath");
				if(countEqualorNot||successEqualorNot||startEqualorNot||tcNoOrNot||createTsOrNot||fileNameOrNot
						||fromPeriodOrNot||toPeriodOrNot||assYrOrNot||filePathOrNot) {
					returnRelatedStatement=false;
				}
				else {
					returnRelatedStatement=true;
				}
			}
			else {
				System.out.println("herehere =");	
				returnRelatedStatement=true;
			}
		 }
		}
		}
		return returnRelatedStatement;
	}
}