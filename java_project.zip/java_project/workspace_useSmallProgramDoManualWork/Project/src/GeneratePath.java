import java.io.BufferedReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class GeneratePath {
	public static ArrayList<String> inputList = new ArrayList<String>();
	public static ArrayList<String> pathList = new ArrayList<String>();
	public static ArrayList<String> outputFileList = new ArrayList<String>();
	public static HashMap<String, String> inputFileMap = new HashMap<String, String>();
	public static void main(String[] args) {
		String inputPath="D:\\ccshare\\jyyau_view_ClearCase_PRD\\TAAS2_DEV\\PRD_Application";
//		String inputPath="D:\\ccshare\\jyyau_view_checking";
//		String inputFunctionListPath="T:\\jackyau\\functionList.txt";
		String outputPath="T:\\jackyau\\output111.txt";
//		String inputCloudPath="D:\\ccshare\\jyyau_view_checking\\TAAS2_UAT\\CloudMigration";
//		String outputCloudPath="T:\\jackyau\\checkingMissingFile\\CloudMigration_File.txt";
//		String folderPath="D:\\User\\jackyau1";
//		String requiredPartOfContent=" ";
//		String outputPath="D:\\User\\jackyau1\\1.GerLabelVesionPath.bat";
//		String resultBat="D:\\User\\jackyau1\\output.bat";
//		try {
//		BufferedReader fileReader = new BufferedReader(new FileReader(inputFunctionListPath));
//		String line=null;
//	    try {
//			while ((line = fileReader.readLine()) != null)
//			{	
//				inputList.add(line);
//			}
//			fileReader.close();
//		} 
//	    catch (IOException e1) {
//			e1.printStackTrace();
//		}
//		} 
//   	catch (FileNotFoundException e1) {
//			e1.printStackTrace();
//		}
//		try (Stream<Path> walk = Files.walk(Paths.get(inputPath))) {
//			List<String> result = walk.map(x -> x.toString())
//					.filter(f -> f.contains(".RUN")).collect(Collectors.toList());
		try (Stream<Path> walk = Files.walk(Paths.get(inputPath))) {
			List<String> result = walk.filter(f -> Files.isRegularFile(f))
					.map(x -> x.toString())
//					.filter(s -> s.toLowerCase().contains(".run"))
//					.filter(s -> !s.toLowerCase().contains(".keep"))
					.collect(Collectors.toList());
			walk.close();
				for (int j = 0; j < result.size(); j++) {
					File file = new File(result.get(j).toString());
					if(file.isFile()) {
//						Pattern pattern = Pattern.compile("([a-zA-Z0-9 ]+)");
//						Matcher patternMatcher=pattern.matcher(file.getName());
//						if (patternMatcher.find()){
//						if(file.getName().contains(s)) {
//							String storeVarible = patternMatcher.group();
//							}
//						}
						System.out.println(result.get(j).toString());
						pathList.add(result.get(j).toString());
					}
				  }
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
		FileWriter fileWriter = new FileWriter(outputPath);
		for (int j = 0; j < pathList.size(); j++) {
			fileWriter.write(pathList.get(j).toString()+System.lineSeparator());
		}
		fileWriter.close();
	} catch (IOException iox) {
		iox.printStackTrace();
		System.out.println("File can not save any data in outputPathList");
	}
		
//		try{    
//		    ProcessBuilder pbuilder = new ProcessBuilder(resultBat);
//		    
//		    pbuilder.directory(new File(folderPath) ); // this is where you set the root folder for the executable to run with
//		    pbuilder.redirectErrorStream(true);
//		    Process process =  pbuilder.start();
//
//		    Scanner s = new Scanner(process.getInputStream());
//		    StringBuilder text = new StringBuilder();
//		    System.out.println(System.lineSeparator());
//		    while (s.hasNextLine()) {
//		      System.out.println(s.nextLine());
//		    }
//		    s.close();
//		    int result1 = process.waitFor();
//		    
//		}catch( Exception e) {
//			e.printStackTrace();
//		}	
//		try {
//		FileWriter fileWriter = new FileWriter(outputPath);
//		for (int i = 0; i < inputFileList.size(); i++) {
//			if(count==0) {
//				fileWriter.write(inputFileList.get(i).toString()+System.lineSeparator());
//				count++;
//			}
//			else {
//				count=0;
//				}
//		}
//		fileWriter.close();
//	} catch (IOException iox) {
//		iox.printStackTrace();
//		System.out.println("File can not save any data in outputPathList");
//	}
//		try {
//			BufferedReader fileReader = new BufferedReader(new FileReader(inputPath));
//			String line=null;
//		    try {
//				while ((line = fileReader.readLine()) != null)
//				{	
//					if(line.contains(requiredPartOfContent)) {
//						inputFileList.add(line);
//					}
//				}
//				fileReader.close();
//			} 
//		    catch (IOException e1) {
//				e1.printStackTrace();
//			}
//			} 
//	   	catch (FileNotFoundException e1) {
//				e1.printStackTrace();
//			}
//		int count=0;
//		try {
//			FileWriter fileWriter = new FileWriter(outputPath);
//			for (int i = 0; i < inputFileList.size(); i++) {
//				if(count==0) {
//					fileWriter.write(inputFileList.get(i).toString()+System.lineSeparator());
//					count++;
//				}
//				else {
//					count=0;
//					}
//			}
//			fileWriter.close();
//		} catch (IOException iox) {
//			iox.printStackTrace();
//			System.out.println("File can not save any data in outputPathList");
//		}
	}
}