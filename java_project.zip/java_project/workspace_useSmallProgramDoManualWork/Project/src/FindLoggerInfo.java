import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class FindLoggerInfo {
	public static List<String> functionNameList = new ArrayList<String>();
	public static List<String> BatchOnlineList = new ArrayList<String>();
	public static List<String> filePathList = new ArrayList<String>();
	public static List<String> statementList = new ArrayList<String>();
	public static ArrayList<String> inputFileList = new ArrayList<String>();
	public static ArrayList<String> fileContentList = new ArrayList<String>();
	public static ArrayList<String> outputContent = new ArrayList<String>();
	public static ArrayList<String> csvDataList = new ArrayList<String>();
	public static HashMap<String, String> removeRepeated = new HashMap<String, String>();
	
	public static void main(String[] args) throws Exception{
		String inputPath = "T:\\jackyau\\others.csv";
		String csvInfo = "T:\\jackyau\\others_main.csv";
		String statementTextPath = "T:\\jackyau\\others_Statement.txt";
		
//		String outputPath = "T:\\jackyau\\Test_CT.csv";
		try {
			BufferedReader fileReader = new BufferedReader(new FileReader(inputPath));
			String line=null;
			String csvData="";
			String lastlineData="";
		    try {
				while ((line = fileReader.readLine()) != null)
				{	
					String[] functionName=line.split(",",2);
//					functionNameList.add(functionName[0]);
					String[] BatchOnline=functionName[1].split(",",2);
//					BatchOnlineList.add(BatchOnline[0]);
					String[] filePath=BatchOnline[1].split(",",2);
//					filePathList.add(filePath[0]);
					line=functionName[0]+","+BatchOnline[0]+","+filePath[0];
//					if(!line.equals(csvData)) {
//						csvDataList.add(line);
//						lastlineData=line;
//					}
//					csvData=line;
					
//					String[] functionName=line.split(",",2);
//					functionNameList.add(functionName[0]);
//					String[] BatchOnline=functionName[1].split(",",2);
//					BatchOnlineList.add(BatchOnline[0]);
//					String[] filePath=BatchOnline[1].split(",",2);
//					filePathList.add(filePath[0]);
					removeRepeated.put(line,"");
				}
				fileReader.close();
				if(!csvData.equals(lastlineData)) {
					csvDataList.add(line);
				}
			} 
		    catch (IOException e1) {
				e1.printStackTrace();
			}
			} 
	   	catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
//		try {
//			FileWriter fileWriter = new FileWriter(outputPath);
//			for (int i = 0; i < csvDataList.size(); i++) {
//				fileWriter.write(csvDataList.get(i).toString()+System.lineSeparator());
//			}
//				fileWriter.close();
//		} catch (IOException iox) {
//			iox.printStackTrace();
//			System.out.println("File can not save any data in outputPathList");
//		}
		
//		for (int i = 0; i < csvDataList.size(); i++) {
//		String[] functionName=csvDataList.get(i).toString().split(",",2);
//		functionNameList.add(functionName[0]);
//		String[] BatchOnline=functionName[1].split(",",2);
//		BatchOnlineList.add(BatchOnline[0]);
//		String[] filePath=BatchOnline[1].split(",",2);
//		filePathList.add(filePath[0]);
//		inputFileList.add("D:\\ccshare\\jyyau_view_ClearCase_UAT\\TAAS2_DEV\\"+filePath[0]);
//		}
		
		for (String requiredPath : removeRepeated.keySet()) {
			String[] functionName=requiredPath.split(",",2);
			functionNameList.add(functionName[0]);
			String[] BatchOnline=functionName[1].split(",",2);
			BatchOnlineList.add(BatchOnline[0]);
			String[] filePath=BatchOnline[1].split(",",2);
			filePathList.add(filePath[0]);
			inputFileList.add("D:\\ccshare\\jyyau_view_ClearCase_UAT\\TAAS2_DEV\\"+filePath[0]);
		}
//		//"D:\\ccshare\\jyyau_view_ClearCase_UAT\\TAAS2_DEV\\"+
		for (int i = 0; i < inputFileList.size(); i++) {
			BufferedReader fileReader = new BufferedReader(new InputStreamReader(new FileInputStream(inputFileList.get(i).toString()),"UTF-8"));
//			BufferedReader fileReader = new BufferedReader(new FileReader(inputFileList.get(i).toString()));
			String bufferedReaderline;
	        String fileContent="";
	        String loggerString="";
	        boolean loggerInfoHasNextLine=false;
	        while ((bufferedReaderline = fileReader.readLine()) != null) {
//	        	bufferedReaderline.replaceAll(System.lineSeparator(), "");
	        	bufferedReaderline=bufferedReaderline.replaceAll("\\s", " ");
	        	while(bufferedReaderline.contains("  ")) {
	        		bufferedReaderline=bufferedReaderline.replaceAll("  ", " ");
	        	}
	        	bufferedReaderline=bufferedReaderline.replaceFirst(" ", "");
//	        	fileContent=fileContent+bufferedReaderline+System.lineSeparator();
	        	if(!bufferedReaderline.startsWith("//")) {
	        		if(bufferedReaderline.contains("ogger.info")) {
//	        			loggerString=loggerString+bufferedReaderline;
	        			loggerInfoHasNextLine=true;
	        		}
	        		if(loggerInfoHasNextLine) {
	        			loggerString=loggerString+bufferedReaderline;
	        			System.out.println("loggerString = "+loggerString);
	        			if(bufferedReaderline.contains(";")) {
	        				loggerInfoHasNextLine=false;
	        				statementList.add(loggerString);
//	        				fileContentList.add(functionNameList.get(i).toString()+","+BatchOnlineList.get(i).toString()+","+filePathList.get(i).toString()+","+"\""+loggerString+"\"");
	        				fileContentList.add(functionNameList.get(i).toString()+","+BatchOnlineList.get(i).toString()+","+filePathList.get(i).toString()+","+"\""+loggerString+"\"");
	        				loggerString="";
	        			}
	        		}
	        	}
	        }
	        fileReader.close();
//			Pattern pattern = Pattern.compile("[a-zA-Z0-9]*[lL]ogger.info[\f]*");
//			Matcher patternMatcher=pattern.matcher(fileContent);
//			while (patternMatcher.find()){
////				patternMatcher.group();
//				System.out.println("patternMatcher.group() = "+patternMatcher.group());
//			}
//	        while(fileContent.contains("ogger.info")) {
//		        String[] splitDataFront=fileContent.split("ogger.info",2);
//		        String[] splitDataBack=splitDataFront[1].split(";",2);
////		        System.out.println("fileContentList = "+"logger.info"+splitDataBack[0]+";");
//		        fileContent=splitDataFront[0]+splitDataBack[1];
//		        String loggerString="logger.info"+splitDataBack[0]+";";
//		        loggerString=loggerString.replaceAll("\r\n", "");
////		        System.out.println("loggerString = "+loggerString);
//		        fileContentList.add(functionNameList.get(i).toString()+","+BatchOnlineList.get(i).toString()+","+filePathList.get(i).toString()+","+"\""+loggerString+"\"");
//		        statementList.add(loggerString);
//	        }
		}
		
		try {
			FileWriter fileWriter = new FileWriter(csvInfo);
//			BufferedWriter fileWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(statementPath), StandardCharsets.UTF_8));
			for (int i = 0; i < fileContentList.size(); i++) {
				fileWriter.write(fileContentList.get(i).toString()+System.lineSeparator());
			}
				fileWriter.close();
		} catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data in outputPathList");
		}
		try {
//			FileWriter fileWriter = new FileWriter(outputPath);
			BufferedWriter fileWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(statementTextPath), StandardCharsets.UTF_8));
			for (int i = 0; i < statementList.size(); i++) {
				fileWriter.write(statementList.get(i).toString()+System.lineSeparator());
			}
				fileWriter.close();
		} catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data in outputPathList");
		}
//		Pattern removePattern6 = Pattern.compile("getSqlMapClientTemplate\\s*[(]\\s*[)]\\s*((\r\n)|(\n)|(\r))*\\s*[.]\\s*([Dd])elete");
//		Matcher removePattern6Matcher=removePattern6.matcher(replacedFileContent);
//		if (removePattern6Matcher.find()){
//			replacedFileContent = removePattern6.matcher(replacedFileContent).replaceAll(Matcher.quoteReplacement("getSqlMapClientTemplate().uncheckedDelete"));
//			}
//		System.out.println("replacedFileContent =" +replacedFileContent);
	}
}