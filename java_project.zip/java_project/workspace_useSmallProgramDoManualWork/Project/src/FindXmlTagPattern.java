import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;



public class FindXmlTagPattern {
	public static ArrayList<String> latestFileList = new ArrayList<String>();
	public static String openingPath = new String();
	public static String outputFolder = new String();
	public static File fileToSave;
	public static File fileToSaveParent;
	public static String convertorFilePath = new String();
	public static String startFolder = "";
	
	public static void main(String[] args) {
//		openingPath=args[0];
		outputFolder = args[1];
		convertorFilePath = args[2];
		String[] inputSplit = openingPath.split(Pattern.quote("\\"));
		startFolder=inputSplit[inputSplit.length-1];
		String requireCsvFile =convertorFilePath+"\\outputRequiredFileMain.csv";
		try {
			BufferedReader fileReader = new BufferedReader(new FileReader(requireCsvFile));
			String line=null;
		    try {
				while ((line = fileReader.readLine()) != null)
				{	
					String[] dataStore = line.split(",");
					latestFileList.add(dataStore[1]);
				}
				fileReader.close();
			} 
		    catch (IOException e1) {
				e1.printStackTrace();
			}
			} 
	   	catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}

		for (int i = 0; i < latestFileList.size(); i++) {
			if (latestFileList.get(i).toString().endsWith(".xml")) {
				 boolean haveWhereClause = false;
				 String checkCorrectFormal = null;

				String[] prdApplicationFolderPath = latestFileList.get(i).toString().split(Pattern.quote(startFolder),2);
				String outputPath = outputFolder +"\\"+startFolder+prdApplicationFolderPath[1];
				String sampleFile = String.valueOf(outputPath);
				fileToSave = new File(outputPath);
				fileToSaveParent = new File(fileToSave.getParent());
				if (!fileToSaveParent.exists()) {
					fileToSaveParent.mkdirs();
				}

				String openingDataString = new String();
				 try {
						checkCorrectFormal = new String(Files.readAllBytes(Paths.get(sampleFile)));
						openingDataString = new String(Files.readAllBytes(Paths.get(sampleFile)));
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				 
				 
				 checkCorrectFormal = checkCorrectFormal.replaceAll("\\s*", "");
				 if (checkCorrectFormal.contains("<mappernamespace")) { 
					 String[] keepOpening = openingDataString.split("<mapper", 2);
					try {
						
						File beforeConvertFile = new File(sampleFile);

						DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
						dbFactory.setValidating(false);
						dbFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);

						DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
						Document doc = dBuilder.parse(beforeConvertFile);

						doc.getDocumentElement().normalize();
						
						NodeList docList = doc.getElementsByTagName("mapper");
						
						TransformerFactory transformerFactory = TransformerFactory.newInstance();
						Transformer transformer = transformerFactory.newTransformer();
						transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");

						DOMSource all = new DOMSource(docList.item(0));
						StreamResult allConsoleResult = new StreamResult(new StringWriter());
						transformer.transform(all, allConsoleResult);
						String allXml = allConsoleResult.getWriter().toString();
						
						NodeList nList = doc.getElementsByTagName("sql");
						String sqlTag = new String();
						String realSqlTag = new String();
						
						NodeList updateList = doc.getElementsByTagName("update");
						
						for (int temp = 0; temp < nList.getLength(); temp++) {
							Node nNode = nList.item(temp);
							if (nNode.getNodeType() == Node.ELEMENT_NODE) {
								Element eElement = (Element) nNode;

								if (eElement.getAttribute("id").toLowerCase().contains("where_clause")) {
									DOMSource sqlTagSource = new DOMSource(nNode);
									StreamResult sqlTagConsoleResult = new StreamResult(new StringWriter());
									transformer.transform(sqlTagSource, sqlTagConsoleResult);
									sqlTag = sqlTagConsoleResult.getWriter().toString();
									realSqlTag = sqlTagConsoleResult.getWriter().toString();
									if(realSqlTag.contains("where <foreach collection")) {
										realSqlTag= realSqlTag.replaceAll(Pattern.quote("where <foreach collection"), Matcher.quoteReplacement("<where> \r\n \t\t<foreach collection"));										
										realSqlTag = realSqlTag.replaceAll(Pattern.quote("</sql>"), Matcher.quoteReplacement("</where>\r\n </sql>"));
										
									}
									allXml = allXml.replaceAll(Pattern.quote(sqlTag), Matcher.quoteReplacement(realSqlTag));
									haveWhereClause=true;
								}
							}
						}
//						for (int temp = 0; temp < updateList.getLength(); temp++) {
//							Node nNode = updateList.item(temp);
//							if (nNode.getNodeType() == Node.ELEMENT_NODE) {
//								Element eElement = (Element) nNode;
//
//								if (eElement.getAttribute("id").toLowerCase().contains("where_clause")) {
//									DOMSource sqlTagSource = new DOMSource(nNode);
//									StreamResult sqlTagConsoleResult = new StreamResult(new StringWriter());
//									transformer.transform(sqlTagSource, sqlTagConsoleResult);
//									sqlTag = sqlTagConsoleResult.getWriter().toString();
//									realSqlTag = sqlTagConsoleResult.getWriter().toString();
//									if(realSqlTag.contains("where <foreach collection")) {
//										realSqlTag= realSqlTag.replaceAll(Pattern.quote("where <foreach collection"), Matcher.quoteReplacement("<where> \r\n \t\t<foreach collection"));										
//										realSqlTag = realSqlTag.replaceAll(Pattern.quote("</sql>"), Matcher.quoteReplacement("</where>\r\n </sql>"));
//										
//									}
//									allXml = allXml.replaceAll(Pattern.quote(sqlTag), Matcher.quoteReplacement(realSqlTag));
//									haveWhereClause=true;
//								}
//							}
//						}
						if(haveWhereClause) {
							try {
								if (!fileToSave.exists()) {
									fileToSave.delete();
								}
								BufferedWriter fileWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileToSave), StandardCharsets.UTF_8));
								fileWriter.write(keepOpening[0]);
								fileWriter.write(allXml);
								fileWriter.close();
							} catch (IOException iox) {
								iox.printStackTrace();
								System.out.println("File can not save any data in AfterConversion");
							}

						}
					}
					catch (Exception e) {
						
					}
					
					
				 }
			}
		}
	}
}