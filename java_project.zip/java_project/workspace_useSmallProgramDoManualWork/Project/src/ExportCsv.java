

import java.io.IOException;
import java.nio.charset.Charset;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

//import org.apache.commons.io.FileUtils;



public class ExportCsv {

	static final String JDBC_DRIVER = "com.ibm.db2.jcc.DB2Driver";
	static final String DB_URL = "jdbc:db2://XX.XX.XX.XX:50000/tadb";
	static final String USERNAME = "schema";
	static final String PASSWORD = "password";

	static Connection conn;

	public static void main(String[] args) throws SQLException, IOException {
		int countTable = 0;
		conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
		
		String tableSql ="select tabname,LISTAGG(CONCAT(CONCAT('\"',CAST(colname AS VARCHAR(10000))),'\"'), ',') AS colName, "
				+ "LISTAGG(CAST(typename AS VARCHAR(10000)) ,',') "
				+ "AS colType from syscat.columns where tabschema = '"+USERNAME+"' GROUP BY tabname order by tabname";
		Statement stmt = conn.createStatement();

		ResultSet rs = stmt.executeQuery(tableSql);
		while (rs.next()) {
			String table = rs.getString("tabname");
			String selectSql="SELECT " + "*" + " FROM "+USERNAME+"." + table;
			stmt = conn.createStatement();
			ResultSet result = stmt.executeQuery(selectSql);
			ResultSetMetaData md = result.getMetaData();
			List<String> row = new ArrayList<String>();
			List<String> col = new ArrayList<String>();

			for (int i = 1; i <= md.getColumnCount(); i++) {
				col.add("\"" + md.getColumnName(i) + "\"");
//				System.out.println("getColumn = = "+md.getColumnName(i) + " - " + md.getColumnTypeName(i));
			}
			row.add(String.join(",", col));
			while (result.next()) {
				col = new ArrayList<String>();
				for (int i = 1; i <= md.getColumnCount(); i++) {
					String str = "";
					if(result.getString(i)!=null) {
						str =result.getString(i);
					}
//					System.out.println("str = "+ str);
					str = result.getString(i) != null ? "" + result.getString(i) + "" : "";
					if(result.getString(i)!=null && i!=1 && !md.getColumnName(i).toUpperCase().contains("PRN")){
						if (isEncoded(result.getString(i)))
							str = result.getString(i) != null ? "" + result.getString(i) + "" : "";
						if (containsDigit(result.getString(i)) || result.getString(i).equals(""))
							if(md.getColumnTypeName(i).equals("VARCHAR") || md.getColumnTypeName(i).equals("CHAR"))
								str = result.getString(i) != null ?  result.getString(i)  : "";
						if (md.getColumnTypeName(i).equals("TIMESTAMP"))
							str = result.getTimestamp(i) != null
									? new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.").format(result.getTimestamp(i))
											+ String.format("%06d", result.getTimestamp(i).getNanos() / 1000)
									: "";
					}
					str="\""+str+"\"";
					col.add(str);					
				}
//				System.out.println(String.join(",", col));
				row.add(String.join(",", col));
//				System.out.println("col = "+col);
			}

//			FileUtils.writeLines(new File("D:\\db_dump\\" + table + ".csv"), row);

			stmt.close();
			result.close();

			System.out.println("table = "+table+" done!!");
			countTable++;
			System.out.println("Count no of table = "+countTable);
		}

		rs.close();

	}
	public static boolean isEncoded(String text) {
//		Charset charset = Charset.forName("US-ASCII");
		Charset charset = Charset.forName("UTF-8");
		String checked = new String(text.getBytes(charset), charset);
		return !checked.equals(text);
	}

	public static boolean containsDigit(final String aString) {
		return aString != null && !aString.isEmpty() && aString.chars().anyMatch(Character::isDigit);
	}
}
