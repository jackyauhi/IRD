//STEP 1. Import required packages
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.swing.text.html.HTMLDocument.Iterator;

public class copyFileToAnotherPath {

	public static List<String> inputFileList = new ArrayList<String>();
	public static List<String> outputFileList = new ArrayList<String>();
	
   public static void deleteFile(File element) {
		    if (element.isDirectory()) {
		        for (File sub : element.listFiles()) {
		            deleteFile(sub);
		        }
		    }
		    element.delete();
		}
   
   public static void main(String[] args) throws IOException {
	   String convertorFilePath = args[0];
	   String inputPath=convertorFilePath+"\\Result\\output";
	   String outputPath=convertorFilePath+"\\AutoSyncFiles";
	   String manualOutputPath=convertorFilePath+"\\WarningFiles";
	   File deleteFile = new File(outputPath);
	   deleteFile(deleteFile);
	   if (!deleteFile.exists()) {
		   deleteFile.mkdirs();
		}
	   deleteFile = new File(manualOutputPath);
	   deleteFile(deleteFile);
	   if (!deleteFile.exists()) {
		   deleteFile.mkdirs();
		}
	   
	   File dir = new File(inputPath);
	   Map<String, Integer> map = new HashMap<>();
	   Map<String, Integer> manualMap = new HashMap<>();
	   File listDir[] = dir.listFiles();
	   for (int j = 0; j < listDir.length; j++) {		   
	       if (listDir[j].isDirectory()) {
	    	   if (listDir[j].getName().contains("manual_")) {
	    		   manualMap.put(listDir[j].getName(), 1);
	    	   }
	    	   else 
	    		   if (listDir[j].getName().contains("_")) {
		    	   String[] splitData = listDir[j].getName().split(Pattern.quote("_"),2);
		    	   map.put(listDir[j].getName(), Integer.parseInt(splitData[0]));
	    	   }
	       }
	   }
	   Stream<Map.Entry<String,Integer>> sorted =map.entrySet().stream().sorted(Map.Entry.comparingByValue());
		Map<String, Integer> resultMap = map.entrySet().stream().sorted(Map.Entry.comparingByValue())
				  .collect(Collectors.toMap(
				    Map.Entry::getKey, 
				    Map.Entry::getValue, 
				    (oldValue, newValue) -> oldValue, LinkedHashMap::new));
		java.util.Iterator<Entry<String, Integer>> entries = resultMap.entrySet().iterator();

		process(resultMap,inputPath,outputPath);
		process(manualMap,inputPath,manualOutputPath);
   }//end main
   public static void process(Map<String, Integer> resultMap, String inputPath, String outputPath) throws IOException {
	   String[] splitPath=null;
		for ( String key : resultMap.keySet() ) {
			String requiredPath = inputPath+"\\"+key;
			try (Stream<Path> walk = Files.walk(Paths.get(requiredPath))) {
			List<String> result = walk.filter(Files::isRegularFile)
					.map(x -> x.toString()).collect(Collectors.toList());
			
//			result.forEach(System.out::println);
			
			for (int i = 0; i < result.size(); i++) {
				String filePath="";
				String sourcePath="";
				if(result.get(i).toString().contains("\\Batch\\Batch")) {
	        		splitPath = result.get(i).toString().split(Pattern.quote("\\Batch\\Batch"),2);
	        		filePath="\\Batch"+splitPath[1];
	        		sourcePath=result.get(i).toString();
	        	}
	        	else if(result.get(i).toString().contains("\\Batch_Common")){
	        		splitPath = result.get(i).toString().split(Pattern.quote("\\Batch_Common"),2);
	        		filePath="\\Batch_Common"+splitPath[1];
	        		sourcePath=result.get(i).toString();
	        	}
	        	else if(result.get(i).toString().contains("\\Common")){
	        		splitPath = result.get(i).toString().split(Pattern.quote("\\Common"),2);
	        		filePath="\\Common"+splitPath[1];
	        		sourcePath=result.get(i).toString();
	        	}
	        	else if(result.get(i).toString().contains("\\Online\\Online")){
	        		splitPath = result.get(i).toString().split(Pattern.quote("\\Online\\Online"),2);
	        		filePath="\\Online"+splitPath[1];
	        		sourcePath=result.get(i).toString();
	        	}
	        	else if(result.get(i).toString().contains("\\Report")){
	        		splitPath = result.get(i).toString().split(Pattern.quote("\\Report"),2);
	        		filePath="\\Report"+splitPath[1];
	        		sourcePath=result.get(i).toString();
	        	}
	        	else {
					if(result.get(i).toString().contains("\\Application\\")){
						splitPath = result.get(i).toString().split(Pattern.quote("\\Application\\"),2);
						filePath="\\"+splitPath[1];
						sourcePath=result.get(i).toString();
					}
					else if(result.get(i).toString().contains("\\TAAS2_DEV\\")){
						splitPath = result.get(i).toString().split(Pattern.quote("\\TAAS2_DEV\\"),2);
						filePath="\\"+splitPath[1];
						sourcePath=result.get(i).toString();
					}
					else {
		        		System.out.println("Remove this file : " +result.get(i).toString());
					}
	        	}

				if(!filePath.equals("")) {
					File fileToSave = new File(outputPath+filePath);
					File sourceFile = new File(sourcePath);
					File fileToSaveParent=new File(fileToSave.getParent());
					if (!fileToSaveParent.exists()) {
						fileToSaveParent.mkdirs();
					}
//					if (fileToSave.exists()) {
//						if(!sourceFile.exists()) {
							fileToSave.delete();
							transform(sourceFile,"UTF-8",fileToSave,"UTF-8");
//						}
//					}
//					else {
//						if(!sourceFile.exists()) {
//							transform(sourceFile,"UTF-8",fileToSave,"UTF-8");
//						}
//					}
				}
			}
		}
	}
   }
   public static void transform(File source, String srcEncoding, File target, String tgtEncoding) throws IOException {
	    BufferedReader br = null;
	    BufferedWriter bw = null;
	    try{
	        br = new BufferedReader(new InputStreamReader(new FileInputStream(source),srcEncoding));
	        bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(target), tgtEncoding));
	        char[] buffer = new char[16384];
	        int read;
	        while ((read = br.read(buffer)) != -1)
	            bw.write(buffer, 0, read);
	    } finally {
	        try {
	            if (br != null)
	                br.close();
	        } finally {
	            if (bw != null)
	                bw.close();
	        }
	    }
	}
}//end FirstExample