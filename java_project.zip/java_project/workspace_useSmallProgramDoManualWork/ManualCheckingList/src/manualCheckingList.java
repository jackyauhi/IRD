import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class manualCheckingList {
	public static int count =0;
	public static String dirCLD2 = "D:\\ccshare\\jyyau_view_ClearCase_PRD\\TAAS2_DEV\\PRD_Application";
//	public static String dirCLD2 = "D:\\ccshare\\jyyau_view_ClearCase_MTN\\TAAS2_UAT\\CloudMigration\\Application\\Batch\\CT_Batch\\src\\ird\\taas2\\batch\\ct\\ctalf1\\CleanTmpWorker.java";
//	public static String dirCLD2 = "D:\\ccshare\\jyyau_view_ClearCase_MTN\\TAAS2_UAT\\CloudMigration\\Application\\Batch\\CT_Batch\\src\\ird\\taas2\\batch\\ct\\ctaua1\\Ctaua1CleanupWorker.java";
	
	public static HashMap<String, String> autowiredMap = new HashMap<String, String>();
	public static List<String> mainTargetList = new ArrayList<String>();
	public static List<String> mainSourceList = new ArrayList<String>();
	public static List<String> finalTargetList = new ArrayList<String>();
	public static List<String> finalSourceList = new ArrayList<String>();
	public static List<String> checkingList = new ArrayList<String>();
	public static List<String> TotalImportList = new ArrayList<String>();
	public static List<String> ExistImportList = new ArrayList<String>();
	public static List<String> OutputList = new ArrayList<String>();
	public static boolean nonDaoFile = true;
	public static void main(String[] args) throws Exception{
		String dirCLD = args[0];
		
		test4(dirCLD);
		
	}
	public static void test4(String dirCLD) throws IOException{
		String inputPath=dirCLD+"\\AutoSyncFiles";
		String outputPath=dirCLD+"\\WarningFiles";
		String filePath="";
		
		Stream<Path> fwalk = Files.walk(Paths.get(inputPath));
		Stream<Path> fwalkJava = Files.walk(Paths.get(dirCLD2));
//		Stream<Path> fwalk = Files.walk(Paths.get(inputPath));
		List<String> cldFList = fwalk.filter(f -> Files.isRegularFile(f))
				.map(x -> x.toString())
				.filter(s -> s.toLowerCase().endsWith("xml"))
				.collect(Collectors.toList());
		fwalk.close();
		List<String> cldFListJava = fwalkJava.filter(f -> Files.isRegularFile(f))
				.map(x -> x.toString())
				.filter(s -> s.toLowerCase().endsWith("java"))
				.collect(Collectors.toList());
		fwalk.close();
		
		for(String file : cldFList) {
//			System.out.println(file);
			if(containNestedForeach(file)){
				System.out.println(file);
				process(file,outputPath);
			}
			else if(containShrVariable(file)){
				System.out.println(file);
				process(file,outputPath);
			}
		}
		for(String file : cldFListJava) {
			
			if(containAutowireAndNonInterface(file)){
				
			}
		}
		for(String file : cldFListJava) {
			for (String requiredPath : autowiredMap.keySet()) {
				String[] storeVarible = requiredPath.split(",",2);
//				System.out.println("storeVarible =" +storeVarible[1]);
//				System.out.println("file =" +file);
				if(file.contains(storeVarible[1])) {
					ExistImportList.add(storeVarible[1]);
					String content = null;
					try {
						content = new String(Files.readAllBytes(Paths.get(file)));
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Pattern pattern = Pattern.compile("public([ 	((\r\n)|(\r)|(\n))]*)([a-zA-Z0-9_]*)([ 	((\r\n)|(\r)|(\n))]*)(class|interface)([ 	((\r\n)|(\r)|(\n))]*)([a-zA-Z0-9_]*)([ 	((\r\n)|(\r)|(\n))]*)([a-zA-Z0-9_]*)([ 	((\r\n)|(\r)|(\n))]*)([a-zA-Z0-9_]*)([ 	((\r\n)|(\r)|(\n))]*)([a-zA-Z0-9_]*)([ 	((\r\n)|(\r)|(\n))]*)([a-zA-Z0-9_]*)([ 	((\r\n)|(\r)|(\n))]*)[{]");
					String storeVarible1 =null;
					Matcher patternMatcher=pattern.matcher(content);
					while (patternMatcher.find()){
						storeVarible1= patternMatcher.group();
//						storeVarible1=storeVarible1.replaceAll(Pattern.quote("{"), "");
//						String[] storeVarible2 = storeVarible1.split(" ");
						
						String[] storePath = file.split(Pattern.quote("\\src\\"));
						File filePathmain = new File(file);
						String fileName= filePathmain.getName().replaceAll(".java", "");
//						System.out.println("storeVarible1 ="+ storeVarible1);
//						System.out.println("storeVarible2[2] ="+ storeVarible2[2]);

						if (storeVarible1.contains(" implements ")){
							System.out.println("storeVarible1 ="+ storeVarible1);
							System.out.println("Maintarget =" +file);
							mainTargetList.add(fileName);
							mainSourceList.add(storePath[1]);
							checkingList.add(file);
						}
						else if (patternMatcher.group(6).toLowerCase().endsWith("impl")){
							System.out.println("patternMatcher.group(6) ="+ patternMatcher.group(6));
							System.out.println("Maintarget =" +file);
							mainTargetList.add(fileName);
							mainSourceList.add(storePath[1]);
							checkingList.add(file);
						}
						else if (patternMatcher.group(10).toLowerCase().endsWith("impl")){
								System.out.println("patternMatcher.group(10) ="+ patternMatcher.group(10));
								System.out.println("Maintarget =" +file);
								mainTargetList.add(fileName);
								mainSourceList.add(storePath[1]);
								checkingList.add(file);
							}
						else if (patternMatcher.group(14).toLowerCase().endsWith("impl")){
							System.out.println("patternMatcher.group(14) ="+ patternMatcher.group(14));
							System.out.println("Maintarget =" +file);
							mainTargetList.add(fileName);
							mainSourceList.add(storePath[1]);
							checkingList.add(file);
						}
						else {
//								System.out.println("Maintarget =" +file);
						}
						

					}
				}
			}
		}
		TotalImportList.removeAll(ExistImportList);
		for (int j = 0; j < TotalImportList.size(); j++) {
			if(TotalImportList.get(j).toString().contains("ird\\taas2")) {
				System.out.println("Non-target =" +TotalImportList.get(j).toString()+System.lineSeparator());
			}
        }
		for (int j = 0; j < checkingList.size(); j++) {
			System.out.println("checkingListPath =" +checkingList.get(j).toString());
			String content = null;
			try {
				content = new String(Files.readAllBytes(Paths.get(checkingList.get(j).toString())));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Pattern pattern = Pattern.compile("package([a-zA-Z0-9._ ]*);");
			String storeVarible =null;
			Matcher patternMatcher=pattern.matcher(content);
			if (patternMatcher.find()){
				storeVarible=patternMatcher.group();
				System.out.println("package =" +storeVarible);
				if(storeVarible.toLowerCase().contains("daoimpl.")) {
					finalTargetList.add(mainTargetList.get(j).toString());
					finalSourceList.add(mainSourceList.get(j).toString());
				}
				else if(storeVarible.toLowerCase().contains(".dao.")) {
					finalTargetList.add(mainTargetList.get(j).toString());
					finalSourceList.add(mainSourceList.get(j).toString());
				}
			}
		}
		for(String file : cldFListJava) {
			String content = null;
			try {
				content = new String(Files.readAllBytes(Paths.get(file)));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			Pattern pattern = Pattern.compile("@Autowired([a-zA-Z0-9 ((\r\n)|(\r)|(\n))]*);");
			String storeVarible =null;
			Matcher patternMatcher=pattern.matcher(content);

			while (patternMatcher.find()){
				storeVarible = patternMatcher.group();
				storeVarible=storeVarible.replaceAll(";", "");
				storeVarible=storeVarible.replaceAll("@Autowired", "");
				storeVarible=storeVarible.replaceAll("private", "");

				Pattern patternJavaFile = Pattern.compile("([ 	((\r\n)|(\r)|(\n))]*)([a-zA-Z0-9]*)([ 	((\r\n)|(\r)|(\n))]*)([a-zA-Z0-9]*)([ 	((\r\n)|(\r)|(\n))]*)");
				String storeVaribleJavaFile =null;
				Matcher patternMatcherJavaFile=patternJavaFile.matcher(storeVarible);
				if (patternMatcherJavaFile.find()){
					storeVaribleJavaFile=patternMatcherJavaFile.group(2);
					for (int j = 0; j < finalTargetList.size(); j++) {				
						if(storeVaribleJavaFile.equals(finalTargetList.get(j).toString().trim())) {
							OutputList.add(file+"    ||    Source  =  "+finalSourceList.get(j).toString().trim());
						}
					}
				}
			}
		}
		try {
		FileWriter fileWriter = new FileWriter("T:\\jackyau\\aaa.txt");
		for (int j = 0; j < finalTargetList.size(); j++) {
			fileWriter.write(finalTargetList.get(j).toString().trim()+System.lineSeparator());
        }
		fileWriter.close();
	} catch (IOException iox) {
		iox.printStackTrace();
		System.out.println("File can not save any data in outputPathList");
	}
		try {
		FileWriter fileWriter = new FileWriter("T:\\jackyau\\bbb.txt");
		for (int j = 0; j < OutputList.size(); j++) {
			fileWriter.write(OutputList.get(j).toString()+System.lineSeparator());
        }
		fileWriter.close();
	} catch (IOException iox) {
		iox.printStackTrace();
		System.out.println("File can not save any data in outputPathList");
	}

		
	}
	private static boolean containAutowireAndNonInterface(String file) throws IOException {
		// TODO Auto-generated method stub
		String content = null;
		try {
			content = new String(Files.readAllBytes(Paths.get(file)));
			if(!content.contains("@Autowired")) 
				return false;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Pattern pattern = Pattern.compile("@Autowired([a-zA-Z0-9 	((\r\n)|(\r)|(\n))]*);");
		String storeVarible =null;
		Matcher patternMatcher=pattern.matcher(content);

		while (patternMatcher.find()){
			nonDaoFile = true;
			storeVarible = patternMatcher.group();
//			System.out.println("storeVarible =" +storeVarible);
			storeVarible=storeVarible.replaceAll(";", "");
			storeVarible=storeVarible.replaceAll("@Autowired", "");
			storeVarible=storeVarible.replaceAll("private", "");
			storeVarible=storeVarible.replaceAll("public", "");
			Pattern patternJavaFile = Pattern.compile("([ 	((\r\n)|(\r)|(\n))]*)([a-zA-Z0-9]*)([ 	((\r\n)|(\r)|(\n))]*)([a-zA-Z0-9]*)([ 	((\r\n)|(\r)|(\n))]*)");
			String storeVaribleJavaFile =null;
			Matcher patternMatcherJavaFile=patternJavaFile.matcher(storeVarible);
			if (patternMatcherJavaFile.find()){
				storeVaribleJavaFile=patternMatcherJavaFile.group(2);
//				System.out.println("storeVaribleJavaFile =" +storeVaribleJavaFile);
//				System.out.println("storeVaribleJavaFile1 =" +patternMatcherJavaFile.group(1));

			}
//			System.out.println("storeVaribleJavaFile2 =" +storeVaribleJavaFile);
//			String[] storeVarible1 = storeVarible.split(" ",2);
//			System.out.println("storeVarible1 =" +storeVarible1[0]);
//			if(file.contains("Web_Service")) {
//				return false;
//			}
//			else 
			if(storeVaribleJavaFile.equals("")) {
				nonDaoFile = false;
			}
			else if(storeVaribleJavaFile.endsWith("Dao")) {
				nonDaoFile = false;
			}
			else if(storeVaribleJavaFile.endsWith("DAO")) {
				nonDaoFile = false;
			}
			else if(storeVaribleJavaFile.toLowerCase().endsWith("daoimpl")) {
				nonDaoFile = false;
				OutputList.add(file+"    ||    @Autowired have daoimpl is error! ");
			}
//			else {
//				System.out.println("file =" +file);
//				System.out.println("target =" +storeVarible1[0]);
//			}
			if(nonDaoFile) {
			Pattern patternImport = Pattern.compile("import([a-zA-Z0-9._ 	((\r\n)|(\r)|(\n)]*);");
			String storeVaribleImport =null;
			Matcher patternMatcherImport=patternImport.matcher(content);
			while (patternMatcherImport.find()){
				storeVaribleImport = patternMatcherImport.group();
//				System.out.println("storeVaribleImport =" +storeVaribleImport);
				Pattern patternImport1 = Pattern.compile(".([ 	((\r\n)|(\r)|(\n))]*)([a-zA-Z0-9_]*)([ 	((\r\n)|(\r)|(\n))]*);");
				String storeVaribleImport1 =null;
				Matcher patternMatcherImport1=patternImport1.matcher(storeVaribleImport);
				while (patternMatcherImport1.find()){
					storeVaribleImport1 = patternMatcherImport1.group(2);
					storeVaribleImport=storeVaribleImport.replaceAll(";", "");
					storeVaribleImport=storeVaribleImport.replaceAll("import", "");
					storeVaribleImport=storeVaribleImport.replaceAll(Pattern.quote("."), Matcher.quoteReplacement("\\"));
					storeVaribleImport=storeVaribleImport.replaceAll("\\s","");
					if(storeVaribleImport1.equals(storeVaribleJavaFile)) {
						autowiredMap.put(storeVaribleJavaFile+","+storeVaribleImport, "");
						TotalImportList.add(storeVaribleImport);
//						System.out.println("storeVaribleImport =" +storeVaribleImport);
//						System.out.println("storeVaribleImport1 =" +storeVaribleImport1);
					}
				}
//				System.out.println("storeVaribleImport =" +storeVaribleImport);
//				if(storeVaribleImport.contains(storeVarible1[0])) {
//					autowiredMap.put(storeVarible1[0]+","+storeVaribleImport, "");
//				}
				}
//			Pattern patternInnerClass = Pattern.compile("public static (class|interface) ([a-zA-Z0-9._ ((\r\n)|(\r)|(\n))]*)[{]");
//			Pattern patternInnerClass = Pattern.compile("public (class|interface) ([a-zA-Z0-9._ ((\r\n)|(\r)|(\n))]*)[{]");
			Pattern patternInnerClass = Pattern.compile("public([ 	((\r\n)|(\r)|(\n))]*)([a-zA-Z0-9_]*)([ 	((\r\n)|(\r)|(\n))]*)(class|interface)([ 	((\r\n)|(\r)|(\n))]*)([a-zA-Z0-9_]*)([ 	((\r\n)|(\r)|(\n))]*)"
					+ "([a-zA-Z0-9_]*)([ 	((\r\n)|(\r)|(\n))]*)([a-zA-Z0-9_]*)([ 	((\r\n)|(\r)|(\n))]*)([a-zA-Z0-9_]*)([ 	((\r\n)|(\r)|(\n))]*)([a-zA-Z0-9_]*)([ 	((\r\n)|(\r)|(\n))]*)[{]");
			String storeVaribleInnerClass =null;
			Matcher patternMatcherInnerClass=patternInnerClass.matcher(content);
//			System.out.println("content =" +content);
			while (patternMatcherInnerClass.find()){
				storeVaribleInnerClass= patternMatcherInnerClass.group();
//				System.out.println("inner-class =" +storeVaribleInnerClass);
//				System.out.println("inner-class1 =" +patternMatcherInnerClass.group(1));
//				System.out.println("inner-class2 =" +patternMatcherInnerClass.group(2));
//				System.out.println("inner-class3 =" +patternMatcherInnerClass.group(3));
//				System.out.println("inner-class4 =" +patternMatcherInnerClass.group(4));
//				System.out.println("inner-class5 =" +patternMatcherInnerClass.group(5));
//				System.out.println("inner-class6 =" +patternMatcherInnerClass.group(6));
//				System.out.println("inner-class7 =" +patternMatcherInnerClass.group(7));
//				System.out.println("inner-class8 =" +patternMatcherInnerClass.group(8));
//				System.out.println("inner-class9 =" +patternMatcherInnerClass.group(9));
//				System.out.println("storeVaribleJavaFile =" +storeVaribleJavaFile);
				String[] storePath = file.split(Pattern.quote("\\src\\"));
				File filePathmain = new File(file);
				String fileName= filePathmain.getName().replaceAll(".java", "");
				if(storeVaribleInnerClass.contains(storeVaribleJavaFile)) {
					if (storeVaribleInnerClass.contains(" implements ")){
						System.out.println("storeVaribleInnerClass ="+ storeVaribleInnerClass);
						System.out.println("Maintarget =" +file);
						mainTargetList.add(fileName);
						mainSourceList.add(storePath[1]);
						checkingList.add(file);
					}
					else if (patternMatcherInnerClass.group(6).toLowerCase().endsWith("impl")){
						System.out.println("patternMatcherInnerClass.group(6) ="+ patternMatcherInnerClass.group(6));
						System.out.println("Maintarget =" +file);
						mainTargetList.add(fileName);
						mainSourceList.add(storePath[1]);
						checkingList.add(file);
					}
					else if (patternMatcherInnerClass.group(10).toLowerCase().endsWith("impl")){
							System.out.println("patternMatcherInnerClass.group(10) ="+ patternMatcherInnerClass.group(10));
							System.out.println("Maintarget =" +file);
							mainTargetList.add(fileName);
							mainSourceList.add(storePath[1]);
							checkingList.add(file);
						}
					else if (patternMatcherInnerClass.group(14).toLowerCase().endsWith("impl")){
						System.out.println("patternMatcherInnerClass.group(10) ="+ patternMatcherInnerClass.group(10));
						System.out.println("Maintarget =" +file);
						mainTargetList.add(fileName);
						mainSourceList.add(storePath[1]);
						checkingList.add(file);
					}
//					System.out.println("inner-class1 =" +patternMatcherInnerClass.group(1));
//					System.out.println("inner-class2 =" +patternMatcherInnerClass.group(2));
//					System.out.println("inner-class3 =" +patternMatcherInnerClass.group(3));
//					System.out.println("inner-class4 =" +patternMatcherInnerClass.group(4));
//					System.out.println("inner-class5 =" +patternMatcherInnerClass.group(5));
//					System.out.println("inner-class6 =" +patternMatcherInnerClass.group(6));
//					System.out.println("inner-class7 =" +patternMatcherInnerClass.group(7));
//					System.out.println("inner-class8 =" +patternMatcherInnerClass.group(8));
//					System.out.println("inner-class9 =" +patternMatcherInnerClass.group(9));
//					System.out.println("inner-class10 =" +patternMatcherInnerClass.group(10));
//					System.out.println("inner-class11 =" +patternMatcherInnerClass.group(11));
//					System.out.println("inner-class12 =" +patternMatcherInnerClass.group(12));
//					System.out.println("inner-class13 =" +patternMatcherInnerClass.group(13));
//					System.out.println("inner-class14 =" +patternMatcherInnerClass.group(14));
				}
			 }
			}
		}
		

		
		return true;
	}
	
	private static boolean containShrVariable(String file) throws IOException {
		// TODO Auto-generated method stub
		String content = null;
		try {
			content = new String(Files.readAllBytes(Paths.get(file)));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Pattern pattern = Pattern.compile("<if test=\"\\s*[sS][hH][rR]\\s*[!=]=\\s*([a-zA-Z0-9_]+)\\s*\">");
		String storeVarible =null;
		Matcher patternMatcher=pattern.matcher(content);
		if (patternMatcher.find()){
//			storeVarible = patternMatcher.group();
//			System.out.println("storeVarible =" +storeVarible);
			return true;
		}
		pattern = Pattern.compile("<if test=\"\\s*([a-zA-Z0-9._ !=]+)[.][sS][hH][rR]\\s*[!=]=\\s*([a-zA-Z0-9_]+)\\s*\">");
		storeVarible =null;
		patternMatcher=pattern.matcher(content);
		if (patternMatcher.find()){
//			storeVarible = patternMatcher.group();
//			System.out.println("storeVarible =" +storeVarible);
			return true;
		}
//		count++;
//		System.out.println("file =" +file);
//		System.out.println("count =" +count);
		
		return false;
	}
	
	private static boolean containNestedForeach(String file) throws IOException {
		// TODO Auto-generated method stub
		List<String> content = Files.readAllLines(Paths.get(file));
		
		String contentStr = String.join("", content);

		contentStr = contentStr.replaceAll("<sql id=\"([a-zA-Z0-9._ ]*)([Ww])here_([Cc])lause([a-zA-Z0-9._ ]*)\"[\\s\\S]*sql>", "");
		

		
		if(contentStr.indexOf("foreach")==-1) return false;
		
		contentStr = contentStr.substring(contentStr.indexOf("foreach")+7, contentStr.length());
		

		if(!contentStr.substring(contentStr.indexOf("foreach")-2).startsWith("</")) return true;
		
		
		return false;
	}
	   public static void process(String inputPath, String outputPath) throws IOException {
		   String[] splitPath=null;
				

					String filePath="";
					String sourcePath="";
						if(inputPath.contains("\\AutoSyncFiles\\")){
							splitPath = inputPath.split(Pattern.quote("\\AutoSyncFiles\\"),2);
							filePath="\\"+splitPath[1];
							sourcePath=inputPath;
						}
//						else if(inputPath.contains("\\TAAS2_UAT\\")){
//							splitPath = inputPath.split(Pattern.quote("\\TAAS2_UAT\\"),2);
//							filePath="\\"+splitPath[1];
//							sourcePath=inputPath;
//						}
//						else {
//			        		System.out.println("Remove this file : " +inputPath);
//						}
		        	

					if(!filePath.equals("")) {
						File fileToSave = new File(outputPath+filePath);
						File sourceFile = new File(sourcePath);
						File fileToSaveParent=new File(fileToSave.getParent());
						if (!fileToSaveParent.exists()) {
							fileToSaveParent.mkdirs();
						}
								fileToSave.delete();
								transform(sourceFile,"UTF-8",fileToSave,"UTF-8");
								sourceFile.delete();
					}	
	   }
	   public static void transform(File source, String srcEncoding, File target, String tgtEncoding) throws IOException {
		    BufferedReader br = null;
		    BufferedWriter bw = null;
		    try{
		        br = new BufferedReader(new InputStreamReader(new FileInputStream(source),srcEncoding));
		        bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(target), tgtEncoding));
		        char[] buffer = new char[16384];
		        int read;
		        while ((read = br.read(buffer)) != -1)
		            bw.write(buffer, 0, read);
		    } finally {
		        try {
		            if (br != null)
		                br.close();
		        } finally {
		            if (bw != null)
		                bw.close();
		        }
		    }
		}
}