package main;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;


public class CompareDiff {
	
	public List<LinkedHashMap<String, Integer>> compareDiff(String fileStr1, String fileStr2) throws IOException{
	    String sCurrentLine;
	    LinkedHashMap<String, Integer> originalrecords = new LinkedHashMap<String, Integer>();
	    LinkedHashMap<String, Integer> newrecords = new LinkedHashMap<String, Integer>();
	    
	    //FileReader fr = new FileReader(fileStr1);
	    BufferedReader br1 = new BufferedReader(new InputStreamReader(new FileInputStream(fileStr1),"UTF-8"));
	    BufferedReader br2 = new BufferedReader(new InputStreamReader(new FileInputStream(fileStr2),"UTF-8"));			
	    
	    while ((sCurrentLine = br1.readLine()) != null) {
	    	sCurrentLine = formatLine(sCurrentLine);
	    	if(isSkippable(sCurrentLine)) continue;
	        if (originalrecords.containsKey(sCurrentLine)) {
	        	originalrecords.put(sCurrentLine, originalrecords.get(sCurrentLine) + 1);
	        } else {
	        	originalrecords.put(sCurrentLine, 1);
	        }
	    }
	    while ((sCurrentLine = br2.readLine()) != null) {
	    	sCurrentLine = formatLine(sCurrentLine);
	    	if(isSkippable(sCurrentLine)) continue;
	        if (originalrecords.containsKey(sCurrentLine)) {
	            int expectedCount = originalrecords.get(sCurrentLine) - 1;
	            if (expectedCount == 0) {
	            	originalrecords.remove(sCurrentLine);
	            } else {
	            	originalrecords.put(sCurrentLine, expectedCount);
	            }
	        } else {
	            if (newrecords.containsKey(sCurrentLine)) {
	            	newrecords.put(sCurrentLine, newrecords.get(sCurrentLine) + 1);
	            } else {
	            	newrecords.put(sCurrentLine, 1);
	            }
	        }
	    }
	    
	    
	    List<LinkedHashMap<String, Integer>> obj = new ArrayList<LinkedHashMap<String, Integer>>();
	    
	    obj.add(originalrecords);
	    obj.add(newrecords);
	    
	    return obj;
	}
	
	public String formatLine(String line){
		line = line.trim();
		return line;
	}
	

    boolean isSkippable(String oriStr){
    	if(oriStr.startsWith("//")) return true;
    	if(oriStr.startsWith("@")) return true;
    	if("".equals(oriStr)) return true;
    	if(oriStr.contains("/*") || oriStr.contains("*/") || oriStr.startsWith("*")) return true;
    	
    	return false;
    	
    }
    
    
    public String retrivePattern(String oriStr){
		Pattern removePattern1 = Pattern.compile("[a-zA-Z0-9.]*StringUtil[s]*.[a-zA-Z0-9]*[(]");
		Matcher removePattern1Matcher=removePattern1.matcher(oriStr);
		String storeVarible1 =null;
		while (removePattern1Matcher.find()){
			storeVarible1 = removePattern1Matcher.group();
			System.out.println("" +storeVarible1.replace("(", ""));
			
		}
		return storeVarible1;
    }
  
}
