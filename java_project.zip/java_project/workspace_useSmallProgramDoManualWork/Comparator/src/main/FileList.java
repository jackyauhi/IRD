package main;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;


public class FileList {
	int count = 0;
	
	String fStr1 = "";
	String fStr2 = "";
	
	String dir1str = "C:\\Users\\ecochan\\Desktop\\prd\\PRD_Application";
	String dir2str = "D:\\ccshare\\ecochan_view\\TAAS2_UAT\\CloudMigration\\Application";
	
	HashMap<String, String> f1map;
	HashMap<String, String> f2map;
	
	public FileList(){
		this.f1map= new HashMap<String, String>();
		this.f2map = new HashMap<String, String>();
		try {
			process();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public HashMap<String, String> getF1map() {
		return f1map;
	}



	public HashMap<String, String> getF2map() {
		return f2map;
	}



	void process() throws IOException{
		listDir(dir1str, 1);
		listDir(dir2str, 2);
		
	}
	

	void listDir(String dirStr,int ind) throws IOException{
		File dir = new File(dirStr); 
		if(dir.exists() && dir.isDirectory()) { 
			File arr[] = dir.listFiles(); 
            RecursivePrint(arr,0, ind);
		}
	}

	void RecursivePrint(File[] arr, int index,int ind) throws IOException {
		if (index == arr.length)
			return;
		if (arr[index].isFile()){
			String key = arr[index].getAbsolutePath();
			
			
			
			if(ind==1) {
				key = key.replace(dir1str, "");
				f1map.put(key,arr[index].getAbsolutePath());
			}
			if(ind==2) {
				key = key.replace(dir2str, "");
				f2map.put(key,arr[index].getAbsolutePath());
			}
		}else if (arr[index].isDirectory()) {
			RecursivePrint(arr[index].listFiles(), 0, ind);
		}
		RecursivePrint(arr, ++index,ind);
	}

}
