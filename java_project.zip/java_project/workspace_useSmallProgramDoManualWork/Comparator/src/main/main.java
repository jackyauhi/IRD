package main;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class main {
	public static void main(String args[]) throws IOException  {
		
		String outputfile = "draft.csv";
		OutputStreamWriter csvWriter = new OutputStreamWriter(new FileOutputStream(outputfile),"UTF-8");
		csvWriter.append("Projects");
		csvWriter.append(",");
		csvWriter.append("Programs");
		csvWriter.append(",");
		csvWriter.append("Original");
		csvWriter.append(",");
		csvWriter.append("New");
		csvWriter.append(",");
		csvWriter.append("Remarks");
		csvWriter.append("\n");

		FileList fileList = new FileList();
		HashMap<String, String> hm1 = fileList.getF1map();
		HashMap<String, String> hm2 = fileList.getF2map();
		
		for(String fstr1 : hm1.keySet()){
			String f1 = hm1.get(fstr1);
			String f2 = hm2.get(fstr1);
		
			if(f2!=null){
				List<LinkedHashMap<String, Integer>> diff = new CompareDiff().compareDiff(f1, f2);
				if(diff!=null){
					LinkedHashMap<String, Integer> originalrecords = diff.get(0);
					LinkedHashMap<String, Integer> newrecords = diff.get(1);
					
					if(originalrecords.isEmpty() && newrecords.isEmpty() || (originalrecords.size()==0&&newrecords.size()==0)) continue;
						
					System.out.println("f1 : " + f1);
					System.out.println("f2 : " + f2);
					String[] patharr = fstr1.split("\\\\");
					String project = patharr[2];
					String program = fstr1;
					String remarks = "";
					
					System.out.println("project : " + project);
					System.out.println("program : " + program);
					System.out.println("remarks : " + remarks);
					
					System.out.println("originalrecords");
					for(String diff1 : originalrecords.keySet())
						System.out.println(diff1);
					System.out.println("newrecords");
					for(String diff2 : newrecords.keySet())
						System.out.println(diff2);
							
					String odiff = "";
					String ndiff = "";

					odiff = odiff.substring(0,odiff.length());
					ndiff = ndiff.substring(0,ndiff.length());
	
					Iterator<Map.Entry<String, Integer>> entries = originalrecords.entrySet().iterator();
					while (entries.hasNext()) {
					    Map.Entry<String, Integer> entry = entries.next();
					    odiff +=  entry.getKey();
					    if(entries.hasNext()) odiff +="\n";
					}
					
					entries = newrecords.entrySet().iterator();
					while (entries.hasNext()) {
					    Map.Entry<String, Integer> entry = entries.next();
					    ndiff +=  entry.getKey();
					    if(entries.hasNext()) ndiff +="\n";
					}
		
					odiff = odiff.replace("\"", "'");
					ndiff = ndiff.replace("\"", "'");
					
					odiff = "\"" + odiff +"\"";
					ndiff = "\"" + ndiff +"\"";

					
					System.out.println("odiff = " + odiff);
					System.out.println("ndiff = " + ndiff);
					System.out.println("===================================================================================================");
					List<List<String>> rows = Arrays.asList(Arrays.asList(project, program, odiff,ndiff,remarks));
					for (List<String> rowData : rows) {
					    csvWriter.append(String.join(",", rowData));
					    csvWriter.append("\n");
					}
									
					
				}
				
				
				
			}
			
		}
		csvWriter.flush();
		csvWriter.close();
		
		
	}

	

}
