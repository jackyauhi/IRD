


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;




public class findLatestFolderPath {
	public static List<String> inputFileList = new ArrayList<String>();
	public static List<String> outputFileList = new ArrayList<String>();
	public static List<String> filesListInDir = new ArrayList<String>();
	public static File chosenFilePath=null;
	public static long lastModifiedTime = Long.MIN_VALUE;
	public static void main(String[] args) {
		
		String inputPath=args[0];
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        File dir = new File(inputPath);
        String convertorFilePath=args[1];
        File listDir[] = dir.listFiles();
        for (int i = 0; i < listDir.length; i++) {
            if (listDir[i].isDirectory()) {
                if (listDir[i].lastModified() > lastModifiedTime)
                {
                    chosenFilePath = listDir[i];
                    lastModifiedTime = listDir[i].lastModified();
                }
                }
        }
        System.out.println("chosenFile = " + chosenFilePath);
        System.out.println("lastModifiedTime = " + lastModifiedTime);

//        findLatestFolderPath.zipDirectory(chosenFile, inputPath+"\\CCMP_123.zip");
		try (Stream<Path> walk = Files.walk(Paths.get(chosenFilePath.toString()))) {

			List<String> result = walk.filter(Files::isRegularFile)
					.map(x -> x.toString()).collect(Collectors.toList());

//			result.forEach(System.out::println);
			inputFileList=result;
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		try {
			FileWriter fileWriter = new FileWriter(convertorFilePath+"\\outputRequiredFileMain.csv");
			for (int i = 0; i < inputFileList.size(); i++) {
				File inputFilePath = new File(inputFileList.get(i).toString());
				fileWriter.write(inputFilePath.getName()+","+inputFilePath.getAbsolutePath()+","+sdf.format(inputFilePath.lastModified())+","+"New_Files_Folder" + System.lineSeparator());
			}
			fileWriter.close();
		} catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data in inputFileList");
		}	
		
		try {
			FileWriter fileWriter = new FileWriter(convertorFilePath+"\\chosenFilePath.txt");
			fileWriter.write(chosenFilePath.toString());
			fileWriter.close();
		} catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data in chosenFilePath");
		}
	}
	
	private static void zipDirectory(File dir, String zipDirName) {
        try {
            populateFilesList(dir);
            //now zip files one by one
            //create ZipOutputStream to write to the zip file
            FileOutputStream fos = new FileOutputStream(zipDirName);
            ZipOutputStream zos = new ZipOutputStream(fos);
            for(String filePath : filesListInDir){
//                System.out.println("Zipping "+filePath);
                //for ZipEntry we need to keep only relative file path, so we used substring on absolute path
                ZipEntry ze = new ZipEntry(filePath.substring(dir.getAbsolutePath().length()+1, filePath.length()));
                zos.putNextEntry(ze);
                //read the file and write to ZipOutputStream
                FileInputStream fis = new FileInputStream(filePath);
                byte[] buffer = new byte[1024];
                int len;
                while ((len = fis.read(buffer)) > 0) {
                    zos.write(buffer, 0, len);
                }
                zos.closeEntry();
                fis.close();
            }
            zos.close();
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * This method populates all the files in a directory to a List
     * @param dir
     * @throws IOException
     */
    private static void populateFilesList(File dir) throws IOException {
        File[] files = dir.listFiles();
        for(File file : files){
            if(file.isFile()) filesListInDir.add(file.getAbsolutePath());
            else populateFilesList(file);
        }
    }
}