import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class generateTextPathListFile {

	public static String openingPath = new String();
	public static String outputPath = new String();
	public static List<String> pathList = new ArrayList<String>();
	public static List<String> savePathList = new ArrayList<String>();
	public static List<String> errorPathList = new ArrayList<String>();
	public static String folderPath = "";
	
	public static void deleteFile(File element) {
		    if (element.isDirectory()) {
		        for (File sub : element.listFiles()) {
		            deleteFile(sub);
		        }
		    }
		    element.delete();
		}
	public static void main(String[] args) {
//		openingPath="D:\\ccshare\\jyyau_view_ClearCase_PRD\\TAAS2_DEV\\PRD_Application";
//		openingPath=args[0];
		openingPath="T:\\jackyau\\filepath.txt";
//		outputPath=args[1];
		outputPath="T:\\jackyau\\AutoSync2";
		boolean errorContains=false;
		try {
			BufferedReader fileReader = new BufferedReader(new FileReader(openingPath));
			String line=null;
		    try {
				while ((line = fileReader.readLine()) != null)
				{	
					pathList.add(line);
				}
				fileReader.close();
			} 
		    catch (IOException e1) {
				e1.printStackTrace();
			}
			} 
	   	catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
		for (int i = 0; i < pathList.size(); i++) {
			String[] inputSplit = pathList.get(i).toString().split(":",2);
			folderPath=inputSplit[1];
			
			File fileToSave = new File(outputPath+"\\"+folderPath);
			File fileToSaveParent=new File(fileToSave.getParent());
			if (!fileToSaveParent.exists()) {
				fileToSaveParent.mkdirs();
			}
			File sourceFile = new File(pathList.get(i).toString());
			File targetFile = new File(outputPath+"\\"+folderPath);
			
			try {
				transform(sourceFile,"UTF-8",targetFile,"UTF-8");
				System.out.println("transform from:"+sourceFile.getAbsolutePath() + System.lineSeparator());
				System.out.println("To:"+targetFile.getAbsolutePath() + System.lineSeparator());
				savePathList.add(sourceFile.getAbsolutePath());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				errorContains=true;
				errorPathList.add(sourceFile.getAbsolutePath());
			}			
		}
		try {
			FileWriter fileWriter = new FileWriter(outputPath+"\\FilePath.txt");
			for (int j = 0; j < savePathList.size(); j++) {
				fileWriter.write(savePathList.get(j).toString()+ System.lineSeparator());
			}
			fileWriter.close();
		} catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data in inputFileList");
			}
		if(errorContains) {
		try {
			FileWriter fileWriter = new FileWriter(outputPath+"\\ErrorFilePath.txt");
			for (int j = 0; j < errorPathList.size(); j++) {
				fileWriter.write(errorPathList.get(j).toString()+ System.lineSeparator());
			}
			fileWriter.close();
		} catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data in inputFileList");
			}
		}
	
	}
	public static void transform(File source, String srcEncoding, File target, String tgtEncoding) throws IOException {
	    BufferedReader br = null;
	    BufferedWriter bw = null;
	    try{
	        br = new BufferedReader(new InputStreamReader(new FileInputStream(source),srcEncoding));
	        bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(target), tgtEncoding));
	        char[] buffer = new char[16384];
	        int read;
	        while ((read = br.read(buffer)) != -1)
	            bw.write(buffer, 0, read);
	    } finally {
	        try {
	            if (br != null)
	                br.close();
	        } finally {
	            if (bw != null)
	                bw.close();
	        }
	    }
	}
}