import java.io.BufferedReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class checkCheckInFileFail {
	public static List<String> inputFileList = new ArrayList<String>();
	public static HashMap<String, String> compareFileMap = new HashMap<String, String>();
	public static List<String> outputFileList = new ArrayList<String>();
	
	public static void main(String[] args) {
		int count=0;
		boolean doNotCheckin=false;
//		String inputPath="D:\\User\\CloudCheckin\\chkin.txt";
//		String comparePath="D:\\User\\CloudCheckin\\mklabelResult.txt";
//		String outputPath="T:\\jackyau\\checkCheckInFileFail.txt";
		String inputPath=args[0];
		String comparePath=args[1];
		String outputPath=args[2];
		String keyValue = "";
		try {
			BufferedReader fileReader = new BufferedReader(new FileReader(inputPath));
			String line=null;
		    try {
				while ((line = fileReader.readLine()) != null)
				{	
					inputFileList.add(line);
//					System.out.println("line =" + line);
				}
				fileReader.close();
			} 
		    catch (IOException e1) {
				e1.printStackTrace();
			}
			} 
	   	catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
		
		try {
			BufferedReader fileReader = new BufferedReader(new FileReader(comparePath));
			String line=null;
		    try {
				while ((line = fileReader.readLine()) != null)
				{	
					if(line.contains("@@\\")) {
			        	String[] spiltData = line.split(Pattern.quote("@@\\"),2);
			        	keyValue =spiltData[0];
					}
					if(line.contains("Apply label CLOUD_DEV")) {
						if(line.endsWith("success")) {
							compareFileMap.put(keyValue, "success");
//							System.out.println("keyValue =" + keyValue);
						}
						else {
							compareFileMap.put(keyValue, "fail");
						}
					}
					
				}
				fileReader.close();
			} 
		    catch (IOException e1) {
				e1.printStackTrace();
			}
			} 
	   	catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
		count=0;
	      for (int j = 0; j < inputFileList.size(); j++) {
	    	  if(!compareFileMap.containsKey(inputFileList.get(j).toString())) {
	    		  System.out.println(inputFileList.get(j).toString());
	    		  outputFileList.add(inputFileList.get(j).toString());
	    		  doNotCheckin=true;
	    	  }
//	    	  if(doNotCheckin) {
//	    		  if(count==0) {
//	    			  System.out.println("Do not check in Path:");
//	    		  }
//	    		  else {
//	    			  System.out.println(inputFileList.get(j).toString());
//	    		  }
//	    		  count++;
//	    	  }
	      }
		try {
		FileWriter fileWriter = new FileWriter(outputPath);
		for (int i = 0; i < outputFileList.size(); i++) {
			fileWriter.write(outputFileList.get(i).toString()+System.lineSeparator());
		}
		fileWriter.close();
	} catch (IOException iox) {
		iox.printStackTrace();
		System.out.println("File can not save any data in outputPathList");
	}
	}
}