import java.io.BufferedReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class testingProgram2 {
	public static ArrayList<String> inputFileList = new ArrayList<String>();
	public static ArrayList<String> inputFileList2 = new ArrayList<String>();
	public static ArrayList<String> outputFileList = new ArrayList<String>();
	
	public static void main(String[] args) throws Exception{
//		String inputPath = "T:\\jackyau\\FileList for manual code change.txt";
//		String outputPath = "T:\\jackyau\\Cloud_Checkin_Tools_Status_N_FileList.txt";
//		try {
//			BufferedReader fileReader = new BufferedReader(new FileReader(inputPath));
//			String line=null;
//		    try {
//				while ((line = fileReader.readLine()) != null)
//				{	
//					inputFileList.add(line);
//				}
//				fileReader.close();
//			} 
//		    catch (IOException e1) {
//				e1.printStackTrace();
//			}
//			} 
//	   	catch (FileNotFoundException e1) {
//				e1.printStackTrace();
//			}
//		String inputPath2 = "T:\\jackyau\\Cloud_Checkin_Tools_Status_Y_FileList.txt";
//		try {
//			BufferedReader fileReader = new BufferedReader(new FileReader(inputPath2));
//			String line=null;
//		    try {
//				while ((line = fileReader.readLine()) != null)
//				{	
//					inputFileList2.add(line);
//				}
//				fileReader.close();
//			} 
//		    catch (IOException e1) {
//				e1.printStackTrace();
//			}
//			} 
//	   	catch (FileNotFoundException e1) {
//				e1.printStackTrace();
//			}
//		inputFileList.removeAll(inputFileList2);
//		try {       
//       		FileWriter fileWriter = new FileWriter(outputPath);
//	    	for(int i=0; i<inputFileList.size();i++) {
//       		fileWriter.write(inputFileList.get(i).toString()+System.lineSeparator());
//	    	}
//       		fileWriter.close();
//       	}catch (IOException iox) {
//       		iox.printStackTrace();
//       		System.out.println("File can not save any data in outputPathList");
//       	}
		
		Date endDate;
		String prn;
		String date="2008-03-31 00:00:00.0";
		prn="";
		
		DateFormat inputFormat  = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
		
		endDate = inputFormat.parse(date);
		
//		System.out.println("endDate =" +endDate);
		String replacedFileContent = new String();
		

//		try {
//			replacedFileContent = new String(Files.readAllBytes(Paths.get("D:\\ccshare\\jyyau_view_ClearCase_MTN\\TAAS2_UAT\\CloudMigration\\Application\\Batch\\ACS_Batch\\src\\ird\\taas2\\batch\\acs\\irdtrcmt1\\Irdtrc002.java")));
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		replacedFileContent="//Check in version of BAT_PRD,09-02-17,rwlszeto:5:465/hf0F1l3xMmrXk0ysV34NT5tSgjxzZQGZhSJDO5FEQwKmodb0HAEMRMccomAQ\r\n" + 
				"//Check in version of BAT_PRD,07-02-17,bhssham:4:J9riheUbRR5tSYFfXAdEXH4NT5tSgjxzZQGZhSJDO5FEQwKmodb0HAEMRMccomAQ\r\n" + 
				"package ird.taas2.batch.ct.ctaicy;\r\n" + 
				"\r\n" + 
				"import java.util.ArrayList;\r\n" + 
				"import java.util.List;\r\n" + 
				"\r\n" + 
				"import ird.taas2.batch.ct.constant.Ctaic2Constant;\r\n" + 
				"import ird.taas2.batch.ct.constant.CtaicConstant;\r\n" + 
				"import ird.taas2.batch.ct.constant.CtmdsConstant;\r\n" + 
				"import ird.taas2.batch.enums.Environment;\r\n" + 
				"import ird.taas2.batch.io.Worker;\r\n" + 
				"import ird.taas2.batch.utils.BatchSystemConfig;\r\n" + 
				"import ird.taas2.report.ct.r6703a.R6703aErrMsgBlock;\r\n" + 
				"import ird.taas2.report.service.IrdReportService;\r\n" + 
				"\r\n" + 
				"import org.apache.log4j.Logger;\r\n" + 
				"import org.springframework.beans.factory.annotation.Autowired;\r\n" + 
				"import org.springframework.stereotype.Component;\r\n" + 
				"import org.springframework.util.StringUtils;\r\n" + 
				"\r\n" + 
				"/***\r\n" + 
				" *\r\n" + 
				" * @author Sam(SHAO YINGSHENG)\r\n" + 
				" *\r\n" + 
				" * @date Created on 2014�~7��15��\r\n" + 
				" *\r\n" + 
				" */\r\n" + 
				"@Component\r\n" + 
				"public class Step01CtaicyWorker extends Worker {\r\n" + 
				"\r\n" + 
				"	private static final Logger logger = Logger.getLogger(Step01CtaicyWorker.class);\r\n" + 
				"		\r\n" + 
				"	@Autowired BatchSystemConfig systemConfig;\r\n" + 
				"		\r\n" + 
				"	private final String ERRMSG_FILE_NOT_EXIST_TEMPLATE = \"FILE <FILE_NAME> DOES NOT EXIST!\";\r\n" + 
				"	private static final String ERR_MSG_REC_CODE = \"CONSTANT MAINTENACE TX RECORD NOT FOUND FOR INPUT RECORD TYPE \";\r\n" + 
				"	private static final String SUCCESS = \"PASSED\";\r\n" + 
				"	\r\n" + 
				"	@Override\r\n" + 
				"	public void initialize() throws Exception {\r\n" + 
				"	}\r\n" + 
				"\r\n" + 
				"	@Override\r\n" + 
				"	public void doAction() throws Exception {\r\n" + 
				"\r\n" + 
				"		logger.debug(\"Step01CtaicyWorker.doAction() started ...............................................\" );\r\n" + 
				"\r\n" + 
				"		if (getSystemConfig()==null || getSystemConfig().getTargetJobName()==null) {\r\n" + 
				"			setJobParmValidated(false);\r\n" + 
				"			logger \r\n . \r\n info(\"JOB NAME DOES NOT EXIST\");\r\n" + 
				"			throw new Exception(\"JOB NAME DOES NOT EXIST\");\r\n" + 
				"		}\r\n" + 
				"		\r\n" + 
				"		String targetJobName =  getSystemConfig().getTargetJobName();\r\n" + 
				"		\r\n" + 
				"		System.out.println(\"targetJobName:[\"+targetJobName+\"]\");\r\n" + 
				"		logger.info(\"targetJobName:[\"+targetJobName+\"]\");\r\n" + 
				"		\r\n" + 
				"		if (CtaicConstant.JOB_NAME_CTAIC1.equals(targetJobName)) {\r\n" + 
				"			String recCode;\r\n" + 
				"			try{\r\n" + 
				"				recCode = getSystemConfig().getJobParameterValue(CtaicConstant.JOB_PARAM_1).toString();\r\n" + 
				"			}catch(Exception e){\r\n" + 
				"				addValidationResult(CtaicConstant.JOB_PARAM_1, ERR_MSG_REC_CODE);\r\n" + 
				"				e.printStackTrace();\r\n" + 
				"				logger.error(e.toString());\r\n" + 
				"				logger.info(\"MISSING PARAMETER!\");\r\n" + 
				"				throw new Exception(\"MISSING PARAMETER!\");\r\n" + 
				"			}\r\n" + 
				"			\r\n" + 
				"			logger.debug(\"recCode = \"+recCode);\r\n" + 
				"\r\n" + 
				"			Boolean validRecCode = false;\r\n" + 
				"			if (recCode != null	&& !StringUtils.isEmpty(recCode) && CtaicConstant.VALID_REC_CODE_LIST.contains(recCode)) {\r\n" + 
				"				validRecCode = true;\r\n" + 
				"			}\r\n" + 
				"\r\n" + 
				"			//If REC_CODE is empty or invalid, fail the job (for PRODUCTION)\r\n" + 
				"			Environment currentEnvironment = systemConfig.getCurrentEnvironment();\r\n" + 
				"			if(currentEnvironment==Environment.PRODUCTION){\r\n" + 
				"				if(!validRecCode){\r\n" + 
				"					addValidationResult(CtaicConstant.JOB_PARAM_1, ERR_MSG_REC_CODE + recCode.toUpperCase());\r\n" + 
				"					logger.info(\"JOB PARM (REC_CODE) CANNOT BE EMPTY OR INVALID!\");\r\n" + 
				"					throw new Exception(\"JOB PARM (REC_CODE) CANNOT BE EMPTY OR INVALID!\");\r\n" + 
				"				}\r\n" + 
				"			}\r\n" + 
				"\r\n" + 
				"			if (validRecCode) {\r\n" + 
				"				setJobParmValidated(true);\r\n" + 
				"				addValidationResult(CtaicConstant.JOB_PARAM_1, SUCCESS);\r\n" + 
				"			} else {\r\n" + 
				"				addValidationResult(CtaicConstant.JOB_PARAM_1, ERR_MSG_REC_CODE + recCode.toUpperCase());\r\n" + 
				"				logger.info(\"JOB PARM (REC_CODE) CANNOT BE EMPTY OR INVALID!\");\r\n" + 
				"				throw new Exception(\"JOB PARM (REC_CODE) CANNOT BE EMPTY OR INVALID!\");\r\n" + 
				"			}\r\n" + 
				"			\r\n" + 
				"		}else if(Ctaic2Constant.JOB_NAME_CTAIC2.equals(targetJobName)){\r\n" + 
				"			\r\n" + 
				"			String updateAssrShort = null;\r\n" + 
				"			String updateAssrLong = null;\r\n" + 
				"			\r\n" + 
				"			String printAssrShort = null;\r\n" + 
				"			String printAssrLong = null;\r\n" + 
				"			String printAssrHistory = null;\r\n" + 
				"\r\n" + 
				"			try\r\n" + 
				"			{\r\n" + 
				"				 updateAssrShort = (String) systemConfig.getJobParameterValue(Ctaic2Constant.UPDATE_ASSR_NOTE_SHORT);\r\n" + 
				"			} catch (Exception e)\r\n" + 
				"			{\r\n" + 
				"				// TODO: handle exception\r\n" + 
				"				addValidationResult(Ctaic2Constant.UPDATE_ASSR_NOTE_SHORT, Ctaic2Constant.MSG_INVALID_UPDATE_ASSR_NOTE_SHORT);\r\n" + 
				"				e.printStackTrace();\r\n" + 
				"				logger.error(e.toString());\r\n" + 
				"				logger.info(\"MISSING PARAMETER!\");\r\n" + 
				"				throw new Exception(\"MISSING PARAMETER!\");\r\n" + 
				"			}\r\n" + 
				"			\r\n" + 
				"			try\r\n" + 
				"			{\r\n" + 
				"				 updateAssrLong = (String) systemConfig.getJobParameterValue(Ctaic2Constant.UPDATE_ASSR_NOTE_LONG);\r\n" + 
				"			} catch (Exception e)\r\n" + 
				"			{\r\n" + 
				"				addValidationResult(Ctaic2Constant.UPDATE_ASSR_NOTE_LONG, Ctaic2Constant.MSG_INVALID_UPDATE_ASSR_NOTE_LONG);\r\n" + 
				"				e.printStackTrace();\r\n" + 
				"				logger.error(e.toString());\r\n" + 
				"				logger.info(\"MISSING PARAMETER!\");\r\n" + 
				"				throw new Exception(\"MISSING PARAMETER!\");\r\n" + 
				"			}\r\n" + 
				"			try\r\n" + 
				"			{\r\n" + 
				"				 printAssrShort = (String) systemConfig.getJobParameterValue(Ctaic2Constant.PRINT_ASSR_NOTE_SHORT);\r\n" + 
				"			} catch (Exception e)\r\n" + 
				"			{\r\n" + 
				"				addValidationResult(Ctaic2Constant.PRINT_ASSR_NOTE_SHORT, Ctaic2Constant.MSG_INVALID_PRINT_ASSR_NOTE_SHORT);\r\n" + 
				"				e.printStackTrace();\r\n" + 
				"				logger.error(e.toString());\r\n" + 
				"				logger.info(\"MISSING PARAMETER!\");\r\n" + 
				"				throw new Exception(\"MISSING PARAMETER!\");\r\n" + 
				"			}\r\n" + 
				"			try\r\n" + 
				"			{\r\n" + 
				"				 printAssrLong = (String) systemConfig.getJobParameterValue(Ctaic2Constant.PRINT_ASSR_NOTE_LONG);\r\n" + 
				"			} catch (Exception e)\r\n" + 
				"			{\r\n" + 
				"				addValidationResult(Ctaic2Constant.PRINT_ASSR_NOTE_LONG, Ctaic2Constant.MSG_INVALID_PRINT_ASSR_NOTE_LONG);\r\n" + 
				"				e.printStackTrace();\r\n" + 
				"				logger.error(e.toString());\r\n" + 
				"				logger.info(\"MISSING PARAMETER!\");\r\n" + 
				"				throw new Exception(\"MISSING PARAMETER!\");\r\n" + 
				"			}\r\n" + 
				"			try\r\n" + 
				"			{\r\n" + 
				"				 printAssrHistory = (String) systemConfig.getJobParameterValue(Ctaic2Constant.PRINT_ASSR_NOTE_HISTORY);\r\n" + 
				"			} catch (Exception e)\r\n" + 
				"			{\r\n" + 
				"				addValidationResult(Ctaic2Constant.PRINT_ASSR_NOTE_HISTORY, Ctaic2Constant.MSG_INVALID_PRINT_ASSR_NOTE_HISTORY);\r\n" + 
				"				e.printStackTrace();\r\n" + 
				"				logger.error(e.toString());\r\n" + 
				"				logger.info(\"MISSING PARAMETER!\");\r\n" + 
				"				throw new Exception(\"MISSING PARAMETER!\");\r\n" + 
				"			}\r\n" + 
				"			if( ! isValidInd(updateAssrShort) )\r\n" + 
				"			{\r\n" + 
				"				String msg = Ctaic2Constant.MSG_INVALID_UPDATE_ASSR_NOTE_SHORT;\r\n" + 
				"				addValidationResult(Ctaic2Constant.UPDATE_ASSR_NOTE_SHORT, msg);\r\n" + 
				"				logger.info(msg);\r\n" + 
				"				throw new Exception(msg);\r\n" + 
				"			}\r\n" + 
				"			else{\r\n" + 
				"				addValidationResult(Ctaic2Constant.UPDATE_ASSR_NOTE_SHORT, SUCCESS);\r\n" + 
				"			}\r\n" + 
				"			\r\n" + 
				"			if( ! isValidInd(updateAssrLong) )\r\n" + 
				"			{\r\n" + 
				"				String msg = Ctaic2Constant.MSG_INVALID_UPDATE_ASSR_NOTE_LONG;\r\n" + 
				"				addValidationResult(Ctaic2Constant.UPDATE_ASSR_NOTE_LONG, msg);\r\n" + 
				"				logger.info(msg);\r\n" + 
				"				throw new Exception(msg);\r\n" + 
				"			}\r\n" + 
				"			else{\r\n" + 
				"				addValidationResult(Ctaic2Constant.UPDATE_ASSR_NOTE_LONG, SUCCESS);\r\n" + 
				"			}\r\n" + 
				"			\r\n" + 
				"			if( ! isValidInd(printAssrShort) )\r\n" + 
				"			{\r\n" + 
				"				String msg = Ctaic2Constant.MSG_INVALID_PRINT_ASSR_NOTE_SHORT;\r\n" + 
				"				addValidationResult(Ctaic2Constant.PRINT_ASSR_NOTE_SHORT, msg);\r\n" + 
				"				logger.info(msg);\r\n" + 
				"				throw new Exception(msg);\r\n" + 
				"			}\r\n" + 
				"			else{\r\n" + 
				"				addValidationResult(Ctaic2Constant.PRINT_ASSR_NOTE_SHORT, SUCCESS);\r\n" + 
				"			}\r\n" + 
				"			\r\n" + 
				"			\r\n" + 
				"			if( ! isValidInd(printAssrLong) )\r\n" + 
				"			{\r\n" + 
				"				String msg = Ctaic2Constant.MSG_INVALID_PRINT_ASSR_NOTE_LONG;\r\n" + 
				"				addValidationResult(Ctaic2Constant.PRINT_ASSR_NOTE_LONG, msg);\r\n" + 
				"				logger.info(msg);\r\n" + 
				"				throw new Exception(msg);\r\n" + 
				"			}\r\n" + 
				"			else{\r\n" + 
				"				addValidationResult(Ctaic2Constant.PRINT_ASSR_NOTE_LONG, SUCCESS);\r\n" + 
				"			}\r\n" + 
				"			\r\n" + 
				"			\r\n" + 
				"			if( ! isValidInd(printAssrHistory) )\r\n" + 
				"			{\r\n" + 
				"				String msg = Ctaic2Constant.MSG_INVALID_PRINT_ASSR_NOTE_HISTORY;\r\n" + 
				"				addValidationResult(Ctaic2Constant.PRINT_ASSR_NOTE_HISTORY, msg);\r\n" + 
				"				logger.info(msg);\r\n" + 
				"				throw new Exception(msg);\r\n" + 
				"			}\r\n" + 
				"			else{\r\n" + 
				"				addValidationResult(Ctaic2Constant.PRINT_ASSR_NOTE_HISTORY, SUCCESS);\r\n" + 
				"			}\r\n" + 
				"			\r\n" + 
				"			\r\n" + 
				"			\r\n" + 
				"//			if( isValidInd(updateAssrShort) && isValidInd(updateAssrLong) &&\r\n" + 
				"//					isValidInd(printAssrShort) && isValidInd(printAssrLong) &&\r\n" + 
				"//					isValidInd(printAssrHistory) )\r\n" + 
				"//			{\r\n" + 
				"//				setJobParmValidated(true); \r\n" + 
				"//			}else {\r\n" + 
				"//				setJobParmValidated(false); \r\n" + 
				"//				\r\n" + 
				"//				logger .   info(\"INVALID PARAMETER! VALUES SHOULD BE 'Y' OR EMPTY\");\r\n" + 
				"//				throw new Exception(\"INVALID PARAMETER VALUE!\");\r\n" + 
				"//			}\r\n" + 
				"			\r\n" + 
				"			setJobParmValidated(true);\r\n" + 
				"			\r\n" + 
				"	\r\n" + 
				"		} else {\r\n" + 
				"			setJobParmValidated(false);\r\n" + 
				"			logger.info(\"INVALID JOB NAME\");\r\n" + 
				"			throw new Exception(\"INVALID JOB NAME\");\r\n" + 
				"		}\r\n" + 
				"\r\n" + 
				"		logger.debug(\"Step01CtaicyWorker.doAction() ended ...............................................\" );\r\n" + 
				"	}\r\n" + 
				"	\r\n" + 
				"	public static boolean isValidInd(String s)\r\n" + 
				"	{\r\n" + 
				"		boolean rs = false;\r\n" + 
				"		if(StringUtils.isEmpty(s)) {\r\n" + 
				"			rs = true;\r\n" + 
				"		}\r\n" + 
				"		if(s!=null && (Ctaic2Constant.VALID_IND.equals(s) || Ctaic2Constant.VALID_IND2.equals(s)))\r\n" + 
				"		{\r\n" + 
				"			rs = true;\r\n" + 
				"		}\r\n" + 
				"		\r\n" + 
				"		return rs; \r\n" + 
				"	}\r\n" + 
				"}\r\n" + 
				"";
		String content = "//Check in version of CLOUD_DEV,22-02-21,ecochan:4-Y:O3CZ2SQcZAOtaO9kHCFJmRKjMArWZhJ0NsJ6p/mbEM9xgSWlrEnQ8VPbpBXehj/K\r\n" + 
				"//Check in version of CLOUD_DEV,14-12-20,jyyau:3-Y:dLQfOkqCkMn8tkcLmTik9BKjMArWZhJ0NsJ6p/mbEM9xgSWlrEnQ8VPbpBXehj/K\r\n" + 
				"//Check in version of BAT_PRD,10-02-21,CKLHO:5:MfRj7USTdhSDlqADn0+Q7AQOqGgyF2m42Aw/zazU/4X/wuPduvr86/IfSOMSEmrc\r\n" + 
				"//Check in version of BAT_PRD,03-12-20,kslui:4:O3CZ2SQcZAOtaO9kHCFJmQQOqGgyF2m42Aw/zazU/4X/wuPduvr86/IfSOMSEmrc\r\n" + 
				"//Check in version of BAT_PRD,03-12-20,kslui:3:dLQfOkqCkMn8tkcLmTik9AQOqGgyF2m42Aw/zazU/4X/wuPduvr86/IfSOMSEmrc\r\n" + 
				"//Check in version of BAT_PRD,01-04-19,kkkngan:2:sXCf9liX0lTNGptzEimDuQQOqGgyF2m42Aw/zazU/4X/wuPduvr86/IfSOMSEmrc\r\n" + 
				"//Check in version of BAT_PRD,30-11-17,ctchan:1:oLrKFg6as6WMjc6qYsSW4AQOqGgyF2m42Aw/zazU/4X/wuPduvr86/IfSOMSEmrc\r\n" + 
				"package ird.taas2.batch.ct.ctaua1;\r\n" + 
				"\r\n" + 
				"\r\n" + 
				"\r\n" + 
				"\r\n" + 
				"import ird.taas2.batch.ct.dao.CtfpownZmCtybiDao;\r\n" + 
				"import ird.taas2.batch.ct.dao.CtfptshrZmCtybiDao;\r\n" + 
				"import ird.taas2.batch.io.Worker;\r\n" + 
				"import ird.taas2.batch.utils.BatchSystemConfig;\r\n" + 
				"import ird.taas2.batch.utils.ControlReportUtils;\r\n" + 
				"import ird.taas2.core.constant.IrdConstant;\r\n" + 
				"import ird.taas2.ct.dao.TmpCtfbownDao;\r\n" + 
				"import ird.taas2.ct.dao.TmpCtfbutrcDao;\r\n" + 
				"import ird.taas2.ct.dao.TmpCtfdsptDao;\r\n" + 
				"import ird.taas2.ct.dao.TmpCtfdsstDao;\r\n" + 
				"import ird.taas2.ct.dao.TmpCtfjbownDao;\r\n" + 
				"import ird.taas2.ct.dao.TmpCtfjpownDao;\r\n" + 
				"import ird.taas2.ct.dao.TmpCtfpaelrDao;\r\n" + 
				"import ird.taas2.ct.dao.TmpCtfprn1Dao;\r\n" + 
				"import ird.taas2.ct.dao.TmpCtfprn2Dao;\r\n" + 
				"import ird.taas2.ct.dao.TmpCtfprn3Dao;\r\n" + 
				"import ird.taas2.ct.dao.TmpCtfprn5Dao;\r\n" + 
				"import ird.taas2.ct.dao.TmpCtfprnbDao;\r\n" + 
				"import ird.taas2.ct.dao.TmpCtfprnfDao;\r\n" + 
				"import ird.taas2.ct.dao.TmpCtfprnmDao;\r\n" + 
				"import ird.taas2.ct.dao.TmpCtfprnsDao;\r\n" + 
				"import ird.taas2.ct.dao.TmpCtfprpaaDao;\r\n" + 
				"import ird.taas2.ct.dao.TmpCtfuasvDao;\r\n" + 
				"import ird.taas2.ct.dao.TmpCtfuasvaDao;\r\n" + 
				"import ird.taas2.ct.dao.TmpCtfujptDao;\r\n" + 
				"import ird.taas2.ct.dao.TmpCtfupaaDao;\r\n" + 
				"import ird.taas2.ct.model.TmpCtfbownExample;\r\n" + 
				"import ird.taas2.ct.model.TmpCtfbutrcExample;\r\n" + 
				"import ird.taas2.ct.model.TmpCtfdsptExample;\r\n" + 
				"import ird.taas2.ct.model.TmpCtfdsstExample;\r\n" + 
				"import ird.taas2.ct.model.TmpCtfjbownExample;\r\n" + 
				"import ird.taas2.ct.model.TmpCtfjpownExample;\r\n" + 
				"import ird.taas2.ct.model.TmpCtfpaelrExample;\r\n" + 
				"import ird.taas2.ct.model.TmpCtfprn1Example;\r\n" + 
				"import ird.taas2.ct.model.TmpCtfprn2Example;\r\n" + 
				"import ird.taas2.ct.model.TmpCtfprn3Example;\r\n" + 
				"import ird.taas2.ct.model.TmpCtfprn5Example;\r\n" + 
				"import ird.taas2.ct.model.TmpCtfprnbExample;\r\n" + 
				"import ird.taas2.ct.model.TmpCtfprnfExample;\r\n" + 
				"import ird.taas2.ct.model.TmpCtfprnmExample;\r\n" + 
				"import ird.taas2.ct.model.TmpCtfprnsExample;\r\n" + 
				"import ird.taas2.ct.model.TmpCtfuasvExample;\r\n" + 
				"import ird.taas2.ct.model.TmpCtfuasvaExample;\r\n" + 
				"import ird.taas2.ct.model.TmpCtfujptExample;\r\n" + 
				"import ird.taas2.ct.model.TmpCtfupaaExample;\r\n" + 
				"import ird.taas2.data.dao.impl.NativeJdbcDaoImpl;\r\n" + 
				"\r\n" + 
				"import java.sql.ResultSet;\r\n" + 
				"import java.sql.Timestamp;\r\n" + 
				"import java.text.SimpleDateFormat;\r\n" + 
				"import java.util.Date;\r\n" + 
				"import java.util.HashMap;\r\n" + 
				"\r\n" + 
				"import org.apache.log4j.Logger;\r\n" + 
				"import org.springframework.beans.factory.annotation.Autowired;\r\n" + 
				"import org.springframework.stereotype.Component;\r\n" + 
				"\r\n" + 
				"/**\r\n" + 
				" * @author: Chan Chung Tai\r\n" + 
				" *\r\n" + 
				" * @create date:2017 06 28\r\n" + 
				" */\r\n" + 
				"\r\n" + 
				"@Component(\"ctaua1CleanupWorker\")\r\n" + 
				"public class Ctaua1CleanupWorker extends\r\n Worker {\r\n" + 
				"	\r\n" + 
				"	private static Logger logger = Logger.getLogger(Ctaua1CleanupWorker.class);\r\n" + 
				"	\r\n" + 
				"	private static final String CONTEXT_KEY_SYSTEM_TS = \"createTs\";\r\n" + 
				"	\r\n" + 
				"	@Autowired private BatchSystemConfig systemConfig;\r\n" + 
				"	@Autowired private ControlReportUtils controlReportUtils;\r\n" + 
				"	\r\n" + 
				"	//Delete	\r\n" + 
				"	@Autowired private TmpCtfprnfDao tmpCtfprnfDao;\r\n" + 
				"	@Autowired private TmpCtfprn1Dao tmpCtfprn1Dao;\r\n" + 
				"	@Autowired private TmpCtfprn5Dao tmpCtfprn5Dao;	\r\n" + 
				"	@Autowired private TmpCtfbownDao tmpCtfbownDao;\r\n" + 
				"	@Autowired private TmpCtfbutrcDao tmpCtfbutrcDao;\r\n" + 
				"	@Autowired private TmpCtfdsptDao tmpCtfdsptDao;\r\n" + 
				"	@Autowired private TmpCtfdsstDao tmpCtfdsstDao;\r\n" + 
				"	@Autowired private TmpCtfjbownDao tmpCtfjbownDao;\r\n" + 
				"	@Autowired private TmpCtfjpownDao tmpCtfjpownDao;\r\n" + 
				"	@Autowired private TmpCtfpaelrDao tmpCtfpaelrDao;\r\n" + 
				"	@Autowired private TmpCtfprn2Dao tmpCtfprn2Dao;\r\n" + 
				"	@Autowired private TmpCtfprn3Dao tmpCtfprn3Dao;\r\n" + 
				"	@Autowired private TmpCtfprnbDao tmpCtfprnbDao;\r\n" + 
				"	@Autowired private TmpCtfprnmDao tmpCtfprnmDao;\r\n" + 
				"	@Autowired private TmpCtfprnsDao tmpCtfprnsDao;\r\n" + 
				"	@Autowired private TmpCtfprpaaDao tmpCtfprpaaDao;\r\n" + 
				"	@Autowired private TmpCtfuasvDao tmpCtfuasvDao;\r\n" + 
				"	@Autowired private TmpCtfuasvaDao tmpCtfuasvaDao;\r\n" + 
				"	@Autowired private TmpCtfujptDao tmpCtfujptDao;\r\n" + 
				"	@Autowired private TmpCtfupaaDao tmpCtfupaaDao;\r\n" + 
				"	@Autowired private CtfpownZmCtybiDao ctfpownZmCtybiDao;\r\n" + 
				"	@Autowired private CtfptshrZmCtybiDao ctfptshrZmCtybiDao;\r\n" + 
				"	@Autowired\r\n" + 
				"	private Ctaua1NativeUpdate nativeUpdate;\r\n" + 
				"	\r\n" + 
				"	@Override\r\n" + 
				"	public void initialize() throws Exception {\r\n" + 
				"	}\r\n" + 
				"	\r\n" + 
				"	@Override\r\n" + 
				"	public void doAction() throws Exception {\r\n" + 
				"		\r\n" + 
				"		logger.debug(\"================== Ctaua1CleanupWorker.doAction() Started ==================\");\r\n" + 
				"		\r\n" + 
				"		Timestamp sysTs = getCreateTs(CONTEXT_KEY_SYSTEM_TS);\r\n" + 
				"		Date submitTs = (Date)systemConfig.getDataObjectMap().get(\"submissionTimestamp\");\r\n" + 
				"		String injobName = systemConfig.getJobName();\r\n" + 
				"		Short injobRunSeq = Short.parseShort(systemConfig.getJobRunNumber());\r\n" + 
				"		logger.debug(\"System date: \" + sysTs);\r\n" + 
				"\r\n" + 
				"		//		TmpCtfprnfExample tmpCtfprnfExample = new TmpCtfprnfExample();\r\n" + 
				"		//		tmpCtfprnfExample.createCriteria().andInjobNameEqualTo(injobName).andInjobRunSeqEqualTo(injobRunSeq).andCreateTsEqualTo(sysTs);\r\n" + 
				"		//		int tmpCtfprnfCnt = tmpCtfprnfDao.deleteByExample(tmpCtfprnfExample);\r\n" + 
				"		//\r\n" + 
				"		//		TmpCtfprn1Example tmpCtfprn1Example = new TmpCtfprn1Example();\r\n" + 
				"		//		tmpCtfprn1Example.createCriteria().andInjobNameEqualTo(injobName).andInjobRunSeqEqualTo(injobRunSeq).andCreateTsEqualTo(sysTs);\r\n" + 
				"		//		int tmpCtfprn1Cnt = tmpCtfprn1Dao.deleteByExample(tmpCtfprn1Example);\r\n" + 
				"		//\r\n" + 
				"		//		TmpCtfprn5Example tmpCtfprn5Example = new TmpCtfprn5Example();\r\n" + 
				"		//		tmpCtfprn5Example.createCriteria().andInjobNameEqualTo(injobName).andInjobRunSeqEqualTo(injobRunSeq).andCreateTsEqualTo(sysTs);\r\n" + 
				"		//		int tmpCtfprn5Cnt = tmpCtfprn5Dao.deleteByExample(tmpCtfprn5Example);\r\n" + 
				"		//\r\n" + 
				"		//		// TMP_CTFBOWN\r\n" + 
				"		//		TmpCtfbownExample tmpCtfbownExample = new TmpCtfbownExample();\r\n" + 
				"		//		tmpCtfbownExample.createCriteria().andInjobNameEqualTo(injobName).andInjobRunSeqEqualTo(injobRunSeq).andCreateTsEqualTo(sysTs);\r\n" + 
				"		//		int tmpCtfbownCnt = tmpCtfbownDao.deleteByExample(tmpCtfbownExample);\r\n" + 
				"		//\r\n" + 
				"		//		// TMP_CTFBUTRC\r\n" + 
				"		//		TmpCtfbutrcExample tmpCtfbutrcExample = new TmpCtfbutrcExample();\r\n" + 
				"		//		tmpCtfbutrcExample.createCriteria().andInjobNameEqualTo(injobName).andInjobRunSeqEqualTo(injobRunSeq).andCreateTsEqualTo(sysTs);\r\n" + 
				"		//		int tmpCtfbutrcCnt = tmpCtfbutrcDao.deleteByExample(tmpCtfbutrcExample);\r\n" + 
				"		//\r\n" + 
				"		//		// TMP_CTFDSPT\r\n" + 
				"		//		TmpCtfdsptExample tmpCtfdsptExample = new TmpCtfdsptExample();\r\n" + 
				"		//		tmpCtfdsptExample.createCriteria().andInjobNameEqualTo(injobName).andInjobRunSeqEqualTo(injobRunSeq).andCreateTsEqualTo(sysTs);\r\n" + 
				"		//		int tmpCtfdsptCnt = tmpCtfdsptDao.deleteByExample(tmpCtfdsptExample);\r\n" + 
				"		//\r\n" + 
				"		//		// TMP_CTFDSST\r\n" + 
				"		//		TmpCtfdsstExample tmpCtfdsstExample = new TmpCtfdsstExample();\r\n" + 
				"		//		tmpCtfdsstExample.createCriteria().andInjobNameEqualTo(injobName).andInjobRunSeqEqualTo(injobRunSeq).andCreateTsEqualTo(sysTs);\r\n" + 
				"		//		int tmpCtfdsstCnt = tmpCtfdsstDao.deleteByExample(tmpCtfdsstExample);\r\n" + 
				"		//\r\n" + 
				"		//		// TMP_CTFJBOWN\r\n" + 
				"		//		TmpCtfjbownExample tmpCtfjbownExample = new TmpCtfjbownExample();\r\n" + 
				"		//		tmpCtfjbownExample.createCriteria().andInjobNameEqualTo(injobName).andInjobRunSeqEqualTo(injobRunSeq).andCreateTsEqualTo(sysTs);\r\n" + 
				"		//		int tmpCtfjbownCnt = tmpCtfjbownDao.deleteByExample(tmpCtfjbownExample);\r\n" + 
				"		//\r\n" + 
				"		//		// TMP_CTFJPOWN\r\n" + 
				"		//		TmpCtfjpownExample tmpCtfjpownExample = new TmpCtfjpownExample();\r\n" + 
				"		//		tmpCtfjpownExample.createCriteria().andInjobNameEqualTo(injobName).andInjobRunSeqEqualTo(injobRunSeq).andCreateTsEqualTo(sysTs);\r\n" + 
				"		//		int tmpCtfjpownCnt = tmpCtfjpownDao.deleteByExample(tmpCtfjpownExample);\r\n" + 
				"		//\r\n" + 
				"		//		// TMP_CTFPAELR\r\n" + 
				"		//		TmpCtfpaelrExample tmpCtfpaelrExample = new TmpCtfpaelrExample();\r\n" + 
				"		//		tmpCtfpaelrExample.createCriteria().andInjobNameEqualTo(injobName).andInjobRunSeqEqualTo(injobRunSeq).andCreateTsEqualTo(sysTs);\r\n" + 
				"		//		int tmpCtfpaelrCnt = tmpCtfpaelrDao.deleteByExample(tmpCtfpaelrExample);\r\n" + 
				"		//\r\n" + 
				"		//		// TMP_CTFPRN2\r\n" + 
				"		//		TmpCtfprn2Example tmpCtfprn2Example = new TmpCtfprn2Example();\r\n" + 
				"		//		tmpCtfprn2Example.createCriteria().andInjobNameEqualTo(injobName).andInjobRunSeqEqualTo(injobRunSeq).andCreateTsEqualTo(sysTs);\r\n" + 
				"		//		int tmpCtfprn2Cnt = tmpCtfprn2Dao.deleteByExample(tmpCtfprn2Example);\r\n" + 
				"		//\r\n" + 
				"		//		// TMP_CTFPRN3\r\n" + 
				"		//		TmpCtfprn3Example tmpCtfprn3Example = new TmpCtfprn3Example();\r\n" + 
				"		//		tmpCtfprn3Example.createCriteria().andInjobNameEqualTo(injobName).andInjobRunSeqEqualTo(injobRunSeq).andCreateTsEqualTo(sysTs);\r\n" + 
				"		//		int tmpCtfprn3Cnt = tmpCtfprn3Dao.deleteByExample(tmpCtfprn3Example);\r\n" + 
				"		//\r\n" + 
				"		//		// TMP_CTFPRNB\r\n" + 
				"		//		TmpCtfprnbExample tmpCtfprnbExample = new TmpCtfprnbExample();\r\n" + 
				"		//		tmpCtfprnbExample.createCriteria().andInjobNameEqualTo(injobName).andInjobRunSeqEqualTo(injobRunSeq).andCreateTsEqualTo(sysTs);\r\n" + 
				"		//		int tmpCtfprnbCnt = tmpCtfprnbDao.deleteByExample(tmpCtfprnbExample);\r\n" + 
				"		//\r\n" + 
				"		//		// TMP_CTFPRNM\r\n" + 
				"		//		TmpCtfprnmExample tmpCtfprnmExample = new TmpCtfprnmExample();\r\n" + 
				"		//		tmpCtfprnmExample.createCriteria().andInjobNameEqualTo(injobName).andInjobRunSeqEqualTo(injobRunSeq).andCreateTsEqualTo(sysTs);\r\n" + 
				"		//		int tmpCtfprnmCnt = tmpCtfprnmDao.deleteByExample(tmpCtfprnmExample);\r\n" + 
				"		//\r\n" + 
				"		//		// TMP_CTFPRNS\r\n" + 
				"		//		TmpCtfprnsExample tmpCtfprnsExample = new TmpCtfprnsExample();\r\n" + 
				"		//		tmpCtfprnsExample.createCriteria().andInjobNameEqualTo(injobName).andInjobRunSeqEqualTo(injobRunSeq).andCreateTsEqualTo(sysTs);\r\n" + 
				"		//		int tmpCtfprnsCnt = tmpCtfprnsDao.deleteByExample(tmpCtfprnsExample);\r\n" + 
				"		//\r\n" + 
				"		//		// TMP_CTFPRPAA		 \r\n" + 
				"		//		int tmpCtfprpaaCnt = tmpCtfprpaaDao.deleteByCreateTsInjobNameInjobRunSeq(injobName, submitTs, injobRunSeq.intValue());\r\n" + 
				"		//\r\n" + 
				"		//		// TMP_CTFUASV\r\n" + 
				"		//		TmpCtfuasvExample tmpCtfuasvExample = new TmpCtfuasvExample();\r\n" + 
				"		//		tmpCtfuasvExample.createCriteria().andInjobNameEqualTo(injobName).andInjobRunSeqEqualTo(injobRunSeq).andCreateTsEqualTo(sysTs);\r\n" + 
				"		//		int tmpCtfuasvCnt = tmpCtfuasvDao.deleteByExample(tmpCtfuasvExample);\r\n" + 
				"		//\r\n" + 
				"		//		// TMP_CTFUASVA\r\n" + 
				"		//		TmpCtfuasvaExample tmpCtfuasvaExample = new TmpCtfuasvaExample();\r\n" + 
				"		//		tmpCtfuasvaExample.createCriteria().andInjobNameEqualTo(injobName).andInjobRunSeqEqualTo(injobRunSeq).andCreateTsEqualTo(sysTs);\r\n" + 
				"		//		int tmpCtfuasvaCnt = tmpCtfuasvaDao.deleteByExample(tmpCtfuasvaExample);\r\n" + 
				"		//\r\n" + 
				"		//		// TMP_CTFUJPT\r\n" + 
				"		//		TmpCtfujptExample tmpCtfujptExample = new TmpCtfujptExample();\r\n" + 
				"		//		tmpCtfujptExample.createCriteria().andInjobNameEqualTo(injobName).andInjobRunSeqEqualTo(injobRunSeq).andCreateTsEqualTo(sysTs);\r\n" + 
				"		//		int tmpCtfujptCnt = tmpCtfujptDao.deleteByExample(tmpCtfujptExample);\r\n" + 
				"		//\r\n" + 
				"		//		// TMP_CTFUPAA\r\n" + 
				"		//		TmpCtfupaaExample tmpCtfupaaExample = new TmpCtfupaaExample();\r\n" + 
				"		//		tmpCtfupaaExample.createCriteria().andInjobNameEqualTo(injobName).andInjobRunSeqEqualTo(injobRunSeq).andCreateTsEqualTo(sysTs);\r\n" + 
				"		//		int tmpCtfupaaCnt = tmpCtfupaaDao.deleteByExample(tmpCtfupaaExample);\r\n" + 
				"		//\r\n" + 
				"		//		int ctfpownZmCtybiCnt = ctfpownZmCtybiDao.clean(sysTs);\r\n" + 
				"		//		int ctfptshrZmCtybiCnt = ctfptshrZmCtybiDao.clean(sysTs);\r\n" + 
				"\r\n" + 
				"		int ctfpownZmCtybiCnt = nativeUpdate.deleteForCTAUA(\"TBL_CTFPOWN_ZM_CTYBI\", injobName, injobRunSeq.intValue(), sysTs);\r\n" + 
				"		int ctfptshrZmCtybiCnt = nativeUpdate.deleteForCTAUA(\"TBL_CTFPTSHR_ZM_CTYBI\", injobName, injobRunSeq.intValue(), sysTs);\r\n" + 
				"		\r\n" + 
				"		int tmpCtfprpaaCnt = tmpCtfprpaaDao.deleteByCreateTsInjobNameInjobRunSeq(injobName, submitTs, injobRunSeq.intValue());\r\n" + 
				"				\r\n" + 
				"		// TMP_CTFBOWN\r\n" + 
				"		TmpCtfbownExample tmpCtfbownExample = new TmpCtfbownExample();\r\n" + 
				"		tmpCtfbownExample.createCriteria().andCreateTsNotEqualTo(sysTs);\r\n" + 
				"		int tmpCtfbownCnt = tmpCtfbownDao.countByExample(tmpCtfbownExample);\r\n" + 
				"		if (tmpCtfbownCnt > 0) {\r\n" + 
				"			throw new Exception(\"TMP_CTFBOWN contains data of other job.\");\r\n" + 
				"		}\r\n" + 
				"\r\n" + 
				"		// TMP_CTFBUTRC\r\n" + 
				"		TmpCtfbutrcExample tmpCtfbutrcExample = new TmpCtfbutrcExample();\r\n" + 
				"		tmpCtfbutrcExample.createCriteria().andCreateTsNotEqualTo(sysTs);\r\n" + 
				"		int tmpCtfbutrcCnt = tmpCtfbutrcDao.countByExample(tmpCtfbutrcExample);\r\n" + 
				"		if (tmpCtfbutrcCnt > 0) {\r\n" + 
				"			throw new Exception(\"TMP_CTFBUTRC contains data of other job.\");\r\n" + 
				"		}\r\n" + 
				"\r\n" + 
				"		// TMP_CTFDSPT\r\n" + 
				"		TmpCtfdsptExample tmpCtfdsptExample = new TmpCtfdsptExample();\r\n" + 
				"		tmpCtfdsptExample.createCriteria().andCreateTsNotEqualTo(sysTs);\r\n" + 
				"		int tmpCtfdsptCnt = tmpCtfdsptDao.countByExample(tmpCtfdsptExample);\r\n" + 
				"		if (tmpCtfdsptCnt > 0) {\r\n" + 
				"			throw new Exception(\"TMP_CTFDSPT contains data of other job.\");\r\n" + 
				"		}\r\n" + 
				"\r\n" + 
				"		// TMP_CTFDSST\r\n" + 
				"		TmpCtfdsstExample tmpCtfdsstExample = new TmpCtfdsstExample();\r\n" + 
				"		tmpCtfdsstExample.createCriteria().andCreateTsNotEqualTo(sysTs);\r\n" + 
				"		int tmpCtfdsstCnt = tmpCtfdsstDao.countByExample(tmpCtfdsstExample);\r\n" + 
				"		if (tmpCtfdsstCnt > 0) {\r\n" + 
				"			throw new Exception(\"TMP_CTFDSST contains data of other job.\");\r\n" + 
				"		}\r\n" + 
				"\r\n" + 
				"		// TMP_CTFJBOWN\r\n" + 
				"		TmpCtfjbownExample tmpCtfjbownExample = new TmpCtfjbownExample();\r\n" + 
				"		tmpCtfjbownExample.createCriteria().andCreateTsNotEqualTo(sysTs);\r\n" + 
				"		int tmpCtfjbownCnt = tmpCtfjbownDao.countByExample(tmpCtfjbownExample);\r\n" + 
				"		if (tmpCtfjbownCnt > 0) {\r\n" + 
				"			throw new Exception(\"TMP_CTFJBOWN contains data of other job.\");\r\n" + 
				"		}\r\n" + 
				"\r\n" + 
				"		// TMP_CTFJPOWN\r\n" + 
				"		TmpCtfjpownExample tmpCtfjpownExample = new TmpCtfjpownExample();\r\n" + 
				"		tmpCtfjpownExample.createCriteria().andCreateTsNotEqualTo(sysTs);\r\n" + 
				"		int tmpCtfjpownCnt = tmpCtfjpownDao.countByExample(tmpCtfjpownExample);\r\n" + 
				"		if (tmpCtfjpownCnt > 0) {\r\n" + 
				"			throw new Exception(\"TMP_CTFJPOWN contains data of other job.\");\r\n" + 
				"		}\r\n" + 
				"\r\n" + 
				"		// TMP_CTFPAELR\r\n" + 
				"		TmpCtfpaelrExample tmpCtfpaelrExample = new TmpCtfpaelrExample();\r\n" + 
				"		tmpCtfpaelrExample.createCriteria().andCreateTsNotEqualTo(sysTs);\r\n" + 
				"		int tmpCtfpaelrCnt = tmpCtfpaelrDao.countByExample(tmpCtfpaelrExample);\r\n" + 
				"		if (tmpCtfpaelrCnt > 0) {\r\n" + 
				"			throw new Exception(\"TMP_CTFPAELR contains data of other job.\");\r\n" + 
				"		}\r\n" + 
				"\r\n" + 
				"		// TMP_CTFPRN1\r\n" + 
				"		TmpCtfprn1Example tmpCtfprn1Example = new TmpCtfprn1Example();\r\n" + 
				"		tmpCtfprn1Example.createCriteria().andCreateTsNotEqualTo(sysTs);\r\n" + 
				"		int tmpCtfprn1Cnt = tmpCtfprn1Dao.countByExample(tmpCtfprn1Example);\r\n" + 
				"		if (tmpCtfprn1Cnt > 0) {\r\n" + 
				"			throw new Exception(\"TMP_CTFPRN1 contains data of other job.\");\r\n" + 
				"		}\r\n" + 
				"		\r\n" + 
				"		// TMP_CTFPRN2\r\n" + 
				"		TmpCtfprn2Example tmpCtfprn2Example = new TmpCtfprn2Example();\r\n" + 
				"		tmpCtfprn2Example.createCriteria().andCreateTsNotEqualTo(sysTs);\r\n" + 
				"		int tmpCtfprn2Cnt = tmpCtfprn2Dao.countByExample(tmpCtfprn2Example);\r\n" + 
				"		if (tmpCtfprn2Cnt > 0) {\r\n" + 
				"			throw new Exception(\"TMP_CTFPRN2 contains data of other job.\");\r\n" + 
				"		}\r\n" + 
				"\r\n" + 
				"		// TMP_CTFPRN3\r\n" + 
				"		TmpCtfprn3Example tmpCtfprn3Example = new TmpCtfprn3Example();\r\n" + 
				"		tmpCtfprn3Example.createCriteria().andCreateTsNotEqualTo(sysTs);\r\n" + 
				"		int tmpCtfprn3Cnt = tmpCtfprn3Dao.countByExample(tmpCtfprn3Example);\r\n" + 
				"		if (tmpCtfprn3Cnt > 0) {\r\n" + 
				"			throw new Exception(\"TMP_CTFPRN3 contains data of other job.\");\r\n" + 
				"		}\r\n" + 
				"\r\n" + 
				"		// TMP_CTFPRN5\r\n" + 
				"		TmpCtfprn5Example tmpCtfprn5Example = new TmpCtfprn5Example();\r\n" + 
				"		tmpCtfprn5Example.createCriteria().andCreateTsNotEqualTo(sysTs);\r\n" + 
				"		int tmpCtfprn5Cnt = tmpCtfprn5Dao.countByExample(tmpCtfprn5Example);\r\n" + 
				"		if (tmpCtfprn5Cnt > 0) {\r\n" + 
				"			throw new Exception(\"TMP_CTFPRN5 contains data of other job.\");\r\n" + 
				"		}\r\n" + 
				"		\r\n" + 
				"		// TMP_CTFPRNB\r\n" + 
				"		TmpCtfprnbExample tmpCtfprnbExample = new TmpCtfprnbExample();\r\n" + 
				"		tmpCtfprnbExample.createCriteria().andCreateTsNotEqualTo(sysTs);\r\n" + 
				"		int tmpCtfprnbCnt = tmpCtfprnbDao.countByExample(tmpCtfprnbExample);\r\n" + 
				"		if (tmpCtfprnbCnt > 0) {\r\n" + 
				"			throw new Exception(\"TMP_CTFPRNB contains data of other job.\");\r\n" + 
				"		}\r\n" + 
				"		\r\n" + 
				"		// TMP_CTFPRNF\r\n" + 
				"		TmpCtfprnfExample tmpCtfprnfExample = new TmpCtfprnfExample();\r\n" + 
				"		tmpCtfprnfExample.createCriteria().andCreateTsNotEqualTo(sysTs);\r\n" + 
				"		int tmpCtfprnfCnt = tmpCtfprnfDao.countByExample(tmpCtfprnfExample);\r\n" + 
				"		if (tmpCtfprnfCnt > 0) {\r\n" + 
				"			throw new Exception(\"TMP_CTFPRNF contains data of other job.\");\r\n" + 
				"		}\r\n" + 
				"\r\n" + 
				"		// TMP_CTFPRNM\r\n" + 
				"		TmpCtfprnmExample tmpCtfprnmExample = new TmpCtfprnmExample();\r\n" + 
				"		tmpCtfprnmExample.createCriteria().andCreateTsNotEqualTo(sysTs);\r\n" + 
				"		int tmpCtfprnmCnt = tmpCtfprnmDao.countByExample(tmpCtfprnmExample);\r\n" + 
				"		if (tmpCtfprnmCnt > 0) {\r\n" + 
				"			throw new Exception(\"TMP_CTFPRNM contains data of other job.\");\r\n" + 
				"		}\r\n" + 
				"		\r\n" + 
				"		// TMP_CTFPRNS\r\n" + 
				"		TmpCtfprnsExample tmpCtfprnsExample = new TmpCtfprnsExample();\r\n" + 
				"		tmpCtfprnsExample.createCriteria().andCreateTsNotEqualTo(sysTs);\r\n" + 
				"		int tmpCtfprnsCnt = tmpCtfprnsDao.countByExample(tmpCtfprnsExample);\r\n" + 
				"		if (tmpCtfprnsCnt > 0) {\r\n" + 
				"			throw new Exception(\"TMP_CTFPRNS contains data of other job.\");\r\n" + 
				"		}\r\n" + 
				"		\r\n" + 
				"		// TMP_CTFUASV\r\n" + 
				"		TmpCtfuasvExample tmpCtfuasvExample = new TmpCtfuasvExample();\r\n" + 
				"		tmpCtfuasvExample.createCriteria().andCreateTsNotEqualTo(sysTs);\r\n" + 
				"		int tmpCtfuasvCnt = tmpCtfuasvDao.countByExample(tmpCtfuasvExample);\r\n" + 
				"		if (tmpCtfuasvCnt > 0) {\r\n" + 
				"			throw new Exception(\"TMP_CTFUASV contains data of other job.\");\r\n" + 
				"		}\r\n" + 
				"		\r\n" + 
				"		// TMP_CTFUASVA\r\n" + 
				"		TmpCtfuasvaExample tmpCtfuasvaExample = new TmpCtfuasvaExample();\r\n" + 
				"		tmpCtfuasvaExample.createCriteria().andCreateTsNotEqualTo(sysTs);\r\n" + 
				"		int tmpCtfuasvaCnt = tmpCtfuasvaDao.countByExample(tmpCtfuasvaExample);\r\n" + 
				"		if (tmpCtfuasvaCnt > 0) {\r\n" + 
				"			throw new Exception(\"TMP_CTFUASVA contains data of other job.\");\r\n" + 
				"		}\r\n" + 
				"		\r\n" + 
				"		// TMP_CTFUJPT\r\n" + 
				"		TmpCtfujptExample tmpCtfujptExample = new TmpCtfujptExample();\r\n" + 
				"		tmpCtfujptExample.createCriteria().andCreateTsNotEqualTo(sysTs);\r\n" + 
				"		int tmpCtfujptCnt = tmpCtfujptDao.countByExample(tmpCtfujptExample);\r\n" + 
				"		if (tmpCtfujptCnt > 0) {\r\n" + 
				"			throw new Exception(\"TMP_CTFUJPT contains data of other job.\");\r\n" + 
				"		}\r\n" + 
				"		\r\n" + 
				"		// TMP_CTFUPAA\r\n" + 
				"		TmpCtfupaaExample tmpCtfupaaExample = new TmpCtfupaaExample();\r\n" + 
				"		tmpCtfupaaExample.createCriteria().andCreateTsNotEqualTo(sysTs);\r\n" + 
				"		int tmpCtfupaaCnt = tmpCtfupaaDao.countByExample(tmpCtfupaaExample);\r\n" + 
				"		if (tmpCtfupaaCnt > 0) {\r\n" + 
				"			throw new Exception(\"TMP_CTFUPAA contains data of other job.\");\r\n" + 
				"		}\r\n" + 
				"		\r\n" + 
				"		int tmpCtfbownCntTrun = nativeUpdate.truncateTable(\"TMP_CTFBOWN\");\r\n" + 
				"		int tmpCtfbutrcCntTrun = nativeUpdate.truncateTable(\"TMP_CTFBUTRC\");\r\n" + 
				"		int tmpCtfdsptCntTrun = nativeUpdate.truncateTable(\"TMP_CTFDSPT\");\r\n" + 
				"		int tmpCtfdsstCntTrun = nativeUpdate.truncateTable(\"TMP_CTFDSST\");\r\n" + 
				"		int tmpCtfjbownCntTrun = nativeUpdate.truncateTable(\"TMP_CTFJBOWN\");\r\n" + 
				"		int tmpCtfjpownCntTrun = nativeUpdate.truncateTable(\"TMP_CTFJPOWN\");\r\n" + 
				"		int tmpCtfpaelrCntTrun = nativeUpdate.truncateTable(\"TMP_CTFPAELR\");\r\n" + 
				"		int tmpCtfprn1CntTrun = nativeUpdate.truncateTable(\"TMP_CTFPRN1\");\r\n" + 
				"		int tmpCtfprn2CntTrun = nativeUpdate.truncateTable(\"TMP_CTFPRN2\");\r\n" + 
				"		int tmpCtfprn3CntTrun = nativeUpdate.truncateTable(\"TMP_CTFPRN3\");\r\n" + 
				"		int tmpCtfprn5CntTrun = nativeUpdate.truncateTable(\"TMP_CTFPRN5\");\r\n" + 
				"		int tmpCtfprnbCntTrun = nativeUpdate.truncateTable(\"TMP_CTFPRNB\");\r\n" + 
				"		int tmpCtfprnfCntTrun = nativeUpdate.truncateTable(\"TMP_CTFPRNF\");\r\n" + 
				"		int tmpCtfprnmCntTrun = nativeUpdate.truncateTable(\"TMP_CTFPRNM\");\r\n" + 
				"		int tmpCtfprnsCntTrun = nativeUpdate.truncateTable(\"TMP_CTFPRNS\");\r\n" + 
				"		int tmpCtfuasvCntTrun = nativeUpdate.truncateTable(\"TMP_CTFUASV\");\r\n" + 
				"		int tmpCtfuasvaCntTrun = nativeUpdate.truncateTable(\"TMP_CTFUASVA\");\r\n" + 
				"		int tmpCtfujptCntTrun = nativeUpdate.truncateTable(\"TMP_CTFUJPT\");\r\n" + 
				"		int tmpCtfupaaCntTrun = nativeUpdate.truncateTable(\"TMP_CTFUPAA\");\r\n" + 
				"\r\n" + 
				"		controlReportUtils.addCustomControlReport(\"TMP_CTFPRNF\",IrdConstant.DB_OPERATION_DELETE, 0 , tmpCtfprnfCntTrun,true);\r\n" + 
				"		controlReportUtils.addCustomControlReport(\"TMP_CTFPRN1\",IrdConstant.DB_OPERATION_DELETE, 0 , tmpCtfprn1CntTrun,true);\r\n" + 
				"		controlReportUtils.addCustomControlReport(\"TMP_CTFPRN5\",IrdConstant.DB_OPERATION_DELETE, 0 , tmpCtfprn5CntTrun,true);\r\n" + 
				"		controlReportUtils.addCustomControlReport(\"TMP_CTFBOWN\",IrdConstant.DB_OPERATION_DELETE, 0 , tmpCtfbownCntTrun,true);\r\n" + 
				"		controlReportUtils.addCustomControlReport(\"TMP_CTFBUTRC\",IrdConstant.DB_OPERATION_DELETE, 0 , tmpCtfbutrcCntTrun,true);\r\n" + 
				"		controlReportUtils.addCustomControlReport(\"TMP_CTFDSPT\",IrdConstant.DB_OPERATION_DELETE, 0 , tmpCtfdsptCntTrun,true);\r\n" + 
				"		controlReportUtils.addCustomControlReport(\"TMP_CTFDSST\",IrdConstant.DB_OPERATION_DELETE, 0 , tmpCtfdsstCntTrun,true);\r\n" + 
				"		controlReportUtils.addCustomControlReport(\"TMP_CTFJBOWN\",IrdConstant.DB_OPERATION_DELETE, 0 , tmpCtfjbownCntTrun,true);\r\n" + 
				"		controlReportUtils.addCustomControlReport(\"TMP_CTFJPOWN\",IrdConstant.DB_OPERATION_DELETE, 0 , tmpCtfjpownCntTrun,true);\r\n" + 
				"		controlReportUtils.addCustomControlReport(\"TMP_CTFPAELR\",IrdConstant.DB_OPERATION_DELETE, 0 , tmpCtfpaelrCntTrun,true);\r\n" + 
				"		controlReportUtils.addCustomControlReport(\"TMP_CTFPRN2\",IrdConstant.DB_OPERATION_DELETE, 0 , tmpCtfprn2CntTrun,true);\r\n" + 
				"		controlReportUtils.addCustomControlReport(\"TMP_CTFPRN3\",IrdConstant.DB_OPERATION_DELETE, 0 , tmpCtfprn3CntTrun,true);\r\n" + 
				"		controlReportUtils.addCustomControlReport(\"TMP_CTFPRNB\",IrdConstant.DB_OPERATION_DELETE, 0 , tmpCtfprnbCntTrun,true);\r\n" + 
				"		controlReportUtils.addCustomControlReport(\"TMP_CTFPRNM\",IrdConstant.DB_OPERATION_DELETE, 0 , tmpCtfprnmCntTrun,true);\r\n" + 
				"		controlReportUtils.addCustomControlReport(\"TMP_CTFPRNS\",IrdConstant.DB_OPERATION_DELETE, 0 , tmpCtfprnsCntTrun,true);\r\n" + 
				"		controlReportUtils.addCustomControlReport(\"TMP_CTFPRPAA\",IrdConstant.DB_OPERATION_DELETE, 0 , tmpCtfprpaaCnt,true);\r\n" + 
				"		controlReportUtils.addCustomControlReport(\"TMP_CTFUASV\",IrdConstant.DB_OPERATION_DELETE, 0 , tmpCtfuasvCntTrun,true);\r\n" + 
				"		controlReportUtils.addCustomControlReport(\"TMP_CTFUASVA\",IrdConstant.DB_OPERATION_DELETE, 0 , tmpCtfuasvaCntTrun,true);\r\n" + 
				"		controlReportUtils.addCustomControlReport(\"TMP_CTFUJPT\",IrdConstant.DB_OPERATION_DELETE, 0 , tmpCtfujptCntTrun,true);\r\n" + 
				"		controlReportUtils.addCustomControlReport(\"TMP_CTFUPAA\",IrdConstant.DB_OPERATION_DELETE, 0 , tmpCtfupaaCntTrun,true);\r\n" + 
				"		controlReportUtils.addCustomControlReport(\"TBL_CTFPOWN_ZM_CTYBI\",IrdConstant.DB_OPERATION_DELETE, 0 , ctfpownZmCtybiCnt,true);\r\n" + 
				"		controlReportUtils.addCustomControlReport(\"TBL_CTFPTSHR_ZM_CTYBI\",IrdConstant.DB_OPERATION_DELETE, 0 , ctfptshrZmCtybiCnt,true);\r\n" + 
				"		\r\n" + 
				"		logger.debug(\"================== Ctaua1CleanupWorker.doAction() Ended ==================\");\r\n" + 
				"		\r\n" + 
				"	}\r\n" + 
				"	\r\n" + 
				"	public Timestamp getCreateTs(String contextKey) throws Exception {\r\n" + 
				"		\r\n" + 
				"		SimpleDateFormat timestampFormat = new SimpleDateFormat(\"yyyyMMddHHmmssSSSSSS\");\r\n" + 
				"		Date sysTs = null;\r\n" + 
				"		\r\n" + 
				"		if (systemConfig.getContextValue(contextKey) != null) { \r\n" + 
				"			sysTs = timestampFormat.parse(systemConfig.getContextValue(contextKey));\r\n" + 
				"		} else {\r\n" + 
				"			sysTs = systemConfig.getSystemTimestamp();\r\n" + 
				"			HashMap<String, Object> contextMap = new HashMap<String, Object> ();\r\n" + 
				"			contextMap.put(contextKey, timestampFormat.format(sysTs));\r\n" + 
				"			systemConfig.addContextMap(contextMap);\r\n" + 
				"		}\r\n" + 
				"		return (new Timestamp(sysTs.getTime()));\r\n" + 
				"	}\r\n" + 
				"\r\n" + 
				"	@Component(\"Ctaua1NativeUpdate\")\r\n" + 
				"	public static class Ctaua1NativeUpdate extends NativeJdbcDaoImpl implements ErFtp2ErConstant{\r\n" + 
				"\r\n" + 
				"		public int deleteForCTAUA(String tableName, String jobName, Integer runSeq, Date createTs) throws Exception {\r\n" + 
				"			String selectSql = \"SELECT COUNT(1) FROM \" + tableName + \" WHERE INJOB_NAME = ? AND INJOB_RUN_SEQ = ? AND CREATE_TS = ?\";\r\n" + 
				"			String deleteSql = \"DELETE FROM (SELECT * FROM \" + tableName + \" ORDER BY ROW_NUM FETCH FIRST 100000 ROWS ONLY) WHERE INJOB_NAME = ? AND INJOB_RUN_SEQ = ? AND CREATE_TS = ?\";\r\n" + 
				"\r\n" + 
				"			int cnt = 0, rcCnt = 1;\r\n" + 
				"			while (rcCnt > 0) {\r\n" + 
				"				ResultSet rs = queryForResultSet(selectSql, jobName, runSeq, createTs);\r\n" + 
				"				rs.next();\r\n" + 
				"				rcCnt = rs.getInt(1);\r\n" + 
				"				if (rcCnt > 0)\r\n" + 
				"					cnt += executeUpdate(deleteSql, jobName, runSeq, createTs);\r\n" + 
				"				getConnection().commit();\r\n" + 
				"			}\r\n" + 
				"			return cnt;\r\n" + 
				"		}\r\n" + 
				"\r\n" + 
				"		public int truncateTable(String tableName) throws Exception {\r\n" + 
				"			String selectSql = \"SELECT COUNT(1) FROM \" + tableName;\r\n" + 
				"			ResultSet rs = queryForResultSet(selectSql);\r\n" + 
				"			rs.next();\r\n" + 
				"			int cnt = rs.getInt(1);\r\n" + 
				"			getConnection().commit();\r\n" + 
				"			String truncateSql = \"TRUNCATE TABLE \" + tableName + \" IMMEDIATE \";\r\n" + 
				"			executeUpdate(truncateSql);\r\n" + 
				"			getConnection().commit();\r\n" + 
				"			return cnt;\r\n" + 
				"		}\r\n" + 
				"	}\r\n" + 
				"\r\n" + 
				"}\r\n" + 
				"";
//		String replacedFileContent="";
//		int countVoid = 0;
//		int countInsert = 0;
//		Pattern removePattern1 = Pattern.compile("public\\s+[a-zA-Z0-9]+\\s+insert");
//		Matcher removePattern1Matcher=removePattern1.matcher(replacedFileContent);
//		while (removePattern1Matcher.find()){
//			String storeVarible = removePattern1Matcher.group();
//			String[] splitValue =storeVarible.split("\\s+");
//			countInsert++;
//			 for (int j = 0; j < splitValue.length; j++) {
//				 if(splitValue[j].equals("void")) {
//					 System.out.println("void =");
//					 countVoid++;
//				 }
//			 }
//			 System.out.println("countVoid ="+countVoid);
//			 System.out.println("countInsert ="+countInsert);
//			System.out.println("storeVarible3 =" +storeVarible);
//			replacedFileContent = removePattern1.matcher(replacedFileContent).replaceAll(Matcher.quoteReplacement("xxx"));
//			}
//		Pattern removePattern2 = Pattern.compile("import\\s+[a-zA-Z0-9.]*StringUtil[s]");
//		Matcher removePattern2Matcher=removePattern2.matcher(replacedFileContent);
//		Pattern removePattern3 = Pattern.compile("//.*[a-zA-Z0-9.]*StringUtil[s]");
//		Pattern patternRemove = Pattern.compile("//.*\\s*[lL]ogger\\s*([((\r\n)|(\r)|(\n))]*)[.]([((\r\n)|(\r)|(\n))]*)\\s*info");
//		Matcher patternRemoveMatcher=patternRemove.matcher(replacedFileContent);
//		String storeVarible456 =null;
//		while (patternRemoveMatcher.find()){
//			storeVarible456= patternRemoveMatcher.group();
//			System.out.println("storeVarible456 ="+ storeVarible456);
//			replacedFileContent=replacedFileContent.replaceAll(storeVarible456, "");
//			}
		Pattern removePattern3 = Pattern.compile("[lL]ogger\\s*([((\r\n)|(\r)|(\n))]*)[.]([((\r\n)|(\r)|(\n))]*)\\s*info");
		Matcher removePattern3Matcher=removePattern3.matcher(replacedFileContent);
		while (removePattern3Matcher.find()){
			String storeVarible111= removePattern3Matcher.group();
			System.out.println("storeVarible111 ="+ storeVarible111);
//			System.out.println("storeVarible1 ="+ storeVarible1[0]);
		}
//		System.out.println("replacedFileContent =" +replacedFileContent);
//		Pattern removePattern1 = Pattern.compile("public ([a-zA-Z0-9]+) get([a-zA-Z0-9]+)[(][)] [{]");//((\r\n)|(\r)|(\n))*
		Pattern pattern111 = Pattern.compile("@Autowired([a-zA-Z0-9 	((\r\n)|(\r)|(\n))]*);");
//		Pattern pattern111 = Pattern.compile("	@Autowired\r\n" + 
//				"	private Ctaua1NativeUpdate nativeUpdate;");
		String storeVarible111 =null;
		Matcher patternMatcher111=pattern111.matcher(content);
		while (patternMatcher111.find()){
			storeVarible111= patternMatcher111.group();
			storeVarible111=storeVarible111.replaceAll(";", "");
			storeVarible111=storeVarible111.replaceAll("@Autowired ", "");
			storeVarible111=storeVarible111.replaceAll("private ", "");

			String[] storeVarible1 = storeVarible111.split(" ",2);
//			System.out.println("storeVarible111 ="+ storeVarible111);
//			System.out.println("storeVarible1 ="+ storeVarible1[0]);
		}
		
		Pattern pattern2 = Pattern.compile("public([ 	((\r\n)|(\r)|(\n))]*)([a-zA-Z0-9_]*)([ 	((\r\n)|(\r)|(\n))]*)(class|interface)([ 	((\r\n)|(\r)|(\n))]*)([a-zA-Z0-9_]*)([ 	((\r\n)|(\r)|(\n))]*)([a-zA-Z0-9_]*)([ 	((\r\n)|(\r)|(\n))]*)([a-zA-Z0-9_]*)([ 	((\r\n)|(\r)|(\n))]*)([a-zA-Z0-9_]*)([ 	((\r\n)|(\r)|(\n))]*)([a-zA-Z0-9_]*)([ 	((\r\n)|(\r)|(\n))]*)[{]");
//		Pattern pattern2 = Pattern.compile("public([ 	((\r\n)|(\r)|(\n))]*)([a-zA-Z0-9_]*)([ 	((\r\n)|(\r)|(\n))]*)([a-zA-Z0-9_]*)([ 	((\r\n)|(\r)|(\n))]*)([a-zA-Z0-9_]*)([ 	((\r\n)|(\r)|(\n))]*)([a-zA-Z0-9_]*)([ 	((\r\n)|(\r)|(\n))]*)([a-zA-Z0-9_]*)([ 	((\r\n)|(\r)|(\n))]*)([a-zA-Z0-9_]*)([ 	((\r\n)|(\r)|(\n))]*)[{]");
//		Pattern pattern2 = Pattern.compile("public([ 	((\r\n)|(\r)|(\n))]*)([a-zA-Z0-9_]*)([ 	((\r\n)|(\r)|(\n))]*)(class|interface)([a-zA-Z0-9._ ((\r\n)|(\r)|(\n))]*)[{]");

		String storeVarible2 =null;
		Matcher patternMatcher2=pattern2.matcher(content);
		while (patternMatcher2.find()){
			storeVarible2= patternMatcher2.group();
//			System.out.println("storeVarible2 ="+ storeVarible2);
//			System.out.println("inner-class1 =" +patternMatcher2.group(1));
//			System.out.println("inner-class2 =" +patternMatcher2.group(2));
//			System.out.println("inner-class3 =" +patternMatcher2.group(3));
//			System.out.println("inner-class4 =" +patternMatcher2.group(4));
//			System.out.println("inner-class5 =" +patternMatcher2.group(5));
//			System.out.println("inner-class6 =" +patternMatcher2.group(6));
//			System.out.println("inner-class7 =" +patternMatcher2.group(7));
//			System.out.println("inner-class8 =" +patternMatcher2.group(8));
//			System.out.println("inner-class9 =" +patternMatcher2.group(9));
//			System.out.println("inner-class10 =" +patternMatcher2.group(10));
//			System.out.println("inner-class11 =" +patternMatcher2.group(11));
//			System.out.println("inner-class12 =" +patternMatcher2.group(12));
//			System.out.println("inner-class13 =" +patternMatcher2.group(13));
//			System.out.println("inner-class14 =" +patternMatcher2.group(14));
		}
		Pattern pattern1 = Pattern.compile("[<]result\\s+column\\s*[=]\\s*[\"]([a-zA-Z0-9._]+)[\"]\\s+jdbcType\\s*[=]\\s*[\"]([a-zA-Z0-9._]+)[\"]\\s+property\\s*[=]\\s*[\"]([a-zA-Z0-9._]+)[\"]\\s*[/][>]");
		Matcher patternMatcher1=pattern1.matcher(replacedFileContent);
		String storeVarible1 =null;
		String varible11 =null;
		String varible21 =null;
		String varible31 =null;
		String storeTIMESTAMPvarible ="";
		int count = 0;
		boolean xmlPattern2 =false;
		while (patternMatcher1.find()){
			storeVarible1= patternMatcher1.group();
			varible11= patternMatcher1.group(1);
			varible21= patternMatcher1.group(2);
			varible31= patternMatcher1.group(3);
//			System.out.println("replacedFileContent ="+ storeVarible1);
//			System.out.println("varible1 ="+ varible11);
//			System.out.println("varible2 ="+ varible21);
//			System.out.println("varible3 ="+ varible31);
			if(varible21.trim().equals("TIMESTAMP")) {
				xmlPattern2=true;
//				System.out.println("varible31 ="+ varible31);
//				System.out.println("count ="+ count);
				if(count==0)
					storeTIMESTAMPvarible=storeTIMESTAMPvarible+varible31.trim();
				else
					storeTIMESTAMPvarible=storeTIMESTAMPvarible+",_,"+varible31.trim();	
//				System.out.println("storeTIMESTAMPvarible ="+ storeTIMESTAMPvarible);
				count++;
			}
			}
//		Pattern pattern = Pattern.compile("[#][{]([a-zA-Z0-9._ ]+),jdbcType=([a-zA-Z0-9._]+)\\s*[}]");
		Pattern pattern = Pattern.compile("a");
		Matcher patternMatcher=pattern.matcher(content);
		String storeVarible =null;
		String varible1 =null;
		String varible2 =null;
		while (patternMatcher.find()){
			storeVarible = patternMatcher.group();
//			varible1= patternMatcher.group(1);
//			varible2= patternMatcher.group(2);
//			if(xmlPattern2) {
//				String[] splitTIMESTAMPVarible = storeTIMESTAMPvarible.split(Pattern.quote(",_,"));
//				for (int j = 0; j < splitTIMESTAMPVarible.length; j++) {
//					if(varible1.trim().contains(splitTIMESTAMPVarible[j])) {
//						if(!varible2.equals("TIMESTAMP")) {
//							System.out.println("splitTIMESTAMPVarible[j] ="+ splitTIMESTAMPVarible[j]);
//							System.out.println("varible1 ="+ varible1);
//							System.out.println("varible2 ="+ varible2);
//						}
//					}
//				}
//			}
//			else {
//				if(varible1.trim().endsWith("Ts")) {
//					if(!varible2.equals("TIMESTAMP")) {
//						System.out.println("varible1 ="+ varible1);
//						System.out.println("varible2 ="+ varible2);
//					}
//				}
//			}
//			System.out.println("replacedFileContent ="+ storeVarible);
//			System.out.println("varible1 ="+ varible1);
//			System.out.println("varible2 ="+ varible2);
//			if(!varible1.equals(varible2)) {
//				System.out.println("error");
//			}
			}
		
		
//		Pattern removePattern6 = Pattern.compile("getSqlMapClientTemplate\\s*[(]\\s*[)]\\s*((\r\n)|(\n)|(\r))*\\s*[.]\\s*([Dd])elete");
//		Matcher removePattern6Matcher=removePattern6.matcher(replacedFileContent);
//		if (removePattern6Matcher.find()){
//			replacedFileContent = removePattern6.matcher(replacedFileContent).replaceAll(Matcher.quoteReplacement("getSqlMapClientTemplate().uncheckedDelete"));
//			}
//		System.out.println("replacedFileContent =" +replacedFileContent);
	}
}