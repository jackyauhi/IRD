import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class FindFuctionResponsiblePerson {
	
//	public static Map<String, String> resultMap = new HashMap<String, String>();

	public static List<String> inputCsvFileList = new ArrayList<String>();
	public static List<String> inputFileList = new ArrayList<String>();
	public static List<String> outputFileList = new ArrayList<String>();
	public static void main(String[] args) throws IOException {
		String inputCsvFile="T:\\jackyau\\CM_Summary.csv";
		String inputFuctionID="T:\\jackyau\\RequiredFunctionName.txt";
		String outputResult="T:\\jackyau\\Fuction_Responsible_Person2.csv";
		
		try {
			BufferedReader fileReader = new BufferedReader(new FileReader(inputCsvFile));
			String line=null;
			int count =0;
		    try {
				while ((line = fileReader.readLine()) != null)
				{	
					String[] dataStore = line.split(",");
					count++;
//					System.out.println("dataStore[0] ="+ dataStore[0]);
//					System.out.println("dataStore[1] ="+ dataStore[1]);
//					System.out.println("count ="+ count);
					inputCsvFileList.add(line);
				}
				fileReader.close();
			} 
		    catch (IOException e1) {
				e1.printStackTrace();
			}
			} 
	   	catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
//		System.out.println("resultMap"+resultMap.size());
		try {
			BufferedReader fileReader = new BufferedReader(new FileReader(inputFuctionID));
			String line=null;
		    try {
				while ((line = fileReader.readLine()) != null)
				{	
					inputFileList.add(line.trim());
				}
				fileReader.close();
			} 
		    catch (IOException e1) {
				e1.printStackTrace();
			}
			} 
	   	catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
	      for (int i = 0; i < inputFileList.size(); i++) {
	    	  boolean haveFunction =true;
	    	  for (int j = 0; j < inputCsvFileList.size(); j++) {
	    		  System.out.println("inputCsvFileList :"+inputCsvFileList.get(j).toString());
	    		  String[] dataStore = inputCsvFileList.get(j).toString().split(",");
	    		  if(dataStore[0].contains(inputFileList.get(i).toString())) {
	    			  System.out.println("dataStore[0] :"+dataStore[0]);
	    			  System.out.println("dataStore[1] :"+dataStore[1]);
	    			  outputFileList.add(inputFileList.get(i).toString()+","+dataStore[1]);
	    			  haveFunction=false;
	    		  }
	    	  }
    		  if(haveFunction) {
    			  System.out.println("inputFileList:"+inputFileList.get(i).toString());
    			  outputFileList.add(inputFileList.get(i).toString()+","+"Not_Find");
    		  }
	      }
	      for (int i = 0; i < outputFileList.size(); i++) {
	    	  int count=0;
	    	  String[] dataStore = outputFileList.get(i).toString().split(",");
	    	  String storeValue="";
	    	  String storeFinalValue="";
	    	  Map<String, String> FunctionIDMap = new HashMap<String, String>();
	    	  Map<String, String> ResponsiblePersonMap = new HashMap<String, String>();
	    	  for (int j = 0; j < outputFileList.size(); j++) {
//	    		  System.out.println("inputCsvFileList :"+inputCsvFileList.get(j).toString());
	    		  String[] dataStore1 = outputFileList.get(j).toString().split(",");
	    		  System.out.println("dataStore :"+dataStore[1]);
	    		  System.out.println("dataStore :"+dataStore[0]);
	    		  System.out.println("dataStore1 :"+dataStore1[1]);
	    		  System.out.println("dataStore1 :"+dataStore1[0]);
	    		  if(dataStore[0].equals(dataStore1[0])) {
	    			  count++;
	    			  if(storeValue=="") {	    				  
	    				  storeValue=dataStore1[1];
	    				  storeFinalValue=dataStore1[1];
	    				  System.out.println("storeFinalValue(storeValue) :"+storeFinalValue);
	    			  }
	    			  if(!storeValue.equals(dataStore1[1])) {
	    				  storeFinalValue=storeFinalValue+","+dataStore1[1];
	    				 
	    			  }
	    		  }
	    	  }
    		  if(count>1) {
    			  System.out.println("storeFinalValue :"+storeFinalValue);
    			  outputFileList.add(outputFileList.get(i).toString()+","+'"'+storeFinalValue+'"');
    		  }
    		  else {
    			  outputFileList.add(outputFileList.get(i).toString()+","+dataStore[1]);
    		  }
	      }
	  	try {
			FileWriter fileWriter = new FileWriter(outputResult);
			for (int j = 0; j < outputFileList.size(); j++) {
				fileWriter.write(outputFileList.get(j).toString()+ System.lineSeparator());
			}
			fileWriter.close();
			} catch (IOException iox) {
				iox.printStackTrace();
				System.out.println("File can not save any data in inputFileList");
				}
		
	}
}