import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class checkingJarFileName {
	

	public static void main(String[] args) throws IOException {
		String inputJarPath="C:\\Users\\jyyau\\Desktop\\new-batch-server-jar\\jar";
		String inputJobXmlPath="C:\\Users\\jyyau\\Desktop\\new-batch-server-jar\\jobXml";
		String inputText="T:\\jackyau\\fileName.csv";
		List<String> correctJarFileList = new ArrayList<String>();
		List<String> correctJobXmlFileList = new ArrayList<String>();
		try (Stream<Path> walk = Files.walk(Paths.get(inputJarPath))) {
			List<String> result = walk.map(x -> x.toString())
			.filter(f -> f.contains(".jar")).collect(Collectors.toList());
			for (int j = 0; j < result.size(); j++) {
				File jarFile = new File(result.get(j).toString());
				if(jarFile.getName().contains("-")) {
					System.out.println(result.get(j).toString());
				}
				else if(jarFile.getName().contains("_")) {
					System.out.println(result.get(j).toString());
				}
				else {

					correctJarFileList.add(jarFile.getName().replaceAll(".jar", ""));
					
				}
			}
		}
		try (Stream<Path> walk = Files.walk(Paths.get(inputJobXmlPath))) {
			List<String> result = walk.map(x -> x.toString())
			.filter(f -> f.contains(".job.xml")).collect(Collectors.toList());
			for (int j = 0; j < result.size(); j++) {
				File jobXmlFile = new File(result.get(j).toString());
				if(jobXmlFile.getName().contains("-")) {
					System.out.println(result.get(j).toString());
				}
				else if(jobXmlFile.getName().contains("_")) {
					System.out.println(result.get(j).toString());
				}
				else {
					correctJobXmlFileList.add(jobXmlFile.getName().replaceAll(".job.xml", ""));
				}
			}
		}
		correctJarFileList.removeAll(correctJobXmlFileList);
		try {
			FileWriter fileWriter = new FileWriter("T:\\jackyau\\wrongJarFileNameList.txt");
			System.out.println(System.lineSeparator());
			System.out.println(System.lineSeparator());
			System.out.println("Wrong Jar File Name List :");
			for (int i = 0; i < correctJarFileList.size(); i++) {
				fileWriter.write(correctJarFileList.get(i).toString()+System.lineSeparator());
				System.out.println(correctJarFileList.get(i).toString());
			}
			fileWriter.close();
		} catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data in outputPathList");
		}
	}
}