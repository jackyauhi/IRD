import java.io.BufferedReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import ird.taas2.utils.BeanUtils;
import ird.taas2.utils.TmpCtfpacom;


public class CountFileSize {
	public static List<String> inputFile = new ArrayList<String>();

	public static List<String> outputFile = new ArrayList<String>();
	public static List<String> outputNoContainFile = new ArrayList<String>();
	public static List<String> outputNoContainFileResult = new ArrayList<String>();
	
	public static void main(String[] args) throws Exception{
		
		String inputFilePath="T:\\jackyau\\FileSize.txt";

		try {
		BufferedReader fileReader = new BufferedReader(new FileReader(inputFilePath));
		String line=null;
	    try {
			while ((line = fileReader.readLine()) != null)
			{	
				inputFile.add(line);
			}
			fileReader.close();
		} 
	    catch (IOException e1) {
			e1.printStackTrace();
		}
		} 
   	catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
		for (int i = 0; i < inputFile.size(); i++) {
			String fileSize = inputFile.get(i).toString();
			Pattern pattern = Pattern.compile("[0-9]+");
			Matcher patternMatcher=pattern.matcher(fileSize);
			long SizeNumber = 0;
			if (patternMatcher.find()){
				SizeNumber= Long.parseLong(patternMatcher.group());
				System.out.println("SizeNumber = "+ SizeNumber);
			}
			if(fileSize.toUpperCase().contains("M")) {
				SizeNumber=SizeNumber*1024;
				System.out.println("SizeNumber(Mb) = "+ SizeNumber);
			}
			else if(fileSize.toUpperCase().contains("G")) {
				SizeNumber=SizeNumber*1024*1024;
				System.out.println("SizeNumber(Gb) = "+ SizeNumber);
			}
			else if(fileSize.toUpperCase().contains("K")) {
				SizeNumber=SizeNumber;
				System.out.println("SizeNumber(Kb) = "+ SizeNumber);
			}
			outputFile.add(String.valueOf(SizeNumber));
//			System.out.println("serverAccount = "+ serverAccount);
//			System.out.println("serverAccountPassword = "+ serverAccountPassword);
		}

		try {
			FileWriter fileWriter = new FileWriter("T:\\jackyau\\outputServerAccountFileSize.txt");
			for (int j = 0; j < outputFile.size(); j++) {
				fileWriter.write(outputFile.get(j).toString()+ System.lineSeparator());
			}
			fileWriter.write("exit");
			fileWriter.close();
			} 
		catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data in inputFileList");
		}
	}
}