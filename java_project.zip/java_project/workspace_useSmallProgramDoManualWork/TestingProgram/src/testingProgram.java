import java.io.BufferedReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import ird.taas2.utils.BeanUtils;
import ird.taas2.utils.TmpCtfpacom;


public class testingProgram {
	public static ArrayList<String> inputFileList = new ArrayList<String>();
	public static ArrayList<String> outputFileList = new ArrayList<String>();
	
	public static void main(String[] args) throws Exception{

		
		String a = "D";
		Short b = new Short("2");
		Long c = new Long("1");
		Date d;
		BigDecimal e = new BigDecimal("0.03");
		String prn;
		String date="2016-09-14 17:18:15.451000";		
		DateFormat inputFormat  = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSS");		
		d = inputFormat.parse(date);
		Timestamp ts=new Timestamp(d.getTime());
		System.out.println("Date ="+d);
		
		TmpCtfpacom src = new TmpCtfpacom();
		TmpCtfpacom dest = new TmpCtfpacom();
		
		src.setStringField(null);   
		src.setShortNum(null);      
		src.setLongNum(null);       
		src.setIssDate(null);       
		src.setBigDecimalNum(null); 

		
		src.setStringField(a);   
		src.setShortNum(b);      
		src.setLongNum(c);       
		src.setIssDate(d);       
		src.setBigDecimalNum(e); 

		
		dest.setStringField(null);   
		dest.setShortNum(null);      
		dest.setLongNum(null);       
		dest.setIssDate(null);       
		dest.setBigDecimalNum(null); 

		
		dest.setStringField(a);   
		dest.setShortNum(b);      
		dest.setLongNum(c);       
		dest.setIssDate(d);       
		dest.setBigDecimalNum(e);
		
		BeanUtils.copyProperties(dest, src,false,false);
		String h ="3E1561356166.uu.oo";
//		int i=Integer.parseInt(a);
//		System.out.println("i ="+i);
		float dnum = Float.valueOf(h);
		System.out.println("i ="+dnum);
		double dnum1 = Double.valueOf(h);
		System.out.println("dnum1 ="+dnum1);
		
//		System.out.println("src.getStringField() ="+src.getStringField());
//		System.out.println("src.getShortNum() ="+src.getShortNum());
//		System.out.println("src.getLongNum() ="+src.getLongNum());
//		System.out.println("src.getIssDate() ="+src.getIssDate());
//		System.out.println("src.getBigDecimalNum() ="+src.getBigDecimalNum());
//		System.out.println(System.lineSeparator());
//		System.out.println("dest.getStringField() ="+dest.getStringField());
//		System.out.println("dest.getShortNum() ="+dest.getShortNum());
//		System.out.println("dest.getLongNum() ="+dest.getLongNum());
//		System.out.println("dest.getIssDate() ="+dest.getIssDate());
//		System.out.println("dest.getBigDecimalNum() ="+dest.getBigDecimalNum());
		
	}
}