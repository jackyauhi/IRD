import java.io.BufferedReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import ird.taas2.utils.BeanUtils;
import ird.taas2.utils.TmpCtfpacom;


public class FindFileAbsolutePath {
	public static List<String> inputFile1 = new ArrayList<String>();
	public static List<String> inputFile2 = new ArrayList<String>();
	public static List<String> outputFile = new ArrayList<String>();
	public static List<String> outputNoContainFile = new ArrayList<String>();
	public static List<String> outputNoContainFileResult = new ArrayList<String>();
	
	public static void main(String[] args) throws Exception{
		
		String inputFilePath1="T:\\jackyau\\outputFilePath_PRD_Control.txt";
		String inputFilePath2="T:\\jackyau\\FilePathMain_Online.txt";
		try {
		BufferedReader fileReader = new BufferedReader(new FileReader(inputFilePath1));
		String line=null;
	    try {
			while ((line = fileReader.readLine()) != null)
			{	
				inputFile1.add(line);
			}
			fileReader.close();
			fileReader= new BufferedReader(new FileReader(inputFilePath2));
			while ((line = fileReader.readLine()) != null)
			{	
				inputFile2.add(line);
			}
			fileReader.close();
		} 
	    catch (IOException e1) {
			e1.printStackTrace();
		}
		} 
   	catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
		for (int i = 0; i < inputFile1.size(); i++) {
			int count=0;
			for (int j = 0; j < inputFile2.size(); j++) {
				File filePath= new File(inputFile2.get(j).toString());
				if(inputFile1.get(i).toString().contains(inputFile2.get(j).toString())) {
//					System.out.println("inputFile1.get(i).toString()"+inputFile1.get(i).toString());
//					System.out.println("inputFile2.get(j).toString()"+inputFile2.get(j).toString());
					outputFile.add(inputFile1.get(i).toString());
					if(count>0) {
						System.out.println("inputFile1.get(i).toString()"+inputFile1.get(i).toString());
					}
					count++;
				}
				else if(inputFile1.get(i).toString().contains(filePath.getName())) {
//					System.out.println("inputFile1 filePath.getName()"+filePath.getName());
					outputFile.add(inputFile1.get(i).toString());
					if(count>0) {
						System.out.println("inputFile1.get(i).toString()"+inputFile1.get(i).toString());
					}
					count++;
				}
			}
		}
		for (int i = 0; i < inputFile2.size(); i++) {
			int count=0;
			for (int j = 0; j < outputFile.size(); j++) {
				File filePath= new File(outputFile.get(j).toString());
				if(inputFile2.get(i).toString().contains(filePath.getName())) {
//					System.out.println("filePath.getName()"+filePath.getName());
					outputNoContainFile.add(inputFile2.get(i).toString());
					if(count>0) {
						System.out.println("inputFile2.get(i).toString()"+inputFile2.get(i).toString());
					}
					count++;
				}
			}
		}
		inputFile2.removeAll(outputNoContainFile);
		try {
			FileWriter fileWriter = new FileWriter("T:\\jackyau\\outputFilePath_PRD_Control_1.txt");
//			FileWriter fileWriter = new FileWriter("T:\\jackyau\\outputFilePath_PRD_Application_Online.txt");
//			FileWriter fileWriter = new FileWriter("T:\\jackyau\\outputFilePath_PRD_Application_Batch.txt");
//			FileWriter fileWriter = new FileWriter("T:\\jackyau\\outputFilePath_Application_Online.txt");
			for (int j = 0; j < outputFile.size(); j++) {
				fileWriter.write(outputFile.get(j).toString()+ System.lineSeparator());
			}
			fileWriter.close();
			} 
		catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data in inputFileList");
		}
		try {
			FileWriter fileWriter = new FileWriter("T:\\jackyau\\outputNoContainFile_PRD_Control_1.txt");
//			FileWriter fileWriter = new FileWriter("T:\\jackyau\\outputNoContainFile_PRD_Application_Online.txt");
//			FileWriter fileWriter = new FileWriter("T:\\jackyau\\outputNoContainFile_PRD_Application_Batch.txt");
//			FileWriter fileWriter = new FileWriter("T:\\jackyau\\outputNoContainFile_Application_Online.txt");
			for (int j = 0; j < inputFile2.size(); j++) {
				fileWriter.write(inputFile2.get(j).toString()+ System.lineSeparator());
			}
			fileWriter.close();
			} 
		catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data in inputFileList");
		}
	}
}