package scan.results.main;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ScanValidator {
	static String cloudDir;
	
	public static void main(String[] args) throws IOException{
		
		
		cloudDir = "D:\\ccshare\\ecochan_view\\TAAS2_UAT\\CloudMigration\\Application";
		
		
		Stream<Path> fwalk = Files.walk(Paths.get(cloudDir));
		List<String> cloudFileList = fwalk.map(x -> x.toString()).filter(f -> (f.toLowerCase().endsWith(".java") && f.toLowerCase().contains("validator")&& f.toLowerCase().contains("online"))).collect(Collectors.toList());
		fwalk.close();
		
		
		for(String f : cloudFileList){
			if(containSimpleDateFormat(f)){
				
				
			}
				//System.out.println(f);
		}
	}
	
	
	
	private static boolean containSimpleDateFormat(String file) throws IOException {
		List<String> content = Files.readAllLines(Paths.get(file));
		
//		String ckeckStr = String.join("", content).toLowerCase();
//		boolean forformat = false;
//		if(ckeckStr.contains(".format") && !Pattern.compile(".parse|.set2DigitYearStart|.get2DigitYearStart|.formatToCharacterIterator|.toPattern|.toLocalizedPattern|.applyPattern|.applyLocalizedPattern|.getDateFormatSymbols|.setDateFormatSymbols|.getInstance|.getAvailableLocales|.getTimeZone|.setTimeZone|.isLenient|.parseObject|.getTimeInstance|.getDateInstance|.getDateTimeInstance|.setCalendar|.getCalendar|.setNumberFormat|.getNumberFormat|.setLenient").matcher(ckeckStr).find()) 
//			forformat = true;
		
		content.replaceAll(s -> s+=" at line:"+ (content.indexOf(s)+1));
		content.replaceAll(String::trim);
		content.removeIf(s -> !(s.toLowerCase().contains(".parse")));	
		content.removeIf(s -> s.toLowerCase().contains("integer.parse"));
		content.removeIf(s -> s.toLowerCase().contains("short.parse"));
		content.removeIf(s -> s.toLowerCase().contains("long.parse"));
		content.removeIf(s -> s.toLowerCase().contains("double.parse"));
		content.removeIf(s -> s.toLowerCase().contains("parseint"));
		
		content.removeIf(s -> s.startsWith("//"));
		content.removeIf(s -> s.startsWith("import"));
		
		
		SimpleDateFormat st = new SimpleDateFormat();
		st.getClass().getMethods();
		
		
		for(String str : content)
			System.out.println("str : " + str);
		
		
		if(content.size()>0){
			
			System.out.println("File : " + file);
			System.out.println("==========================================");
		}
		
		
		
		return content.size()>0?true:false;
	}

}
