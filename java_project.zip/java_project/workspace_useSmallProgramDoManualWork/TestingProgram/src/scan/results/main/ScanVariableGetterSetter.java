package scan.results.main;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;

//import com.mysql.cj.jdbc.exceptions.MySQLTransactionRollbackException;

public class ScanVariableGetterSetter {
	static String dirCLD;
	public static boolean requiredPathName=false;
	public static String pathName="";
	public static List<String> methodList = new ArrayList<String>();
	public static List<String> methodListPath = new ArrayList<String>();
	public static void main(String[] args) throws IOException{
		
		dirCLD = "D:\\ccshare\\jyyau_view_ClearCase_MTN\\TAAS2_UAT\\CloudMigration\\Application";
		
		Stream<Path> fwalk = Files.walk(Paths.get(dirCLD));
		List<String> cldFList = fwalk.filter(f -> Files.isRegularFile(f))
				.map(x -> x.toString())
//				.filter(s -> s.toLowerCase().contains("validator")||s.toLowerCase().contains("worker"))
				.filter(s -> s.toLowerCase().contains(".java"))
				.filter(s -> s.toLowerCase().contains("model"))
				.filter(s -> !s.toLowerCase().contains("daoimpl"))
				.collect(Collectors.toList());
		fwalk.close();
		
		for(String file : cldFList){
			requiredPathName=false;
			List<String> content = Files.readAllLines(Paths.get(file));
			List<String> varList = checkVar(content);
			if(varList==null) continue;
			for(String varName : varList){
				checkGetterSetter(varName, content, file);
//				System.out.println(file);
//				System.out.println("============");
				
			}
			if(requiredPathName) {
				System.out.println("------------------------------------------");
				System.out.println(pathName);
				System.out.println("------------------------------------------");
				methodListPath.add(pathName);
			}
		}
		try {
		FileWriter fileWriter = new FileWriter("T:\\jackyau\\methodName.txt");
		for (int i = 0; i < methodList.size(); i++) {
			if(i==199) {
				
			}
			fileWriter.write(methodList.get(i).toString()+System.lineSeparator());
		}
		fileWriter.close();			
	} catch (IOException iox) {
		iox.printStackTrace();
		System.out.println("File can not save any data in outputPathList");
	}
		try {
		FileWriter fileWriter = new FileWriter("T:\\jackyau\\methodNamePath.txt");
		for (int i = 0; i < methodListPath.size(); i++) {
			fileWriter.write(methodListPath.get(i).toString()+System.lineSeparator());
		}
		fileWriter.close();			
	} catch (IOException iox) {
		iox.printStackTrace();
		System.out.println("File can not save any data in outputPathList");
	}
		
		
	}
	private static List<String> checkVar(List<String> content) throws IOException {
		List<String> tempContent = new ArrayList<String>();
		tempContent.addAll(content);
		tempContent.replaceAll(String::trim);
		
		tempContent.removeIf(s -> s.startsWith("//"));
		tempContent.removeIf(s->!(s.startsWith("private")||s.startsWith("public")||s.startsWith("protected")));
		tempContent.removeIf(s->s.contains("{")|s.contains("("));
		tempContent.removeIf(s->s.contains("class"));
		
		try{
			tempContent.replaceAll(s -> s.substring(0,s.lastIndexOf(";")).trim());
			tempContent.replaceAll(s -> s.substring(s.lastIndexOf(" ")).trim());
		}catch(StringIndexOutOfBoundsException e ){return null;}
//		tempContent.replaceAll(s -> s.substring(s.lastIndexOf(" ")));
//		tempContent.replaceAll(s -> s.replace(";", ""));
		
//		for(String str : tempContent){
//			System.out.println(str);
//		}
		return tempContent;
	}
	private static List<String> checkGetterSetter(String varName, List<String> content, String fName) throws IOException {
		
		List<String> tempContent = new ArrayList<String>();
		tempContent.addAll(content);
		tempContent.replaceAll(String::trim);
		tempContent.removeIf(s -> s.startsWith("//"));
		

		
		String contentStr = String.join("", tempContent);
//		contentStr = contentStr.replaceAll("(?s)(<!--.*?-->)", "").replaceAll("(?s)(<%--.*?--%>)", "").replaceAll("(?s)(/*.*?*/)", "");
		
		try{
			contentStr = contentStr.substring(contentStr.indexOf("{"));
		}catch(StringIndexOutOfBoundsException e){return null;}

		
		tempContent.clear();
		tempContent = new ArrayList<String>(Arrays.asList(contentStr.split("public")));
		tempContent.remove(0);
		tempContent.replaceAll(s -> "public"+s);
		tempContent.removeIf(s -> !(s.toLowerCase().contains(("get"+varName).toLowerCase())|s.toLowerCase().contains(("set"+varName).toLowerCase())));
//		tempContent.removeIf(s -> !s.toLowerCase().contains(varName.toLowerCase()));
		
		for(String str : tempContent){
			try{
				
				String methodName = str.substring(0, str.indexOf("(")).trim();
				methodName = methodName.substring(methodName.lastIndexOf(" ")).trim();
				if(!(methodName.startsWith("get")||methodName.startsWith("set"))) continue;
				String fullmethodName =methodName;
				methodName = methodName.substring(3).trim();
				String thisName = str.substring(str.indexOf("{")).trim();

				
				int count = StringUtils.countMatches(thisName.toLowerCase(), methodName.toLowerCase());
				if(count==0){
					requiredPathName=true;
					System.out.println("str : " + str);
					System.out.println("methodName : " + methodName);
					System.out.println("methodContent :" +  thisName);
					System.out.println("count :" +  count);	
					pathName=fName;
					System.out.println(fName);
					System.out.println("=============================================");
					File FileName= new File(fName);
					String fileName = FileName.getName();
					fileName=fileName.replaceAll(".java", ".");
					System.out.println(FileName.getName());
					System.out.println("=============================================");
					System.out.println(fileName+fullmethodName);
					methodList.add(fileName+fullmethodName);
				}
				
				
			}catch(Exception e){
				continue;
				
			}
			
		}
		
		return null;
		
	}

}
