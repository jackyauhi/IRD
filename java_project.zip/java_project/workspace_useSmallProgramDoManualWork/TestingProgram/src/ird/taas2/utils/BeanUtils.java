
package ird.taas2.utils;



import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;




public class BeanUtils {

    public static void setProperty(final Object bean, final String name, final Object value)
        throws IllegalAccessException, InvocationTargetException {

    	org.apache.commons.beanutils.BeanUtilsBean.getInstance().setProperty(bean, name, value);
    }

    public static Object cloneBean(final Object bean)
            throws IllegalAccessException, InstantiationException,
            InvocationTargetException, NoSuchMethodException {

        return org.apache.commons.beanutils.BeanUtilsBean.getInstance().cloneBean(bean);

    }
    
    public static String getProperty(final Object bean, final String name)
            throws IllegalAccessException, InvocationTargetException,
            NoSuchMethodException {

        return org.apache.commons.beanutils.BeanUtilsBean.getInstance().getProperty(bean, name);

    }
    
    public static void populate(final Object bean, final Map<String, ? extends Object> properties)
        throws IllegalAccessException, InvocationTargetException {

    	org.apache.commons.beanutils.BeanUtilsBean.getInstance().populate(bean, properties);
    }
    
	public static void copyProperties(final Object dest, final Object src,boolean prefillNumericField,boolean prefillStringField) throws Exception {
		org.apache.commons.beanutils.BeanUtils.copyProperties(dest,src);
		if(prefillNumericField||prefillStringField) {
			generateDbObjectDefaultValue(dest,prefillNumericField,prefillStringField);			
		}
	}
	public static void copyProperties(final Object dest, final Object src) throws Exception {
		copyProperties(dest,src,true,false);
	}

	public static void generateDbObjectDefaultValue(Object o,boolean prefillNumericField,boolean prefillStringField) throws Exception{
		
		if( o == null ){
			return;
		}
		
		List<Field> fieldList = new ArrayList<Field>();
		
		fieldList.addAll( Arrays.asList(o.getClass().getDeclaredFields() ));
		
		@SuppressWarnings("rawtypes")
		Class c = o.getClass();
		while( c.getSuperclass() != null ) {
			fieldList.addAll( Arrays.asList(c.getDeclaredFields() ));
			c = c.getSuperclass();
		}
		
		for( Field f : fieldList ){
			
			if (Modifier.isFinal(f.getModifiers())) {
				continue;
			}

			f.setAccessible(true);
			if(prefillNumericField) {
				if(f.get(o)==null) {
					switch( f.getType().getName() ){
						case "short":
						case "java.lang.Short":
							f.set(o, (short)0);
							break;
						case "int":
						case "java.lang.Integer":
							f.set(o, 0);
							break;
						case "long":
						case "java.lang.Long":
							f.set(o, 0L);
							break;
						case "double":
						case "java.lang.Double":
							f.set(o, 0.0);
							break;
						case "java.math.BigDecimal":
							f.set(o, new BigDecimal(0));
							break;						
						case "java.util.Date":
							f.set(o, null);
						break;
					}
				}
			}
			if(prefillStringField) {
				if(f.get(o)==null) {
					switch( f.getType().getName() ){
						case "java.lang.String":
						f.set(o, " ");
						break;
					}
				}
			}
		}
		
	}
}
