//Check in version of WAS_PRD,04-06-19,kclai:3:BhughfCkHRQfmZDwJYpEucKIpa4YlVlqHLG/VC/tqHo=
//Check in version of WAS_PRD,04-02-17,bhssham:2:7pRESRaMnuOVqB8GgfOQP8KIpa4YlVlqHLG/VC/tqHo=
//Check in version of WAS_PRD,02-02-17,jwccheung:1:POnT7H6aOGrrXMVLTmepfMKIpa4YlVlqHLG/VC/tqHo=
package ird.taas2.utils;

import java.math.BigDecimal;
import java.util.Date;



public class TmpCtfpacom {
    private String stringField;

    private Short shortNum;

    private Long longNum;

    private Date issDate;
  
    private BigDecimal bigDecimalNum;

	public String getStringField() {
		return stringField;
	}

	public void setStringField(String stringField) {
		this.stringField = stringField;
	}

	public Short getShortNum() {
		return shortNum;
	}

	public void setShortNum(Short shortNum) {
		this.shortNum = shortNum;
	}

	public Long getLongNum() {
		return longNum;
	}

	public void setLongNum(Long longNum) {
		this.longNum = longNum;
	}

	public Date getIssDate() {
		return issDate;
	}

	public void setIssDate(Date issDate) {
		this.issDate = issDate;
	}

	public BigDecimal getBigDecimalNum() {
		return bigDecimalNum;
	}

	public void setBigDecimalNum(BigDecimal bigDecimalNum) {
		this.bigDecimalNum = bigDecimalNum;
	}

	@Override
	public String toString() {
		return "TmpCtfpacom [stringField=" + stringField + ", shortNum=" + shortNum + ", longNum=" + longNum
				+ ", issDate=" + issDate + ", bigDecimalNum=" + bigDecimalNum + "]";
	}

}
