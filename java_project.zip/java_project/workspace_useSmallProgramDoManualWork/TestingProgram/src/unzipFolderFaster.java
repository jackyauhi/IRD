import java.io.BufferedOutputStream;
import java.io.BufferedReader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;



public class unzipFolderFaster {
	public static ArrayList<String> inputFileList = new ArrayList<String>();
	public static ArrayList<String> outputFileList = new ArrayList<String>();
	public static String filePath="D:\\�s�W��Ƨ� (2)\\DeploymentWorker.zip";
	public static String destination="D:\\�s�W��Ƨ� (2)\\�s�W��Ƨ�\\";
	public static File fParent=null;
	public static void main(String[] args) throws Exception{
		String hihi ="";
		unzip();
		System.out.println("unzip finished");
	}
	public static void unzip() {

	    try {
	        FileInputStream inputStream = new FileInputStream(filePath);
	        ZipInputStream zipStream = new ZipInputStream(inputStream);
	        ZipEntry zEntry = null;
	        while ((zEntry = zipStream.getNextEntry()) != null) {
//	            Log.d("Unzip", "Unzipping " + zEntry.getName() + " at "
//	                    + destination);

	            if (zEntry.isDirectory()) {
	                hanldeDirectory(zEntry.getName());
	            } else {
//	            	File f = new File(destination + "\\" + zEntry.getName());
//	            	if(!f.isFile()) {
//	            		f.mkdirs();
//	            	}
	                FileOutputStream fout = new FileOutputStream(
	                		destination + "\\" + zEntry.getName());
	                BufferedOutputStream bufout = new BufferedOutputStream(fout);
	                byte[] buffer = new byte[1024];
	                int read = 0;
	                while ((read = zipStream.read(buffer)) != -1) {
	                    bufout.write(buffer, 0, read);
	                }

	                zipStream.closeEntry();
	                bufout.close();
	                fout.close();
	            }
	        }
	        zipStream.close();

	    } catch (Exception e) {

	        e.printStackTrace();
	    }

	}

	public static void hanldeDirectory(String dir) {
	       File f = new File(destination+dir);
	        if (!f.isFile()) {
	            f.mkdirs();
	        }
	}
}