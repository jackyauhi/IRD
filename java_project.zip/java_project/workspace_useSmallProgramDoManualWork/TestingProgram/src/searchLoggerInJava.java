import java.io.BufferedReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class searchLoggerInJava {
	public static ArrayList<String> inputFileList = new ArrayList<String>();
	public static ArrayList<String> inputFileList2 = new ArrayList<String>();
	public static ArrayList<String> outputContent = new ArrayList<String>();
	public static HashMap<String, String> outputContentMap = new HashMap<String, String>();
	
	public static void main(String[] args) throws Exception{
		String searchPath = "T:\\jackyau\\output_File5\\ccshare\\jyyau_view_ClearCase_MTN\\TAAS2_UAT\\CloudMigration\\Application";
		String outputPath = "T:\\jackyau\\KeyWorkSearch.txt";
		String content=null;
		try (Stream<Path> walk = Files.walk(Paths.get(searchPath))) {
			List<String> result = walk.filter(Files::isRegularFile)
					.map(x -> x.toString()).collect(Collectors.toList());
			for (int i = 0; i < result.size(); i++) {
				if(result.get(i).toString().endsWith(".java")) {
				try {
					content = new String(Files.readAllBytes(Paths.get(result.get(i).toString())));				
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
//				Pattern patternRemove = Pattern.compile("//.*\\s*[lL]ogger\\s*([((\r\n)|(\r)|(\n))]*)[.]([((\r\n)|(\r)|(\n))]*)\\s*info");
				Pattern patternRemove = Pattern.compile("//.*\\s*[lL]ogger\\s*([((\r\n)|(\r)|(\n))]*)[.]([((\r\n)|(\r)|(\n))]*)\\s*info");
				Matcher patternRemoveMatcher=patternRemove.matcher(content);
				String storeVarible1 =null;
//				System.out.println("File Path =" +result.get(i).toString());
				while (patternRemoveMatcher.find()){
					storeVarible1= patternRemoveMatcher.group();
					content=content.replaceAll(storeVarible1, "");
					}
//				Pattern pattern = Pattern.compile("[lL]ogger\\s*([((\r\n)|(\r)|(\n))]*)[.]([((\r\n)|(\r)|(\n))]*)\\s*info");
				Pattern pattern = Pattern.compile("[lL]ogger\\s*([((\r\n)|(\r)|(\n))]*)[.]([((\r\n)|(\r)|(\n))]*)\\s*info");
				Matcher patternMatcher=pattern.matcher(content);
				System.out.println("File Path =" +result.get(i).toString());
				while (patternMatcher.find()){
					storeVarible1= patternMatcher.group();
					storeVarible1= storeVarible1.toUpperCase();
					outputContentMap.put(storeVarible1, "table");
					System.out.println("replacedFileContent =" +storeVarible1);
					}
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		for (String requiredPath : outputContentMap.keySet()) {
			
		}
		try {
			FileWriter fileWriter = new FileWriter(outputPath);
			for (String outputContent : outputContentMap.keySet()) {
				fileWriter.write(outputContent+System.lineSeparator());
			}
				fileWriter.close();
		} catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data in outputPathList");
		}
//		Pattern removePattern6 = Pattern.compile("getSqlMapClientTemplate\\s*[(]\\s*[)]\\s*((\r\n)|(\n)|(\r))*\\s*[.]\\s*([Dd])elete");
//		Matcher removePattern6Matcher=removePattern6.matcher(replacedFileContent);
//		if (removePattern6Matcher.find()){
//			replacedFileContent = removePattern6.matcher(replacedFileContent).replaceAll(Matcher.quoteReplacement("getSqlMapClientTemplate().uncheckedDelete"));
//			}
//		System.out.println("replacedFileContent =" +replacedFileContent);
	}
}