package cloud.migration;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import hk.gov.ird.ccmpplus.utils.JobScriptExecutor;

public class SyncParm {
	
	public static void main(String[] args) throws Exception{
		
		
//		List<String> files = Files.readAllLines(Paths.get("FileList"));
		List<String> files = Files.readAllLines(Paths.get("D:\\User\\CloudCheckin\\filePath_parm.txt"));
		
//		for(String file : files){
////			System.out.println(file);
//			checkinPath(file);
////			getLatestVersion(file);
//		}
		
		System.out.println("--------------------------------------------------------------------------------------");
		for(String file : files){
//			System.out.println(file);
//			checkinPath(file);
			getLatestVersion(file);
		}
		
		
		
	}
	
	public static void checkinPath(String path) throws Exception {
		try {
//			ClearCaseUtils.doCheckout(path);
			String command = "cleartool checkin " + path;
			ProcessBuilder builder = new ProcessBuilder();
			builder.redirectErrorStream(true);
			Process p = builder.command("cmd.exe", "/c", command).start();
			BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
			String line;
//			while ((line = reader.readLine()) != null) {
//				System.out.println(line);
//			}
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Fail to checkin.");
			System.exit(1);
		}
	}
	
	

	
	static void getLatestVersion(String path) {
		String command = "cleartool find "+path+" -type f -version \"version(\\main\\LATEST)\" -print";
		ProcessBuilder builder = new ProcessBuilder();
		builder.redirectErrorStream(true);
		try {
			Process p = builder.command("cmd.exe", "/c", command).start();
			BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
			String line;
			while ((line = reader.readLine()) != null) {
				try {
					System.out.println(line);
				} catch (NumberFormatException | IndexOutOfBoundsException e) {
					continue;
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Fail to load Clearcase version.");
			System.exit(1);
		}
	}

}
