package cloud.migration;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.MalformedInputException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.io.FileUtils;

public class SyncCloudCheckInToken {
	public static void main(String[] args) throws IOException{
		process();
	}
	public static void process() throws IOException{
		
		String manualDir = "D:\\helper_tmp\\AutoSyncFiles\\";
//		String manualDir = "C:\\Users\\ecochan\\Desktop\\working\\item24\\ConvertedApplication";
		String cloudDir = SyncCodeUtils.cloudDir+"\\";
//		try{
//			manualDir = args[0];
//			cloudDir = args[1] + "TAAS2_UAT/CloudMigration/Application";
//		}catch(ArrayIndexOutOfBoundsException e){
//			System.out.println("Please specify Dir...");
//		}
		
//		System.out.println("args[0]" + args[0]);
//		System.out.println("args[1]" + args[1]);
		
		Stream<Path> fwalk = Files.walk(Paths.get(manualDir));
		List<String> fileList = fwalk.filter(f -> Files.isRegularFile(f)).map(x -> x.toString()).collect(Collectors.toList());
		fwalk.close();
		
		
		System.out.println("fileList size : " + fileList.size());
		for(String file : fileList){
			try{
				System.out.println("Sync cloud token ...  " + file);
				System.out.println("SyncCloudCheckInToken.manualDir  " + manualDir);
				System.out.println("SyncCloudCheckInToken.cloudDir  " + cloudDir);
				String cloudFile = file.replace(manualDir, cloudDir);
				if(file.contains("AutoSyncFiles\\Framework\\")){
					System.out.println("!!!!!!!!!!");
					cloudFile = file.replace(manualDir, SyncCodeUtils.cloudMigrationFolder);
					System.out.println("cloudFile" + cloudFile);
				}
				System.out.println("cloudFile :" + cloudFile);
				
				String cloudToken = getCloudDevToken(cloudFile);
				List<String> cloudTokenList = getCloudDevTokenList(cloudFile);
				
				
				if(cloudToken!=null){
					System.out.println("Found cloud token :  " + cloudToken);	
					
					List<String> manualFContent = Files.readAllLines(Paths.get(file), Charset.forName("UTF-8"));
					
					manualFContent.removeIf(s -> s.contains("CLOUD_DEV"));
							
					if(file.toUpperCase().endsWith("XML"))
						manualFContent.add(1, cloudToken);
					else
//						manualFContent.add(0, cloudToken);
						manualFContent.addAll(0, cloudTokenList);
					
					FileUtils.writeLines(new File(file), "UTF-8", manualFContent);
				}
			}catch(NoSuchFileException e){
				System.out.println("File path not found : " + file);
				continue;
			}
				
			
		}
			
		
		
	}

	private static String getCloudDevToken(String file) throws IOException {	
		List<String> cloudToken = new ArrayList<String>();
		try{
			cloudToken = Files.readAllLines(Paths.get(file), Charset.forName("UTF-8"));
		}catch(FileNotFoundException e){
			System.out.println("FileNotFoundException");
			return null;
		}catch(MalformedInputException ex){
			System.out.println("MalformedInputException");
			return null;
		}
		cloudToken.removeIf(s -> !s.contains("CLOUD_DEV"));
		return cloudToken.size()>0? cloudToken.get(0):null;
		
	}
	
	private static List<String> getCloudDevTokenList(String file) throws IOException {	
		List<String> cloudToken = new ArrayList<String>();
		try{
			cloudToken = Files.readAllLines(Paths.get(file), Charset.forName("UTF-8"));
		}catch(FileNotFoundException e){
			System.out.println("FileNotFoundException");
			return null;
		}catch(MalformedInputException ex){
			System.out.println("MalformedInputException");
			return null;
		}
		cloudToken.removeIf(s -> !s.contains("CLOUD_DEV"));
		return cloudToken;
		
	}
	
	
	

}
