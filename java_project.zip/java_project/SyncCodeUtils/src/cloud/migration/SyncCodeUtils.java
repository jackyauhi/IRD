package cloud.migration;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.io.FileUtils;

public class SyncCodeUtils {
	public static String chkin = "D:\\User\\CloudCheckin\\chkin.txt";
	public static String cloudMigrationFolder = "D:\\ccshare\\jyyau_view_ClearCase_MTN\\TAAS2_UAT\\CloudMigration\\";
	public static String cloudView = "D:/ccshare/jyyau_view_ClearCase_MTN";
	public static String cloudDir = "D:/ccshare/jyyau_view_ClearCase_MTN/TAAS2_UAT/CloudMigration/Application";
	public static String prdDir = "D:/ccshare/jyyau_view_ClearCase_UAT";
	
	public static List<String> reqlist;
	
	public static String convertorFilePath = "D:/helper_tmp";
	public static String autoConvertorBat = convertorFilePath + "/1.Sync_Code_autoUse.bat";
	
	public static String cloudCheckinPath = "D:/User/CloudCheckin/";
	public static String checkinBat = cloudCheckinPath + "checkin_cloud.bat";
	public static String checkinFailCheckingBat = cloudCheckinPath + "1.checkCheckInFileFail.bat";
	
	public static String markLabelPath = "D:\\User\\marklabel_cloud\\marklabel\\";
	public static String markLabelBatName = "1.marklabel_cloud.bat";
	
	static Scanner scanner = new Scanner(System.in);
	public static void main(String[] args) throws IOException{
		
		
		// 1. Retrieve Req IDs
		try {
			System.out.println("====================================Step 1 - Retrieve Req IDs=========================================");
			ReqIdUtils.process();
			reqlist = ReqIdUtils.getReqIdList();
			
			
			for(String req : reqlist) System.out.println("Req : " + req);
			
			System.out.println("Step 1 Complete Success!");
			System.out.println("======================================================================================================");

			if(reqlist.size()==0) {
				System.out.println("No pending request ID. Bye");
				return;
			}
			
			System.out.print("Acknowledge?(Y/N) : ");
		    String ans = scanner.nextLine(); 
			if(!ans.trim().equalsIgnoreCase("Y")) return;
			
		} catch (Exception e) {
			System.out.println("Step 1 Fail!");
			System.out.println("======================================================================================================");
			e.printStackTrace();
			return;
		}
		
		// 2. Update PRD_App by Request ID
		try {
			System.out.println("================================Step 2 - Update PRD_App by Request ID=================================");
			for(String req : reqlist)
				ClearCaseUtils.updateFileByReqID(req);
			System.out.println("Step 2 Complete Success!");
			System.out.println("======================================================================================================");
			System.out.print("Acknowledge?(Y/N) : ");
		    String ans = scanner.nextLine(); 
			if(!ans.trim().equalsIgnoreCase("Y")) return;
			
		} catch (Exception e){
			System.out.println("Step 2 Fail!");
			System.out.println("======================================================================================================");
			e.printStackTrace();
			return;
			
		}
		
		

		// 3. Run Auto Converter
		try{
			System.out.println("================================Step 3 - Convert Files By Convertor===================================");
			ProcessBuilder pbuilder = new ProcessBuilder(autoConvertorBat);
			pbuilder.directory(new File(convertorFilePath));
			pbuilder.redirectErrorStream(true);
			Process process = pbuilder.start();
			Scanner s = new Scanner(process.getInputStream());
			while (s.hasNextLine()) System.out.println(s.nextLine());
			s.close();
			System.out.println("Step 3 Complete Success!");
			System.out.println("======================================================================================================");
			System.out.print("Acknowledge?(Y/N) : ");
		    String ans = scanner.nextLine(); 
			if(!ans.trim().equalsIgnoreCase("Y")) return;
		} catch (Exception e) {
			System.out.println("Step 3 Fail!");
			System.out.println("======================================================================================================");
			e.printStackTrace();
			return;
		}
		SyncCloudCheckInToken.process();
		
		// 4. Handle warning files
		try{
			System.out.println("================================Step 4 - Handle Warning Files===================================");
			BlockWarningFiles.process();
			List<String> blockFileList = BlockWarningFiles.getBlockedFileList();
			if(blockFileList!=null) for(String blockFile : blockFileList) System.out.println(blockFile);
			System.out.println("Step 4 Complete Success!");
			System.out.println("======================================================================================================");
			System.out.print("Acknowledge?(Y/N) : ");
		    String ans = scanner.nextLine(); 
			if(!ans.trim().equalsIgnoreCase("Y")) return;
		}catch(Exception e){
			System.out.println("Step 4 Fail!");
			System.out.println("======================================================================================================");
			e.printStackTrace();
			return;
		}
		
		
		
		// 5. Checkout, Replace to ClearCase
		try{
			System.out.println("================================Step 5 - Checkout, Replace to ClearCase===================================");
			FileMigration.process();
			System.out.println("Step 5 Complete Success!");
			System.out.println("======================================================================================================");
			System.out.print("Acknowledge?(Y/N) : ");
		    String ans = scanner.nextLine(); 
			if(!ans.trim().equalsIgnoreCase("Y")) return;
		}catch(Exception e){
			System.out.println("Step 5 Fail!");
			System.out.println("======================================================================================================");
			e.printStackTrace();
			return;
		}
		
		
		// 6. Cloud Check-in to ClearCase
		try{
			System.out.println("================================Step 6 - Cloud Check-in to ClearCase===================================");
			ProcessBuilder pbuilder = new ProcessBuilder(checkinBat);
			pbuilder.directory(new File(cloudCheckinPath));
			pbuilder.redirectErrorStream(true);
			Process process = pbuilder.start();
			Scanner s = new Scanner(process.getInputStream());
			OutputStream stdin = process.getOutputStream ();
			BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(stdin));
			String input;
			while (s.hasNextLine()) {
				String output = s.nextLine();
				System.out.println(output);
				if(output.startsWith("Is this version")){
					input = scanner.nextLine();
					input += "\n";
					writer.write(input);
					writer.flush();
				}
				if(output.startsWith("Previous version is checked-in by developer")){
					input = scanner.nextLine();
					input += "\n";
					writer.write(input);
					writer.flush();
				}
				
				if(output.startsWith("The result")){
					break;
				}
			}
			s.close();
			pbuilder = new ProcessBuilder(checkinFailCheckingBat);
			pbuilder.directory(new File(cloudCheckinPath));
			pbuilder.redirectErrorStream(true);
			process = pbuilder.start();
			s = new Scanner(process.getInputStream());
			stdin = process.getOutputStream ();
			writer = new BufferedWriter(new OutputStreamWriter(stdin));
			System.out.println("======================================================================================================");
			System.out.println("Files that do not checking in :");
			while (s.hasNextLine()) {
				String output = s.nextLine();
				System.out.println(output);
			}
			System.out.println("======================================================================================================");
			System.out.println("No.of Files that checking out:"+ FileMigration.checkOutCount);
			System.out.println("Autosync folder total " + Files.walk(Paths.get("D:\\helper_tmp\\AutoSyncFiles")).filter(f -> Files.isRegularFile(f)).count() + " files.");
			System.out.println("Warning folder total " + Files.walk(Paths.get("D:\\helper_tmp\\WarningFiles")).filter(f -> Files.isRegularFile(f)).count() + " files.");
			System.out.println("======================================================================================================");
			s.close();

//				BufferedReader fileReader = new BufferedReader(new FileReader(cloudCheckinPath+"checkCheckInFileFail.txt"));
//				String line=null;
//
//			    try {
//					while ((line = fileReader.readLine()) != null)
//					{	
//						System.out.println(line);
//					}
//					fileReader.close();
//				} 
//			    catch (IOException e1) {
//					e1.printStackTrace();
//				}
			
			System.out.println("Step 6 Complete Success!");
			System.out.println("======================================================================================================");
			System.out.print("Acknowledge?(Y/N) : ");
		    String ans = scanner.nextLine(); 
			if(!ans.trim().equalsIgnoreCase("Y")) return;
		} catch (Exception e) {
			System.out.println("Step 6 Fail!");
			System.out.println("======================================================================================================");
			e.printStackTrace();
			return;
		}
		
		
		// 7. Mark Label (RELEASE_XXXXXX)
		try{
			
			System.out.println("================================Step 7 - Mark Label (RELEASE_XXXXXX)===================================");
			List<String> mklabelFiles = Files.readAllLines(Paths.get(cloudCheckinPath+"mklabelResult.txt"));
			mklabelFiles.removeIf(s -> !s.startsWith("\\TAAS2_UAT\\CloudMigration"));
			FileUtils.writeLines(new File(markLabelPath+"input.txt"), mklabelFiles);
			
			ProcessBuilder pbuilder = new ProcessBuilder(markLabelPath+markLabelBatName);
			pbuilder.directory(new File(markLabelPath));
			pbuilder.redirectErrorStream(true);
			Process process = pbuilder.start();
			Scanner s = new Scanner(process.getInputStream());
			OutputStream stdin = process.getOutputStream ();
			BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(stdin));
			String input;
			while (s.hasNextLine()) {
				String output = s.nextLine();
				System.out.println(output);
				if(output.startsWith("Choose")){
					input = scanner.nextLine();
					input += "\n";
					writer.write(input);
					writer.flush();
				}
				if(output.startsWith("Enter System")){
					input = scanner.nextLine();
					input += "\n";
					writer.write(input);
					writer.flush();
				}
				if(output.startsWith("Enter the label")){
					input = scanner.nextLine();
					input += "\n";
					writer.write(input);
					writer.flush();
				}
				if(output.startsWith("Cannot create label")|output.startsWith("Invalid Input")) throw new Exception();		
			}
			s.close();
			System.out.println("Step 7 Complete Success!");
			System.out.println("======================================================================================================");
			System.out.println("Autosync folder total " + Files.walk(Paths.get(convertorFilePath+"\\AutoSyncFiles")).filter(f -> Files.isRegularFile(f)).count() + " files.");
			System.out.println("Total " + mklabelFiles.size() + " file(s) marked label.");
			System.out.print("Acknowledge?(Y/N) : ");
		    String ans = scanner.nextLine(); 
			if(!ans.trim().equalsIgnoreCase("Y")) return;
			
		} catch (Exception e) {
			System.out.println("Step 7 Fail!");
			System.out.println("======================================================================================================");
			e.printStackTrace();
		}
					
		// 8. Commit to CCMP
		try {
			PathAnalyzer.process();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		System.out.println("\n\nAutosync folder file list size : " + Files.walk(Paths.get(convertorFilePath+"\\AutoSyncFiles")).filter(f -> Files.isRegularFile(f)).count());
		System.out.println("Mark label file list size : " + PathAnalyzer.fileList.size());
		String reqExcelPath = "H:/DEV/TAAS/Cloud Migration/Phase 2/Cloud Deployment/TAAS Cloud Migration List.xlsx";
		System.out.println("Please fill in :\n" + reqExcelPath + "\n");
	
	}
	
	
	
	
}
	
	