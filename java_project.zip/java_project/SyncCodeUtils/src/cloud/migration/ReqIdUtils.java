package cloud.migration;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.io.FileUtils;
import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.jcraft.jsch.Logger;

public class ReqIdUtils {
	
	static List<String> reqIdList = new ArrayList<String>(); 
	static String reqIdFilePath = "D:/helper_tmp/req_id.txt";
	
	public static void process() throws IOException{
		ZipSecureFile.setMinInflateRatio(0);
		
		
		String reqExcelPath = "H:/DEV/TAAS/Cloud Migration/Phase 2/Cloud Deployment/TAAS Cloud Migration List.xlsx";
		System.out.println("For more details. Please refer to :\n" + reqExcelPath + "\n");
		
		Path path = Paths.get(reqExcelPath);
		FileInputStream fis = new FileInputStream(new File(path.toString()));
		Workbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = (XSSFSheet) workbook.getSheetAt(0);
		Iterator<Row> rowIt = sheet.iterator();
		while (rowIt.hasNext()) {
			Row row = rowIt.next();		
			String reqId = row.getCell(1) + "";
			String status = row.getCell(9) + "";
			
			if(reqId.length()!=7) continue;
			if(!reqId.equals("") && status.equals("")) {
				System.out.println("Request id :" + reqId.substring(0, 5));
				reqIdList.add(reqId.substring(0, 5));
			}
			
			
			
			
			
			
			
			
		}
//		reqIdList = Stream.of("57361").collect(Collectors.toList());
//		reqIdList.removeIf(s -> s.equals("57262") || s.equals("57263"));
		System.out.println("===================");
		
//		if(reqIdList.size() >4)
//			reqIdList = reqIdList.subList(0,3);
		workbook.close();
		fis.close();
//		reqIdList.clear();
//		reqIdList.add("59121");
//		reqIdList.add("59194");
//		reqIdList.add("59195");
//		reqIdList.add("57856");
//		reqIdList.add("57836");
//		reqIdList.add("57779");
//		reqIdList.add("57852");
		writeReqIdToFile();
		
	}
	
	
	public static void writeReqIdToFile() throws IOException{
		
		FileUtils.writeLines(new File(reqIdFilePath), getReqIdList());
		
	}

	public static List<String> getReqIdList() {
		return reqIdList;
	}

	public static void setReqIdList(List<String> reqIdList) {
		ReqIdUtils.reqIdList = reqIdList;
	}
	

	
	

}
