package cloud.migration;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Scanner;

import org.apache.commons.io.FileUtils;

public class NonAutoSyncCodeUtils {
	
	public static List<String> reqlist;
	

	public static String convertorFilePath = "D:/helper_tmp";
	public static String autoConvertorBat = convertorFilePath + "/1.Sync_Code.bat";
	
	public static String cloudCheckinPath = "D:/CloudCheckin/";
	public static String checkinBat = cloudCheckinPath + "checkin_cloud.bat";
	

	public static String prdDir = "R:\\taas2_view";
	public static String destDir = "D:\\helper_tmp\\output";
	
	static List<String> fileList;
	
	static Scanner scanner = new Scanner(System.in);
	public static void main(String[] args) throws IOException{
		
		// 1. Retrieve File List
		try{
			System.out.println("================================Step 1 - Convert Files By Convertor===================================");
			fileList = Files.readAllLines(Paths.get("NonAutoSyncFileList"));
			
			FileUtils.cleanDirectory(new File(destDir)); 
			for(String file : fileList) {
				// 1.1 with @@ version
//				file = file.split("@@")[0];
				String srcPath = "" + prdDir + file;
//				srcPath = srcPath.split("@@")[0];
				System.out.println(srcPath);
				File srcFile = new File(srcPath);
				
				if(srcFile.exists())
					ClearCaseUtils.doUpdate(srcPath);
				
				file = file.replace("TAAS2_DEV\\PRD_Application\\Online", "");
				file = file.replace("TAAS2_DEV\\PRD_Application\\Batch", "");
				String destPath = destDir + file.split("@@")[0];
				
				File destFile = new File(destPath);//"D:\\helper_tmp\\output" + file;
				FileUtils.copyFile(srcFile, destFile);
			}
			System.out.println("======================================================================================================");
			System.out.print("Acknowledge?(Y/N) : ");
			String ans = scanner.nextLine(); 
			if(!ans.trim().equalsIgnoreCase("Y")) return;
		} catch (Exception e) {
			System.out.println("Step 1 Fail!");
			System.out.println("======================================================================================================");
			e.printStackTrace();
			return;
		}
		
		
		// 2. Convert by converter
		try{
			System.out.println("================================Step 2 - Convert Files By Convertor===================================");
			FileUtils.cleanDirectory(new File("D:\\helper_tmp\\Result\\output"));
			ProcessBuilder pbuilder = new ProcessBuilder("D:\\helper_tmp\\1Non_Auto_Convertor.bat");
			pbuilder.directory(new File("D:\\helper_tmp"));
			pbuilder.redirectErrorStream(true);
			Process process = pbuilder.start();
			Scanner s = new Scanner(process.getInputStream());
			while (s.hasNextLine()) System.out.println(s.nextLine());
			s.close();
			System.out.println("Step 2 Complete Success!");
			System.out.println("======================================================================================================");
			System.out.print("Acknowledge?(Y/N) : ");
		    String ans = scanner.nextLine(); 
			if(!ans.trim().equalsIgnoreCase("Y")) return;
		} catch (Exception e) {
			System.out.println("Step 2 Fail!");
			System.out.println("======================================================================================================");
			e.printStackTrace();
			return;
		}
		
		
		// 3. Move to AutoSyncFiles Dir & Add token
		try{
			System.out.println("================================Step 3 - Move file from output to autoSync==================================="); 
			FileUtils.cleanDirectory(new File("D:\\helper_tmp\\AutoSyncFiles"));
			FileUtils.copyDirectory(new File("D:\\helper_tmp\\Result\\output"), new File("D:\\helper_tmp\\AutoSyncFiles"));
			SyncCloudCheckInToken.process();
			System.out.print("Acknowledge?(Y/N) : ");
		    String ans = scanner.nextLine(); 
			if(!ans.trim().equalsIgnoreCase("Y")) return;
		}catch (Exception e) {
			System.out.println("Step 3 Fail!");
			System.out.println("======================================================================================================");
			e.printStackTrace();
			return;
		}
		
		
		
		// 4. Handle warning files
		try{
			System.out.println("================================Step 4 - Handle Warning Files===================================");
			BlockWarningFiles.process();
			List<String> blockFileList = BlockWarningFiles.getBlockedFileList();
			if(blockFileList!=null) for(String blockFile : blockFileList) System.out.println(blockFile);
			System.out.println("Step 4 Complete Success!");
			System.out.println("======================================================================================================");
			System.out.print("Acknowledge?(Y/N) : ");
		    String ans = scanner.nextLine(); 
			if(!ans.trim().equalsIgnoreCase("Y")) return;
		}catch(Exception e){
			System.out.println("Step 4 Fail!");
			System.out.println("======================================================================================================");
			e.printStackTrace();
			return;
		}
		
		
		
		// 5. Checkout, Replace to ClearCase
		try{
			System.out.println("================================Step 5 - Checkout, Replace to ClearCase===================================");
			FileMigration.process();
			System.out.println("Step 5 Complete Success!");
			System.out.println("======================================================================================================");
			System.out.print("Acknowledge?(Y/N) : ");
		    String ans = scanner.nextLine(); 
			if(!ans.trim().equalsIgnoreCase("Y")) return;
		}catch(Exception e){
			System.out.println("Step 5 Fail!");
			System.out.println("======================================================================================================");
			e.printStackTrace();
			return;
		}
		
		
		// 6. Cloud Check-in to ClearCase
		try{
			System.out.println("================================Step 6 - Cloud Check-in to ClearCase===================================");
			ProcessBuilder pbuilder = new ProcessBuilder(checkinBat);
			pbuilder.directory(new File(cloudCheckinPath));
			pbuilder.redirectErrorStream(true);
			Process process = pbuilder.start();
			Scanner s = new Scanner(process.getInputStream());
			OutputStream stdin = process.getOutputStream ();
			BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(stdin));
			String input;
			while (s.hasNextLine()) {
				String output = s.nextLine();
				System.out.println(output);
				if(output.startsWith("Is this version")){
					input = scanner.nextLine();
					input += "\n";
					writer.write(input);
					writer.flush();
				}
				if(output.startsWith("Previous version is checked-in by developer")){
					input = scanner.nextLine();
					input += "\n";
					writer.write(input);
					writer.flush();
				}
				
				if(output.startsWith("The result")){
					break;
				}
			}
			s.close();
			System.out.println("Step 6 Complete Success!");
			System.out.println("======================================================================================================");
			System.out.print("Acknowledge?(Y/N) : ");
		    String ans = scanner.nextLine(); 
			if(!ans.trim().equalsIgnoreCase("Y")) return;
		} catch (Exception e) {
			System.out.println("Step 6 Fail!");
			System.out.println("======================================================================================================");
			e.printStackTrace();
			return;
		}
		
		
		// 7. Mark Label (RELEASE_XXXXXX)
		try{
			
			System.out.println("================================Step 7 - Mark Label (RELEASE_XXXXXX)===================================");
			List<String> mklabelFiles = Files.readAllLines(Paths.get("D:\\CloudCheckin\\mklabelResult.txt"));
			mklabelFiles.removeIf(s -> !s.startsWith("\\TAAS2_UAT\\CloudMigration"));
			FileUtils.writeLines(new File("D:\\marklabel_cloud\\marklabel\\input.txt"), mklabelFiles);
			
			ProcessBuilder pbuilder = new ProcessBuilder("D:/marklabel_cloud/marklabel/marklabel_cloud.bat");
			pbuilder.directory(new File("D:/marklabel_cloud/marklabel/"));
			pbuilder.redirectErrorStream(true);
			Process process = pbuilder.start();
			Scanner s = new Scanner(process.getInputStream());
			OutputStream stdin = process.getOutputStream ();
			BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(stdin));
			String input;
			while (s.hasNextLine()) {
				String output = s.nextLine();
				System.out.println(output);
				if(output.startsWith("Choose")){
					input = scanner.nextLine();
					input += "\n";
					writer.write(input);
					writer.flush();
				}
				if(output.startsWith("Enter System")){
					input = scanner.nextLine();
					input += "\n";
					writer.write(input);
					writer.flush();
				}
				if(output.startsWith("Enter the label")){
					input = scanner.nextLine();
					input += "\n";
					writer.write(input);
					writer.flush();
				}
				if(output.startsWith("Cannot create label")|output.startsWith("Invalid Input")) throw new Exception();		
			}
			s.close();
			System.out.println("Step 7 Complete Success!");
			System.out.println("Autosync folder total " + Files.walk(Paths.get("D:\\helper_tmp\\AutoSyncFiles")).filter(f -> Files.isRegularFile(f)).count() + " file(s).");
			System.out.println("Total " + mklabelFiles.size() + " file(s) marked label.");
			System.out.println("======================================================================================================");
			System.out.print("Acknowledge?(Y/N) : ");
		    String ans = scanner.nextLine(); 
			if(!ans.trim().equalsIgnoreCase("Y")) return;
			
		} catch (Exception e) {
			System.out.println("Step 7 Fail!");
			System.out.println("======================================================================================================");
			e.printStackTrace();
		}
					
		// 8. Commit to CCMP
		try {
			PathAnalyzer.process();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("File list size : " + fileList.size());
		System.out.println("Mark label file list size : " + PathAnalyzer.fileList.size());
	
	}
	
	
	
	
}
	
	