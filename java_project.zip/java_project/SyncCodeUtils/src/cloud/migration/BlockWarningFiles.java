package cloud.migration;

import java.io.File;
import java.io.IOException;
import java.nio.charset.MalformedInputException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.io.FileUtils;

public class BlockWarningFiles {
	static String cloudDir = SyncCodeUtils.cloudDir;
	static String autoSyncDir = SyncCodeUtils.convertorFilePath+"\\AutoSyncFiles\\";
	static String warningDir = SyncCodeUtils.convertorFilePath+"\\WarningFiles\\";
	static List<String> blockedFileList = new ArrayList<String>();
	public static List<String> CloudCheckinFiles = new ArrayList<String>();
	
	
	
	public static List<String> getBlockedFileList() {
		return blockedFileList;
	}

	//	public static void main(String[] args) throws IOException, ParseException{
	public static void process() throws IOException, ParseException{
		
		Stream<Path> fwalk = Files.walk(Paths.get(autoSyncDir));
		List<String> autoSyncFiles = fwalk.filter(f -> Files.isRegularFile(f)).map(x -> x.toString()).collect(Collectors.toList());
		fwalk.close();
		
		for(String file : autoSyncFiles){
			if(isWarningFile(file)){
				System.out.println("File : " + file + " - cannot sync directly");
				File srcFile = new File(file);
				autoSyncDir=autoSyncDir.replace("/", "\\");
				warningDir=warningDir.replace("/", "\\");
				File destFile = new File(file.replace(autoSyncDir, warningDir));
//				if(destFile.exists())
				FileUtils.copyFile(srcFile, destFile);
				FileUtils.forceDelete(srcFile);
				blockedFileList.add(file);
				

			}
		}		
		FileUtils.writeLines(new File("D:\\helper_tmp\\blockedByProgram.txt"), blockedFileList);

	}

	private static boolean isWarningFile(String file) throws IOException, ParseException {
		
		List<String> content = Files.readAllLines(Paths.get(file));
		
		
		// NOT application
		if(!file.contains("AutoSyncFiles\\Batch")
				&&!file.contains("AutoSyncFiles\\Batch_Common")
				&&!file.contains("AutoSyncFiles\\Common")
				&&!file.contains("AutoSyncFiles\\Framework_Related")
				&&!file.contains("AutoSyncFiles\\Report")
				&&!file.contains("AutoSyncFiles\\Web_Service")
				&&!file.contains("AutoSyncFiles\\Online")) {
			System.out.println("Warning !File path not application");
			return true;
		}
		
		// cloud token N
		String token = content.get(0);
		if(token.contains("CLOUD_DEV")){
			String[] tokenArr = token.split(":");
			if(tokenArr[1].contains("N")) {
				System.out.println("Warning !human code change found");
				return true;
			}
			
		}

		
		
		
		

		try{
			String cloudFile = file.replace(autoSyncDir, cloudDir);
			System.out.println("cloudFile : " + cloudFile);
			CloudCheckinFiles.add(cloudFile);
			List<String> cloudContent = Files.readAllLines(Paths.get(cloudFile));
			
			// any match human code change
			if(cloudContent.stream().anyMatch(s -> s.contains("TAAS-IRM172"))){
				System.out.println("Warning !human code change found");
				return true;
			}
			
			
			// Cloud version later than PRD
			List<String> cloudTokens = cloudContent.stream().filter(s -> s.contains("Check in version") && !s.contains("CLOUD_DEV")).collect(Collectors.toList());
			List<String> syncTokens  = content.stream().filter(s -> s.contains("Check in version") && !s.contains("CLOUD_DEV")).collect(Collectors.toList());
			
			String cloudToken = cloudTokens.get(0);
			String syncToken = syncTokens.get(0);
			
			String[] cldTokenArr = cloudToken.split(",");
			String[] syncTokenArr = syncToken.split(",");
			
			SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yy");
			Date cldDate = formatter.parse(cldTokenArr[1]);
			Date syncDate = formatter.parse(syncTokenArr[1]);
			
			if(cldDate.after(syncDate)){
				System.out.println("Warning !cloud version later then prd");
				return true;
			}
		}catch (NoSuchFileException e){
			System.out.println("Warning !file not found");
			return false;
		}catch (IndexOutOfBoundsException e){
			System.out.println(file + " index out of bound - new added file or config file.");
			return true;
		}catch (MalformedInputException e){
			System.out.println(file + " : MalformedInputException");
			return true;
		}
		
		
		
		
		return false;
		
	}

}
