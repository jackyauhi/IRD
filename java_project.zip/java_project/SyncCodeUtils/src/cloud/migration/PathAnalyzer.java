package cloud.migration;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class PathAnalyzer {
	
	
	static List<String> wasPath = new ArrayList<String>();
	static List<String> batPath = new ArrayList<String>();
	
	static List<String> fileList;
	
	public static void main(String[] args) throws IOException{
		process();
	}
	
	public static void process() throws IOException{
		
		
		System.out.println("\n\nStart PathAnalyzer\n------------------");
		fileList = Files.readAllLines(Paths.get(SyncCodeUtils.markLabelPath+"input.txt"));
		
		for(String file:fileList){
			if(isWasPath(file)) wasPath.add(file);
			if(isBatPath(file)) batPath.add(file);
		}
		
		System.out.println("Was Path:");
		for(String path:wasPath) System.out.println(path);
		
		System.out.println("\nBat Path:");
		for(String path:batPath) System.out.println(path);
		
		
		System.out.println("\n-----------------\nTotal : " + fileList.size() + " files. ");	
		System.out.println("wasPath : " + wasPath.size() + " files. ");
		System.out.println("batPath : : " + batPath.size() + " files. ");

	}
	
	
	static boolean isBatPath(String path){
		path = path.toLowerCase();
		String[] pathArr = path.split("\\\\");
		if(pathArr[4].contains("batch") || pathArr[4].equals("common"))
			return true;
		
		return false;
	}
	
	static boolean isWasPath(String path){
		path = path.toLowerCase();
		String[] pathArr = path.split("\\\\");
		if(pathArr[4].contains("online") || pathArr[4].equals("common"))
			return true;
		
		return false;
		
	}
	
	
	
	
	
	
	
	
	

}
