package cloud.migration;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class DiffReport {
	
	
	
	
	
	public static void main(String[]  args){
		
		
		
	}
	
	
	
	public static void genDiffReport(String path1, String path2) throws IOException{
		genDiffReport("00000", path1, path2);
	}
	
	
	public static void genDiffReport(String reqId, String path1, String path2) throws IOException{
		
		List<String> f1Content = Files.readAllLines(Paths.get(path1));
		List<String> f2Content = Files.readAllLines(Paths.get(path2));
		
		
		
	}
	
	
	
	
	

}
