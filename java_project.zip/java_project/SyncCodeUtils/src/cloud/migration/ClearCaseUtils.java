package cloud.migration;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import org.apache.commons.io.FileUtils;

import hk.gov.ird.ccmpplus.utils.JobScriptExecutor;

public class ClearCaseUtils {

	static String clearcase_path = "C:/Program Files (x86)/IBM/RationalSDLC/ClearCase/bin/cleartool.exe";
	static String cloudDir = SyncCodeUtils.cloudDir;
	static String prdDir = SyncCodeUtils.prdDir;

	public static void main(String[] args) throws Exception {

		String dir = "D:/helper_tmp/AutoSyncFiles";
		// checkoutAutoSyncFile(dir);

		String file = "D:/ccshare/ecochan_view/TAAS2_UAT/CloudMigration/Tools/ProgramChangeListGenerator/src/main/FunctionIDFindImpact.java";
		// System.out.println(doCheckout(file));
		// System.out.println(doCheckin(file, true));

		updateFileByReqID("00000");
	}

	public static void updateFileByReqID(String reqID) throws Exception {

		Class.forName("com.ibm.db2.jcc.DB2Driver");
		Connection conn = DriverManager.getConnection("jdbc:db2://10.31.90.26:50010/tadb", "dtabatd1", "batcom246");
		Statement stmt = conn.createStatement();
		String sql = "SELECT req_id, file_list, cluster FROM ccmpplus.tbl_req where req_id =" + reqID;

		ResultSet rs = stmt.executeQuery(sql);
		String file_list = "";
		while (rs.next()) {
			file_list = rs.getString("file_list");

		}

		// System.out.println("file_list : \n" + file_list.substring(0,
		// endIndex));
		String[] file_list_path = file_list.split(System.lineSeparator());
		
		HashSet<String> updatelist = new HashSet<String>();
		for (String file : file_list_path) {
			// update clearcase relevant files
			file = prdDir + file.substring(0, file.lastIndexOf("@@")).replace("\\", "/");
			System.out.println("Processing Request Id : " +reqID + " - "+ file);
			
			File fileObj = new File(file);
			String filePath = file.replace(fileObj.getName(), "");
			updatelist.add(filePath);
			
			
			
//			System.out.println("doUpdate(file) : " + );
		}
		
		for(String updatef : updatelist){
			System.out.println("Updating Dir : " + updatef);
			doUpdate(updatef);
		}

		rs.close();
		stmt.close();
		conn.close();

	}

	public static boolean undoCheckout(String filePath) throws Exception {
		List<String> result = JobScriptExecutor.execute(clearcase_path, new String[] { "unco", "-rm", filePath }).getOutMsgs();
		if ((result == null) || (result.size() == 0)) return false;
		return true;
	}


	public static boolean doUpdate(String filePath) throws Exception {
		
//		System.out.println(filePath);
		List<String> result = JobScriptExecutor.execute(clearcase_path, new String[] { "update", "-overwrite", filePath }).getOutMsgs();
		if ((result == null) || (result.size() == 0))
			return false;
//		for (String str : result)
//			System.out.println("" + str);
		return true;
	}

	public static boolean doCheckout(String filePath) throws Exception {
		System.out.println("Filepath : " + filePath);
		List<String> result = JobScriptExecutor.execute(clearcase_path, new String[] { "co", "-nc", filePath }).getOutMsgs();
		if ((result == null) || (result.size() == 0))
			return false;

		return true;
	}

	public static boolean doCheckin(String filePath, boolean isFile) throws Exception {
		BufferedWriter checkInResult = new BufferedWriter(new FileWriter("checkInResult.txt"));
		BufferedWriter mklabelResult = new BufferedWriter(new FileWriter("mklabelResult.txt"));
		boolean isCloudVer = true;
		boolean checkin = true;
		String rootPath = "D:/ccshare/ecochan_view";

		String filename = new File(filePath).getName();

		generateToken(filePath);

		List<String> result = JobScriptExecutor.execute(clearcase_path, new String[] { "ci", "-nc", filePath }).getOutMsgs();

		if (isFile) {
			System.out.println("Checkin: " + result);
			checkInResult.write("Checkin: " + result);
			checkInResult.newLine();
			String newVersion = "";
			if ((result == null) || (result.size() == 0)) {
				System.out.println("Error to checkin file: " + filePath);
				checkInResult.write("Error to checkin file: " + filePath);
				checkInResult.newLine();

				checkin = false;
			} else if (result.size() > 1) {
				int index = ((String) result.get(1)).lastIndexOf("\\main\\");
				int indexend = ((String) result.get(1)).lastIndexOf("\".");
				if ((index > -1) && (indexend > -1)) {
					newVersion = ((String) result.get(1)).substring(index, indexend);
					String rfilePath = filePath.substring(rootPath.length());
					if (!rfilePath.startsWith("\\")) {
						rfilePath = "\\" + rfilePath;
					}
					mklabelResult.write(rfilePath + "@@" + newVersion);
					mklabelResult.newLine();
				}
			} else if (result.size() == 1) {
				int index = ((String) result.get(0)).lastIndexOf("\\main\\");
				int indexend = ((String) result.get(0)).lastIndexOf("\".");
				if ((index > -1) && (indexend > -1)) {
					newVersion = ((String) result.get(0)).substring(index, indexend);
					String rfilePath = filePath.substring(rootPath.length());
					if (!rfilePath.startsWith("\\")) {
						rfilePath = "\\" + rfilePath;
					}
					mklabelResult.write(rfilePath + "@@" + newVersion);
					mklabelResult.newLine();
				}
			}
			if ((checkin) && (isCloudVer)) {
				result = JobScriptExecutor
						.execute(clearcase_path,
								new String[] { "mklabel", "-replace", "CLOUD_DEV", filePath + "@@/" + newVersion })
						.getOutMsgs();
				if ((result == null) || (result.size() == 0)) {
					System.out.println("Error in apply label to file: " + filename);
					mklabelResult.write("Error in apply label to file: " + filename);
					mklabelResult.newLine();
					System.exit(1);
				} else {
					mklabelResult.write("Apply label CLOUD_DEV to file: " + filename + " success");
					mklabelResult.newLine();
				}
			}
		} else if ((result == null) || (result.size() == 0)) {
			System.out.println("Error to checkin folder: " + filePath);
			checkInResult.write("Error to checkin folder: " + filePath);
			checkInResult.newLine();
			checkin = false;
		}

		checkInResult.flush();
		checkInResult.close();
		mklabelResult.flush();
		mklabelResult.close();
		return checkin;
	}

	private static void generateToken(String filePath) throws IOException {
		List<String> fileContent = Files.readAllLines(Paths.get(filePath));

		if (fileContent.get(0).contains("//Checkin Time"))
			fileContent.set(0, "//Checkin Time - " + new Date().getTime());
		else
			fileContent.add(0, "//Checkin Time - " + new Date().getTime());

		FileUtils.writeLines(new File(filePath), "UTF-8", fileContent);
	}

}
