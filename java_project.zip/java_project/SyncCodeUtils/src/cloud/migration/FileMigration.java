package cloud.migration;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.io.FileUtils;

public class FileMigration {
	
	static List<String> cldFileList;
	
	static String chkin = SyncCodeUtils.chkin;
	
	public static int checkOutCount = 0;
	
	public static void process() throws Exception{
		
		String syncDir = "D:/helper_tmp/AutoSyncFiles";
		String cloudDir = SyncCodeUtils.cloudDir;

		cldFileList = new ArrayList<String>();
		
		Stream<Path> fwalk = Files.walk(Paths.get(syncDir));
		List<String> fileList = fwalk.filter(f -> Files.isRegularFile(f)).map(x -> x.toString().replace("\\", "/")).collect(Collectors.toList());
		fwalk.close();
		
//		fileList.removeIf(s -> s.contains("Ptnadjav.java"));
	
		for(String srcfileStr : fileList){
			String destfileStr = srcfileStr.replace(syncDir, cloudDir);
			System.out.println("Checkout file : " + destfileStr);
			checkOutCount++;
			File srcFile = new File(srcfileStr);
			File destFile = new File(destfileStr);
//			System.out.println("SyncCodeUtils.cloudView : " + SyncCodeUtils.cloudView);
			cldFileList.add(destfileStr.replace(SyncCodeUtils.cloudView, "").replace("/", "\\"));
				
			ClearCaseUtils.doCheckout(destfileStr);
			
			FileUtils.copyFile(srcFile, destFile);
		}
		
		System.out.println("********************************************Deployment file list********************************************");
		
		for(String str : cldFileList)
			System.out.println(str);
		
		System.out.println("*************************************************************************************************************");
		FileUtils.writeLines(new File(chkin), "UTF-8", cldFileList);
	}
	
	
	public static void main(String[] args) throws Exception{
		process();
	}
	
	
	

}
