package cloud.migration;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.io.FileUtils;

import com.sshtools.j2ssh.util.Hash;



public class test {
	public static String cloudCheckinPath = "D:\\CloudCheckin\\";
	public static String checkinBat = cloudCheckinPath + "checkin_cloud.bat";
	
	public static String markLabelPath = "D:/marklabel_cloud/marklabel";
	public static String markLabelBat = markLabelPath + "/marklabel_cloud.bat";
	
	static Scanner scanner = new Scanner(System.in);
	
	public static void main(String[] args) throws IOException{

		List<String> jsps = Files.walk(Paths.get("D:\\ccshare\\ecochan_production_view\\TAAS2_DEV\\PRD_Application\\Online")).map(s -> s.toString()).filter(s -> s.toLowerCase().endsWith(".jsp")).collect(Collectors.toList());
		
		
		for(String srcPath : jsps){
			
			File srcFile = new File(srcPath);
			
			String destPath = srcPath.replace("D:\\ccshare\\ecochan_production_view\\TAAS2_DEV\\PRD_Application\\Online", "C:\\Users\\ecochan\\Desktop\\working\\jsp\\before");
			
			File destFile = new File(destPath);
			FileUtils.copyFile(srcFile, destFile);
		}
		
		
		
//		filelist.forEach(s -> );

	}

}
