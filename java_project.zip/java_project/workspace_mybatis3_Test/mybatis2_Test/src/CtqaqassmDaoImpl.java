//Check in version of WAS_PRD,16-03-18,mcli:4:vUZ48aqVbJjUwRvlxT180h0tZ0/kVFSmbgciDbVnTmU=
//Check in version of WAS_PRD,05-05-17,kclai:3:s7goLat6lgCrNbV2wz+OgR0tZ0/kVFSmbgciDbVnTmU=
//Check in version of WAS_PRD,04-02-17,bhssham:2:ciUOB1FCK2+lOVjRPuaNtR0tZ0/kVFSmbgciDbVnTmU=
//Check in version of WAS_PRD,02-02-17,jwccheung:1:jTnNiLLGzrT5helmL+HOrh0tZ0/kVFSmbgciDbVnTmU=


import com.ibatis.sqlmap.client.SqlMapClient;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;




public class CtqaqassmDaoImpl {


	public Ctqaqassm selectByPrimaryKey(Integer assYr, String prn,SqlMapClient sqlmapClient) throws SQLException {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("prn", prn);
		paramMap.put("assYr", assYr);

		return (Ctqaqassm)sqlmapClient.queryForObject("Ctqaqassm.selectByPrimaryKey", paramMap);
	}
	

	public List<Ctqaqassm> getForCtpb548(String lastCpKey,Integer chkPtFreq,SqlMapClient sqlmapClient) throws SQLException {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("lastCpKey", lastCpKey);
		paramMap.put("chkPtFreq", chkPtFreq);		
		return (List<Ctqaqassm>)sqlmapClient.queryForList("Ctqaqassm.getForCtpb548", paramMap);
	}


	public List<Ctqaqassm> getForCtpb542(String lastCpKey,Integer chkPtFreq,SqlMapClient sqlmapClient) throws SQLException {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("lastCpKey", lastCpKey);
		paramMap.put("chkPtFreq", chkPtFreq);		
		return (List<Ctqaqassm>)sqlmapClient.queryForList("Ctqaqassm.getForCtpb542", paramMap);
	}


	public int updateSpsePrn(String prn, int assYrFrom, int assYrTo, String oldSpsePrn, String newSpsePrn,SqlMapClient sqlmapClient) throws SQLException {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("prn", prn);
		paramMap.put("assYrFrom", assYrFrom);
		paramMap.put("assYrTo", assYrTo);
		paramMap.put("oldSpsePrn", oldSpsePrn);
		paramMap.put("newSpsePrn", newSpsePrn);
//		sqlmapClient.queryForObject("Ctqaqassm.updateSpsePrn", paramMap);
		return (int)sqlmapClient.queryForObject("Ctqaqassm.updateSpsePrn", paramMap);
	}
	
	public List<Ctqaqassm> selectByPrnAndAssYrWithinFromTo(String prn, Integer assYrFrom, Integer assYrTo,SqlMapClient sqlmapClient) throws SQLException {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("prn", prn);
		paramMap.put("assYrFrom", assYrFrom);
		paramMap.put("assYrTo", assYrTo);
		return (List<Ctqaqassm>)sqlmapClient.queryForList("Ctqaqassm.selectByPrnAndAssYrWithinFromTo", paramMap);
	}
	
	public List<Ctqaqassm> selectByPrnAndAssYrFromTo(String prn, Integer assYrFrom, Integer assYrTo,SqlMapClient sqlmapClient) throws SQLException {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("prn", prn);
		paramMap.put("assYrFrom", assYrFrom);
		paramMap.put("assYrTo", assYrTo);
		return (List<Ctqaqassm>)sqlmapClient.queryForList("Ctqaqassm.selectByParam", paramMap);
	}
	
	public Ctqaqassm insert(Ctqaqassm ctqaqassm,SqlMapClient sqlmapClient) throws SQLException {
		return (Ctqaqassm)sqlmapClient.insert("Ctqaqassm.insert", ctqaqassm);
	}
	
	public int deleteByPrn(String prn,SqlMapClient sqlmapClient) throws SQLException {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("prn", prn);
		return sqlmapClient.delete("Ctqaqassm.deleteByParam", paramMap);
	}


	public void delete(Ctqaqassm ctqaqassm,SqlMapClient sqlmapClient) throws SQLException {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("prn", ctqaqassm.getPrn());
		paramMap.put("assYr", ctqaqassm.getAssYr());
		sqlmapClient.delete("Ctqaqassm.deleteByParam", paramMap);
	}
	
	
		public List<Ctqaqassm> selectBySpsePrnAndAssYrFromTo(String spsePrn, Integer assYrFrom, Integer assYrTo,SqlMapClient sqlmapClient) throws SQLException {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("spsePrn", spsePrn);
		paramMap.put("assYrFrom", assYrFrom);
		paramMap.put("assYrTo", assYrTo);
		return (List<Ctqaqassm>)sqlmapClient.queryForList("Ctqaqassm.selectByParam", paramMap);
	}
	
		
	

	public int countAll(SqlMapClient sqlmapClient) throws SQLException {
		return (int) sqlmapClient.queryForObject("Ctqaqassm.countAll");
	}

}
