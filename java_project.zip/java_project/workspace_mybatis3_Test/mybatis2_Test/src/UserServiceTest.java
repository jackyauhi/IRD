import java.io.IOException;
import java.io.Reader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.ibatis.common.resources.Resources;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapClientBuilder; 

import com.ibatis.sqlmap.client.SqlMapClient;
 
public class UserServiceTest 
{
	public static void main(String[] args) {
		UserService userService= new UserService();
		
		CtqaqassmDaoImpl ctqaqassmDaoImpl = new CtqaqassmDaoImpl();
		
		List<String> List= new ArrayList<>();


		List.add("DPT.DPAPD.PTFEQ80.PT4085.T150807");
		
		List<User> userList= new ArrayList<>();
		List<Ctqaqassm> ctqaqassmList = new ArrayList<>();
		
        Reader reader = null;
		try {
			reader = Resources.getResourceAsReader("mybatis-config.xml");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        SqlMapClient sqlmapClient = SqlMapClientBuilder.buildSqlMapClient (reader);
        
        try {
//			Ctqaqassm ctqaqassm = ctqaqassmDaoImpl.selectByPrimaryKey(null, null,sqlmapClient);
//			ctqaqassmList = ctqaqassmDaoImpl.selectByPrnAndAssYrFromTo(null, null, null, sqlmapClient);
			
			Ctqaqassm ctqaqassm = ctqaqassmDaoImpl.selectByPrimaryKey(1994, " A1749237",sqlmapClient);
//			ctqaqassmList = ctqaqassmDaoImpl.selectByPrnAndAssYrFromTo(" A1749237", 1994, 1996, sqlmapClient);
			
			
//			//~~~~~~~~~~insert~~~~~~~~~~~
//			Ctqaqassm insert =new Ctqaqassm();
//			insert.setPrn(" A4900386");
//			Integer AssYr = new Integer("1996");
//			insert.setAssYr(AssYr.shortValue());
//			insert.setSpsePrn(" B8228529");			
//			ctqaqassmDaoImpl.insert(insert,sqlmapClient);
//			System.out.println("insert -->"+insert);
//			
//
//			
////			ctqaqassmDaoImpl.updateSpsePrn(" A4900386", 1996, 1996, " B8228529", " C1228529",sqlmapClient);
//			
//
//			//~~~~~~~~~~delete~~~~~~~~~~~
//			Ctqaqassm delete =new Ctqaqassm();
//			delete.setPrn(" A4900386");
//			Integer deleteassYr = new Integer("1996");
//			delete.setAssYr(deleteassYr.shortValue());
//			ctqaqassmDaoImpl.delete(delete,sqlmapClient);
//			System.out.println("delete -->"+delete);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        
//		  User user = userService.getUserById("DPT.DPAPD.PTFEQ80.PT4085.T150805",sqlmapClient);
//		  
//		  userList = userService.getList(List,"P",sqlmapClient);
////		  //~~~~~~~~~~insert~~~~~~~~~~~		  
//		User insert =new User();
//		insert.setTaasFilename("DPT.DPAPD.PTFEQ80.PT4085.T150831");
//		insert.setUploadDate("2016-09-14");
//		insert.setProcessDate("2016-09-17");
//		insert.setJobName("PTAPD1");
//		insert.setStatus("S");
//		userService.insertUser(insert,sqlmapClient);
////
////	      //~~~~~~~~~~update~~~~~~~~~~~		  
//			User update =new User();
//			update.setTaasFilename("DPT.DPAPD.PTFEQ80.PT4085.T150805");
//			update.setUploadDate("2016-09-14");
//			update.setProcessDate("2016-09-17");
//			update.setJobName("PTAPD1");
//			update.setStatus("S");
//			userService.updateUser(update,sqlmapClient);
////		
////	      //~~~~~~~~~~delete~~~~~~~~~~~	
//			userService.deleteUser("DPT.DPAPD.PTFEQ80.PT4085.T150831",sqlmapClient);
//	
//			
//			
//		  
//		  System.out.println("getUserById ==="+user);
//		  System.out.println("getList ==="+userList);
	}

}
