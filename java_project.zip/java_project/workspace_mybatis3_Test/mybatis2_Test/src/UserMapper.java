//import java.util.List;
//
//import com.ibatis.sqlmap.client.SqlMapClient;
//import java.sql.SQLException;
//
//public interface UserMapper 
//{
// 
// public void insertUser(User user,SqlMapClient sqlmapClient);
// 
// public User getUserById(String taasFilename,SqlMapClient sqlmapClient);
// 
// public List<User> getAllUsers();
// 
// public void updateUser(User user);
// 
// public void deleteUser(String taasFilename);
// 
// 
// 
//}