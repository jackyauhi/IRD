import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ibatis.sqlmap.client.SqlMapClient;

 
public class UserService 
{
 
 public void insertUser(User user,SqlMapClient sqlmapClient) {
	 try
     {
		 sqlmapClient.insert("UserMapper.insertUser", user);
     }
     catch(Exception e)
     {
         e.printStackTrace();
     }

 }
 
 public User getUserById(String taasFilename,SqlMapClient sqlmapClient) {
	 try
     {
		 User user = (User)sqlmapClient.queryForObject("UserMapper.getUserById",taasFilename);
         return user;
     }
     catch(Exception e)
     {
         e.printStackTrace();
     }
	return null;

 }
 
 public List<User> getAllUsers() {
	return null;

 }
 public List<User> getList(List<String> List,String status,SqlMapClient sqlmapClient) {
	 Map<String, Object> paramMap = new HashMap<String, Object>();
	 if (List != null){
		 paramMap.put("List",List);
	 }
	 if (status != null){
		 paramMap.put("status",status);
	 }
	 try {
		return (List<User>)sqlmapClient.queryForList("UserMapper.getList",paramMap);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return null;
 }
 public void updateUser(User user,SqlMapClient sqlmapClient) {
	 try
     {
		 sqlmapClient.update("UserMapper.updateUser", user);
     }
     catch(Exception e)
     {
         e.printStackTrace();
     }
 
 }
 
 public void deleteUser(String taasFilename,SqlMapClient sqlmapClient) {
	 try
     {
		 sqlmapClient.delete("UserMapper.deleteUser", taasFilename);
     }
     catch(Exception e)
     {
         e.printStackTrace();
     }
 
 }
 
}
