//Check in version of WAS_PRD,04-02-17,bhssham:2:ojhBpzZw6SgLWkFu0iin/hFW0iKGiHx7Aidn+sXSD84=
//Check in version of WAS_PRD,02-02-17,jwccheung:1:qRSkeMAaIWOWT6pl+4x1dBFW0iKGiHx7Aidn+sXSD84=


public class Ctqaqassm {
    private String spsePrn;

	private Short assYr;

	private String prn;

    public String getSpsePrn() {
        return spsePrn;
    }

    public void setSpsePrn(String spsePrn) {
        this.spsePrn = spsePrn;
    }


	public Short getAssYr() {
		return assYr;
	}

	public void setAssYr(Short assYr) {
		this.assYr = assYr;
	}

	public String getPrn() {
		return prn;
	}

	public void setPrn(String prn) {
		this.prn = prn;
	}
	
	 @Override
	 public String toString() {
		  return "Mybatis2_Test --> [spsePrn=" + spsePrn + ", assYr=" + assYr
		    + ", prn=" + prn + ']';
		 }
}
