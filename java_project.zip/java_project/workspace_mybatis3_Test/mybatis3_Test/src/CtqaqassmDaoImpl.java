//Check in version of WAS_PRD,16-03-18,mcli:4:vUZ48aqVbJjUwRvlxT180h0tZ0/kVFSmbgciDbVnTmU=
//Check in version of WAS_PRD,05-05-17,kclai:3:s7goLat6lgCrNbV2wz+OgR0tZ0/kVFSmbgciDbVnTmU=
//Check in version of WAS_PRD,04-02-17,bhssham:2:ciUOB1FCK2+lOVjRPuaNtR0tZ0/kVFSmbgciDbVnTmU=
//Check in version of WAS_PRD,02-02-17,jwccheung:1:jTnNiLLGzrT5helmL+HOrh0tZ0/kVFSmbgciDbVnTmU=


import org.apache.ibatis.session.SqlSession;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;




public class CtqaqassmDaoImpl {

	static SqlSession sqlSession = MyBatisUtil.getSqlSessionFactory().openSession();
	
	public Ctqaqassm selectByPrimaryKey(Integer assYr, String prn) throws SQLException {
		//SqlSession sqlSession = MyBatisUtil.getSqlSessionFactory().openSession();
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("prn", prn);
		paramMap.put("assYr", assYr);

		return (Ctqaqassm)sqlSession.selectOne("Ctqaqassm.selectByPrimaryKey", paramMap);
		
	}
	

	public List<Ctqaqassm> getForCtpb548(String lastCpKey,Integer chkPtFreq) throws SQLException {
		//SqlSession sqlSession = MyBatisUtil.getSqlSessionFactory().openSession();
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("lastCpKey", lastCpKey);
		paramMap.put("chkPtFreq", chkPtFreq);		

		return sqlSession.selectList("Ctqaqassm.getForCtpb548", paramMap);
	}


	public List<Ctqaqassm> getForCtpb542(String lastCpKey,Integer chkPtFreq) throws SQLException {
		//SqlSession sqlSession = MyBatisUtil.getSqlSessionFactory().openSession();
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("lastCpKey", lastCpKey);
		paramMap.put("chkPtFreq", chkPtFreq);		

		return sqlSession.selectList("Ctqaqassm.getForCtpb542", paramMap);
	}


	public void updateSpsePrn(String prn, int assYrFrom, int assYrTo, String oldSpsePrn, String newSpsePrn) throws SQLException {
		//SqlSession sqlSession = MyBatisUtil.getSqlSessionFactory().openSession();
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("prn", prn);
		paramMap.put("assYrFrom", assYrFrom);
		paramMap.put("assYrTo", assYrTo);
		paramMap.put("oldSpsePrn", oldSpsePrn);
		paramMap.put("newSpsePrn", newSpsePrn);

		sqlSession.selectOne("Ctqaqassm.updateSpsePrn", paramMap);
		
		sqlSession.commit();


	}
	
	public List<Ctqaqassm> selectByPrnAndAssYrWithinFromTo(String prn, Integer assYrFrom, Integer assYrTo) throws SQLException {
		//SqlSession sqlSession = MyBatisUtil.getSqlSessionFactory().openSession();
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("prn", prn);
		paramMap.put("assYrFrom", assYrFrom);
		paramMap.put("assYrTo", assYrTo);
		

		return sqlSession.selectList("Ctqaqassm.selectByPrnAndAssYrWithinFromTo", paramMap);
	}
	
	public List<Ctqaqassm> selectByPrnAndAssYrFromTo(String prn, Integer assYrFrom, Integer assYrTo) throws SQLException {
		//SqlSession sqlSession = MyBatisUtil.getSqlSessionFactory().openSession();
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("prn", prn);
		paramMap.put("assYrFrom", assYrFrom);
		paramMap.put("assYrTo", assYrTo);
		

		return sqlSession.selectList("Ctqaqassm.selectByParam", paramMap);
	}
	
	public Ctqaqassm insert(Ctqaqassm ctqaqassm) throws SQLException {
		//SqlSession sqlSession = MyBatisUtil.getSqlSessionFactory().openSession();
		ctqaqassm=sqlSession.selectOne("Ctqaqassm.insert", ctqaqassm);
		sqlSession.commit();
	
		return ctqaqassm;
	}
	
	public int deleteByPrn(String prn) throws SQLException {
		//SqlSession sqlSession = MyBatisUtil.getSqlSessionFactory().openSession();
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("prn", prn);
		int delete=sqlSession.selectOne("Ctqaqassm.deleteByParam", paramMap);
		sqlSession.commit();

		return delete;
	}


	public void delete(Ctqaqassm ctqaqassm) throws SQLException {
		//SqlSession sqlSession = MyBatisUtil.getSqlSessionFactory().openSession();
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("prn", ctqaqassm.getPrn());
		paramMap.put("assYr", ctqaqassm.getAssYr());
		sqlSession.selectOne("Ctqaqassm.deleteByParam", paramMap);
		
		sqlSession.commit();

		
	}
	
	
		public List<Ctqaqassm> selectBySpsePrnAndAssYrFromTo(String spsePrn, Integer assYrFrom, Integer assYrTo) throws SQLException {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("spsePrn", spsePrn);
		paramMap.put("assYrFrom", assYrFrom);
		paramMap.put("assYrTo", assYrTo);
		return sqlSession.selectList("Ctqaqassm.selectByParam", paramMap);
	}
	
		
	

	public int countAll() throws SQLException {
		return (int) sqlSession.selectOne("Ctqaqassm.countAll");
	}
	
}
