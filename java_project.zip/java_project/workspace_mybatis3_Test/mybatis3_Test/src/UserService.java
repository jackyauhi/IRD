import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;



import org.apache.ibatis.binding.BindingException; 
 
public class UserService
{
 
  public User insertUser(User user) {
  SqlSession sqlSession = MyBatisUtil.getSqlSessionFactory().openSession();
  try{
//  UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
//  userMapper.insertUser(user);
	  user = sqlSession.selectOne("UserMapper.getUserById",user);

  sqlSession.commit();
  }finally{
   sqlSession.close();
  
  }
return user;
 }
 
 public User getUserById(String taasFilename) {
  SqlSession sqlSession = MyBatisUtil.getSqlSessionFactory().openSession();
  try{
//  UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
//  return userMapper.getUserById(taasFilename);
	  User user = sqlSession.selectOne("UserMapper.getUserById",taasFilename);
	  return user;
  }finally{
   sqlSession.close();
  }
 }
 
 public List<User> getAllUsers() {
  SqlSession sqlSession = MyBatisUtil.getSqlSessionFactory().openSession();
  try{
//  UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
//  return userMapper.getAllUsers();
	  List<User> user =  sqlSession.selectList("UserMapper.getAllUsers",null);
	  return user;
  }finally{
   sqlSession.close();
  }
 }

 
 public void renameTableTmpYToTmpX() {
	  SqlSession sqlSession = MyBatisUtil.getSqlSessionFactory().openSession();
	  try{
	//  UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
	//  userMapper.updateUser(user);
		  sqlSession.selectOne("UserMapper.renameTableTmpYToTmpX",null);
	  sqlSession.commit();
	  }finally{
	   sqlSession.close();
	  }
	 
	 } 
 
 public void updateUser(User user) {
  SqlSession sqlSession = MyBatisUtil.getSqlSessionFactory().openSession();
  try{
//  UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
//  userMapper.updateUser(user);
	  sqlSession.selectOne("UserMapper.updateUser",user);
  sqlSession.commit();
  }finally{
   sqlSession.close();
  }
 
 }
 public void lock(String lockVar) {
	  SqlSession sqlSession = MyBatisUtil.getSqlSessionFactory().openSession();
	  try{
	//  UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
	//  userMapper.updateUser(user);
		  sqlSession.selectOne("UserMapper.lock",lockVar);
	  sqlSession.commit();
	  }finally{
	   sqlSession.close();
	  }
	 
	 }
 
 public void deleteUser(String taasFilename) {
  SqlSession sqlSession = MyBatisUtil.getSqlSessionFactory().openSession();
  try{
//  UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
//  userMapper.deleteUser(taasFilename);
	  sqlSession.selectOne("UserMapper.deleteUser",taasFilename);
  sqlSession.commit();
  }finally{
   sqlSession.close();
  }
 
 }
 public List<User> getList(Map<String, Object> paramMap){

	 SqlSession sqlSession = MyBatisUtil.getSqlSessionFactory().openSession();

	  try{
//		  UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
//		  return userMapper.getList(paramMap);
		  List<User> user = sqlSession.selectList("UserMapper.getList",paramMap);
		  System.out.println("UserService_paramMap -->"+paramMap);
		  return user;
		  }finally{
		   sqlSession.close();
		  }
	 
 }
 
 
}
