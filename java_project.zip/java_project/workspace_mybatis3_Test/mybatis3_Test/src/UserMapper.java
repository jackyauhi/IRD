import java.util.List;
import java.util.Map;

import org.apache.ibatis.binding.BindingException; 

public interface UserMapper 
{
 
 public void insertUser(User user);
 
 public User getUserById(String taasFilename);
 
 public List<User> getAllUsers();
 
 public void updateUser(User user);
 
 public void deleteUser(String taasFilename);

 public List<User> getList(List<String> List,String status);
//public void insertUser(String taasFilename, String uploadDate, String processDate, String jobName, String status);

 

public List<User> getList(Map<String, Object> paramMap);
 
}