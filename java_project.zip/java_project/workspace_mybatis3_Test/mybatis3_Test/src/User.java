import java.util.Date;
import org.apache.ibatis.binding.BindingException; 
public class User 
{
 private String taasFilename;
 private String uploadDate;
 private String processDate;
 private String jobName;
 private String status;
 
 @Override
 public String toString() {
  return "Mybatis3_Test --> [taasFilename=" + taasFilename + ", uploadDate=" + uploadDate
    + ", processDate=" + processDate + ", jobName=" + jobName
    + ", status=" + status + ']';
 }
 //setters and getters 

public String getTaasFilename() {
	return taasFilename;
}

public void setTaasFilename(String taasFilename) {
	this.taasFilename = taasFilename;
}

public String getUploadDate() {
	return uploadDate;
}

public void setUploadDate(String uploadDate) {
	this.uploadDate = uploadDate;
}

public String getProcessDate() {
	return processDate;
}

public void setProcessDate(String processDate) {
	this.processDate = processDate;
}

public String getJobName() {
	return jobName;
}

public void setJobName(String jobName) {
	this.jobName = jobName;
}

public String getStatus() {
	return status;
}

public void setStatus(String status) {
	this.status = status;
}
 
}