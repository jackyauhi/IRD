import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.mapping.BoundSql;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.session.SqlSessionFactory;



 
 
public class UserServiceTest 
{
	public static void main(String[] args) {
		UserService userService= new UserService();
		CtqaqassmDaoImpl ctqaqassmDaoImpl = new CtqaqassmDaoImpl();
		List<String> list= new ArrayList<>();
		List<Ctqaqassm> ctqaqassmList = new ArrayList<>();
		list.add("DPT.DPAPD.PTFEQ80.PT4085.T150822");
		list.add("DPT.DPAPD.PTFEQ80.PT4085.T150807");
		list.add("DPT.DPAPD.PTFEQ80.PT4085.T150805");
		List<User> userList= new ArrayList<>();
//
		User user = userService.getUserById("DPT.DPAPD.PTFEQ80.PT4085.T150805");
//		list=null;
		
		String status="P";
		status=null;
		String lockVar="TBL_IRKDESTAS";
		
		String processDate="2016-09-17";


		String jobName = "PTAPD3";
		jobName=null;
		try {
//			ctqaqassmList = ctqaqassmDaoImpl.selectByPrnAndAssYrFromTo(null, null, null);
//			Ctqaqassm ctqaqassm = ctqaqassmDaoImpl.selectByPrimaryKey(null, null);
			
			ctqaqassmList = ctqaqassmDaoImpl.selectByPrnAndAssYrFromTo(" A1749237", 1994, 1996);
			Ctqaqassm ctqaqassm = ctqaqassmDaoImpl.selectByPrimaryKey(1994, " A1749237");
			
//			System.out.println("selectByPrnAndAssYrFromTo =="+ctqaqassmList);
//			System.out.println("selectByPrimaryKey =="+ctqaqassm);
//			
//			//~~~~~~~~~~insert~~~~~~~~~~~
//			Ctqaqassm insert =new Ctqaqassm();
//			insert.setPrn(" A4900386");
//			Integer AssYr = new Integer("1996");
//			insert.setAssYr(AssYr.shortValue());
//			insert.setSpsePrn(" B8228529");			
//			ctqaqassmDaoImpl.insert(insert);
//			System.out.println("insert -->"+insert);
//			
//
//			
//			ctqaqassmDaoImpl.updateSpsePrn(" A4900386", 1996, 1996, " B8228529", " C1228529");
//
//			//~~~~~~~~~~delete~~~~~~~~~~~
//			Ctqaqassm delete =new Ctqaqassm();
//			delete.setPrn(" A4900386");
//			Integer deleteassYr = new Integer("1996");
//			delete.setAssYr(deleteassYr.shortValue());
//			ctqaqassmDaoImpl.delete(delete);
//			System.out.println("delete -->"+delete);
//
//
//			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			CtqaqassmDaoImpl.sqlSession.close();
        }
		
//		 Map<String, Object> paramMap = new HashMap<String, Object>();
//
//		 if (list != null){
//			 paramMap.put("list",list);
//		 }
//
//		 
//		 if (jobName != null){
//			 paramMap.put("jobName",jobName);
//		 }
//		 
//		 if (status != null){
//			 paramMap.put("status",status);
//		 }  
//		 
//		 System.out.println("paramMap -->"+paramMap);
//		userList = userService.getList(paramMap); 
//		
//	 	SqlSessionFactory sessionFactory = MyBatisUtil.getSqlSessionFactory();
//		Configuration configuration = sessionFactory.getConfiguration();

		
		
		
		
		//		userService.renameTableTmpYToTmpX();
//		userService.lock(lockVar);
		
		
//		//~~~~~~~~~~insert~~~~~~~~~~~
//		User insert =new User();
//		insert.setTaasFilename("DPT.DPAPD.PTFEQ80.PT4085.T150831");
//		insert.setUploadDate("2016-09-14");
//		insert.setProcessDate("2016-09-14");
//		insert.setJobName("PTAPD1");
//		insert.setStatus("P");
//		userService.insertUser(insert);
//		System.out.println("insert -->"+insert);
//		
//		//~~~~~~~~~~update~~~~~~~~~~~
//		User update =new User();
//		update.setTaasFilename("DPT.DPAPD.PTFEQ80.PT4085.T150831");
//		update.setUploadDate("2016-09-16");
//		update.setProcessDate("2016-09-15");
//		update.setJobName("PTAPD1");
//		update.setStatus("O");
//		userService.updateUser(update);
//		System.out.println("update -->"+update);
//		
//		//~~~~~~~~~~delete~~~~~~~~~~~
//		User delete =new User();
//		delete.setTaasFilename("DPT.DPAPD.PTFEQ80.PT4085.T150831");
//		userService.deleteUser("DPT.DPAPD.PTFEQ80.PT4085.T150831");
//		System.out.println("delete -->"+delete);		
//		
//		/*~~~~~~~~~see SQL statement setting~~~~~~~~~~~*/
//		
//		//for insert
//		MappedStatement ms1 = configuration.getMappedStatement("UserMapper.insertUser");   
//		BoundSql boundSql1 = ms1.getBoundSql(insert);		
//		
//		//for update
//		MappedStatement ms2 = configuration.getMappedStatement("UserMapper.updateUser");   
//		BoundSql boundSql2 = ms2.getBoundSql(update);
//		
//		//for delete
//		MappedStatement ms3 = configuration.getMappedStatement("UserMapper.deleteUser");   
//		BoundSql boundSql3 = ms3.getBoundSql(delete);
//		
//		//for select the list
//		MappedStatement ms = configuration.getMappedStatement("UserMapper.getList"); 	
//		BoundSql boundSql = ms.getBoundSql(paramMap);
//
//		System.out.println("getList =="+userList);
//		
//		String sql = boundSql.getSql();
//		String sql1 = boundSql1.getSql();
//		String sql2 = boundSql2.getSql();
//		String sql3= boundSql3.getSql();
//		
//		System.out.println("SQL getList--> "+sql);
//		System.out.println("SQL insertUser--> "+sql1);
//		System.out.println("SQL updateUser--> "+sql2);
//		System.out.println("SQL deleteUser--> "+sql3);
		
		
		  //System.out.println(insert);
		
//		  System.out.println("getUserById =="+user);

	}

}
