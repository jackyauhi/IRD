import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class autoGenerateFilePath {

	public static String openingPath = new String();
	public static String comparePath = new String();
	
	public static ArrayList<String> inputFileList = new ArrayList<String>();
	public static ArrayList<String> gitInputFileList = new ArrayList<String>();
	
	public static ArrayList<String> requiredFileList = new ArrayList<String>();
	
	public static ArrayList<String> inputFileContent = new ArrayList<String>();
	public static ArrayList<String> onlyContainsApacheImportList = new ArrayList<String>();
	public static ArrayList<String> containsBothImportList = new ArrayList<String>();
	public static boolean containsframeworkImport=false;
	public static boolean containsApacheImport=false;
	public static ArrayList<String> finalFileContent = new ArrayList<String>();
	
	
	public static ArrayList<String> errorLogList = new ArrayList<String>();
	
	public static ArrayList<Integer> onlineNonCommonFileList = new ArrayList<>();
	
	public static ArrayList<String> finalOutputResultList = new ArrayList<String>();
	public static boolean batchEqualFile=false;
	public static boolean onlineEqualFile=false;
	
	public static boolean checkingFileName=false;
	
	public static String requireDate;
	
	public static String convertorFilePath = new String();
	
	public static String batchComparePath;
	public static String onlineComparePath;
	public static String referenceFilePath;
	public static String findComparePath;
	
	public static String outputPath;
	
//	public static void transform(File source, String srcEncoding, File target, String tgtEncoding) throws IOException {
//	    BufferedReader br = null;
//	    BufferedWriter bw = null;
//	    try{
//	        br = new BufferedReader(new InputStreamReader(new FileInputStream(source),srcEncoding));
//	        bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(target), tgtEncoding));
//	        char[] buffer = new char[16384];
//	        int read;
//	        while ((read = br.read(buffer)) != -1)
//	            bw.write(buffer, 0, read);
//	    } finally {
//	        try {
//	            if (br != null)
//	                br.close();
//	        } finally {
//	            if (bw != null)
//	                bw.close();
//	        }
//	    }
//	}
	public static void main(String[] args) {
//		openingPath="D:\\ccshare\\jyyau_view_ClearCase_PRD\\TAAS2_DEV\\PRD_Application";
		openingPath=args[0];
		convertorFilePath = args[1];
		File inputFile = new File(openingPath);

		autoGenerateFilePath listFiles = new autoGenerateFilePath();
		try {
			listFiles.listAllFiles(inputFile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			FileWriter fileWriter = new FileWriter(convertorFilePath+"\\outputRequiredFileMain.csv");	
			inputFileList.removeAll(requiredFileList);
			for (int i = 0; i < inputFileList.size(); i++) {
				fileWriter.write(inputFileList.get(i).toString() + System.lineSeparator());
			}
			fileWriter.close();
		} catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data in outputPathList");
		}
		
	}
	public void listAllFiles(File folder) throws IOException {
		File[] fileNamePath = folder.listFiles();

		for (int i = 0; i < fileNamePath.length; i++) {
			String fileName = fileNamePath[i].getName();  
			// if directory call the same method again
			if (fileNamePath[i].isDirectory()) {
				if (!fileName.toLowerCase().equals("bin")) {
					listAllFiles(fileNamePath[i]);
				}			
			}	
			 else {
					try {
						DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
						String Date=dateFormat.format(fileNamePath[i].lastModified());
						inputFileList.add(fileNamePath[i].getName()+","+fileNamePath[i].getAbsolutePath()+","+Date+","+"New_Files_Folder");

					} catch (Exception e) {
						
						 e.printStackTrace();

					}

				}
			}

		}
	}