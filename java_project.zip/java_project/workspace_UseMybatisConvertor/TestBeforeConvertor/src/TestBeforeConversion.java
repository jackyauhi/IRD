import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class TestBeforeConversion { 
	
//	public static String foreachListValueTag = new String();
//	public static String sqlTag = new String();
//	public static String realSqlTag = new String();
	
    public static void main(String[] args) {
    	try {

    	String openingDataString= new String();
    	String InputFile = "D:\\ibatis2mybatis-master\\source\\JDI_BATCH_SqlMap.xml";

    	String outputFile = "T:\\jackyau\\output1.xml";
    	File afterConvertFile = new File(InputFile);
    	
    	DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
    	dbFactory.setValidating(false);
    	dbFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
    	
    	DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
    	Document doc = dBuilder.parse(afterConvertFile);

    	doc.getDocumentElement().normalize();
    	

    	NodeList docList=doc.getElementsByTagName("sqlMap");
    	
    	NodeList dynamicList = doc.getElementsByTagName("dynamic");

    	NodeList isParameterPresentList = doc.getElementsByTagName("isParameterPresent");
    	

    	String tag = new String();
    	String realTag = new String();
    	


        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
        
  	  	  DOMSource all = new DOMSource(docList.item(0));
		  StreamResult allConsoleResult = new StreamResult(new StringWriter());
		  transformer.transform(all, allConsoleResult);
		  String allXml =allConsoleResult.getWriter().toString();
		  
		  String checkCorrectFormal = null;
	    	try {
				checkCorrectFormal = new String(Files.readAllBytes(Paths.get(InputFile)));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    	openingDataString=checkCorrectFormal;

	    	checkCorrectFormal=checkCorrectFormal.replaceAll(" ", "");
	    	checkCorrectFormal=checkCorrectFormal.replaceAll("\t", "");
	    	
		  if(checkCorrectFormal.contains("<sqlMapnamespace")) {

			  String[] keepAllXmlFrontData=openingDataString.split("<sqlMap");
			  allXml=keepAllXmlFrontData[0]+allXml;			  
		for (int i = 0; i < isParameterPresentList.getLength(); i++) {
			Node nNode = isParameterPresentList.item(i);
			if (nNode.getNodeType() == Node.ELEMENT_NODE) {
    			Element eElement = (Element) nNode;
			  	DOMSource sqlTagSource = new DOMSource(nNode);
				StreamResult sqlTagConsoleResult = new StreamResult(new StringWriter());
				transformer.transform(sqlTagSource, sqlTagConsoleResult);
				tag=sqlTagConsoleResult.getWriter().toString();
				
				  String[] keepFrontData=tag.split("<isParameterPresent",2);
				  String[] keepBackData=keepFrontData[1].split(">",2);
				  
				  String[] keepCloseFrontData=keepBackData[1].split("</isParameterPresent",2);
				  String[] keepCloseBackData=keepCloseFrontData[1].split(">",2);
				  
				  realTag=keepFrontData[0]+"<!--<isParameterPresent>-->"+keepCloseFrontData[0]+"<!--</isParameterPresent>-->"+keepCloseBackData[1];


		        if(allXml.contains(tag)) {
		        	allXml=allXml.replaceAll(Pattern.quote(tag), Matcher.quoteReplacement(realTag));
		               }
			}
		}
				
        for (int temp = 0; temp < dynamicList.getLength(); temp++) {   		
    		Node nNode = dynamicList.item(temp);

    		if (nNode.getNodeType() == Node.ELEMENT_NODE) {
    			Element eElement = (Element) nNode;
    			if(eElement.getAttribute("prepend").contains("set")) {
				  DOMSource sqlTagSource = new DOMSource(nNode);
  				  StreamResult sqlTagConsoleResult = new StreamResult(new StringWriter());
  				  transformer.transform(sqlTagSource, sqlTagConsoleResult);
  				  tag=sqlTagConsoleResult.getWriter().toString();

  				  String[] keepDynamicFrontData=tag.split("<dynamic",2);
  				  String[] keepDynamicBackData=keepDynamicFrontData[1].split(">",2);
  				  
  				  String[] keepCloseDynamicFrontData=keepDynamicBackData[1].split("</dynamic",2);
  				  String[] keepCloseDynamicBackData=keepCloseDynamicFrontData[1].split(">",2);
  				  
  				  realTag=keepDynamicFrontData[0]+"<!--<dynamic prepend=\"set\">-->"+keepCloseDynamicFrontData[0]+"<!--</dynamic prepend=\"set\">-->"+keepCloseDynamicBackData[1];


  		        if(allXml.contains(tag)) {
  		        	allXml=allXml.replaceAll(Pattern.quote(tag), Matcher.quoteReplacement(realTag));
  		               }
    			}
    			else if(eElement.getAttribute("prepend").contains("where")) {
				  DOMSource sqlTagSource = new DOMSource(nNode);
  				  StreamResult sqlTagConsoleResult = new StreamResult(new StringWriter());
  				  transformer.transform(sqlTagSource, sqlTagConsoleResult);
  				  tag=sqlTagConsoleResult.getWriter().toString();

  				  String[] keepDynamicFrontData=tag.split("<dynamic",2);
  				  String[] keepDynamicBackData=keepDynamicFrontData[1].split(">",2);
  				  
  				  String[] keepCloseDynamicFrontData=keepDynamicBackData[1].split("</dynamic",2);
  				  String[] keepCloseDynamicBackData=keepCloseDynamicFrontData[1].split(">",2);
  				  
  				  realTag=keepDynamicFrontData[0]+"<!--<dynamic prepend=\"where\">-->"+keepCloseDynamicFrontData[0]+"<!--</dynamic prepend=\"where\">-->"+keepCloseDynamicBackData[1];

  				  
  		        if(allXml.contains(tag)) {
  		        	allXml=allXml.replaceAll(Pattern.quote(tag), Matcher.quoteReplacement(realTag));
  		               }
    			}
    			else if(eElement.getAttribute("prepend").contains("(")) {
				  DOMSource sqlTagSource = new DOMSource(nNode);
  				  StreamResult sqlTagConsoleResult = new StreamResult(new StringWriter());
  				  transformer.transform(sqlTagSource, sqlTagConsoleResult);
  				  tag=sqlTagConsoleResult.getWriter().toString();

  				  String[] keepDynamicFrontData=tag.split("<dynamic",2);
  				  String[] keepDynamicBackData=keepDynamicFrontData[1].split(">",2);
  				  
  				  String[] keepCloseDynamicFrontData=keepDynamicBackData[1].split("</dynamic",2);
  				  String[] keepCloseDynamicBackData=keepCloseDynamicFrontData[1].split(">",2);
  				  
  				  realTag=keepDynamicFrontData[0]+"<!--<dynamic prepend=\"(\">-->"+keepCloseDynamicFrontData[0]+"<!--</dynamic>-->"+keepCloseDynamicBackData[1];

  				  
  		        if(allXml.contains(tag)) {
  		        	allXml=allXml.replaceAll(Pattern.quote(tag), Matcher.quoteReplacement(realTag));
  		               }
    			}
    			else {
  				  DOMSource sqlTagSource = new DOMSource(nNode);
  				  StreamResult sqlTagConsoleResult = new StreamResult(new StringWriter());
  				  transformer.transform(sqlTagSource, sqlTagConsoleResult);
  				  tag=sqlTagConsoleResult.getWriter().toString();

  				  String[] keepDynamicFrontData=tag.split("<dynamic",2);
  				  String[] keepDynamicBackData=keepDynamicFrontData[1].split(">",2);
  				  
  				  String[] keepCloseDynamicFrontData=keepDynamicBackData[1].split("</dynamic",2);
  				  String[] keepCloseDynamicBackData=keepCloseDynamicFrontData[1].split(">",2);
  				  
  				  realTag=keepDynamicFrontData[0]+"<!--<dynamic>-->"+keepCloseDynamicFrontData[0]+"<!--</dynamic>-->"+keepCloseDynamicBackData[1];
  				  
    		        if(allXml.contains(tag)) {
    		        	allXml=allXml.replaceAll(Pattern.quote(tag), Matcher.quoteReplacement(realTag));
    		               }

    			}
        					}
        }
        

        System.out.println(allXml);
        
    	try {       
       		FileWriter fileWriter = new FileWriter(outputFile);
       		
       		fileWriter.write(allXml);
       		fileWriter.close();
       		System.out.println("Complete the file");
       	}catch (IOException iox) {
       		iox.printStackTrace();
       		System.out.println("File can not save any data");
       	}
    	
    	}//if allXml.contains("<sqlMap namespace")
		  else {
			  System.out.println("This file is not using ibatis-sqlMap-2 format. Please Check!");
			  
		  }  
    	  }catch (Exception e) {
	        	e.printStackTrace();
	        }
    	}
    }