import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class command {
	
	public static List<String> fileList = new ArrayList<String>();
	
    public static void main(String[] args) throws Exception {
    	String testStr ="import ird.taas2.batch.ct.dao.CtfdetnrZmCtdtwDao;\r\n" + 
    			"import ird.taas2.batch.ct.model.CtfdetnrZmCtdtw;\r\n" + 
    			"import ird.taas2.batch.ct.model.CtfdetnrZmCtdtwExample;\r\n" + 
    			"import ird.taas2.batch.ct.model.CtfdetnrZmCtdtwKey;\r\n" + 
    			"import ird.taas2.data.dao.impl.BaseDaoIbatisImpl;";
    	
//    	String testStr1 = "getSqlMapClientTemplate().delete(\\\"CtaypCleanup.truncate\\\", table);" ; 
    			


		Pattern removePattern6 = Pattern.compile("import\\s+([a-zA-Z0-9.]+)+[.]\\s+ibatis\\s+[.]\\s*sqlmap\\s*[.]\\s*client\\s*[.]\\s*SqlMapClient\\s*[;]");
		Matcher removePattern6Matcher=removePattern6.matcher(testStr);
		if (removePattern6Matcher.find()){
			testStr = removePattern6.matcher(testStr).replaceAll(Matcher.quoteReplacement("getSqlMapClientTemplate().uncheckedDelete"));
		}
		
		System.out.println(testStr);
//        String testStr = "abcdefghijkTYYtyyQ";
//        String regEx = "(\\p{Lu})";
//        Pattern pattern = Pattern.compile(regEx);
//        Matcher matcher = pattern.matcher(testStr);
//        while (matcher.find())
//            System.out.printf("Found %d, of capital letters in %s%n", 
//              matcher.groupCount(), testStr);
//        
//    	String a ="a #bb#"; 
    	String b ;
//    	Pattern p = Pattern.compile("#[a-zA-Z_0-9]#",Pattern.DOTALL | Pattern.CASE_INSENSITIVE);
//    	b = p.matcher(a).replaceAll("#{[a-zA-Z_0-9]}");
//    	System.out.println(b);
    	
//		String content = "<tagA name=\"myName\" value=# my.Va.1l : cHAR # aaa   value=# my_Val : cHAR # aaa  value=#{my_Val}/>";
//		String content = "public interface 		BrbpbrinfDao {";
//    	String content = "public  BrbpbrinfDaoImpl() {";
//    	String content = "private SqlMapClient sqlMapClient;";
    	
    	
//		Pattern p = Pattern.compile("#([^\\t\\n\\x0b\\r\\f]+)(:[^\\t\\n\\x0b\\r\\f]+)#");
//		Matcher m = p.matcher(content);
//		b = p.matcher(content).replaceAll("value=#{$1}");
//		
//		System.out.println(b);
		
//		Pattern p = Pattern.compile("#([^\\s_]+):([a-zA-Z0-9]+)#");
		
//		Pattern p = Pattern.compile("#\\s+([a-zA-Z0-9._]+)\\s+:\\s+([a-zA-Z0-9._]+)\\s+#");
//		Matcher m = p.matcher(content);
//		
//		b = p.matcher(content).replaceAll("value=#{$1}");
		
//		Pattern p = Pattern.compile("([a-zA-Z0-9_]+) ([a-zA-Z0-9_]+) ([a-zA-Z0-9_]+)Dao");
//		Pattern pattern = Pattern.compile("(?:public\\s)?(?:.*\\s)?(class|interface|enum)\\s+([$_a-zA-Z][$_a-zA-Z0-9]*)");
//		Pattern a =Pattern.compile("([a-zA-Z0-9]+)Dao");
//		Matcher aa=a.matcher(content);
//		String zone =null;
//		if (aa.find()){
//			zone = aa.group(1);
//		}
		
//		Pattern p = Pattern.compile("private\\s+SqlMapClient\\s+sqlMapClient?(?:.*\\s)?;");
//		b = p.matcher(content).replaceAll(Matcher.quoteReplacement(""));
		
//		Pattern p = Pattern.compile("public\\s+([a-zA-Z0-9]+)DaoImpl(?:.*\\s)?((?:.*\\s)?)(?:.*\\s)?");
//		Matcher pp=p.matcher(content);
//		String s =null;
//		if (pp.find()){
//			s = pp.group();
//		}
//		b = p.matcher(content).replaceAll(Matcher.quoteReplacement("111"));
//		System.out.println(s);
//		System.out.println(b);
		
		
//		if (m.find()){
//			
//			System.out.println(m.group(2));
//			
//			System.out.println(m.replaceAll("value=#{$1"+m.group(2).toUpperCase()+"}"));
//			
//			System.out.println("#{$1}");
//		}
		
		
//		if (m.find()){
//			
//			System.out.println(m.group(2));
//			
//			System.out.println(m.group(1));
//			
//			System.out.println(m.replaceAll("value=#{$1"+m.group(2).toUpperCase()+"}"));
//			
//			System.out.println(m.replaceAll("value=#{$1}"));
//		}
    	
    	
    	
//        ProcessBuilder builder = new ProcessBuilder(
//            "cmd.exe", "/c","setx path D:\\ccshare\\jyyau_view_ClearCase\\TAAS2_DEV\\EPS\\Tools;D:\\apache-ant-1.9.6-bin\\apache-ant-1.9.6\\bin;&&path");
//        builder.redirectErrorStream(true);
//        Process p = builder.start();
//        BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
//        String line;
//        while (true) {
//            line = r.readLine();
//            if (line == null) { break; }
//            System.out.println(line);
//        }
//        p.destroy();
//        ProcessBuilder builder1 = new ProcessBuilder(
//                "cmd.exe", "/c","path");
//            builder1.redirectErrorStream(true);
//            Process pp = builder1.start();
//            BufferedReader rr = new BufferedReader(new InputStreamReader(pp.getInputStream()));
//            String line1;
//            while (true) {
//                line1 = rr.readLine();
//                if (line1 == null) { break; }
//                System.out.println(line1);
//            }
//            pp.destroy();
    	
    	
    	
    	
//		String Test = "\r\n  	hi of3 \r\n <isNotNull prepend=\"and\" property=\"brn\"> 		\r\n</isNotNull><isNotNull <isNotNull prepend=\\\"and\\\" property=\\\"brn\\\"> <isNotNull ewr </isNotNull><isNotNull" ;
//		String Test2 = "\r\n prepend1	\r\nprepend2	prepend3 \\r\\n prepend1	\\r\\nprepend2	prepend3 \\r\\n prepend1	\\r\\nprepend2	prepend3<isNotNull prepend=\"and\" property=\"brn\" > \r\n<isNotNull> \r\n <isNotNull op3" ;
//		String test1;		
//		Pattern removePattern = Pattern.compile("<isNotNull(.*?)((\r\n)|(\n)|(\r))*(.*?)</isNotNull");
////		Pattern removePattern = Pattern.compile("\\s*(.*?)\\s*((\r\n)|(\n)|(\r))*\\s*(.*?)\\s*<isNotNull\\s*(.*?)\\s*((\r\n)|(\n)|(\r))*\\s*(.*?)\\s*<isNotNull");
//		Matcher removePatternMatcher=removePattern.matcher(Test);
//		List<String> allMatches = new ArrayList<String>();
//		while (removePatternMatcher.find()){
//			System.out.println("removePatternMatcher.group() ="+removePatternMatcher.group());
//			Pattern removePattern2 = Pattern.compile("<isNotNull(.*?)((\r\n)|(\n)|(\r))*(.*?)<isNotNull");
//			Matcher removePatternMatcher2=removePattern2.matcher(removePatternMatcher.group());
//			while (removePatternMatcher2.find()){
//				System.out.println("removePatternMatcher2.group() ="+removePatternMatcher2.group());
//				test1 = removePattern2.matcher(removePatternMatcher.group()).replaceAll("a");
//				System.out.println("test1 ="+test1);
//			}
//		}
////		System.out.println(Test);
    	
//		String testing="D:\\AutoConvertor\\cloud_ver_control\\dynamic_ccshare\\PRD_Application\\Online\\Report\\IR_Report\\src\\ird\\taas2\\common\\ct\\irc1930\\Irc1930ReportModel.java";
//		String[] testPath = testing.split(Pattern.quote("\\IR_Report"),2);
//		File fileToSave = new File(testPath[1]);
//		System.out.println("testPath.length = "+testPath.length);
//		System.out.println("testPath[1] = "+testPath[1]);
//		System.out.println("fileToSave.getAbsolutePath() = "+fileToSave.getPath());
//		System.out.println("fileToSave.getParent() = "+fileToSave.getParent());

    	
    	
    	
    	//    	try (Stream<Path> walk = Files.walk(Paths.get("D:\\ccshare\\jyyau_view_ClearCase_PRD\\TAAS2_DEV\\PRD_Application"))) {
//
//    		List<String> result = walk.filter(Files::isRegularFile)
//    				.map(x -> x.toString()).collect(Collectors.toList());
//
//    		result.forEach(System.out::println);
//    		fileList=result;
//    	} catch (IOException e) {
//    		e.printStackTrace();
//    	}
//		try {
//			FileWriter fileWriter = new FileWriter("T:\\jackyau\\testingResult\\result.txt");
//			for (int j = 0; j < fileList.size(); j++) {
//			fileWriter.write(fileList.get(j).toString()+System.lineSeparator());
//			}
//			fileWriter.close();
//		} catch (IOException iox) {
//			iox.printStackTrace();
//			System.out.println("File can not save any data in BeforeConversion");
//		}
    }
}