//JackyAu version
//
//import java.util.*;
//import java.util.regex.*;
//
//public class Tag {
//	
//	HashMap<String, String> attributeList = new HashMap<String, String>();
//	
//	String tag,style,styleO,htmlAttb;
//	
//	String[] attributes = {"style"};
//	ArrayList<String> list = new ArrayList<String>();
//	
//	public Tag(String tag) {	
//		this.tag = tag;
////		styleNorm = tag;
//		
//		genAttributes();
//		 
//	}
//	
//	
//
//	public String getTag() {
//		return tag;
//	}
//
//
//	public void genAttributes() {	
//		
//		for(String attri : attributes) {
//			try {
//				
//			 	Pattern regex  = Pattern.compile("(?i)(\\s*("+"\\w+-?\\w*"+")\\s*=\\s*\"\\s*(.*?)\\s*\")");
//	            Matcher regexMatcher = regex.matcher(tag);	         
//           
//	            while (regexMatcher.find()) {
//	            	list.add(regexMatcher.group(1));
//	            	}
//   	           
//	        } catch (PatternSyntaxException ex) {
//	            // Syntax error in the regular expression
//	        }
//		}
//	}
//	
//	public void printAttributes() {
//		for(String attri : list) {
//			System.out.println(attri);
//		}
//	}
//	
//	public boolean isValid() {
//		ArrayList<String> checkList = new ArrayList<String>();
//		Boolean valid = true;
//		if(tag.startsWith("<s:div")||tag.startsWith("</s:div")) {
//			valid = false;
//		}
//		if(tag.contains("?rd??")) {
//			valid = false;
//		}
//		if(tag.endsWith("//>")) {
//			valid = false;
//		}
//		for(String attri : list) {
//			if(attri.trim().startsWith("import")&&attri.contains("com.ibm.websphere.management.repository.Document")) {
//				return false;
//			}
//			if(!attri.startsWith(" ")&&!attri.startsWith("	")&&!attri.startsWith("\n")&&!attri.startsWith("\\n")) {
//				//System.out.println(attri);
//				//System.out.println("  Tag has missing space. "+tag);
//				valid = false;
//			}
//			if(attri.split("=")[0].trim().toLowerCase().equals("escape")&&!attri.trim().startsWith("escapeHtml")) {
//				//System.out.println(attri);
//				//System.out.println("  Tag has wrong escape. "+tag);
//				valid = false;
//			}
//			if(attri.trim().startsWith("required")) {
//				//System.out.println(attri);
//				//System.out.println("  Tag has wrong escape. "+tag);
//				valid = false;
//			}
//			if(hasChecked()) {
//				valid = false;
//			}
//			String temp = attri.split("=")[0].trim();
//			if(checkList.contains(temp)&&!isIf()) {
//				//System.out.println("  Tag contains dulplicate attributes: "+tag);
//				valid = false;
//			}else {
//				checkList.add(temp);
//			}
//		}
//		
//		return valid;
//	}
//	
//	public String fixedTag() {
//		String newTag = tag;
//		ArrayList<String> checkList = new ArrayList<String>();
//		if(tag.startsWith("<s:div")) {
//			newTag = newTag.replace("<s:div", "<div");
//			System.out.println("  Tag starts with <s:div");
//			CssStyleChecker.ConvertJspList.add("  Tag starts with <s:div");
//		}
//		if(tag.startsWith("</s:div")) {
//			newTag = newTag.replace("</s:div", "</div");
//			System.out.println("  Tag starts with </s:div");
//			CssStyleChecker.ConvertJspList.add("  Tag starts with </s:div");
//		}
//		if(tag.contains("?rd??")) {
//			newTag = newTag.replace("?rd??", "\"ird\"");
//			System.out.println("  Tag includes wrong encode ?rd??");
//			CssStyleChecker.ConvertJspList.add("  Tag includes wrong encode ?rd??");
//		}
//		if(tag.endsWith("//>")) {
//			newTag = newTag.replaceAll("//>$", "/>");
//			System.out.println("  Tag includes wrong ending //>");
//			CssStyleChecker.ConvertJspList.add("  Tag includes wrong ending //>");
//		}
//		for(String attri : list) {
//			if(attri.trim().startsWith("import")&&attri.contains("com.ibm.websphere.management.repository.Document")) {
//				System.out.println("  Tag contains import=\"com.ibm.websphere.management.repository.Document\"");
//				System.out.println("  Remove tag. ");
//				CssStyleChecker.ConvertJspList.add("  Tag contains import=\"com.ibm.websphere.management.repository.Document\"");
//				CssStyleChecker.ConvertJspList.add("  Remove tag. ");
//				return "";				
//			}
//			if(!attri.startsWith(" ")&&!attri.startsWith("	")&&!attri.startsWith("\n")&&!attri.startsWith("\\n")) {
//				newTag = newTag.replace(attri, " "+attri);
//				System.out.println("  Tag has missing space. "+attri);
//				CssStyleChecker.ConvertJspList.add("  Tag has missing space. "+attri);
//			}
//			if(attri.split("=")[0].trim().toLowerCase().equals("escape")&&!attri.trim().startsWith("escapeHtml")) {
//				newTag = newTag.replace(attri, " escapeHtml="+attri.split("=")[1]);
//				System.out.println("  Tag has wrong escape. "+attri);
//				CssStyleChecker.ConvertJspList.add("  Tag has wrong escape. "+attri);
//			}
//			if(attri.trim().startsWith("required")) {
//				newTag = newTag.replace(attri, " noblank="+attri.split("=")[1]);
//				System.out.println("  Tag has wrong required. "+attri);
//				CssStyleChecker.ConvertJspList.add("  Tag has wrong required. "+attri);
//			}
//			String temp = attri.split("=")[0].trim().toLowerCase();
//			if(checkList.contains(temp)) {
//				checkList.add(temp);
//			}else {
//				checkList.add(temp);
//			}
//		}
//		
//		if(Collections.frequency(checkList, "style")>1) {
//			String style = "style=\"";
//			for(String attri : list) {
//				String name = attri.split("=")[0].trim().toLowerCase();
//				String content = attri.split("=")[1].trim().replace("\"", "");
//				if(!content.endsWith(";")) {
//					content += "; ";
//				}
//				if(name.equals("style")) {
//					style = style + content;
//				}
//			}
//			style = " "+style.trim()+"\"";
//			int count = 0;
//			for(String attri : list) {
//				String temp = attri.split("=")[0].trim().toLowerCase();
//				if(temp.equals("style")) {
//					if (count==0){
//						newTag = newTag.replaceFirst(Pattern.quote(attri), style);
//						count=1;
//					}else if(count==1) {
//						newTag = newTag.replaceFirst(Pattern.quote(attri), "");
//					}
//					
//				}
//			}
//		}
//		
//		ArrayList<String> reverseList = list;
//		
//		Collections.reverse(reverseList);
//		
//		if(!isIf()) {
//			for(String attri : reverseList) {
//				String temp = attri.split("=")[0].trim().toLowerCase();
//				if(Collections.frequency(checkList, temp)>1) {
//					newTag = newTag.replaceFirst(Pattern.quote(attri), "");
//					checkList.remove(temp);
//					System.out.println("  remove dulplicate : "+attri);
//					CssStyleChecker.ConvertJspList.add("  remove dulplicate : "+attri);
//				}
//			}
//		}
//		
//		if(hasChecked()) {
//			newTag = newTag.replace(" checked", " checked=\"true\" ");
//			System.out.println("  Tag has wrong checked.");
//			CssStyleChecker.ConvertJspList.add("  Tag has wrong checked.");
////			ConvertJspLog
//		}
//		
//		newTag = newTag.replace("  ", " ");
//		newTag = newTag.replace("  ", " ");
//		System.out.println("  Original tag: "+tag);
//		System.out.println("  Fixed tag:    "+newTag);
//		System.out.println("");
//		CssStyleChecker.ConvertJspList.add("  Original tag: "+tag);
//		CssStyleChecker.ConvertJspList.add("  Fixed tag:    "+newTag);
//		CssStyleChecker.ConvertJspList.add("");
//		return newTag;
//	}
//	
//	public boolean isIf() {
//		if(tag.trim().startsWith("<s:if")||tag.trim().startsWith("<s:else")) {
//			return true;
//		}
//		
//		return false;
//	}
//	
//	public boolean hasChecked() {
//		try {
//			
//		 	Pattern regex  = Pattern.compile("(?i)\\s*(checked)\\s*");
//            Matcher regexMatcher = regex.matcher(tag);	         
//       
//            while (regexMatcher.find()) {
//            	regex  = Pattern.compile("(?i)\\s*((checked)\\s*=\\s*\"\\s*(.*?)\\s*\")");
//            	regexMatcher = regex.matcher(tag);	
//            	while (regexMatcher.find()) {
//            		return false;
//            	}
//            	return true;
//            }
//	           
//        } catch (PatternSyntaxException ex) {
//            // Syntax error in the regular expression
//        }
//		
//		return false;
//	}
//
//	public static void main(String argv[]) throws Exception {
//		Tag tag = new Tag("<input type=\"button\" value=\"View\" onclick=\"\r\n" + 
//				"				document.getElementById('tc0009_passRefNo').value='<s:property value=\"#mapItem.refNo\" escape =\"true\" />"); 
//		//Tag tag = new Tag("<td height=\"10\" style=\"width:10px;\">");
//		System.out.println(tag.getTag());
//		CssStyleChecker.ConvertJspList.add(tag.getTag());
//		tag.printAttributes();
//		System.out.println(tag.isValid());
//		CssStyleChecker.ConvertJspList.add(String.valueOf(tag.isValid()));
//		tag.fixedTag();
//	}
//	
//}
