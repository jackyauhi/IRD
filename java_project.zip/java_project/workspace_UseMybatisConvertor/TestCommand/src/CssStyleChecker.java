

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.regex.*;


public class CssStyleChecker {
	static final String filepath = "C:\\Users\\mhma\\Desktop\\online test\\Online_converted_test" ;	
	static final String newPath = "C:\\Users\\mhma\\Desktop\\online test\\Online_converted_test_output";
	
	public String reader(String path) throws Exception {
		StringBuilder sb = new StringBuilder();
		 
		try (BufferedReader br = new BufferedReader(new InputStreamReader(
			    new FileInputStream(path), "UTF-8"))) {	
            // read line by line
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line).append("\n");  	                      
            }
            br.close();

        } catch (IOException e) {
            System.err.format("IOException: %s%n", e);
        }
			
//        System.out.println(sb);    
		return sb.toString();
	}
	
	
	public void checkJSP(String readpath, String writepath) throws Exception {
		String original = reader(readpath);
		Boolean valid = true;

		for (Tag tag : printTag(original)) {
			//System.out.println(tag.getTag());
			if (!tag.isValid()) {
				valid = false;
			}
		}
		
		if(valid) {
			//System.out.println("  file pass."+readpath);
		}else {
			System.out.println("--------------------"+readpath+"----------------------");
			convertJSP(readpath,writepath);
		}


	}			
	
	public void convertJSP(String readpath, String writepath) throws Exception {
		String original = reader(readpath);
		String output = original;


		for (Tag tag : printTag(original)) {
			if (!tag.isValid()) {
				output = output.replace(tag.getTag(), tag.fixedTag()); 	
			}
		}
		
		String[] lines = output.split("\n");
		
//		BufferedWriter bufferedwriter = new BufferedWriter(new FileWriter(writepath));
//		for (String line : lines) {
//		bufferedwriter.write(line);
//		bufferedwriter.newLine();
//		}	
//		bufferedwriter.close();
		
		File fileDir = new File(writepath);
		
		Writer out = new BufferedWriter(new OutputStreamWriter
                (new FileOutputStream(fileDir), StandardCharsets.UTF_8));
		for (String line : lines) {
			out.append(line).append("\r\n");
		}
		out.flush();
        out.close();
        
		System.out.println("  JSP converted: "+writepath);
		System.out.println("");
		System.out.println("");
		System.out.println("");
	}		
	
	public ArrayList<Tag> printTag(String content) throws Exception {
			
		// System.out.println(content);
		ArrayList<Tag> tagList = new ArrayList<Tag>();
		
		try {
			content = content.replaceAll("(?s)(<!--.*?-->)", "").replaceAll("(?s)(<%--.*?--%>)", "");
            Pattern regex = Pattern.compile("(?s)(<\\w+(:\\w+)?\\s.*?[^|]>)"); 
            Matcher regexMatcher = regex.matcher(content);
            String tag="";
            Tag tagN = null;

			while (regexMatcher.find()) {
				tag = regexMatcher.group(1);
				//System.out.println("print tag :" + tag);
				tagN = new Tag(tag);
				tagList.add(tagN);            	
            }	
			regex = Pattern.compile("(?s)(</s:div\\s*>)"); 
            regexMatcher = regex.matcher(content);
            while (regexMatcher.find()) {
				tag = regexMatcher.group(1);
				//System.out.println("print tag :" + tag);
				tagN = new Tag(tag);
				tagList.add(tagN);            	
            }
            regex = Pattern.compile("(?s)(<%@page\\s*import\\s*=\\s*\"\\s*com.ibm.websphere.management.repository.Document\\s*\"\\s*%>)"); 
            regexMatcher = regex.matcher(content);
            while (regexMatcher.find()) {
				tag = regexMatcher.group(1);
				//System.out.println("print tag :" + tag);
				tagN = new Tag(tag);
				tagList.add(tagN);            	
            }
             
        } catch (PatternSyntaxException ex) {
        	System.out.println("printTag not working");
        }
		return tagList;
		
	}
	
	public ArrayList<File> listf(String directoryName, ArrayList<File> files) {
	    File directory = new File(directoryName);

	    // Get all files from a directory.
	    File[] fList = directory.listFiles();
	    if(fList != null)
	        for (File file : fList) {      
	            if (file.isFile()) {
	                files.add(file);
	            } else if (file.isDirectory()) {
	                listf(file.getAbsolutePath(), files);
	            }
	        }
	    
	    return files;
	    }
	
	public long deleteFolder(String dir) {

        File f = new File(dir);
        String listFiles[] = f.list();
        long totalSize = 0;
        for (String file : listFiles) {

            File folder = new File(dir + "/" + file);
            if (folder.isDirectory()) {
                totalSize += deleteFolder(folder.getAbsolutePath());
            } else {
                totalSize += folder.length();
            }
        }

        if (totalSize ==0) {
            f.delete();
        }

        return totalSize;
	}
	
	
	
	public static void main(String argv[]) throws Exception {		
		CssStyleChecker ccss = new CssStyleChecker();
		
		File folder = new File(filepath);
		File newpath = new File(newPath);
		
		folder = new File(argv[0]);
		newpath = new File(argv[1]);
		
		//folder = new File(".\\");

		ArrayList<File> filelist = new ArrayList<File>();
		ccss.listf(folder.toString(), filelist);
		
//		System.out.println(filepath);
//		System.out.println(newPath);
		
		for(File file:filelist){
			if(file.toString().toLowerCase().endsWith(".jsp")) {
				File filea = new File(file.getParent().toString()
						.replace(folder.toString(), newpath.toString()));
				
				boolean dirCreated = filea.mkdirs();
				String newFilePath = filea.toString()+File.separator+file.getName();
				
				
				ccss.checkJSP(file.toString(),newFilePath);
			}			
		}
		ccss.deleteFolder(newpath.toString());
		//ccss.newJSP(folder.toString(),newpath.toString());
		
    }  
}
