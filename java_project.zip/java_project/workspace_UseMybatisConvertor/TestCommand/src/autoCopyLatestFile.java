import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.io.BufferedReader;



public class autoCopyLatestFile {
	public static List<String> latestFileList = new ArrayList<String>();
	public static String outputFolder = new String();
	public static String convertorFilePath = new String();
	public static String openingPath = new String();
	public static ArrayList<String> outputResultList = new ArrayList<String>();
	
	public static ArrayList<String> newFileFolderList = new ArrayList<String>();
	public static ArrayList<String> updateFileFolderList = new ArrayList<String>();


	public static String startFolder = "";
	public static void main(String[] args) throws IOException {
		openingPath= args[0];
		outputFolder = args[1];
//		convertorFilePath = args[2];
		String[] inputSplit = openingPath.split(Pattern.quote("\\"));
		startFolder=inputSplit[inputSplit.length-1];
        Calendar cal = Calendar.getInstance();
        
        try (Stream<Path> walk = Files.walk(Paths.get(openingPath))) {
			List<String> result = walk.map(x -> x.toString())
			.filter(f -> f.contains(".java")).collect(Collectors.toList());
//			result.forEach(System.out::println);
			latestFileList=result;
        }
		for (int i = 0; i < latestFileList.size(); i++) {
   			String copyFile=latestFileList.get(i).toString();
   			String[] prdApplicationFolderPath = copyFile.split(Pattern.quote(startFolder),2);
//   			String[] dataStore = copyFile.split(",");
//   			String[] prdApplicationFolderPath = dataStore[0].split(Pattern.quote(startFolder),2);
   			String requiredPath=outputFolder+"\\"+startFolder+prdApplicationFolderPath[1];
			File fileToSave = new File(requiredPath);
			File fileToSaveParent=new File(fileToSave.getParent());
			if (!fileToSaveParent.exists()) {
				fileToSaveParent.mkdirs();
			}
//			File sourceFile = new File(dataStore[0]);
			File sourceFile = new File(copyFile);
			File targetFile = new File(requiredPath);
			File fileParent;
			if (fileToSave.exists()) {
				fileToSave.delete();
			}
			else {
				String parent= fileToSave.getParent();
				fileParent= new File(parent);
				fileParent.mkdirs();
			}

				try {
					transform(sourceFile,"UTF-8",targetFile,"UTF-8");
					outputResultList.add(targetFile.getName()+","+targetFile.getAbsolutePath()+","+""+","+"New_Files_Folder");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			

		}
		try {
			FileWriter fileWriter = new FileWriter(outputFolder+"\\outputRequiredFileMain.csv");
			for (int i = 0; i < outputResultList.size(); i++) {
				fileWriter.write(outputResultList.get(i).toString() + System.lineSeparator());
			}
			fileWriter.close();
		} catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data in outputPathList");
		}
//		try {
//			DateFormat df = new SimpleDateFormat("dd-MM-yyyy HH_mm_ss");
//			String outputTxtFile=outputFolder+"\\"+df.format(cal.getTime())+"_Update_log.txt";
//			FileWriter fileWriter = new FileWriter(outputTxtFile);
//			fileWriter.write("Update date time : "+df.format(cal.getTime()));
//			fileWriter.write(System.lineSeparator());
//			fileWriter.write(System.lineSeparator());
//			fileWriter.write("New files :");
//			fileWriter.write(System.lineSeparator());
//			for (int i = 0; i < latestFileList.size(); i++) {
//	   			String[] dataStore = latestFileList.get(i).toString().split(",");
//	   			if(dataStore[1].equals("New_Files_Folder")) {
//	   				fileWriter.write(dataStore[0] + System.lineSeparator());
//	   				newFileFolderList.add(dataStore[0]);
//	   			}
//	   			else {
//	   				updateFileFolderList.add(dataStore[0]);
//	   			}
//			}
//			fileWriter.write(System.lineSeparator());
//			fileWriter.write("Total : "+newFileFolderList.size());
//			
//			fileWriter.write(System.lineSeparator());
//			fileWriter.write(System.lineSeparator());
//			fileWriter.write(System.lineSeparator());
//			fileWriter.write(System.lineSeparator());
//			
//			fileWriter.write("Update files :");
//			fileWriter.write(System.lineSeparator());
//			for (int i = 0; i < updateFileFolderList.size(); i++) {
//				fileWriter.write(updateFileFolderList.get(i).toString() + System.lineSeparator());
//			}
//			fileWriter.write(System.lineSeparator());
//			fileWriter.write("Total : "+updateFileFolderList.size());
//			
//			fileWriter.close();
//		} catch (IOException iox) {
//			iox.printStackTrace();
//			System.out.println("File can not save any data in Update_log.txt");
//		}
		
	}
	public static void transform(File source, String srcEncoding, File target, String tgtEncoding) throws IOException {
	    BufferedReader br = null;
	    BufferedWriter bw = null;
	    try{
	        br = new BufferedReader(new InputStreamReader(new FileInputStream(source),srcEncoding));
	        bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(target), tgtEncoding));
	        char[] buffer = new char[16384];
	        int read;
	        while ((read = br.read(buffer)) != -1)
	            bw.write(buffer, 0, read);
	    } finally {
	        try {
	            if (br != null)
	                br.close();
	        } finally {
	            if (bw != null)
	                bw.close();
	        }
	    }
	}
}
//}