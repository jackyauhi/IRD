import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class comparePrdApplicationFile {

	public static String openingPath = new String();
	public static ArrayList<String> outputPathList = new ArrayList<String>();
	public static ArrayList<String> versionList = new ArrayList<String>();

	public static void main(String[] args) {
		String inputCsvFile ="T:\\jackyau\\outputRequiredFileMain111.csv";
		ArrayList<String> csvFilePathList = new ArrayList<String>();
		ArrayList<String> csvFileNameList = new ArrayList<String>();
		ArrayList<String> outputNewFileDeployList = new ArrayList<String>();
		ArrayList<String> outputCompareDifferentList = new ArrayList<String>();
		ArrayList<String> outputCommonFileList = new ArrayList<String>();
		
		String inputPathGit ="D:\\1.ProgramCleanCase\\Mybatis3_Application\\Application";
		String inputPathNewVersion ="D:\\ccshare\\jyyau_view_ClearCase_PRD\\TAAS2_DEV\\PRD_Application";
		String gitFile =new String();
		String newVersionFile =new String();
int count =0;
int countFileOpenProblem =0;
int countOpenNewVersionFileProblem =0;
int processCount =0;
int totalCount =0;
int fileCanNotWrite=0;
int fileCanNotWriteForNewVersion=0;
int count11=0;
		try {
			BufferedReader fileReader = new BufferedReader(new FileReader(inputCsvFile));
			String line=null;
		    try {
				while ((line = fileReader.readLine()) != null)
				{	if(count11!=0) {
					String[] dataStore = line.split(",");
					csvFilePathList.add(dataStore[1]);
					csvFileNameList.add(dataStore[0]);
					}
				count11++;
				}
				fileReader.close();
			} 
		    catch (IOException e1) {
				e1.printStackTrace();
			}
			} 
	   	catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
		for(int i = 0; i <csvFilePathList.size(); i++){
       		String fileNamePath=csvFilePathList.get(i).toString();
       		String fileName=csvFileNameList.get(i).toString();
       		String finalInputPathGit="";
       		String finalInputPathNewVersion="";
    		boolean openGitFile =true;
    		boolean openNewVersionFile =true;
    		boolean unKnowCase =false;
    		boolean isCommon =false;
    		if(fileName.toLowerCase().endsWith("dao.java")||fileName.toLowerCase().endsWith("daoimpl.java")||fileName.toLowerCase().endsWith(".xml")) {
//    		if(!fileName.toLowerCase().endsWith("dao.java")) {
//        		if(!fileName.toLowerCase().endsWith("daoimpl.java")) {
//            		if(!fileName.toLowerCase().endsWith(".xml")) {
        		
    			if(!fileName.toLowerCase().endsWith(".job.xml")){
       		if(fileNamePath.contains("\\Common")) {
       			String[]dataStore=fileNamePath.split(Pattern.quote("\\Common"),2);
       			finalInputPathGit=inputPathGit+"\\Common"+dataStore[1];
       			finalInputPathNewVersion=inputPathNewVersion+"\\Batch\\Common"+dataStore[1];
       			isCommon=true;
//       			System.out.println("!finalInputPathGit = " +finalInputPathGit);
//       			System.out.println("finalInputPathNewVersion = " +finalInputPathNewVersion);
       		}
       		else if(fileNamePath.contains("\\Batch")){
       			String[] dataStore = fileNamePath.split(Pattern.quote("D:\\ccshare\\jyyau_view_ClearCase_PRD\\TAAS2_DEV\\PRD_Application\\Batch"),2);
       			finalInputPathGit=inputPathGit+dataStore[1];
       			finalInputPathNewVersion=inputPathNewVersion+"\\Batch"+dataStore[1];
//	   			System.out.println("!finalInputPathGit = " +finalInputPathGit);
//	   			System.out.println("finalInputPathNewVersion = " +finalInputPathNewVersion);
       		}
       		else if(fileNamePath.contains("\\Online")){
       			String[] dataStore = fileNamePath.split(Pattern.quote("D:\\ccshare\\jyyau_view_ClearCase_PRD\\TAAS2_DEV\\PRD_Application\\Online"),2);
       			finalInputPathGit=inputPathGit+dataStore[1];
       			finalInputPathNewVersion=inputPathNewVersion+"\\Online"+dataStore[1];
//	   			System.out.println("!finalInputPathGit = " +finalInputPathGit);
//	   			System.out.println("finalInputPathNewVersion = " +finalInputPathNewVersion);
       		}
       		else {
//       			System.out.println("fileNamePath !!!!!!!!= " +fileNamePath);
       			unKnowCase=true;
       		}
//       		if(fileNamePath.contains("\\IR_Report")) {
//       			String[] dataStore = fileNamePath.split(Pattern.quote("D:\\ccshare\\jyyau_view_ClearCase_PRD\\TAAS2_DEV\\PRD_Application\\Online"),2);
//
//       			finalInputPathNewVersion=inputPathNewVersion+"\\Batch"+dataStore[1];
//       		}
    		try {
    			gitFile = new String(Files.readAllBytes(Paths.get(finalInputPathGit)));
			} catch (IOException e) {
				// TODO Auto-generated catch block
//				System.out.println("errorOpenFile = " +finalInputPathGit);
				openGitFile =false;
			}
    		try {
    			newVersionFile = new String(Files.readAllBytes(Paths.get(finalInputPathNewVersion)));
			} catch (IOException e) {
				// TODO Auto-generated catch block
//				System.out.println("errorOpenFile = " +finalInputPathNewVersion);
				 openNewVersionFile =false;
			}
    		File fileToSave;


    		String newFileStorePosition="T:\\jackyau\\newFileForDeploy666\\";
    		String gitFileStorePosition="T:\\jackyau\\git666\\";
    		String newVersionFileStorePosition="T:\\jackyau\\newVersion666\\";
 			String[] filePathForNewVersion=finalInputPathNewVersion.split(":",2);
 			String[] filePathForGit=finalInputPathGit.split(":",2);
 			
 			
    		fileToSave = new File(newFileStorePosition+filePathForNewVersion[1]);
    		String fileParentNewFile=fileToSave.getParent();
    		fileToSave = new File(gitFileStorePosition+filePathForGit[1]);
    		String fileParentGit=fileToSave.getParent();
    		fileToSave = new File(newVersionFileStorePosition+filePathForNewVersion[1]);
    		String fileParentNewVersion=fileToSave.getParent();
    		
    		fileToSave = new File(fileParentNewFile);
    		if (!fileToSave.exists()) {
    			fileToSave.mkdirs();
    		}
    		fileToSave = new File(fileParentGit);
    		if (!fileToSave.exists()) {
    			fileToSave.mkdirs();
    		}
    		fileToSave = new File(fileParentNewVersion);
    		if (!fileToSave.exists()) {
    			fileToSave.mkdirs();
    		}
    		
//    		fileToSave = new File("T:\\jackyau\\newFileForDeploy");
//    		if (!fileToSave.exists()) {
//    			fileToSave.mkdirs();
//    		}
//    		fileToSave = new File("T:\\jackyau\\git\\");
//    		if (!fileToSave.exists()) {
//    			fileToSave.mkdirs();
//    		}
//    		fileToSave = new File("T:\\jackyau\\newVersion\\");
//    		if (!fileToSave.exists()) {
//    			fileToSave.mkdirs();
//    		}

    		if(openGitFile==false) {
    			if(isCommon==true) {
    				outputCommonFileList.add(fileName+","+finalInputPathNewVersion+","+" ");
    			}
    			//no File exist in git!!
    			try {
					FileWriter fileWriterNewVersion = new FileWriter(newFileStorePosition+filePathForNewVersion[1]);
					fileWriterNewVersion.write(newVersionFile);
					fileWriterNewVersion.close();
					outputNewFileDeployList.add(fileName+","+finalInputPathNewVersion);
					totalCount++;
				} catch (IOException iox) {
//					System.out.println("File can not write for New Version !!!");
					fileCanNotWriteForNewVersion++;
				}
    		}
    		else if(openNewVersionFile ==false) {
    			//not exactly problem find! exist in git!!
//    			System.out.println("File openNewVersionFile problem!!");
    			System.out.println("finalInputPathNewVersion = " +finalInputPathNewVersion);
//    			if(finalInputPathNewVersion.contains("\\Batch\\")) {
//    				finalInputPathNewVersion=finalInputPathNewVersion.replaceAll(Pattern.quote("\\Batch\\"), Matcher.quoteReplacement("\\Online\\"));
//    			}
//        		try {
//        			newVersionFile = new String(Files.readAllBytes(Paths.get(finalInputPathNewVersion)));
//    			} catch (IOException e) {
//    				// TODO Auto-generated catch block
////    				System.out.println("errorOpenFile = " +finalInputPathNewVersion);
//    				 openNewVersionFile =false;
//    			}
//        		String[] filePathForNewVersion111=finalInputPathNewVersion.split(":",2);
//        		File fileToSave1;
//        		fileToSave1 = new File("T:\\jackyau\\gitdiff"+filePathForGit[1]);
//        		File fileToSave2= new File(fileToSave1.getParent());
//        		if (!fileToSave2.exists()) {
//        			fileToSave2.mkdirs();
//        		}
//        		fileToSave1 = new File("T:\\jackyau\\Newvers!"+filePathForNewVersion111[1]);
//        		fileToSave2= new File(fileToSave1.getParent());
//        		if (!fileToSave2.exists()) {
//        			fileToSave2.mkdirs();
//        		}
//    			try {
//					FileWriter fileWriterGit = new FileWriter("T:\\jackyau\\gitdiff"+filePathForGit[1]);
//					FileWriter fileWriterNewVersion = new FileWriter("T:\\jackyau\\Newvers!"+filePathForNewVersion111[1]);
//					fileWriterGit.write(gitFile);
//					fileWriterNewVersion.write(newVersionFile);
//					fileWriterGit.close();
//					fileWriterNewVersion.close();
//				} catch (IOException iox) {
////					System.out.println("File can not write!!!");
//					fileCanNotWrite++;
//				}
    			countOpenNewVersionFileProblem++;
    			totalCount++;
    		}
    		else if (unKnowCase==true) {
//    			System.out.println("File open problem!!");
    			countFileOpenProblem++;
    			totalCount++;
    		}
    		else if(!gitFile.equals(newVersionFile)) {
    			if(isCommon==true) {
    				outputCommonFileList.add(fileName+","+finalInputPathNewVersion+","+finalInputPathGit);
    			}
    			
				try {
					FileWriter fileWriterGit = new FileWriter(gitFileStorePosition+filePathForGit[1]);
					FileWriter fileWriterNewVersion = new FileWriter(newVersionFileStorePosition+filePathForNewVersion[1]);
					fileWriterGit.write(gitFile);
					fileWriterNewVersion.write(newVersionFile);
					fileWriterGit.close();
					fileWriterNewVersion.close();
					outputCompareDifferentList.add(fileName+","+finalInputPathGit+","+finalInputPathNewVersion);
					totalCount++;
				} catch (IOException iox) {
//					System.out.println("File can not write!!!");
					fileCanNotWrite++;
				}
    		}
    		else if(gitFile.equals(newVersionFile)){
    			count++;
    			totalCount++;
    		}
    		else {
    			//have problem!!
    			totalCount++;
    			System.out.println("!finalInputPathGit = " +finalInputPathGit);
    			System.out.println("finalInputPathNewVersion = " +finalInputPathNewVersion);
    			
    		}

//       		System.out.println("csvListData =" +csvListData);
    			}//end with .job.xml
    			
//    		}
//        		}
    			versionList.add(finalInputPathNewVersion);
    		}
    		processCount++;
		}
		try {
			FileWriter fileWriter = new FileWriter("T:\\jackyau\\versionList.txt");
//			fileWriter.write("File Name,File Name Absolute Path");
//			fileWriter.write(System.lineSeparator());
			for (int i = 0; i < versionList.size(); i++) {
				fileWriter.write(versionList.get(i).toString() + System.lineSeparator());
			}
			fileWriter.close();
		} catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data in outputPathList");
		}
		try {
			FileWriter outputfileWriterNewVersion = new FileWriter("T:\\jackyau\\newFileDeploy.csv");
			outputfileWriterNewVersion.write("File Name,File Name Absolute Path");
			outputfileWriterNewVersion.write(System.lineSeparator());
			for (int i = 0; i < outputNewFileDeployList.size(); i++) {
				outputfileWriterNewVersion.write(outputNewFileDeployList.get(i).toString() + System.lineSeparator());
			}
			outputfileWriterNewVersion.close();
			
			FileWriter outputfileWriterCompareDifferent = new FileWriter("T:\\jackyau\\compareDifferent.csv");
			outputfileWriterCompareDifferent.write("File Name,Git File Name Absolute Path,New Version File Name Absolute Path");
			outputfileWriterCompareDifferent.write(System.lineSeparator());
			for (int i = 0; i < outputCompareDifferentList.size(); i++) {
				outputfileWriterCompareDifferent.write(outputCompareDifferentList.get(i).toString() + System.lineSeparator());
			}
			outputfileWriterCompareDifferent.close();
			
			FileWriter outputfileWriterCommonFile = new FileWriter("T:\\jackyau\\CommonList.csv");
			outputfileWriterCommonFile.write("File Name,New Version File Name Absolute Path,Git File Name Absolute Path");
			outputfileWriterCommonFile.write(System.lineSeparator());
			for (int i = 0; i < outputCommonFileList.size(); i++) {
				outputfileWriterCommonFile.write(outputCommonFileList.get(i).toString() + System.lineSeparator());
			}
			outputfileWriterCommonFile.close();
		} catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data in outputPathList");
		}
		System.out.println("Same file =" +count);
		System.out.println("Open Problem File =" +countFileOpenProblem);
		System.out.println("Open NewVersion Problem File =" +countOpenNewVersionFileProblem);
		System.out.println("fileCanNotWrite =" +fileCanNotWrite);
		System.out.println("fileCanNotWriteForNewVersion =" +fileCanNotWriteForNewVersion);
		System.out.println("totalCount =" +totalCount);
		System.out.println("processCount = " +processCount);
	}
}