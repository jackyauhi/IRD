import java.io.BufferedReader;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;


public class FindFileLastModifiedTime {

	public static String openingPath = new String();
	public static ArrayList<String> outputPathList = new ArrayList<String>();


	public static void main(String[] args) {

		String outputPath="T:\\jackyau\\outputRequiredFileMain111.csv";
		openingPath="D:\\ccshare\\jyyau_view_ClearCase_PRD\\TAAS2_DEV\\PRD_Application";
		File inputFile = new File(openingPath);

		FindFileLastModifiedTime listFiles = new FindFileLastModifiedTime();

		try {
			listFiles.listAllFiles(inputFile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			FileWriter fileWriter = new FileWriter(outputPath);
			fileWriter.write("File Name,File Name Absolute Path,Last update ClearCase View time");
			fileWriter.write(System.lineSeparator());
			for (int i = 0; i < outputPathList.size(); i++) {
				fileWriter.write(outputPathList.get(i).toString() + System.lineSeparator());
			}
			fileWriter.close();
		} catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data in outputPathList");
		}

	}

	public void listAllFiles(File folder) throws IOException {
		File[] fileNamePath = folder.listFiles();

		for (int i = 0; i < fileNamePath.length; i++) {
			String fileName = fileNamePath[i].getName();

			// if directory call the same method again
			if (fileNamePath[i].isDirectory()) {
				if (!fileName.toLowerCase().equals("bin")) {
					listAllFiles(fileNamePath[i]);
				}
			} else {
//				if (fileName.toLowerCase().endsWith(".log4j.properties")) {
//					
//				}
//				else if(fileName.toLowerCase().endsWith(".job.xml")) {
//					
//				}
//				else if(fileName.toUpperCase().endsWith(".RUN")) {
//					
//				}
//				else if(fileName.toUpperCase().endsWith(".PARM")) {
//					
//				}
				
//				else {
					try {
//					    DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy - hh:mm:ss");
						DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
						String Date1="8/11/2019";
						Date date1=new SimpleDateFormat("dd/MM/yyyy").parse(Date1);  
					    String Date2=dateFormat.format(fileNamePath[i].lastModified());  
					    Date date2=new SimpleDateFormat("dd/MM/yyyy").parse(Date2);  
//					    date1=dateFormat.format(fileNamePath[i].lastModified());
//						System.out.println("fileNamePath[i] =" + fileNamePath[i].getAbsolutePath());
//						System.out.println("fileNamePath[i].lastModified() =" + dateFormat.format(fileNamePath[i].lastModified()));
			            if(date1.after(date2)){
//			                System.out.println("Date1 is after Date2");
			            }

			            if(date1.before(date2)){
			                System.out.println("Date1 is before Date2");
			                outputPathList.add(fileName+","+fileNamePath[i].getAbsolutePath()+","+dateFormat.format(fileNamePath[i].lastModified()));
			            }

			            if(date1.equals(date2)){
			                System.out.println("Date1 is equal Date2");
			                outputPathList.add(fileName+","+fileNamePath[i].getAbsolutePath()+","+dateFormat.format(fileNamePath[i].lastModified()));
			            }
					} catch (Exception e) {
						 e.printStackTrace();

					}

				}
			}

		}
	}
//}