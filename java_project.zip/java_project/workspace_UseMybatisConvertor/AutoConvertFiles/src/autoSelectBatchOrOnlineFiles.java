import java.io.BufferedReader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class autoSelectBatchOrOnlineFiles {

	public static String openingPath = new String();
	public static String comparePath = new String();
	
	public static ArrayList<String> outputResultList = new ArrayList<String>();
	
	public static ArrayList<String> batchCommonFileList = new ArrayList<String>();
	public static ArrayList<String> onlineCommonFileList = new ArrayList<String>();
	
	public static ArrayList<String> batchNonEqualCommonFileList = new ArrayList<String>();
	public static ArrayList<String> onlineNonEqualCommonFileList = new ArrayList<String>();	
	
	public static ArrayList<String> errorLogList = new ArrayList<String>();
	
	public static ArrayList<Integer> onlineNonCommonFileList = new ArrayList<>();
	
	public static ArrayList<String> finalOutputResultList = new ArrayList<String>();
	public static boolean batchEqualFile=false;
	public static boolean onlineEqualFile=false;
	
	public static boolean updateFileChecking=false;
	
	public static String requireDate;
	
	public static String convertorFilePath = new String();
	
	public static String batchComparePath;
	public static String onlineComparePath;
	public static String referenceFilePath;
	public static String findComparePath;
	
	public static String finalReferenceFilePath;
	public static String startFolder = "";
	public static String comparePathStartFolder = "";

	public static boolean noCheckInDayFile=true;
	
	public static void main(String[] args) {
		String numOfDaysBeforeTodayString =args[0];
		openingPath=args[1];
		comparePath=args[2];
		convertorFilePath = args[3];
		String[] inputSplit = openingPath.split(Pattern.quote("\\"));
		startFolder=inputSplit[inputSplit.length-1];
		String[] compareSplit = openingPath.split(Pattern.quote("\\"));
		comparePathStartFolder=compareSplit[compareSplit.length-1];
		try {
			 int numOfDaysBeforeToday =Integer.parseInt(numOfDaysBeforeTodayString);
			 if(numOfDaysBeforeToday<0) {
				 System.out.println("Number can not less than zero!");
			 }
			 else {
				 DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

			        Date date = new Date();
			        String todate = dateFormat.format(date);

			        Calendar cal = Calendar.getInstance();
			        cal.add(Calendar.DATE, -numOfDaysBeforeToday);
			        Date todate1 = cal.getTime();    
			        requireDate = dateFormat.format(todate1);
			        
//			        requireDate="9/11/2019 00:00:00";

		    System.out.println("requireDate ="+requireDate);
		    
		String outputPath=convertorFilePath+"\\outputRequiredFileMain.csv";
		String timeStampsFolderFile =convertorFilePath+"\\OutputFiles_TimeStamps.txt";
		String outputFilePath="T:\\jackyau";
		File inputFile = new File(openingPath);

		autoSelectBatchOrOnlineFiles listFiles = new autoSelectBatchOrOnlineFiles();

		try {
			listFiles.listAllFiles(inputFile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (int i = 0; i < batchCommonFileList.size(); i++) {
			batchEqualFile=false;
			String batchCommonFile=batchCommonFileList.get(i).toString();

       		String[] batchDataStore = batchCommonFile.split(",");
       		String[] batchCommonFolderPath = batchDataStore[1].split(Pattern.quote("\\Common"),2);
       		String[] batchReportFolderPath = batchDataStore[1].split(Pattern.quote("\\Report"),2);
       		if(batchCommonFolderPath.length==2) {
       			batchComparePath=batchCommonFolderPath[1];
       		}
       		else if(batchReportFolderPath.length==2){
       			batchComparePath=batchReportFolderPath[1];
       		}
       		for (int j = 0; j < onlineCommonFileList.size(); j++) {
       			String onlineCommonFile=onlineCommonFileList.get(j).toString();
       			String[] onlineDataStore = onlineCommonFile.split(",");
           		String[] onlineCommonFolderPath = onlineDataStore[1].split(Pattern.quote("\\Common"),2);
           		String[] onlineReportFolderPath = onlineDataStore[1].split(Pattern.quote("\\Report"),2);
           		if(onlineCommonFolderPath.length==2) {
           			onlineComparePath=onlineCommonFolderPath[1];
           		}
           		else if(onlineReportFolderPath.length==2){
           			onlineComparePath=onlineReportFolderPath[1];
           		}
       			if(batchComparePath.equals(onlineComparePath)) {
//       				batchEqualFile=true;
//       				onlineNonCommonFileList.add(j);
       				batchNonEqualCommonFileList.add(batchCommonFileList.get(i).toString());
       				onlineNonEqualCommonFileList.add(onlineCommonFileList.get(j).toString());
       				String batchFileContent = "";
        			String onlineFileContent = "";
        			Date batchDate = null;
        			Date onlineDate = null;
        			try {
        				BufferedReader batchFileReader = new BufferedReader(new FileReader(batchDataStore[1]));
        				BufferedReader onlineFileReader = new BufferedReader(new FileReader(onlineDataStore[1]));
        				String line=null;
        			    try {
        					while ((line = batchFileReader.readLine()) != null)
        					{	
        						if(line.contains("Check in version of")) {
        							String[] keepLatesetFile =line.split(Pattern.quote(","));
        							try {
										batchDate=new SimpleDateFormat("dd-MM-yy").parse(keepLatesetFile[1]);
									} catch (ParseException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
        							noCheckInDayFile=false;
        							break;		
        						}
        					}
        					batchFileReader.close();
        					while ((line = onlineFileReader.readLine()) != null)
        					{	
        						if(line.contains("Check in version of")) {
        							String[] keepLatesetFile =line.split(Pattern.quote(","));
        							try {
        								onlineDate=new SimpleDateFormat("dd-MM-yy").parse(keepLatesetFile[1]);
									} catch (ParseException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
        							noCheckInDayFile=false;
        							break;		
        						}
        					}
        					onlineFileReader.close();
        				} 
        			    catch (IOException e1) {
        					e1.printStackTrace();
        				}
        				} 
        		   	catch (FileNotFoundException e1) {
        					e1.printStackTrace();
        				}
        			if(noCheckInDayFile==false) {
						if(batchDate.after(onlineDate)){
							System.out.println("batchDate Latest");
							outputResultList.add(batchDataStore[0]+","+batchDataStore[1]+","+batchDataStore[2]);
						}
						else if(batchDate.before(onlineDate)){
							System.out.println("onlineDate Latest");
							outputResultList.add(onlineDataStore[0]+","+onlineDataStore[1]+","+onlineDataStore[2]);
				        }
						else if(batchDate.equals(onlineDate)){
							System.out.println("batchDate = onlineDate"); //batch be default.
							outputResultList.add(batchDataStore[0]+","+batchDataStore[1]+","+batchDataStore[2]);
				        }
						else {
							System.out.println("batchDate have check in date or onlineDate have check in date"); //batch be default.
							outputResultList.add(batchDataStore[0]+","+batchDataStore[1]+","+batchDataStore[2]);
						}
        			}
       			  if(noCheckInDayFile==true) {//no check in day find
					try {
						Date date1=new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").parse(batchDataStore[2]);
						Date date2=new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").parse(onlineDataStore[2]); 
       				if(!batchDataStore[2].equals(onlineDataStore[2])) {
						DateFormat dateFormating = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
							if(date1.after(date2)){
								outputResultList.add(batchDataStore[0]+","+batchDataStore[1]+","+batchDataStore[2]);
							}
							if(date1.before(date2)){
								outputResultList.add(onlineDataStore[0]+","+onlineDataStore[1]+","+onlineDataStore[2]);         
					        }
						}
       				else {
						//batch is the default version if equal date happened!
				        outputResultList.add(batchDataStore[0]+","+batchDataStore[1]+","+batchDataStore[2]); 					            				        
       				}
       				}catch (ParseException e) {
       					errorLogList.add(batchDataStore[0]+","+batchDataStore[1]+","+batchDataStore[2]+","+onlineDataStore[1]+","+onlineDataStore[2]);
					}
       				}//end of noCheckInDayFile
       			}
       		}
//       		if(batchEqualFile==false) {
//       			outputResultList.add(batchDataStore[0]+","+batchDataStore[1]+","+batchDataStore[2]);
//       		}
		}
//		for (int i = 0; i < onlineCommonFileList.size(); i++) {
//			onlineEqualFile=false;
//			String commonFile=onlineCommonFileList.get(i).toString();
//			String[] dataStore = commonFile.split(",");
//			for (int j = 0; j < onlineNonCommonFileList.size(); j++) {
//				int commonFileExist =onlineNonCommonFileList.get(j);
//				if(i==commonFileExist) {
//					onlineEqualFile=true;
//				}
//			}
//			if(onlineEqualFile==false) {
//       			outputResultList.add(dataStore[0]+","+dataStore[1]+","+dataStore[2]);
//       		}			
//		}
		batchCommonFileList.removeAll(batchNonEqualCommonFileList);
		onlineCommonFileList.removeAll(onlineNonEqualCommonFileList);
		outputResultList.addAll(batchCommonFileList);
		outputResultList.addAll(onlineCommonFileList);
		
		File checkExistFile;

			for (int j = 0; j < outputResultList.size(); j++) {

				String[] dataSplit = outputResultList.get(j).toString().split(",");
				String[] prdApplicationFolderPath = dataSplit[1].split(Pattern.quote(startFolder),2);

				
				if(prdApplicationFolderPath[1].contains("\\Batch\\Batch\\")) {
					prdApplicationFolderPath[1]=prdApplicationFolderPath[1].replaceAll(Pattern.quote("\\Batch\\Batch\\"), Matcher.quoteReplacement("\\Batch\\"));
				}
				else if(prdApplicationFolderPath[1].contains("\\Online\\Online\\")) {
					prdApplicationFolderPath[1]=prdApplicationFolderPath[1].replaceAll(Pattern.quote("\\Online\\Online\\"), Matcher.quoteReplacement("\\Online\\"));
				}
				else if(prdApplicationFolderPath[1].contains("\\Batch_Common\\")) {
					String[] partOfPath=prdApplicationFolderPath[1].split(Pattern.quote("\\Batch_Common"), 2);
					prdApplicationFolderPath[1]="\\Batch_Common"+partOfPath[1];
				}
				else if(prdApplicationFolderPath[1].contains("\\Common\\")) {
					String[] partOfPath=prdApplicationFolderPath[1].split(Pattern.quote("\\Common"), 2);
					prdApplicationFolderPath[1]="\\Common"+partOfPath[1];
				}
				else if(prdApplicationFolderPath[1].contains("\\Report\\")) {
					String[] partOfPath=prdApplicationFolderPath[1].split(Pattern.quote("\\Report"), 2);
					prdApplicationFolderPath[1]="\\Report"+partOfPath[1];
				}
           		finalReferenceFilePath =comparePath+comparePathStartFolder+prdApplicationFolderPath[1];
           		checkExistFile= new File(finalReferenceFilePath);
				if (checkExistFile.exists()) {
					finalOutputResultList.add(dataSplit[0]+","+dataSplit[1]+","+dataSplit[2]+","+"Update_Files_Folder");
				}
				else {
					finalOutputResultList.add(dataSplit[0]+","+dataSplit[1]+","+dataSplit[2]+","+"New_Files_Folder");
				}
			}
			
		try {
			DateFormat df = new SimpleDateFormat("dd-MM-yyyy HH_mm_ss");
			FileWriter fileWriter = new FileWriter(timeStampsFolderFile);
			String timeStamps=df.format(cal.getTime());
			fileWriter.write(timeStamps);
			fileWriter.close();
		} catch (IOException iox) {
			iox.printStackTrace();
		}
		
		try {
			FileWriter fileWriter = new FileWriter(outputPath);
			for (int i = 0; i < finalOutputResultList.size(); i++) {
				fileWriter.write(finalOutputResultList.get(i).toString() + System.lineSeparator());
			}
			fileWriter.close();
		} catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data in outputPathList");
		}		
		}
		}// end of try
		catch (NumberFormatException e) {
			errorLogList.add(e.toString());
			System.out.println("Error Number Format!");
		}
	}
	public void listAllFiles(File folder) throws IOException {
		File[] fileNamePath = folder.listFiles();

		for (int i = 0; i < fileNamePath.length; i++) {
			String fileName = fileNamePath[i].getName();

			// if directory call the same method again
			if (fileNamePath[i].isDirectory()) {
				if (!fileName.toLowerCase().equals("bin")) {
					listAllFiles(fileNamePath[i]);
				}			
			}	
			 else {
					try {
						DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
						String Date1=requireDate;
						Date date1=new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").parse(Date1);  
					    String Date2=dateFormat.format(fileNamePath[i].lastModified());  
					    Date date2=new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").parse(Date2);  
			            if(!date1.after(date2)){
			            	
			            		if(fileNamePath[i].getAbsolutePath().contains("\\Batch")) {
			            			if(fileNamePath[i].getAbsolutePath().contains("\\Common")) {
			            				batchCommonFileList.add(fileName+","+fileNamePath[i].getAbsolutePath()+","+dateFormat.format(fileNamePath[i].lastModified()));
			            			}
			            			else if(fileNamePath[i].getAbsolutePath().contains("\\Report")){
			            				batchCommonFileList.add(fileName+","+fileNamePath[i].getAbsolutePath()+","+dateFormat.format(fileNamePath[i].lastModified()));
			            			}
			            			else {
			            				outputResultList.add(fileName+","+fileNamePath[i].getAbsolutePath()+","+dateFormat.format(fileNamePath[i].lastModified()));
			            			}
			            		}
			            		else if(fileNamePath[i].getAbsolutePath().contains("\\Online")) {
			            			if(fileNamePath[i].getAbsolutePath().contains("\\Common")) {
			            				onlineCommonFileList.add(fileName+","+fileNamePath[i].getAbsolutePath()+","+dateFormat.format(fileNamePath[i].lastModified()));
			            			}
			            			else if(fileNamePath[i].getAbsolutePath().contains("\\Report")){
			            				onlineCommonFileList.add(fileName+","+fileNamePath[i].getAbsolutePath()+","+dateFormat.format(fileNamePath[i].lastModified()));
			            			}
			            			else {
			            				outputResultList.add(fileName+","+fileNamePath[i].getAbsolutePath()+","+dateFormat.format(fileNamePath[i].lastModified()));
			            			}
			            		} 
			            		else {
			            			outputResultList.add(fileName+","+fileNamePath[i].getAbsolutePath()+","+dateFormat.format(fileNamePath[i].lastModified()));
			            		}  
			            }
			            

					} catch (Exception e) {
						 e.printStackTrace();

					}

				}
			}

		}
	}
//}