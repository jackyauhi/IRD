/**
 * 
 */


import java.util.ArrayList;
import java.util.List;



/**
 * @author mliu
 *
 */
public class JocBaseInput {
	private String jobschedulerId = "scheduler";

	public Input[] jobs;




	public Input[] getJobs() {
		return jobs;
	}



	public void setJobs(Input[] jobs) {
		this.jobs = jobs;
	}

	public String getJobschedulerId() {
		return jobschedulerId;
	}

	public void setJobschedulerId(String jobschedulerId) {
		this.jobschedulerId = jobschedulerId;
	}

	@Override
	public String toString() {
		return "JocBaseInput [ jobschedulerId = " + jobschedulerId + "jobs = "+jobs+" ]";
	}
}
