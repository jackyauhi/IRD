/**
 * 
 */


import java.util.ArrayList;
import java.util.List;



/**
 * @author mliu
 *
 */
public class Input {
	public String job = "/TAAS/IRCHK1";
	public String at = "now";

	public Input(String job, String at){
		      this.job = job;
		      this.at = at;
		   }
	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public String getAt() {
		return at;
	}

	public void setAt(String at) {
		this.at = at;
	}

	@Override
	public String toString() {
		return "Input [ jobschedulerId = " + job + "at = "+at+" ]";
	}
}
