import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.google.common.collect.Lists;
import com.google.gson.Gson;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicHeader;
import org.apache.log4j.Logger;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

public class testJson {
    public static void main(String[] args) throws Exception {
    	Map<String, String> jobMap = new HashMap();
    	Map<String, String> timeMap = new HashMap();
    	jobMap.put("job","/TAAS/IRCHK1");

    	timeMap.put("at", "now");
    	String content = "result column=\"ROW_NUMBER\"  jdbcType = \" LONG \" ";
    	Pattern removePattern1 = Pattern.compile("jdbcType\\s*[=]\\s*\"\\s*LONG\\s*\"");
//    	Matcher removePattern1Matcher=removePattern1.matcher(content);
//    	if (removePattern1Matcher.find()){
//    		content = removePattern1.matcher(content).replaceAll(Matcher.quoteReplacement("1"));
//    	}
    	content = removePattern1.matcher(content).replaceAll(Matcher.quoteReplacement("jdbcType=\"BIGINT\""));
    	System.out.println("content = "+content);
    	
//    	String content1 = "result column=\"ROW_NUMBER\" @Autowired private DataSource dataSource";
//		Pattern removeDataSourcePattern = Pattern.compile("@Autowired\\s*((\r\\n)|(\n)|(\r))*\\s*([a-zA-Z0-9]*)\\s*DataSource\\s*([a-zA-Z0-9]+)");
//		Matcher removeDataSourceMatcher=removeDataSourcePattern.matcher(content1);
//		if (removeDataSourceMatcher.find()){
//			content1 = removeDataSourcePattern.matcher(content1).replaceAll("");
//		}
//		System.out.println("content1 = "+content1);
    	String content2="result column=\"ROW_NUMBER\"      <if test=\"item != null and item.valid == true\">\r\n" + 
    			"        (\r\n" + 
    			"";
    	Pattern removePattern2 = Pattern.compile("<if\\s*test\\s*=\\s*\"\\s*item\\s*!=\\s*null\\s*and\\s*item.valid\\s*==\\s*([a-zA-Z]*)\"\\s*>\\s*((\r\n)|(\n)|(\r))*\\s*[(]");
		Matcher removeMatcher2=removePattern2.matcher(content2);
		if (removeMatcher2.find()){
			String booleanValue=removeMatcher2.group(1);
			content2 = removePattern2.matcher(content2).replaceAll(Matcher.quoteReplacement("      <if test=\"item != null and item.valid == "+booleanValue+"\">\r\n" + 
	    			"        (\r\n" + 
	    			"        <trim prefixOverrides=\"and|or|,\">"));
			System.out.println("booleanValue = "+booleanValue);
		}
    	System.out.println("content2 = "+content2);
    	
    	String content3="result column=\"1\"             )\r\n" + 
    			"      </if>\r\n" + 
    			" ";
    	Pattern removePattern3 = Pattern.compile("[)]\\s*((\r\n)|(\n)|(\r))*\\s*</if>");
		Matcher removeMatcher3=removePattern3.matcher(content3);
		if (removeMatcher3.find()){
			content3 = removePattern3.matcher(content3).replaceAll(")\r\n" + 
					"        </trim>\r\n" + 
					"      </if>");
		}
    	System.out.println("content3 = "+content3);
    	String content4="result column=\"123145\" <foreach collection=\"item.criteriaWithoutValue\" item=\"itemitem\"separator=\"and\"   >";
    	
    	Pattern removePattern4 = Pattern.compile("<foreach\\s*collection\\s*=\\s*\"\\s*([a-zA-Z0-9.]+)\\s*\"\\s*item\\s*=\\s*\"\\s*itemitem\\s*\"\\s*separator\\s*=\\s*\"\\s*([a-zA-Z0-9.,]+)\\s*\"\\s*>");
		Matcher removeMatcher4=removePattern4.matcher(content4);
		if (removeMatcher4.find()){
			String collectionValue=removeMatcher4.group(1);
			String separatorValue=removeMatcher4.group(2);
			content4 = removePattern4.matcher(content4).replaceAll(Matcher.quoteReplacement("<foreach collection=\""+collectionValue+"\" item=\"itemitem\">"+separatorValue));
			System.out.println("collectionValue = "+collectionValue);
			System.out.println("separatorValue = "+separatorValue);
		}
    	System.out.println("content4 = "+content4);
//    	String[] splitCheck =content.split("\\s");
//    	for(int i=0;i<splitCheck.length; i++) {
//    	System.out.println("splitCheck = "+splitCheck[i]);
//    	}
    	JocBaseInput inputJoc= new JocBaseInput();
    	Input inputString[]= new Input[1];
    	String jobs[] =new String[10];
    	List<Input> list= new ArrayList();
//    	List jobsList =new ArrayList();
//    	String jobArray[]=new String[2];
//    	String timeArray[]=new String[2];
//    	jobArray[0]="IRCHK1";
//    	jobArray[1]="CTDOL1";
//    	timeArray[0]="now";
//    	timeArray[1]="now + 60";
//for(int i=0; i<2;i++) {
//	jobs[i]="{ \"job\":"+jobArray[i]+","+"\"at\":"+timeArray[i]+"}";
////	"{"+"job"+ ":" +jobsList.get(0).getJobId().toString()+" , "+"at" +":" +"now"+ "}"
//	jobsList.add(jobArray[i]+","+timeArray[i]);
//}
    	
    	inputString[0]=new Input("IRCHK","now");
    	inputString[0].setAt("now");
    		jobs[0]=jobMap.get("job")+timeMap.get("at");
    	
    	


    		inputJoc.setJobs(inputString);
    	System.out.println("jobs = "+jobs);
    	Gson gson = new Gson();
		HttpEntity stringEntity = new StringEntity(gson.toJson(inputJoc), ContentType.APPLICATION_JSON);
		
		System.out.println("gson.toJson(input) = "+gson.toJson(inputJoc));
		System.out.println("gson.toJson(input) = "+gson.toJson(inputJoc));
		System.out.println("stringEntity = "+stringEntity);
		System.out.println("input = "+inputJoc);
		
//jocJobSubmissionDriver!!		
//		String a[] = new String[1];
//		for (int i = 0; i <= jobsList.size(); i++) {
//		a[0]="{ \"job\" : "+"\""+"/TAAS/"+jobsList.get(0).getJobId().toString()+"\""+" , "+"\"at\" : "+"\""+"now"+"\""+" }";
		//jobs[i]="{ \"job\":"+jobArray[i]+","+"\"at\":"+timeArray[i]+"}";
		//{ "jobschedulerId": "scheduler", "jobs":[]}
//		}
//	}
		
//	jocJobInput.setJobs(a);
//	jsonCode="{ \"jobschedulerId\": \"scheduler\", " + "\"jobs\" : [ " + a[0]+"] }";		
		
		
		
    }
}