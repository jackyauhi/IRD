//import java.io.File;
//import java.io.FileInputStream;
//import java.io.FileOutputStream;
//import java.io.IOException;
//import java.io.InputStream;
//import java.io.OutputStream;
//import java.util.regex.Matcher;
//import java.util.regex.Pattern;
import java.io.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.lang.*;
import java.text.*;

public class TestClassConversion {
	Map<Integer, Integer> showReqListMap = new HashMap<Integer, Integer>();
	public static void main(String[] args) {
//		String inputContent = "       public class MyObjectDao implements MyObjectDao{";
//		String inputContent = "sss \t@Autowired\r\n\n\nprivate SqlMapClient sqlMapClient ; 3432";//\t@Autowired\r\n\t
		String inputContent = "public OTYuDaoImpl () 34";
//		Pattern pattern = Pattern.compile("(?:public\\s)?(?:.*\\s)?(SqlMapClient)\\s+([$_a-zA-Z][$_a-zA-Z0-9]*)");
//		Pattern pattern = Pattern.compile("@Autowired((\r\n)|(\n)|(\r))\\s+private\\s+SqlMapClient\\s+sqlMapClient?(?:.*\\s)?;");//@Autowired((\r\n)|(\n)|(\r))?(?:.*\\s)?		
//		Pattern pattern = Pattern.compile("sqlMapClient\\s*((\r\n)|(\n)|(\r))*[.]");//@Autowired((\r\n)|(\n)|(\r))?(?:.*\\s)?	
//		Pattern pattern = Pattern.compile("@Autowired((\r\\n)|(\n)|(\r))*\\s*private\\s*SqlMapClient\\s*sqlMapClient\\s*;");
//		Pattern pattern = Pattern.compile("public\\s+([a-zA-Z0-9]+)DaoImpl\\s*[(]\\s*[)]\\s*");
//		String a =pattern.matcher(inputContent).replaceAll("");
//		Matcher matcher = pattern.matcher(inputContent);
//		if (matcher.find()) {
//		   //System.out.println(matcher.replaceAll("$2 extends "));
//			String daoClassName = matcher.group(2);
//			System.out.println(daoClassName);
//			String modelName=null;
//			if(daoClassName.toUpperCase().contains("DAOIMPL")) {
//				modelName = daoClassName.replaceAll("(?i)(DaoImpl)", "");
//				System.out.println(modelName);
//			}
//			else if(daoClassName.toUpperCase().contains("DAO")) {
//				modelName = daoClassName.replaceAll("(?i)(Dao)", "");
//				System.out.println(modelName);
//			}
//			System.out.println(matcher.group());
//			System.out.println(inputContent.replaceAll(daoClassName, daoClassName + " extends BasoDaoImpl<"+modelName+">"));
//		}
//		System.out.println(a);
		
//		String paramString = new String("2020-01-19 19:32:29.0");
//		String paramString11 = new String("/");
//	    StringBuffer localStringBuffer = new StringBuffer(12);
//	    //add padding zero for charAt function
//	    paramString=String.format("%-26s", paramString).replace(' ', '0');
//	    System.out.println("paramString value = "+paramString);
//	    System.out.println("paramString11 value = "+paramString11);
//	    localStringBuffer.append(paramString.charAt(11));
//	    localStringBuffer.append(paramString.charAt(12));
//	    localStringBuffer.append(paramString.charAt(14));
//	    localStringBuffer.append(paramString.charAt(15));	    
//	    localStringBuffer.append(paramString.charAt(17));
//	    localStringBuffer.append(paramString.charAt(18));
//	    localStringBuffer.append(paramString.charAt(20));
//	    localStringBuffer.append(paramString.charAt(21));
//	    localStringBuffer.append(paramString.charAt(22));
//	    localStringBuffer.append(paramString.charAt(23));
//	    localStringBuffer.append(paramString.charAt(24));
//	    localStringBuffer.append(paramString.charAt(25));
//	    System.out.println("localStringBuffer value = "+localStringBuffer);
		String qrCodeSource = "D:\\testFindXml\\test2";
		String qrCodeTarget = "D:\\testFindXml\\Testing2";
		File qrCodeSourceLocation=new File(qrCodeSource);
		File qrCodeTargetLocation=new File(qrCodeTarget);
		boolean showDisplay=false;
		
		qrCodeSource.equals("");
		Map<Integer, Integer> showReqListMap = new HashMap<Integer, Integer>();
		int showReqListCount=2;
		int i=1;
		showReqListMap.put(showReqListCount, i);
		
		String m_sCreTs="2020-20-01 10:09:58.090000";
		
		String input="1";
		int countnum=20;
		String checkInput=input.replaceAll("[^0-9]+", "");
		if(checkInput.length()==input.length()) {
			int num;
			num = Integer.parseInt(input.trim());
			if(num<1||num>countnum) {
				System.out.println("num 1 value = "+num);
			}
			else {
				System.out.println("num 2 value = "+num);
			}
		}
		else {
			System.out.println("input 1 value = "+input);
		}
		
		System.out.println("checkInput.length() value = "+checkInput.length());
		System.out.println("input.length() value = "+input.length());
		String listReq_m_sCreTs=m_sCreTs;
		listReq_m_sCreTs=listReq_m_sCreTs.replaceAll(" ", "-");
		listReq_m_sCreTs=listReq_m_sCreTs.replaceAll(":", ".");
		if(listReq_m_sCreTs.contains("*")) {
			listReq_m_sCreTs=listReq_m_sCreTs.replaceAll(" ", "-");
			listReq_m_sCreTs=listReq_m_sCreTs.replaceAll(":", ".");
		}
		listReq_m_sCreTs=listReq_m_sCreTs.replaceAll(" ", "D");
		listReq_m_sCreTs=String.format("%-26s", listReq_m_sCreTs).replace(' ', '0');
		listReq_m_sCreTs=listReq_m_sCreTs.replaceAll("D", " ");
		if(m_sCreTs.length()==19)
			m_sCreTs=m_sCreTs+".";
		System.out.println("listReq_m_sCreTs value = "+listReq_m_sCreTs);
		System.out.println("ii value = "+m_sCreTs);
		System.out.println("showReqListMap key value = "+showReqListMap.get("5"));
	}
	protected static void copyDirectory(File sourceLocation , File targetLocation,boolean showDisplay){
		        if (sourceLocation.isDirectory()) {
		            if (!targetLocation.exists()) {
		                targetLocation.mkdir();
		            }
		            String[] sourceFileList = sourceLocation.list();
		            for (int i=0; i<sourceFileList.length; i++) {
		                copyDirectory(new File(sourceLocation, sourceFileList[i]),new File(targetLocation, sourceFileList[i]), showDisplay);
		                System.out.println("file copy!" + sourceLocation+sourceFileList[i]+ "to"+ targetLocation);
		            }
		        } else {
		            InputStream inputStream = null;
		            OutputStream outputStream= null;
					try {
						inputStream = new FileInputStream(sourceLocation);
						outputStream = new FileOutputStream(targetLocation);
			            // Copy the bits from instream to outstream
			            byte[] fileByte = new byte[10240];
			            int lenght;
			            try {
							while ((lenght = inputStream.read(fileByte)) > 0) {
							    outputStream.write(fileByte, 0, lenght);
							}
							inputStream.close();
							outputStream.close();
						} catch (IOException e) {
//							e.printStackTrace();
							System.out.println("file copy!" + sourceLocation+ "to"+ targetLocation);
						}
					} catch (FileNotFoundException e) {
						e.printStackTrace();
					}
		        }
		    }

}
