
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.regex.*;


public class CssStyleChecker {
	static final String filepath = "" ;	
	static final String newPath = "";
	public static String convertorFilePath = new String();
	public static ArrayList<File> latestFileList = new ArrayList<File>();
	public static ArrayList<String> ConvertJspList = new ArrayList<String>();
	public static String startFolder = "";
	public String reader(String path) throws Exception {
		StringBuilder sb = new StringBuilder();
		 
		try (BufferedReader br = new BufferedReader(new InputStreamReader(
			    new FileInputStream(path), "UTF-8"))) {	
            // read line by line
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line).append("\n");  	                      
            }

        } catch (IOException e) {
            System.err.format("IOException: %s%n", e);
        }
			
//        System.out.println(sb);    
		return sb.toString();
	}
	
	
	public void checkJSP(String readpath, String writepath) throws Exception {
		String original = reader(readpath);
		Boolean valid = true;

		for (Tag tag : printTag(original)) {
			if (!tag.isValid()) {
				valid = false;
			}
		}
		
		if(valid) {
			//System.out.println("  file pass."+readpath);
		}else {
			System.out.println("--------------------"+readpath+"----------------------");
			convertJSP(readpath,writepath);
			ConvertJspList.add("--------------------"+readpath+"----------------------");
		}


	}			
	
	public void convertJSP(String readpath, String writepath) throws Exception {
		String original = reader(readpath);
		String output = original;


		for (Tag tag : printTag(original)) {
			if (!tag.isValid()) {
				output = output.replace(tag.getTag(), tag.fixedTag()); 	
//				System.out.println("  tag.getTag() "+tag.getTag());
//				System.out.println("  tag.fixedTag() "+tag.fixedTag());
//				System.out.println(" end ");
			}
		}

		String[] lines = output.split("\n");
		File fileDir = new File(writepath);
		File fileDirParent = new File(fileDir.getParent());
		if (!fileDirParent.exists()) {
			fileDirParent.mkdirs();
		}
		if (!fileDir.exists()) {
			fileDir.delete();
		}
		Writer out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileDir), StandardCharsets.UTF_8));
		for (String line : lines) {
			out.append(line).append("\r\n");
		}	
		out.flush();
        out.close();
		
		System.out.println("  JSP converted: "+writepath);
		ConvertJspList.add("  JSP converted: "+writepath);

	}		
	
	public ArrayList<Tag> printTag(String content) throws Exception {
			
		// System.out.println(content);
		ArrayList<Tag> tagList = new ArrayList<Tag>();
		
		try {
			//content = content.replaceAll("(?s)(<!--.*?-->)", "").replaceAll("(?s)(<%--.*?--%>)", "");
			content = content.replaceAll("(?s)(<%--.*?--%>)", "");
            Pattern regex = Pattern.compile("(?s)(<\\w+(:\\w+)?\\s.*?[^|]>)"); 
            Matcher regexMatcher = regex.matcher(content);
            String tag="";
            Tag tagN = null;

			while (regexMatcher.find()) {
				tag = regexMatcher.group(1);
				//System.out.println("print tag :" + tag);
				tagN = new Tag(tag);
				tagList.add(tagN);            	
            }	
			regex = Pattern.compile("(?s)(</s:div\\s*>)"); 
            regexMatcher = regex.matcher(content);
            while (regexMatcher.find()) {
				tag = regexMatcher.group(1);
				//System.out.println("print tag :" + tag);
				tagN = new Tag(tag);
				tagList.add(tagN);            	
            }
            regex = Pattern.compile("(?s)(<%@page\\s*import\\s*=\\s*\"\\s*com.ibm.websphere.management.repository.Document\\s*\"\\s*%>)"); 
            regexMatcher = regex.matcher(content);
            while (regexMatcher.find()) {
				tag = regexMatcher.group(1);
				//System.out.println("print tag :" + tag);
				tagN = new Tag(tag);
				tagList.add(tagN);            	
            }
             
        } catch (PatternSyntaxException ex) {
        	System.out.println("printTag not working");
        	ConvertJspList.add("printTag not working");
        }
		return tagList;
		
	}
	
//	public ArrayList<File> listf(String directoryName, ArrayList<File> files) {
//	    File directory = new File(directoryName);
//
//	    // Get all files from a directory.
//	    File[] fList = directory.listFiles();
//	    if(fList != null)
//	        for (File file : fList) {      
//	            if (file.isFile()) {
//	                files.add(file);
//	            } else if (file.isDirectory()) {
//	                listf(file.getAbsolutePath(), files);
//	            }
//	        }
//	    
//	    return files;
//	    }
	
//	public long deleteFolder(String dir) {
//
//        File f = new File(dir);
//        String listFiles[] = f.list();
//        long totalSize = 0;
//        for (String file : listFiles) {
//
//            File folder = new File(dir + "/" + file);
//            if (folder.isDirectory()) {
//                totalSize += deleteFolder(folder.getAbsolutePath());
//            } else {
//                totalSize += folder.length();
//            }
//        }
//
//        if (totalSize ==0) {
//            f.delete();
//        }
//
//        return totalSize;
//	}
	
	
	
	public static void main(String argv[]) throws Exception {		
		CssStyleChecker ccss = new CssStyleChecker();
		File inputPath = new File(filepath);
		File outputPath = new File(newPath);

		inputPath = new File(argv[0]);
		outputPath = new File(argv[1]);
		
		ArrayList<File> filelist = new ArrayList<File>();
		convertorFilePath = argv[2];
		String[] inputSplit = inputPath.getAbsoluteFile().toString().split(Pattern.quote("\\"));
		startFolder=inputSplit[inputSplit.length-1];
		
		String requireCsvFile =convertorFilePath+"\\outputRequiredFileMain.csv";
		try {
			BufferedReader fileReader = new BufferedReader(new FileReader(requireCsvFile));
			String line=null;
		    try {
				while ((line = fileReader.readLine()) != null)
				{	
					String[] dataStore = line.split(",");
					File dataFile = new File(dataStore[1]);
					latestFileList.add(dataFile);
				}
				fileReader.close();
			} 
		    catch (IOException e1) {
				e1.printStackTrace();
			}
			} 
	   	catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
//		ccss.listf(inputPath.toString(), filelist);
		filelist=latestFileList;

		
		for(File file:filelist){
			if(file.toString().toLowerCase().endsWith(".jsp")) {
				//Auto Using this
				File filea = new File(file.getParent().toString()
						.replace(inputPath.toString(), outputPath.toString()+"\\"+startFolder));
				
				boolean dirCreated = filea.mkdirs();
				String newFilePath = filea.toString()+File.separator+file.getName();
				
				
				ccss.checkJSP(file.toString(),newFilePath);
			}			
		}
		try {
			FileWriter fileWriter = new FileWriter(convertorFilePath+"\\ConvertJspList.txt");
			for (int j = 0; j < ConvertJspList.size(); j++) {
				fileWriter.write(ConvertJspList.get(j).toString()+ System.lineSeparator());
			}
			fileWriter.close();
			} catch (IOException iox) {
				iox.printStackTrace();
				System.out.println("File can not save any data in inputFileList");
				}
//		ccss.deleteFolder(outputPath.toString());
		
    }  
}
