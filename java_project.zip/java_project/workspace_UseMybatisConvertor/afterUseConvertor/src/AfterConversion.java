import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class AfterConversion { 
	
//	public static String foreachListValueTag = new String();
//	public static String sqlTag = new String();
//	public static String realSqlTag = new String();
	
    public static void main(String[] args) {
    	try {
    	ArrayList<String> openingDataList = new ArrayList<String>(); 
    	String openingDataString= new String();
    	String InputFile = "D:\\ibatis2mybatis-master\\destination\\JDI_BATCH_SqlMap.xml";

    	String outputFile = "T:\\jackyau\\output.xml";
    	File afterConvertFile = new File(InputFile);
    	
    	DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
    	dbFactory.setValidating(false);
    	dbFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
    	
    	DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
    	Document doc = dBuilder.parse(afterConvertFile);

    	doc.getDocumentElement().normalize();
    	

    	NodeList docList=doc.getElementsByTagName("mapper");
    	
    	NodeList nList = doc.getElementsByTagName("sql");

    	String foreachListValueTag = new String();
    	String sqlTag = new String();
    	String realSqlTag = new String();
    	
    	String sampleFormalofListValue =(
"<foreach collection=\"itemitem.values\" index=\"index\" item=\"criterionItem\">\r\n" + 
"           				<if test=\"index == 1\">\r\n" + 
"           					<foreach collection=\"criterionItem\" separator=\",\" open=\"(\" close=\")\" item=\"criterionItemValue\">\r\n" +
"           						#{criterionItemValue}\r\n" + 
"	            			    </foreach>\r\n" + 
"	            		    </if>\r\n" + 
"           			  </foreach>");

        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
        
  	  	  DOMSource all = new DOMSource(docList.item(0));
		  StreamResult allconsoleResult = new StreamResult(new StringWriter());
		  transformer.transform(all, allconsoleResult);
		  String allXml =allconsoleResult.getWriter().toString();
		  
		  String checkCorrectFormal = null;
	    	try {
				checkCorrectFormal = new String(Files.readAllBytes(Paths.get(InputFile)));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    	openingDataString=checkCorrectFormal;

	    	checkCorrectFormal=checkCorrectFormal.replaceAll(" ", "");
	    	checkCorrectFormal=checkCorrectFormal.replaceAll("\t", "");
	    	
		  if(checkCorrectFormal.contains("<mappernamespace")) {

			  String[] keepFrontData=openingDataString.split("<mapper");
			  allXml=keepFrontData[0]+allXml;			  
					
				
        for (int temp = 0; temp < nList.getLength(); temp++) {   		
    		Node nNode = nList.item(temp);
    		if (nNode.getNodeType() == Node.ELEMENT_NODE) {
    			Element eElement = (Element) nNode;
    			if(eElement.getAttribute("id").startsWith("Example_Where_Clause")) {
				  DOMSource sqlTagSource = new DOMSource(nNode);
  				  StreamResult sqlTagConsoleResult = new StreamResult(new StringWriter());
  				  transformer.transform(sqlTagSource, sqlTagConsoleResult);
  				  sqlTag=sqlTagConsoleResult.getWriter().toString();
  				  realSqlTag=sqlTagConsoleResult.getWriter().toString();

  				  if(realSqlTag.contains("and <foreach")) {
  					realSqlTag=realSqlTag.replaceAll("and <foreach", "<foreach");
  				  }
  				  if(realSqlTag.contains("Value\" item=\"item\"")) {
  					realSqlTag=realSqlTag.replaceAll("Value\" item=\"item\"", "Value\" item=\"itemitem\"");
  				  }

    				NodeList requireList = eElement.getElementsByTagName("foreach");
    				for (int j = 0; j < requireList.getLength(); j++) {
    					Node requireNode = requireList.item(j);
    					if (requireNode.getNodeType() == requireNode.ELEMENT_NODE) {
    						Element requireElement = (Element) requireNode;
    						if(requireElement.getAttribute("collection").equals("itemitem.values")) {
    							  DOMSource source = new DOMSource(requireNode);
			    				  StreamResult consoleResult = new StreamResult(new StringWriter());
			    				  transformer.transform(source, consoleResult);
			    				  foreachListValueTag=consoleResult.getWriter().toString();

    											}
    										}
    									}
    								}
    							}
        					}
        if(allXml.contains(sqlTag)) {
        	allXml=allXml.replaceAll(Pattern.quote(sqlTag), Matcher.quoteReplacement(realSqlTag));
        }
        if(allXml.contains(foreachListValueTag)) {
        	allXml=allXml.replaceAll(Pattern.quote(foreachListValueTag), sampleFormalofListValue);
        }
        if(allXml.contains("&quot;true&quot;")) {
        	allXml=allXml.replaceAll("&quot;true&quot;", "true");
        }
        if(allXml.contains(":INTEGER#")) {
        	allXml=allXml.replaceAll(":INTEGER#", "}");
        }
        if(allXml.contains(":CHAR#")) {
        	allXml=allXml.replaceAll(":CHAR#", "}");
        }
        if(allXml.contains(":SMALLINT#")) {
        	allXml=allXml.replaceAll(":SMALLINT#", "}");
        }
        if(allXml.contains(":DATE#")) {
        	allXml=allXml.replaceAll(":DATE#", "}");
        }
        if(allXml.contains("#")) {
        	allXml=allXml.replaceAll("#", "#{");
        }
        if(allXml.contains("#{{")) {
        	allXml=allXml.replaceAll(Pattern.quote("#{{"), "#{");
        }
        if(allXml.contains("<!--<isParameterPresent>-->")) {
        	allXml=allXml.replaceAll("<!--<isParameterPresent>-->", "<if test=\"_parameter != null\">");
        }
        if(allXml.contains("<!--</isParameterPresent>-->")) {
        	allXml=allXml.replaceAll("<!--</isParameterPresent>-->", "</if>");
        }
        if(allXml.contains("<!--<dynamic prepend=\"(\">-->")) {
        	allXml=allXml.replaceAll(Pattern.quote("<!--<dynamic prepend=\"(\">-->"), "(");
        }
        if(allXml.contains("<!--<dynamic prepend=\"set\">-->")) {
        	allXml=allXml.replaceAll("<!--<dynamic prepend=\"set\">-->", "<set>");
        }
        if(allXml.contains("<!--</dynamic prepend=\"set\">-->")) {
        	allXml=allXml.replaceAll("<!--</dynamic prepend=\"set\">-->", "</set>");
        }
        if(allXml.contains("<!--<dynamic prepend=\"where\">-->")) {
        	allXml=allXml.replaceAll("<!--<dynamic prepend=\"where\">-->", "<where>");
        }
        if(allXml.contains("<!--</dynamic prepend=\"where\">-->")) {
        	allXml=allXml.replaceAll("<!--</dynamic prepend=\"where\">-->", "</where>");
        }
        if(allXml.contains("<!--<dynamic>-->")) {
        	allXml=allXml.replaceAll("<!--<dynamic>-->", "");
        }
        if(allXml.contains("<!--</dynamic>-->")) {
        	allXml=allXml.replaceAll("<!--<dynamic>-->", "");
        }
        System.out.println(allXml);
        
    	try {       
       		FileWriter fileWriter = new FileWriter(outputFile);
       		
       		fileWriter.write(allXml);
       		fileWriter.close();
       		System.out.println("Complete the file");
       	}catch (IOException iox) {
       		iox.printStackTrace();
       		System.out.println("File can not save any data");
       	}
    	
    	}//if allXml.contains("<mapper namespace")
		  else {
			  System.out.println("This file is not using mybatis-3-mapper format. Please Check!");
			  
		  }  
    	  }catch (Exception e) {
	        	e.printStackTrace();
	        }
    	}
    }