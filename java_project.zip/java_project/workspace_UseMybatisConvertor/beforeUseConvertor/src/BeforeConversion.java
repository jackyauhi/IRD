import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class BeforeConversion { 
	
	public static String foreachListValueTag = new String();
	public static String sqlTag = new String();
	public static String realSqlTag = new String();
	
    public static void main(String[] args) {
    	ArrayList<String> beforeConvertList = new ArrayList<String>();
    	String InputFile = "D:\\ibatis2mybatis-master\\source\\JDI_BATCH_SqlMap.xml";
//    	String InputFile = "T:\\jackyau\\output.xml";
    	String outputFile = "T:\\jackyau\\output1.xml";
    	boolean checkSetPrepend=false;
    	boolean checkWherePrepend=false;
    	boolean addToBeforeConvertList=false;
    	boolean dynamicTagExist=false;
    	String checkCorrectFormal= null;
    	try {
			checkCorrectFormal = new String(Files.readAllBytes(Paths.get(InputFile)));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	checkCorrectFormal=checkCorrectFormal.replaceAll(" ", "");
    	checkCorrectFormal=checkCorrectFormal.replaceAll("\t", "");
    	if(checkCorrectFormal.contains("<sqlMapnamespace")){
    	try {
    		
			BufferedReader fileReader = new BufferedReader(new FileReader(InputFile));
			String readListLine=null;
			
		    try {
				while ((readListLine = fileReader.readLine()) != null)
				{	
					String readNoSpaceLine=readListLine.replaceAll(" ", "");
					readNoSpaceLine=readNoSpaceLine.replaceAll("\t", "");
					
						if(readNoSpaceLine.contains("<dynamicprepend=\"set\">")){
							String[] keepSpace;
							if(readNoSpaceLine.contains("<!--")){
								keepSpace=readListLine.split("<!--");
							}
							else {
								keepSpace=readListLine.split("<dynamic");
							}
							readListLine=keepSpace[0]+"<dynamic prepend=\"set\">";
							readListLine=readListLine.replaceAll("<dynamic prepend=\"set\">", "<!--<dynamic prepend=\"set\">-->");
							checkSetPrepend=true;
							beforeConvertList.add(readListLine);
							addToBeforeConvertList=true;
						}
						else if(readNoSpaceLine.contains("<dynamicprepend=\"where\">")){
							String[] keepSpace;
							if(readNoSpaceLine.contains("<!--")){
								keepSpace=readListLine.split("<!--");
							}
							else {
								keepSpace=readListLine.split("<dynamic");
							}
							readListLine=keepSpace[0]+"<dynamic prepend=\"where\">";
							readListLine=readListLine.replaceAll("<dynamic prepend=\"where\">", "<!--<dynamic prepend=\"where\">-->");
							checkWherePrepend=true;
							beforeConvertList.add(readListLine);
							addToBeforeConvertList=true;
						}
						else if(readNoSpaceLine.contains("<dynamicprepend=\"(\">")){
							String[] keepSpace;
							if(readNoSpaceLine.contains("<!--")){
								keepSpace=readListLine.split("<!--");
							}
							else {
								keepSpace=readListLine.split("<dynamic");
							}						
							readListLine=keepSpace[0]+"<dynamic prepend=\"(\">";
							readListLine=readListLine.replaceAll(Pattern.quote("<dynamic prepend=\"(\">"), "<!--<dynamic prepend=\"(\">-->");
							beforeConvertList.add(readListLine);
							addToBeforeConvertList=true;
						}
						else if(readNoSpaceLine.contains("<isParameterPresent>")){
							String[] keepSpace;
							if(readNoSpaceLine.contains("<!--")){
								keepSpace=readListLine.split("<!--");
							}
							else {
								keepSpace=readListLine.split("<isParameterPresent>");
							}
							readListLine=keepSpace[0]+"<isParameterPresent>";
							readListLine=readListLine.replaceAll("<isParameterPresent>", "<!--<isParameterPresent>-->");
							beforeConvertList.add(readListLine);
							addToBeforeConvertList=true;
						}
						else if(readNoSpaceLine.contains("</isParameterPresent>")){
							String[] keepSpace;
							if(readNoSpaceLine.contains("<!--")){
								keepSpace=readListLine.split("<!--");
							}
							else {
								keepSpace=readListLine.split("</isParameterPresent>");
							}
							readListLine=keepSpace[0]+"</isParameterPresent>";
							readListLine=readListLine.replaceAll("</isParameterPresent>", "<!--</isParameterPresent>-->");
							beforeConvertList.add(readListLine);
							addToBeforeConvertList=true;
						}
						else if(readNoSpaceLine.contains("<dynamic>")){
							String[] keepSpace;
							if(readNoSpaceLine.contains("<!--")){
								keepSpace=readListLine.split("<!--");
							}
							else {
								keepSpace=readListLine.split("<dynamic");
							}
							readListLine=keepSpace[0]+"<dynamic>";
							readListLine=readListLine.replaceAll("<dynamic>", "<!--<dynamic>-->");
							beforeConvertList.add(readListLine);
							addToBeforeConvertList=true;
						}
						if(checkSetPrepend==true){
							if(readNoSpaceLine.contains("</dynamic>")) {
								readListLine=readListLine.replaceAll("</dynamic>", "<!--</dynamic prepend=\"set\">-->");
								beforeConvertList.add(readListLine);
								checkSetPrepend=false;
								addToBeforeConvertList=true;
								dynamicTagExist=true;
							}
						}
						if(checkWherePrepend==true){
							if(readNoSpaceLine.contains("</dynamic>")) {
								readListLine=readListLine.replaceAll("</dynamic>", "<!--</dynamic prepend=\"where\">-->");
								beforeConvertList.add(readListLine);
								checkWherePrepend=false;
								addToBeforeConvertList=true;
								dynamicTagExist=true;
							}
						}
						if(checkSetPrepend==false && checkWherePrepend==false && readNoSpaceLine.contains("</dynamic>")&& dynamicTagExist==false) {
							readListLine=readListLine.replaceAll("</dynamic>", "<!--</dynamic>-->");
							beforeConvertList.add(readListLine);
							addToBeforeConvertList=true;
						}
						else {
							if(addToBeforeConvertList==false) {
							beforeConvertList.add(readListLine);
							}
						}
						beforeConvertList.add("\r\n");
						addToBeforeConvertList=false;
						dynamicTagExist=false;
				}
				fileReader.close();
			} 
		    catch (IOException e1) {
				e1.printStackTrace();
			}
		    System.out.println("beforeConvertList "+ beforeConvertList);
	    	try {       
	       		FileWriter fileWriter = new FileWriter(outputFile);
	       		for(int i=0;i<beforeConvertList.size();i++) {
	       		fileWriter.write(beforeConvertList.get(i).toString());
	       		}
	       		fileWriter.close();
	       		System.out.println("Complete the file");
	       	}catch (IOException iox) {
	       		iox.printStackTrace();
	       		System.out.println("File can not save any data");
	       	}
    	} 
		catch (FileNotFoundException e1) {
		e1.printStackTrace();
	}
    }//if(data.contains("<sqlMap namespace"))
		  else {
			  System.out.println("This file is not using ibatis-sqlMap-2 format. Please Check!");
			  
		  }
    	}
    }