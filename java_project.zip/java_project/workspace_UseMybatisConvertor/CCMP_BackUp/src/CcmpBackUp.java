import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

public class CcmpBackUp {
	
public static void main(String[] args) {
	try {				
		String command = "db2cmd /c /w /i dbback.bat";
		Process p=null;
            
            p = Runtime.getRuntime().exec(command,null,new File("Q:\\IR1E\\Development\\CCMP Plus\\DB Backup\\"));
            System.out.println("Process start!!");
            BufferedReader stdInput = new BufferedReader(new InputStreamReader(p.getInputStream()));
	        BufferedReader stdError = new BufferedReader(new InputStreamReader(p.getErrorStream()));
	        StringBuffer response = new StringBuffer();
	        StringBuffer errorStr = new StringBuffer();
	        boolean alreadyWaited = false;
	        while (p.isAlive()) {
	            try {
	                if(alreadyWaited) {
	                    String temp;
	                    while ((temp = stdInput.readLine()) != null) {
	                        response.append(temp);
	                        System.out.println(temp);
	                    }
	                    String errTemp;
	                    while ((errTemp = stdError.readLine()) != null) {
	                        errorStr.append(errTemp);
	                    }                                                   
	                }
	                Thread.sleep(1000);
	                alreadyWaited = true;
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }
	        }
	        System.out.println("Completed!!");
	}
	catch (IOException e) {
		e.printStackTrace();
	}
}
}