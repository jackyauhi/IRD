import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class Convertor {

	public static String openingPath = new String();
	public static String outputFile = new String();
	public static String startFolderFilePath = new String();
	public static File fileToSave;
	public static File fileToSaveParent;
	public static String convertorFilePath = new String();
	public static String destinationFilePath = new String();
	public static String sourceFilePath = new String();
	public static File wirteFileFolder;
	public static ArrayList<String> latestFileList = new ArrayList<String>();
	public static ArrayList<String> outputPathList = new ArrayList<String>();
	public static ArrayList<String> errorInputList = new ArrayList<String>();
	public static int countError;
	public static int countFile = 0;
	public static int countRedoTimes = 0;
	public static int countMultipleSameTag = 0;
	public static boolean breakProcess = false;
	public static boolean errorHappen = false;
	public static boolean ReDoWhileLoop = true;

	public static String[] keepDynamicFrontData;
	public static String[] keepDynamicBackData;
	public static String[] keepCloseDynamicFrontData;
	public static String[] keepCloseDynamicBackData;
	public static String tag = new String();
	public static String realTag = new String();
	public static String tag1 = new String();
	public static String realTag1 = new String();
	public static String prependValue = "";
	public static String prefixOverrides = "";
	public static String startFolder = "";
	public static String antPath = "";
	public static void main(String[] args) {
		countError = 0;
		openingPath= args[0];
		outputFile = args[1];
		antPath = args[2];
		convertorFilePath = args[3];
		String[] inputSplit = openingPath.split(Pattern.quote("\\"));
		startFolder=inputSplit[inputSplit.length-1];
		
		String requireCsvFile =convertorFilePath+"\\outputRequiredFileMain.csv";
		
		try {
			BufferedReader fileReader = new BufferedReader(new FileReader(requireCsvFile));
			String line=null;
		    try {
				while ((line = fileReader.readLine()) != null)
				{	
					String[] dataStore = line.split(",");
					latestFileList.add(dataStore[1]);
				}
				fileReader.close();
			} 
		    catch (IOException e1) {
				e1.printStackTrace();
			}
			} 
	   	catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}

		sourceFilePath = convertorFilePath + "\\source";
		destinationFilePath = convertorFilePath + "\\destination";
		String outputConvertPath = convertorFilePath + "\\outputConvert.txt";
		String errorInputPath = convertorFilePath + "\\errorInput.txt";
		String outputConvertPathFile = "";
		String errorInputPathFile = "";

		fileToSave = new File(sourceFilePath);
		if (!fileToSave.exists()) {
			fileToSave.mkdirs();
		}
		fileToSave = new File(destinationFilePath);
		if (!fileToSave.exists()) {
			fileToSave.mkdirs();
		}

		

		Convertor listFiles = new Convertor();

		try {
			for (int i = 0; i < latestFileList.size(); i++) {
				File inputFile = new File(latestFileList.get(i).toString());
				listFiles.listAllFiles(inputFile, antPath);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		fileToSave = new File(outputConvertPath);
		if (fileToSave.exists()) {
			try {
				outputConvertPathFile = new String(Files.readAllBytes(Paths.get(outputConvertPath)));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		fileToSave = new File(errorInputPath);
		if (fileToSave.exists()) {
			try {
				errorInputPathFile = new String(Files.readAllBytes(Paths.get(errorInputPath)));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		try {
			FileWriter fileWriter = new FileWriter(outputConvertPath);
			if (outputConvertPathFile != "") {
				fileWriter.write(outputConvertPathFile);
			}
			for (int i = 0; i < outputPathList.size(); i++) {
				fileWriter.write(outputPathList.get(i).toString() + System.lineSeparator());
			}
			fileWriter.close();
		} catch (IOException iox) {
			iox.printStackTrace();
			System.out.println("File can not save any data in outputPathList");
		}
		if (errorHappen == true) {
			try {
				FileWriter fileWriter = new FileWriter(errorInputPath);
				if (errorInputPathFile != "") {
					fileWriter.write(errorInputPathFile);
				}
				for (int i = 0; i < errorInputList.size(); i++) {
					fileWriter.write(errorInputList.get(i).toString() + System.lineSeparator());
				}
				fileWriter.close();
			} catch (IOException iox) {
				iox.printStackTrace();
				System.out.println("File can not save any data in errorInputList");
			}
		}
		
		for (String outputPath : outputPathList) {
			try {
				File xmlFile = new File(outputPath);
				String content = new String(Files.readAllBytes(xmlFile.toPath()));
				content = replaceContent(content, convertStringToXMLDocument(content));
				
				FileWriter fw = new FileWriter(xmlFile, false);
				fw.write(content);
				fw.close();
				
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		int countSqlXml = countError + outputPathList.size();
		System.out.println();
		System.out.println("Complete all the Conversion. Please Check!");
		System.out.println("SQL Xml Count :" + countSqlXml);
		System.out.println("Convert SQL Xml Count :" + outputPathList.size());
		System.out.println("The SQL Xml files convert list is put in (" + outputConvertPath + ")");
		if (errorHappen == true) {
			System.out.println("The Error Input List is put in (" + errorInputPath + ")");
		}
	}
	
	private static String replaceContent(String xmlString, Node node) {
		
		if (node.hasChildNodes()) {
			NodeList list = node.getChildNodes();
	        int count = list.getLength();
	        for (int i = 0; i < count; i++) {
	            Node childNode = list.item(i);
	            xmlString = replaceContent(xmlString, childNode);
	        }
		}

		if (!node.hasAttributes()) {
			return xmlString;
		}
		NamedNodeMap nnm = node.getAttributes();
        Node testNode = nnm.getNamedItem("test");
        if (testNode == null) {
        	return xmlString;
        }

        String testCondition = testNode.getNodeValue();
        String[] testElements = testCondition.split("\\s+");
        StringBuffer sb = new StringBuffer();
        for(String testElement : testElements) {
        	if (!testElement.contains(":")) {
        		sb.append(testElement);
        	}else {
            	sb.append(testElement.subSequence(0, testElement.indexOf(":")));
        	}
        	sb.append(" ");
        }
        xmlString = xmlString.replaceAll(Pattern.quote(testCondition), sb.toString());
        return xmlString;
	}
	
	public static void transform(File source, String srcEncoding, File target, String tgtEncoding) throws IOException {
	    BufferedReader br = null;
	    BufferedWriter bw = null;
	    try{
	        br = new BufferedReader(new InputStreamReader(new FileInputStream(source),srcEncoding));
	        bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(target), tgtEncoding));
	        char[] buffer = new char[16384];
	        int read;
	        while ((read = br.read(buffer)) != -1)
	            bw.write(buffer, 0, read);
	    } finally {
	        try {
	            if (br != null)
	                br.close();
	        } finally {
	            if (bw != null)
	                bw.close();
	        }
	    }
	}
	private static Document convertStringToXMLDocument(String xmlString){
        //Parser that produces DOM object trees from XML content
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setValidating(false);
    	
        //API to obtain DOM Document instance
        DocumentBuilder builder = null;
        try{        
        	factory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);

            //Create DocumentBuilder with default configuration
            builder = factory.newDocumentBuilder();
             
            //Parse the content to Document object
            Document doc = builder.parse(new InputSource(new StringReader(xmlString)));
            return doc;
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
        return null;
    }

	public void listAllFiles(File csvFilePath, String antPath) throws IOException {
		
			String fileName = csvFilePath.getName();

			// if directory call the same method again
			if (csvFilePath.isDirectory()) {
				if (!fileName.toLowerCase().equals("bin")) {
					listAllFiles(csvFilePath, antPath);
				}
			} else {
				if (fileName.toLowerCase().endsWith(".xml")) {
					try {
						String savePath = String.valueOf(csvFilePath);
						String[] prdApplicationFolderPath = savePath.split(Pattern.quote(startFolder),2);
						String outputPath = outputFile +"\\"+startFolder+prdApplicationFolderPath[1];
						
						fileToSave = new File(outputPath);
						fileToSaveParent = new File(fileToSave.getParent());
						if (!fileToSaveParent.exists()) {
							fileToSaveParent.mkdirs();
						}
						String openingDataString = new String();
						String sampleFile = csvFilePath.getAbsolutePath();
						File beforeConvertFile = new File(sampleFile);

						DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
						dbFactory.setValidating(false);
						dbFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);

						DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
						Document doc = dBuilder.parse(beforeConvertFile);

						doc.getDocumentElement().normalize();

						NodeList docList = doc.getElementsByTagName("sqlMap");

						NodeList dynamicList = doc.getElementsByTagName("dynamic");

						NodeList isParameterPresentList = doc.getElementsByTagName("isParameterPresent");
						
						NodeList isNotParameterPresentList = doc.getElementsByTagName("isNotParameterPresent");

						NodeList isPropertyAvailableList = doc.getElementsByTagName("isPropertyAvailable");
						
						NodeList isNotPropertyAvailableList = doc.getElementsByTagName("isNotPropertyAvailable");
						
						NodeList isNotEmptyList = doc.getElementsByTagName("isNotEmpty");

						NodeList typeAliasList = doc.getElementsByTagName("typeAlias");

						ArrayList<String> propertyVaribleList = new ArrayList<String>();
						ArrayList<String> isNotPropertyVaribleList = new ArrayList<String>();
						ArrayList<String> dynamicPrependVaribleList = new ArrayList<String>();
						Map<String, String> typeAliasMap = new HashMap<String, String>();

						TransformerFactory transformerFactory = TransformerFactory.newInstance();
						Transformer transformer = transformerFactory.newTransformer();
						transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");

						DOMSource all = new DOMSource(docList.item(0));
						StreamResult allConsoleResult = new StreamResult(new StringWriter());
						transformer.transform(all, allConsoleResult);
						String allXml = allConsoleResult.getWriter().toString();

						String checkCorrectFormal = null;
						try {
							checkCorrectFormal = new String(Files.readAllBytes(Paths.get(sampleFile)));
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						openingDataString = checkCorrectFormal;

						checkCorrectFormal = checkCorrectFormal.replaceAll(" ", "");
						checkCorrectFormal = checkCorrectFormal.replaceAll("\t", "");

						if (checkCorrectFormal.contains("<sqlMapnamespace")) {

							String[] keepAllXmlFrontData = openingDataString.split("<sqlMap");
							allXml = keepAllXmlFrontData[0] + allXml;
							for (int j = 0; j < typeAliasList.getLength(); j++) {
								Node nNode = typeAliasList.item(j);
								if (nNode.getNodeType() == Node.ELEMENT_NODE) {
									Element eElement = (Element) nNode;
									DOMSource sqlTagSource = new DOMSource(nNode);
									StreamResult sqlTagConsoleResult = new StreamResult(new StringWriter());
									transformer.transform(sqlTagSource, sqlTagConsoleResult);
									tag = sqlTagConsoleResult.getWriter().toString();

									String[] keepFrontData = tag.split("<typeAlias", 2);
									String[] keepBackData = keepFrontData[1].split(">", 2);

									realTag = keepFrontData[0] + keepBackData[1];

									if (allXml.contains(tag)) {
										allXml = allXml.replaceAll(Pattern.quote(tag),
												Matcher.quoteReplacement(realTag));
										typeAliasMap.put(eElement.getAttribute("alias"), eElement.getAttribute("type"));
									}
								}
							}
							for (int temp = 0; temp < docList.getLength(); temp++) {
								Element docListElement = (Element) docList.item(temp);
								NodeList innerElementList = docListElement.getChildNodes();
								for (int j = 0; j < innerElementList.getLength(); j++) {
									Node nNode = innerElementList.item(j);
									if (nNode.getNodeType() == Node.ELEMENT_NODE) {
										Element eElement = (Element) nNode;
										DOMSource sqlTagSource = new DOMSource(nNode);
										StreamResult sqlTagConsoleResult = new StreamResult(new StringWriter());
										transformer.transform(sqlTagSource, sqlTagConsoleResult);
										tag = sqlTagConsoleResult.getWriter().toString();
										realTag = tag;
										NodeList innerElementList1 = nNode.getChildNodes();
										for (int a = 0; a < innerElementList1.getLength(); a++) {
											Node nNode1 = innerElementList1.item(a);
											if (nNode1.getNodeType() == Node.ELEMENT_NODE) {
												Element eElement1 = (Element) nNode1;
												DOMSource sqlTagSource1 = new DOMSource(nNode1);
												StreamResult sqlTagConsoleResult1 = new StreamResult(
														new StringWriter());
												transformer.transform(sqlTagSource1, sqlTagConsoleResult1);
												tag1 = sqlTagConsoleResult1.getWriter().toString();
												realTag1 = tag1;
												if (typeAliasMap.containsKey(eElement1.getAttribute("typeHandler"))) {
													Node classAttributes = innerElementList1.item(a).getAttributes()
															.getNamedItem("typeHandler");
													String oldClassValue = innerElementList1.item(a).getAttributes()
															.getNamedItem("typeHandler").toString();
													String classValue = classAttributes.getNodeValue();
													classAttributes.setNodeValue(classValue.replaceAll(
															Pattern.quote(eElement1.getAttribute("typeHandler")),
															Matcher.quoteReplacement(typeAliasMap.get(eElement1.getAttribute("typeHandler")))));
													realTag1 = realTag1.replaceAll(Pattern.quote(oldClassValue),
															Matcher.quoteReplacement(classAttributes.toString()));

													allXml = allXml.replaceAll(Pattern.quote(tag1),
															Matcher.quoteReplacement(realTag1));

												}
											}

											if (typeAliasMap.containsKey(eElement.getAttribute("class"))) {
												Node classAttributes = innerElementList.item(j).getAttributes()
														.getNamedItem("class");
												String oldClassValue = innerElementList.item(j).getAttributes()
														.getNamedItem("class").toString();
												String classValue = classAttributes.getNodeValue();
												
												classAttributes.setNodeValue(classValue.replaceAll(Pattern.quote(eElement.getAttribute("class")),Matcher.quoteReplacement(typeAliasMap.get(eElement.getAttribute("class")))));
												realTag = realTag.replaceAll((Pattern.quote(oldClassValue)), Matcher.quoteReplacement(classAttributes.toString()));

												allXml = allXml.replaceAll(Pattern.quote(tag),
														Matcher.quoteReplacement(realTag));

											} else if (typeAliasMap
													.containsKey(eElement.getAttribute("parameterClass"))) {
												Node classAttributes = innerElementList.item(j).getAttributes()
														.getNamedItem("parameterClass");
												String oldClassValue = innerElementList.item(j).getAttributes()
														.getNamedItem("parameterClass").toString();
												String classValue = classAttributes.getNodeValue();
												classAttributes.setNodeValue(classValue.replaceAll(
														eElement.getAttribute("parameterClass"),
														typeAliasMap.get(eElement.getAttribute("parameterClass"))));
												realTag = realTag.replaceAll(oldClassValue, classAttributes.toString());

												allXml = allXml.replaceAll(Pattern.quote(tag),
														Matcher.quoteReplacement(realTag));

											} else if (typeAliasMap.containsKey(eElement.getAttribute("typeHandler"))) {
												Node classAttributes = innerElementList.item(j).getAttributes()
														.getNamedItem("typeHandler");
												String oldClassValue = innerElementList.item(j).getAttributes()
														.getNamedItem("typeHandler").toString();
												String classValue = classAttributes.getNodeValue();
												classAttributes.setNodeValue(classValue.replaceAll(
														eElement.getAttribute("typeHandler"),
														typeAliasMap.get(eElement.getAttribute("typeHandler"))));
												realTag = realTag.replaceAll(oldClassValue, classAttributes.toString());

												allXml = allXml.replaceAll(Pattern.quote(tag),
														Matcher.quoteReplacement(realTag));

											}
										}
									}
								}
							}

							for (int temp = 0; temp < dynamicList.getLength(); temp++) {
								Node nNode = dynamicList.item(temp);
								if (nNode.getNodeType() == Node.ELEMENT_NODE) {
									Element eElement = (Element) nNode;
									boolean havePrefixOverrides = false;
									DOMSource sqlTagSource = new DOMSource(nNode);
									StreamResult sqlTagConsoleResult = new StreamResult(new StringWriter());
									transformer.transform(sqlTagSource, sqlTagConsoleResult);
									tag = sqlTagConsoleResult.getWriter().toString();

									keepDynamicFrontData = tag.split("<dynamic", 2);
									keepDynamicBackData = keepDynamicFrontData[1].split(">", 2);

									keepCloseDynamicFrontData = keepDynamicBackData[1].split("</dynamic", 2);
									keepCloseDynamicBackData = keepCloseDynamicFrontData[1].split(">", 2);
									NodeList innerElementList1 = nNode.getChildNodes();

									for (int a = 0; a < innerElementList1.getLength(); a++) {
										Node nNode1 = innerElementList1.item(a);
										if (nNode1.getNodeType() == Node.ELEMENT_NODE) {
											Element eElement1 = (Element) nNode1;
											prependValue = eElement1.getAttribute("prepend");
											prependValue = prependValue.replaceAll("\\s", "");
											DOMSource sqlTagSource1 = new DOMSource(nNode1);
											StreamResult sqlTagConsoleResult1 = new StreamResult(new StringWriter());
											transformer.transform(sqlTagSource1, sqlTagConsoleResult1);
											tag1 = sqlTagConsoleResult1.getWriter().toString();
											realTag1 = tag1;
											if (!prependValue.equals("") || prependValue == null) {
												havePrefixOverrides = true;
											}

										}
									}
									if (havePrefixOverrides == true) {
										prefixOverrides = (" prefixOverrides=\"and|or|,\"");
									} else {
										prefixOverrides = "";
									}
									// <dynamic> tag
									if (eElement.getAttribute("prepend").equals("")
											|| eElement.getAttribute("prepend") == null) {
										realTag = keepDynamicFrontData[0] + keepCloseDynamicFrontData[0]
												+ keepCloseDynamicBackData[1];
									}
									// other use dynamic with prepend value but not match above case!
									else {
										realTag = keepDynamicFrontData[0] + "<!--<trim prefix=\""
												+ eElement.getAttribute("prepend") + "\"" + prefixOverrides + ">-->"
												+ keepCloseDynamicFrontData[0] + "<!--</trim>-->"
												+ keepCloseDynamicBackData[1];
										dynamicPrependVaribleList.add(eElement.getAttribute("prepend"));
									}
									allXml = allXml.replaceAll(Pattern.quote(tag), Matcher.quoteReplacement(realTag));
								}
							} // <dynamic> must be process before process other tag!
							
							for (int j = 0; j < isNotParameterPresentList.getLength(); j++) {
								Node nNode = isNotParameterPresentList.item(j);
								if (nNode.getNodeType() == Node.ELEMENT_NODE) {
									Element eElement = (Element) nNode;
									DOMSource sqlTagSource = new DOMSource(nNode);
									StreamResult sqlTagConsoleResult = new StreamResult(new StringWriter());
									transformer.transform(sqlTagSource, sqlTagConsoleResult);
									tag = sqlTagConsoleResult.getWriter().toString();

									String[] keepFrontData = tag.split("<isNotParameterPresent", 2);
									String[] keepBackData = keepFrontData[1].split(">", 2);

									String[] keepCloseFrontData = keepBackData[1].split("</isNotParameterPresent", 2);
									String[] keepCloseBackData = keepCloseFrontData[1].split(">", 2);

									realTag = keepFrontData[0] + "<!--<isNotParameterPresent>-->" + keepCloseFrontData[0]
											+ "<!--</isNotParameterPresent>-->" + keepCloseBackData[1];
									allXml = allXml.replaceAll(Pattern.quote(tag), Matcher.quoteReplacement(realTag));
								}
							}
							for (int j = 0; j < isParameterPresentList.getLength(); j++) {
								Node nNode = isParameterPresentList.item(j);
								if (nNode.getNodeType() == Node.ELEMENT_NODE) {
									Element eElement = (Element) nNode;
									DOMSource sqlTagSource = new DOMSource(nNode);
									StreamResult sqlTagConsoleResult = new StreamResult(new StringWriter());
									transformer.transform(sqlTagSource, sqlTagConsoleResult);
									tag = sqlTagConsoleResult.getWriter().toString();

									String[] keepFrontData = tag.split("<isParameterPresent", 2);
									String[] keepBackData = keepFrontData[1].split(">", 2);

									String[] keepCloseFrontData = keepBackData[1].split("</isParameterPresent", 2);
									String[] keepCloseBackData = keepCloseFrontData[1].split(">", 2);

									realTag = keepFrontData[0] + "<!--<isParameterPresent>-->" + keepCloseFrontData[0]
											+ "<!--</isParameterPresent>-->" + keepCloseBackData[1];
									allXml = allXml.replaceAll(Pattern.quote(tag), Matcher.quoteReplacement(realTag));
								}
							}
							
							for (int j = 0; j < isNotPropertyAvailableList.getLength(); j++) {
								Node nNode = isNotPropertyAvailableList.item(j);
								if (nNode.getNodeType() == Node.ELEMENT_NODE) {
									Element eElement = (Element) nNode;
									DOMSource sqlTagSource = new DOMSource(nNode);
									StreamResult sqlTagConsoleResult = new StreamResult(new StringWriter());
									transformer.transform(sqlTagSource, sqlTagConsoleResult);
									tag = sqlTagConsoleResult.getWriter().toString();

									String[] keepFrontData = tag.split("<isNotPropertyAvailable", 2);
									String[] keepBackData = keepFrontData[1].split(">", 2);

									String[] keepCloseFrontData = keepBackData[1].split("</isNotPropertyAvailable", 2);
									String[] keepCloseBackData = keepCloseFrontData[1].split(">", 2);
									String parameterType = eElement.getAttribute("parameterType");
									
									realTag = keepFrontData[0] + "<!--<if test=\""
											+ eElement.getAttribute("property") + "==null\">-->"
											+ eElement.getAttribute("prepend") + keepCloseFrontData[0]
											+ "<!--</if>-->" + keepCloseBackData[1];
									
									allXml = allXml.replaceAll(Pattern.quote(tag), Matcher.quoteReplacement(realTag));
									isNotPropertyVaribleList.add(eElement.getAttribute("property"));
								}
							}
							
							ReDoWhileLoop = true;
							while (ReDoWhileLoop == true) {
								int isPropertyAvailableSize = isPropertyAvailableList.getLength();
								ReDoWhileLoop = false;
								for (int j = 0; j < isPropertyAvailableSize; j++) {
									Node nNode = isPropertyAvailableList.item(j);
									if (nNode.getNodeType() == Node.ELEMENT_NODE) {
										Element eElement = (Element) nNode;
										DOMSource sqlTagSource = new DOMSource(nNode);
										StreamResult sqlTagConsoleResult = new StreamResult(new StringWriter());
										transformer.transform(sqlTagSource, sqlTagConsoleResult);
										tag = sqlTagConsoleResult.getWriter().toString();
										String[] splitCheck = tag.split("<isPropertyAvailable");
										countMultipleSameTag = splitCheck.length;
										keepDynamicFrontData = tag.split("<isPropertyAvailable", 2);
										keepDynamicBackData = keepDynamicFrontData[1].split(">", 2);

										keepCloseDynamicFrontData = keepDynamicBackData[1]
												.split("</isPropertyAvailable", 2);
										keepCloseDynamicBackData = keepCloseDynamicFrontData[1].split(">", 2);
										
										realTag = keepDynamicFrontData[0] + "<!--<if test=\""
												+ eElement.getAttribute("property") + "!=null\">-->"
												+ eElement.getAttribute("prepend") + keepCloseDynamicFrontData[0]
												+ "<!--</if>-->" + keepCloseDynamicBackData[1];
										
										allXml = allXml.replaceAll(Pattern.quote(tag),
												Matcher.quoteReplacement(realTag));
										propertyVaribleList.add(eElement.getAttribute("property"));
									}
									if (countMultipleSameTag > 2) {
										ReDoWhileLoop = true;
									}
								}
								if (ReDoWhileLoop == true) {
									int existNameEqual = 0;
									String exportTempPath = csvFilePath.getParent();
									File tempFile = new File(exportTempPath + "\\Temp" + existNameEqual + ".xml");
									while (tempFile.exists()) {
										existNameEqual++;
										tempFile = new File(exportTempPath + "\\Temp" + existNameEqual + ".xml");
									}
									try {
										FileWriter fileWriter = new FileWriter(tempFile);
										fileWriter.write(allXml);
										fileWriter.close();
									} catch (IOException iox) {
										iox.printStackTrace();
										System.out.println("File can not save any data in outputPathList");
									}

									Document document = dBuilder.parse(tempFile);

									document.getDocumentElement().normalize();

									isPropertyAvailableList = document.getElementsByTagName("isPropertyAvailable");

									tempFile.delete();
								}
							}

							String inputPath = destinationFilePath + "\\" + fileName;
							System.out.println("inputPath: "+inputPath);
							fileToSave = new File(outputPath);
//							System.out.println(allXml);
							try {
								File fileToSaveInTemp= new File(outputPath);
								if (fileToSaveInTemp.exists()) {
									fileToSaveInTemp.delete();
								}
								BufferedWriter fileWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileToSave), StandardCharsets.UTF_8));
								System.out.println("Create "+fileToSave);
								fileWriter.write(allXml);
								fileWriter.close();

							} catch (IOException iox) {
								iox.printStackTrace();
								System.out.println("File can not save any data in BeforeConversion");
							}
							wirteFileFolder = new File(sourceFilePath + "\\" + fileName);
							if (fileToSave.exists()) {
								try {
									if (wirteFileFolder.exists()) {
										wirteFileFolder.delete();
									}
									System.out.println("[COPY] "+fileToSave+" ==> \n\t"+wirteFileFolder);
									transform(fileToSave,"UTF-8",wirteFileFolder,"UTF-8");
								} catch (IOException e1) {
									e1.printStackTrace();
									System.out.println("File can not copy any data in BeforeConversion");
								}
							}
							int countRedoProcess = 0;

							Process p = null;
							File InputPathFileExist = new File(inputPath);

							while (!InputPathFileExist.exists()) {
								System.out.println("[PENDING]"+InputPathFileExist.getAbsolutePath());
								if (countRedoProcess > 3) {
									System.out.println("[RETRY MAX]Error happened and can not convert!");
									errorInputList.add(csvFilePath.getAbsolutePath());
									errorInputList.add("Can not Convert in the Convertor");
									errorHappen = true;
									breakProcess = true;
									countError++;
									break;
								}
								if (countRedoProcess == 0) {
									System.out.println("redo the command process");
								}
								try {
									boolean isFinish = false;
									boolean isFailed = false;
									while (!isFinish) {
										try{    
										    ProcessBuilder pbuilder = new ProcessBuilder( antPath);
										    
										    pbuilder.directory(new File(convertorFilePath) ); // this is where you set the root folder for the executable to run with
										    pbuilder.redirectErrorStream(true);
										    Process process =  pbuilder.start();

										    Scanner s = new Scanner(process.getInputStream());
										    StringBuilder text = new StringBuilder();
										    while (s.hasNextLine()) {
										      text.append(s.nextLine());
										      text.append("\n");
										    }
										    s.close();

										    int result = process.waitFor();
										    if (result == 0) {
										    	System.out.println("********** SUCCESS");
										    	isFinish= true;
										    	break;
										    }
										    
										    if (text.toString().contains("BUILD FAILED")) {
										    	errorInputList.add(csvFilePath.getAbsolutePath());
										    	isFailed = true;
										    	throw new Exception(text.toString());
										    }
										    
										    System.out.printf( "Process exited with result %d and output %s%n", result, text );
										}catch( Exception e) {
											e.printStackTrace();
											if (isFailed) {
												throw new Exception();
											}
										}
									    
									    Thread.sleep(1000);

									}
	
									countRedoProcess++;
									breakProcess = false;
								} catch (Exception e) {
									e.printStackTrace();
									System.out.println("Error happened and can not convert!!");
									errorInputList.add(csvFilePath.getAbsolutePath());
									errorInputList.add(e.toString());
									breakProcess = true;
									errorHappen = true;
									countError++;
								}

							}
							if (countRedoProcess > 1) {
								countRedoTimes++;
							}
							prefixOverrides = (" prefixOverrides=\"and|or|,\"");
							AfterConversion afterConversion = new AfterConversion(inputPath, outputPath,
									convertorFilePath, csvFilePath.getAbsolutePath(), propertyVaribleList,isNotPropertyVaribleList,
									dynamicPrependVaribleList, prefixOverrides);
							if (breakProcess == false) {
								outputPathList.add(outputPath);
							}
							countFile++;

							System.out.println("Input Path " + csvFilePath + " finish, countFile = " + countFile);

							// delete the require file! save file size
							fileToSave = new File(sourceFilePath + "\\" + fileName);
							fileToSave.delete();
							fileToSave = new File(destinationFilePath + "\\" + fileName);
							System.out.println("fileToSave "+fileToSave);
							fileToSave.delete();
						}else {
							System.out.println(csvFilePath+" already converted");
						} 
					} catch (Exception e) {
						System.out.println("Error happened and can not convert!!!");
						errorInputList.add(csvFilePath.getAbsolutePath());
						errorInputList.add(e.toString());
						errorHappen = true;
						countError++;
					}

				}
			}
	}

}