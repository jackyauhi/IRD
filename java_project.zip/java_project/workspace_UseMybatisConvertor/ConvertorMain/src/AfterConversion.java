import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class AfterConversion {
	public static Document doc;

	public AfterConversion(String inputFile, String outputFile, String convertorFilePath, String InputOpeningPath,
			ArrayList<String> propertyVaribleList, ArrayList<String> isNotPropertyVaribleList,ArrayList<String> dynamicPrependVaribleList,
			String prefixOverrides) {
		try {

			String openingDataString = new String();

			String checkCorrectFormal = null;

			try {
				checkCorrectFormal = new String(Files.readAllBytes(Paths.get(inputFile)));
				openingDataString = new String(Files.readAllBytes(Paths.get(InputOpeningPath)));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// String[] keepOpeningFrontData=openingDataString.split("<!DOCTYPE",2);
			// String[] keepOpeningBackData=keepOpeningFrontData[1].split(">",2);
			/*
			 * openingDataString=keepOpeningFrontData[0]
			 * +"<!DOCTYPE mapper PUBLIC '-//mybatis.org//DTD Mapper 3.0//EN'\r\n" +
			 * "  'http://mybatis.org/dtd/mybatis-3-mapper.dtd'>"+keepOpeningBackData[1]; //
			 * "<!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper
			 * 3.0//EN" "http://mybatis.org/dtd/mybatis-3-mapper.dtd">"
			 */
			/* bcfsham */
			openingDataString = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n"
					+ "<!DOCTYPE mapper PUBLIC '-//mybatis.org//DTD Mapper 3.0//EN'\r\n"
					+ "  'http://mybatis.org/dtd/mybatis-3-mapper.dtd'>\n";

			checkCorrectFormal = checkCorrectFormal.replaceAll("\\s*", "");

			if (checkCorrectFormal.contains("<mappernamespace")) {
				File afterConvertFile = new File(inputFile);

				DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
				dbFactory.setValidating(false);
				dbFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);

				DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();

				doc = dBuilder.parse(afterConvertFile);

				doc.getDocumentElement().normalize();

				NodeList docList = doc.getElementsByTagName("mapper");

				NodeList nList = doc.getElementsByTagName("sql");

				String foreachListValueTag = new String();
				String sqlTag = new String();
				String realSqlTag = new String();

				String sampleFormalofListValue = ("<foreach collection=\"itemitem.values\" index=\"index\" item=\"criterionItem\">\r\n"
						+ "           				<if test=\"index == 1\">\r\n"
						+ "           					<foreach collection=\"criterionItem\" separator=\",\" open=\"(\" close=\")\" item=\"criterionItemValue\">\r\n"
						+ "           						#{criterionItemValue}\r\n"
						+ "	            			</foreach>\r\n" + "	            		</if>\r\n"
						+ "           </foreach>");

				TransformerFactory transformerFactory = TransformerFactory.newInstance();
				Transformer transformer = transformerFactory.newTransformer();
				transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");

				DOMSource all = new DOMSource(docList.item(0));
				StreamResult allconsoleResult = new StreamResult(new StringWriter());
				transformer.transform(all, allconsoleResult);
				String allXml = allconsoleResult.getWriter().toString();

				String[] keepFrontData = openingDataString.split("<sqlMap");
				allXml = keepFrontData[0] + allXml;

				for (int temp = 0; temp < nList.getLength(); temp++) {
					Node nNode = nList.item(temp);
					if (nNode.getNodeType() == Node.ELEMENT_NODE) {
						Element eElement = (Element) nNode;
						/* from Example_Where_Clause to lower contains where_clause */
						if (eElement.getAttribute("id").toLowerCase().contains("where_clause")) {
							DOMSource sqlTagSource = new DOMSource(nNode);
							StreamResult sqlTagConsoleResult = new StreamResult(new StringWriter());
							transformer.transform(sqlTagSource, sqlTagConsoleResult);
							sqlTag = sqlTagConsoleResult.getWriter().toString();
							realSqlTag = sqlTagConsoleResult.getWriter().toString();

							if (realSqlTag.contains("and <foreach")) {
								realSqlTag = realSqlTag.replaceAll("and <foreach", "<foreach");
							}
							if (realSqlTag.contains("Value\" item=\"item\"")) {
								realSqlTag = realSqlTag.replaceAll("Value\" item=\"item\"",
										"Value\" item=\"itemitem\"");
							}
							if (realSqlTag.contains("&quot;true&quot;")) {
								realSqlTag = realSqlTag.replaceAll("&quot;true&quot;", "true");
							}
							if (realSqlTag.contains("&quot;false&quot;")) {
								realSqlTag = realSqlTag.replaceAll("&quot;false&quot;", "false");
							}
							Pattern addTrimPattern = Pattern.compile(
									"<if\\s*test\\s*=\\s*\"\\s*item\\s*!=\\s*null\\s*and\\s*item.valid\\s*==\\s*([a-zA-Z]*)\"\\s*>\\s*((\r\n)|(\n)|(\r))*\\s*[(]");
							Matcher addTrimMatcher = addTrimPattern.matcher(realSqlTag);
							String trimTag =  "<trim prefixOverrides=\"and|or|,\">";
							if (addTrimMatcher.find()) {
								String booleanValue = addTrimMatcher.group(1);
								realSqlTag = addTrimPattern.matcher(realSqlTag).replaceAll(Matcher.quoteReplacement(
										"<if test=\"item != null and item.valid == " + booleanValue + "\">\r\n"
												+ "        (\r\n" + "        "+trimTag));
								// System.out.println("booleanValue = "+booleanValue);
							}

							Pattern addCloseTrimPattern;
							Matcher addCloseTrimMatcher;

//							addCloseTrimPattern = Pattern.compile("[)]\\s*((\r\n)|(\n)|(\r))*\\s*</trim>");
//							addCloseTrimMatcher = addCloseTrimPattern.matcher(realSqlTag);
//							if (addCloseTrimMatcher.find()) {
//								realSqlTag = addCloseTrimPattern.matcher(realSqlTag)
//										.replaceAll(")\r\n" + "        </trim>");
//							}

							addCloseTrimPattern = Pattern.compile("[)]\\s*((\r\n)|(\n)|(\r))*\\s*</if>");
							addCloseTrimMatcher = addCloseTrimPattern.matcher(realSqlTag);
							if (addCloseTrimMatcher.find()) {
								String trimClause = "";
								if (realSqlTag.contains(trimTag)) {
									trimClause = "        </trim>\r\n";
								}
								realSqlTag = addCloseTrimPattern.matcher(realSqlTag)
										.replaceAll(")\r\n" + trimClause+"      </if>");
							}
							List<String> allMatches = new ArrayList<String>();
							Pattern removeSeparatorPattern = Pattern.compile(
									"<foreach\\s*collection\\s*=\\s*\"\\s*([a-zA-Z0-9.]+)\\s*\"\\s*item\\s*=\\s*\"\\s*itemitem\\s*\"\\s*separator\\s*=\\s*\"\\s*([a-zA-Z0-9.,]+)\\s*\"\\s*>");
							Matcher removeSeparatorMatcher = removeSeparatorPattern.matcher(realSqlTag);
							while (removeSeparatorMatcher.find()) {
								allMatches.add(removeSeparatorMatcher.group());
							}
							for (int i = 0; i < allMatches.size(); i++) {
								removeSeparatorMatcher = removeSeparatorPattern.matcher(allMatches.get(i).toString());
								if (removeSeparatorMatcher.find()) {
									String collectionValue = removeSeparatorMatcher.group(1);
									String separatorValue = removeSeparatorMatcher.group(2);
									realSqlTag = realSqlTag.replaceAll(Pattern.quote(allMatches.get(i).toString()),
											Matcher.quoteReplacement("<foreach collection=\"" + collectionValue
													+ "\" item=\"itemitem\">" + separatorValue));
								}
							}

							if (allXml.contains(sqlTag)) {
								allXml = allXml.replaceAll(Pattern.quote(sqlTag), Matcher.quoteReplacement(realSqlTag));
							}
							NodeList requireList = eElement.getElementsByTagName("foreach");
							for (int j = 0; j < requireList.getLength(); j++) {
								Node requireNode = requireList.item(j);
								if (requireNode.getNodeType() == requireNode.ELEMENT_NODE) {
									Element requireElement = (Element) requireNode;
									if (requireElement.getAttribute("collection").equals("itemitem.values")) {
										DOMSource source = new DOMSource(requireNode);
										StreamResult consoleResult = new StreamResult(new StringWriter());
										transformer.transform(source, consoleResult);
										foreachListValueTag = consoleResult.getWriter().toString();
										if (allXml.contains(foreachListValueTag)) {
											allXml = allXml.replaceAll(Pattern.quote(foreachListValueTag),
													sampleFormalofListValue);
										}
									}
								}
							}
						}
					}
				}
				if (allXml.contains("&quot;true&quot;")) {
					allXml = allXml.replaceAll("&quot;true&quot;", "true");
				}
				if (allXml.contains("&quot;false&quot;")) {
					allXml = allXml.replaceAll("&quot;false&quot;", "false");
				}
				Pattern p = Pattern.compile("#([a-zA-Z0-9_]+)(:?[a-zA-Z0-9]+)#");
				allXml = p.matcher(allXml).replaceAll("#{$1}");
				Pattern p1 = Pattern.compile("#([^\\s_]+):([a-zA-Z0-9]+)#");
				allXml = p1.matcher(allXml).replaceAll("#{$1}");
				List<String> alljdbcTypeMatches = new ArrayList<String>();
				Pattern jdbcTypePattern = Pattern.compile("jdbcType\\s*[=]\\s*\"\\s*([a-zA-Z]+)\\s*\"");
				Matcher jdbcTypeMatcher = jdbcTypePattern.matcher(allXml);
				while (jdbcTypeMatcher.find()) {
					alljdbcTypeMatches.add(jdbcTypeMatcher.group());
				}
				/* bcfsham fix typo START */
				alljdbcTypeMatches.add("DECIMAL");
				/* bcfsham fix typo END */
				for (int i = 0; i < alljdbcTypeMatches.size(); i++) {
					jdbcTypeMatcher = jdbcTypePattern.matcher(alljdbcTypeMatches.get(i).toString());
					if (jdbcTypeMatcher.find()) {
						String jdbcTypeValue = jdbcTypeMatcher.group(1);
						if (jdbcTypeValue.equalsIgnoreCase("LONG"))
							allXml = allXml.replaceAll(Pattern.quote(alljdbcTypeMatches.get(i).toString()),
									Matcher.quoteReplacement("jdbcType=\"BIGINT\""));
						else if (jdbcTypeValue.equalsIgnoreCase("String"))
							allXml = allXml.replaceAll(Pattern.quote(alljdbcTypeMatches.get(i).toString()),
									Matcher.quoteReplacement("jdbcType=\"VARCHAR\""));
					}
				}

				if (allXml.contains("<!--<isParameterPresent>-->")) {
					allXml = allXml.replaceAll("<!--<isParameterPresent>-->", "<if test=\"_parameter != null\">");
				}
				if (allXml.contains("<!--</isParameterPresent>-->")) {
					allXml = allXml.replaceAll("<!--</isParameterPresent>-->", "</if>");
				}
				if (allXml.contains("<!--<isNotParameterPresent>-->")) {
					allXml = allXml.replaceAll("<!--<isNotParameterPresent>-->", "<if test=\"_parameter == null\">");
				}
				if (allXml.contains("<!--</isNotParameterPresent>-->")) {
					allXml = allXml.replaceAll("<!--</isNotParameterPresent>-->", "</if>");
				}
				for (int j = 0; j < propertyVaribleList.size(); j++) {
					/* bcfsham remove jdbctype (if exists) from condition variable START */
					String[] keepData = propertyVaribleList.get(j).toString().split(",splitData,", 2);
					String propertyVariableWithPrepend =keepData[1];
					String propertyVariableWithJdbcType = keepData[0];
					String propertyVariableWithoutJdbcType = null;
					if (propertyVariableWithJdbcType.indexOf(":") != -1) {
						propertyVariableWithoutJdbcType = propertyVariableWithJdbcType.substring(0,
								propertyVariableWithJdbcType.indexOf(":"));
					} else {
						propertyVariableWithoutJdbcType = propertyVariableWithJdbcType;
					}

					if (allXml.contains("<!--<if test=\"" + propertyVariableWithJdbcType + "!=null\"><trim prefix=\""+propertyVariableWithPrepend+"\">-->")) {
						allXml = allXml.replaceAll(
								Pattern.quote("<!--<if test=\"" + propertyVariableWithJdbcType + "!=null\"><trim prefix=\""+propertyVariableWithPrepend+"\">-->"),
								Matcher.quoteReplacement(
										"<if test=\"" + propertyVariableWithoutJdbcType + "!=null\"><trim prefix=\""+propertyVariableWithPrepend+"\">"));
					}

					if (allXml.contains("<if test=\"" + propertyVariableWithJdbcType + "!=null\"><trim prefix=\""+propertyVariableWithPrepend+"\">")) {
						allXml = allXml.replaceAll(
								Pattern.quote("<if test=\"" + propertyVariableWithJdbcType + "!=null\"><trim prefix=\""+propertyVariableWithPrepend+"\">"),
								Matcher.quoteReplacement(
										"<if test=\"" + propertyVariableWithoutJdbcType + "!=null\"><trim prefix=\""+propertyVariableWithPrepend+"\">"));
					}
					/* bcfsham remove jdbctype (if exists) from condition variable END */
				}
				for (int j = 0; j < isNotPropertyVaribleList.size(); j++) {
					String[] keepData = isNotPropertyVaribleList.get(j).toString().split(",splitData,", 2);
					String propertyVariableWithPrepend =keepData[1];
					String propertyVariableWithJdbcType = keepData[0];
					String propertyVariableWithoutJdbcType = null;
					if (propertyVariableWithJdbcType.indexOf(":") != -1) {
						propertyVariableWithoutJdbcType = propertyVariableWithJdbcType.substring(0,
								propertyVariableWithJdbcType.indexOf(":"));
					} else {
						propertyVariableWithoutJdbcType = propertyVariableWithJdbcType;
					}

					if (allXml.contains("<!--<if test=\"" + propertyVariableWithJdbcType + "==null\"><trim prefix=\""+propertyVariableWithPrepend+"\">-->")) {
						allXml = allXml.replaceAll(
								Pattern.quote("<!--<if test=\"" + propertyVariableWithJdbcType + "==null\"><trim prefix=\""+propertyVariableWithPrepend+"\">-->"),
								Matcher.quoteReplacement(
										"<if test=\"" + propertyVariableWithoutJdbcType + "==null\"><trim prefix=\""+propertyVariableWithPrepend+"\">"));
					}

					if (allXml.contains("<if test=\"" + propertyVariableWithJdbcType + "==null\"><trim prefix=\""+propertyVariableWithPrepend+"\">")) {
						allXml = allXml.replaceAll(
								Pattern.quote("<if test=\"" + propertyVariableWithJdbcType + "==null\"><trim prefix=\""+propertyVariableWithPrepend+"\">"),
								Matcher.quoteReplacement(
										"<if test=\"" + propertyVariableWithoutJdbcType + "==null\"><trim prefix=\""+propertyVariableWithPrepend+"\">"));
					}
				}
				for (int j = 0; j < dynamicPrependVaribleList.size(); j++) {
					if (allXml.contains("<!--<trim prefix=\"" + dynamicPrependVaribleList.get(j).toString() + "\""
							+ prefixOverrides + ">-->")) {
						allXml = allXml.replaceAll(
								Pattern.quote("<!--<trim prefix=\"" + dynamicPrependVaribleList.get(j).toString() + "\""
										+ prefixOverrides + ">-->"),
								Matcher.quoteReplacement("<trim prefix=\"" + dynamicPrependVaribleList.get(j).toString()
										+ "\"" + prefixOverrides + ">"));
					}

					else if (allXml
							.contains("<!--<trim prefix=\"" + dynamicPrependVaribleList.get(j).toString() + "\">-->")) {
						allXml = allXml.replaceAll(
								Pattern.quote(
										"<!--<trim prefix=\"" + dynamicPrependVaribleList.get(j).toString() + "\">-->"),
								Matcher.quoteReplacement(
										"<trim prefix=\"" + dynamicPrependVaribleList.get(j).toString() + "\">"));
					}

				}
				if (allXml.contains("<!--</trim></if>-->")) {
					allXml = allXml.replaceAll("<!--</trim></if>-->", "</trim></if>");
				}
				if (allXml.contains("<!--</trim>-->")) {
					allXml = allXml.replaceAll("<!--</trim>-->", "</trim>");
				}
				if (allXml.contains("<!--</if>-->")) {
					allXml = allXml.replaceAll("<!--</if>-->", "</if>");
				}
				if (allXml.contains("DECIAML")) {
					allXml = allXml.replaceAll("DECIAML", "DECIMAL");
				}

				// System.out.println(allXml);
				try {
					FileWriter fileWriter = new FileWriter(outputFile);

					fileWriter.write(allXml);
					fileWriter.close();
				} catch (IOException iox) {
					iox.printStackTrace();
					System.out.println("File can not save any data in AfterConversion");
				}
			} // if allXml.contains("<mapper namespace")
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("File error happen in AfterConversion");
		}

	}

}