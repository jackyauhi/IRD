

/**
 *
 ******************************************************************************
 * Amendment log
 * -------------
 * 
 * Ref no.    Date       Amended by     Description
 * -------  ----------   ----------     ---------------------------------------
 *                                                                         
 ******************************************************************************
 *
 */

public class PunValidator {
	
	static final String DEFAULT_ERROR_CODE = "message.1177";
	static final int TOTAL_PUN_LENGTH = 14;

	public static ValidationResult validate(String PUN) {
		
		int errorCode = IrdValidConstant.NORMAL_PUN;
	
		if (StringUtils.isEmpty(PUN))
			return new ValidationResult(true, "", errorCode, "");

		String formattedPun = StringUtils.leftPad(PUN, '0', TOTAL_PUN_LENGTH - PUN.length());

		if ((formattedPun.length() != 14) && (formattedPun.length() != 0))
			errorCode = IrdValidConstant.INVALID_PUN;
		
		String pun = generate(PUN);	
		if (!PUN.equalsIgnoreCase(pun))
			errorCode = IrdValidConstant.INVALID_PUN;

		return new ValidationResult((errorCode == IrdValidConstant.NORMAL_PUN), formattedPun, errorCode, DEFAULT_ERROR_CODE);
	}

	public static String generate(String PUN) {
		
		String PUN_N = null, PUNUnitCode = null;
		char[] arrayPUN;
		short unit = 0;

		try {
			PUN_N = PUN.substring(0, 12);
			PUNUnitCode = PUN.substring(12, 13).toUpperCase();
		} catch (Throwable t) {
			return "Error";
		}

		// Numeric check
		try {
			Long.parseLong(PUN_N);
		} catch (NumberFormatException e) {
			return "Error";
		}
			
		// Prepare Unit Code information
		try {
			Short.parseShort(PUNUnitCode);
		} catch (NumberFormatException e) {
			// ASCII value for 'A' to 'Z' is 65 to 90
			if ((PUNUnitCode.getBytes()[0] < 65)
				|| (PUNUnitCode.getBytes()[0] > 90)
				|| PUNUnitCode.equals("I")
				|| PUNUnitCode.equals("O")
				|| PUNUnitCode.equals("Z")) {
					return "Error";
			}
		}

		if (!PUNUnitCode.equals("0")) {
			if (Character.isDigit(PUNUnitCode.charAt(0)))
				unit = Short.parseShort(PUNUnitCode);
			switch (PUNUnitCode.charAt(0)) {
				case 'A':
				case 'K':
				case 'U':
					unit = 1;
					break;
				case 'B':
				case 'L':
				case 'V':
					unit = 2;
					break;
				case 'C':
				case 'M':
				case 'W':
					unit = 3;
					break;
				case 'D':
				case 'N':
				case 'X':
					unit = 4;
					break;
				case 'E':
				case 'O':
				case 'Y':
					unit = 5;
					break;
				case 'F':
				case 'P':
				case 'Z':
					unit = 6;
					break;
				case 'G':
				case 'Q':
					unit = 7;
					break;
				case 'H':
				case 'R':
					unit = 8;
					break;
				case 'I':
				case 'S':
					unit = 9;
					break;
				case 'J':
				case 'T':
					unit = 0;
					break;
				default:
					break;
			}
			if (PUNUnitCode.charAt(0) > 'S')
				unit += 20;
			else if (PUNUnitCode.charAt(0) > 'I')
				unit += 10;
		}
		arrayPUN = PUN_N.toCharArray();
		short total = 0;
		for (int i = 0; i < arrayPUN.length; i++) {
			if (i < 4)
				total += (Integer.parseInt(String.valueOf(arrayPUN[i]))) * (5 - i);
			else
				total += (Integer.parseInt(String.valueOf(arrayPUN[i]))) * (14 - i);
		}
		total += (unit * 2);

		int remainder = total % 11;
		if (remainder < 0)
			remainder += 11;

		String checkDigit;
		if (remainder == 10)
			checkDigit = "A";
		else
			checkDigit = Integer.toString(remainder);

		return PUN_N + PUNUnitCode + checkDigit;
	}
}
