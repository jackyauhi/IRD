

/**
 * 
 * @author mliu
 *
 *******************************************************************************
 * Amendment log
 * -------------
 * 
 * Ref no.    Date       Amended by     Description
 * -------  ----------   ----------     ---------------------------------------
 * N/A      03.07.2018    YC WANG       Add new constant for case no. and 
 *                                      PD ref no.
 *                                                                
 * N/A      12.07.2018    bcfsham       Add new constant for BRC no.
 *                                                                         
 ******************************************************************************
 */
public class IrdValidConstant {
	
	public static final int NORMAL_BRN = 0;
	public static final int INVALID_BRN = 2;
	public static final int INVALID_BRN_CHECK_DIGIT = 5;

	public static final int NORMAL_PRN = 0;
	public static final int INVALID_PRN = 1;
	public static final int INVALID_PRN_CHECK_DIGIT = 2;
	public static final int DUMMY_PRN = 3;
	
	public static final int NOTBLANK = 0;
	public static final int BLANK = 1;
	
	public static final int NORMAL_PUN = 0;
	public static final int INVALID_PUN = 1;
	public static final int INVALID_PUN_CHECK_DIGIT = 2;
	
	public static final int NORMAL_DEC = 0;
	public static final int WRONG_DEC_PT_PLACE = 1;
	public static final int NOT_NUM_AFTER_FRIST_DEC = 3;
	public static final int NOT_NUM_AFTER_SECOND_DEC = 2;
	public static final int NOT_NUM_AFTER_DEC = 4;
	public static final int NOT_NUM = 5;
	
	public static final int NORMAL_INT = 0;
	public static final int WITH_DEC = 1;
	public static final int WITH_SIGN = 6;
	
	public static final int NORMAL_DATE = 0;
	public static final int INVALID_DATE = 1;
	
	public static final int NORMAL_CHRG = 0;
	public static final int INVALID_CHRG_TAX_TYPE = 2;
	public static final int INVALID_CHRG_CHRGNO = 3;
	public static final int INVALID_CHRG_ASS_YEAR = 4;
	public static final int INVALID_CHRG_CHECK_DIGIT = 5;
	
	public static final int NORMAL_USER = 0;
	public static final int INVALID_USER = 1;
	
	public static final int ALPHA_NUMERIC = 0;
	public static final int NON_ALPHA_NUMERIC = 1;
	public static final int CHINESE_INPUT = 2;
	
	public static final int NORMAL_BRH_NO = 0;
	public static final int INPUT_FILED_MISSING = 1;
	public static final int INVALID_BRH_NO = 2;
	
	public static final int VALID_NAME = 0;
	public static final int INVALID_NAME = 1;
	public static final int INPUT_NAME_LENGTH = 27;
	
	public static final int VALID_NONDB_CHRG = 0;
	public static final int INVALID_NONDB_CHRG = 1;
	
	public static final int NORMAL_IRN = 0;
	public static final int INVALID_IRN = 1;
	public static final int INVALID_IRN_CHECK_DIGIT = 2;
	
	public static final int NORMAL_CASE_NO = 0;
	public static final int INVALID_CASE_NO = 1;
	
	public static final int NORMAL_PD_REF_NO = 0;
	public static final int INVALID_PD_REF_NO = 1;
	//
	public static final int NORMAL_BRC_NO = 0;
	public static final int INVALID_BRC_NO = 1;
	public static final int INVALID_BRC_BRN = 2001;
	public static final int INVALID_BRC_BRN_CHECK_DIGIT = 5000;
	public static final int INVALID_BRC_BRANCH_NO = 5003;
	public static final int INVALID_BRC_REG_MONTH = 5004;
	public static final int INVALID_BRC_REG_YEAR = 5005;
	public static final int INVALID_BRC_BLANK_CHECK_DIGIT = 2055;
	public static final int INVALID_BRC_CHECK_DIGIT = 5006;
}
