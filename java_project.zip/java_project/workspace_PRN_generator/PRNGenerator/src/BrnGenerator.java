import java.util.Random;

public class BrnGenerator {
	
	private static String generateSum(int[] key, int[] brn){
		int sum = 0;
		for(int i = 0; i<8;i++){
			sum += key[i]*brn[i];
		}
		return sum%10+"";
	}
	
	private static int generateDigit(Random rnd){
		int digit = rnd.nextInt(7) + 2;
		int output = 1;
		//System.out.print(digit);
		for(int i=0;i<digit;i++){
			output *= 10;
		}
		//System.out.println(" " + output);
		return output;
	}
	
	private static String generateBRN(Random rnd){
		int digit = generateDigit(rnd);
		int brnInt = rnd.nextInt(digit);
		while(brnInt<10){
			brnInt = rnd.nextInt(digit);
		}
		String brn =  String.format("%s",brnInt);
		
		int[] BRN_WEIGHT_TABLE = {0,8,1,2,3,6,7,8};
		int[] BRN_TABLE = new int[8];
		
		//----------prepare brn, convert string to int array------
		
		int brnLength = brn.length();
		
		for(int i = brnLength;i<8;i++ ){
			brn = "0" + brn;
		}
		
		//System.out.println("num: " + brn);
		
		for(int i=0;i<8;i++){
			BRN_TABLE[i] = Integer.valueOf(brn.charAt(i)+"");
		}
		
		String checkedBrn = brn + generateSum(BRN_WEIGHT_TABLE, BRN_TABLE);
		
		return Integer.parseInt(checkedBrn)+"";
	}
	
	/*public static void main(String[] args) throws Exception{
		
		Random rnd = new Random();
		
		for(int i=0;i<100;i++){
		String brn = generateBRN(rnd);
		System.out.println("brn: "+ brn);
		
		if(!BrnValidator.validate(brn).isSuccess()){
			System.out.println("BRN not Success");
			
		}
		else{
			System.out.println("BRN Success");
		}
		}
	}*/
	public static String generate() throws Exception{
		Random rnd = new Random();
		String brn = generateBRN(rnd);
		return brn;
	}
}