public class callTestPrnGenerator {
	
	public static void main(String[] args) throws Exception{
		/*
		String brn=new String();
		for(int i=0;i<100;i++){
		brn=BrnGenerator.generate();
		if(!BrnValidator.validate(brn).isSuccess()){
			
			System.out.println("brn not Success");
			
		}
		else{
			System.out.println("brn Success");
		}
		System.out.println("brn =" + brn);
		System.out.println("---------------------------------------------------");
		}
		*/
		//System.out.println("prn =" + prn);
		 //{0,8,1,2,3,6,7,8};
		//int[] BRN_WEIGHT_TABLE = {0,8,1,2,3,6,7,8};
		//int TOTAL_BRN_LENGTH = 9;
		//String brn="19578";
		//String brn="181";
		
		//String formattedBrn = StringUtils.leftPad(brn, '0', TOTAL_BRN_LENGTH - brn.length());
	//	String see1 =String.format("%07d",12345);
	//	String str = String.format("%8s","Apple");
	//	str = str.replace(' ','0');
		//String see=String.format("%0"+ (8 - "Apple".length() )+"d%s",0 ,"Apple");
		
	//	System.out.println("BRN_WEIGHT_TABLE.length =" +BRN_WEIGHT_TABLE.length);
	//	System.out.println("formattedBrn =" +formattedBrn);
	//	System.out.println("see =" +see);
	//	System.out.println("see1 =" +see1);
		

		
		//first 12 number, multiple 0,1,2,3,10,9,8,7,6,5,4,3 -->total
		//second 1 number-->unit,  total+(unit*2)--> new total
		//third new total%11 = remainder if =10, then = A
		//formal 12 + 1 + 1
		//14454681592194
		for(int i=0;i<1000;i++){
		//String pun="11023805175350";
		String pun=PunGenerator.generate();
		if(!PunValidator.validate(pun).isSuccess()){
			System.out.println("pun not Success");
			
		}
		else{
			System.out.println("pun Success");
		}
		
		System.out.println("pun =" + pun);
		}
	}
}