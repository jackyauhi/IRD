

import java.io.UnsupportedEncodingException;
import java.text.NumberFormat;
import java.text.ParsePosition;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.lang.StringEscapeUtils;

/**
 * 
 * @author mliu
 * 
 *
 *
 ******************************************************************************
 * Amendment log
 * -------------
 * 
 * Ref no.    Date       Amended by     Description
 * -------  ----------   ----------     ---------------------------------------
 * N/A      07.05.2015   Man Liu		add leftPadByMaxByte method
 * 
 * N/A		02.07.2015	 Man Liu		add new method "isEmptyWithFullWidthSpace" 
 * 										to support trimming full-width character
 * 
 * N/A      08.07.2015   Hailey Yau     add toNbsp method                  
 * 
 * N/A		08.07.2015	 Man Liu		add new method convertToEmptyStringIfNull
 * 
 * N/A		06.10.2016	 Sincere Tsang  add rightPadByMax method and rightPadByMaxByte method
 * 
 * N/A      08.12.2016   Janice Leung   add getFirstXBytes method
 * 		                                       
 ******************************************************************************
 */
public class StringUtils {
	public static boolean isNumeric(String str){
	  NumberFormat formatter = NumberFormat.getInstance();
	  ParsePosition pos = new ParsePosition(0);
	  formatter.parse(str, pos);
	  
	  return str.length() == pos.getIndex();
	}
	
	public static String leftPadByMax(String str, char charToPad, int maxCharacters){
		StringBuffer sb = new StringBuffer();
		int numberOfCharToAdd = maxCharacters - str.length();
		if(numberOfCharToAdd < 1){
			numberOfCharToAdd = 0;
		}
		for(int i=0; i<numberOfCharToAdd; i++){
			sb.append(charToPad);
		}
		
		return sb.toString()+str;
	}
	
	public static String rightPadByMax(String str, char charToPad, int maxCharacters){
		StringBuffer sb = new StringBuffer();
		int numberOfCharToAdd = maxCharacters - str.length();
		if (numberOfCharToAdd < 1) {
			numberOfCharToAdd = 0;
		}
		for (int i=0; i<numberOfCharToAdd; i++) {
			sb.append(charToPad);
		}
		return str + sb.toString();
	}
	
	public static String leftPadByMaxByte(String str, char charToPad, int maxBytes) throws UnsupportedEncodingException{
		StringBuffer sb = new StringBuffer();
		int numberOfCharToAdd = maxBytes - str.getBytes("UTF-8").length;
		if(numberOfCharToAdd < 1){
			numberOfCharToAdd = 0;
		}
		for(int i=0; i<numberOfCharToAdd; i++){
			sb.append(charToPad);
		}
		return sb.toString()+str;
	}
	
	public static String rightPadMaxByte(String str, char charToPad, int maxBytes) throws UnsupportedEncodingException{
		StringBuffer sb = new StringBuffer();
		int numberOfCharToAdd = maxBytes - str.getBytes("UTF-8").length;
		if (numberOfCharToAdd < 1) {
			numberOfCharToAdd = 0;
		}
		for (int i=0; i<numberOfCharToAdd; i++) {
			sb.append(charToPad);
		}
		return str + sb.toString();
	}
	
	public static String leftPad(String str, char charToPad, int nofPad){
		StringBuffer sb = new StringBuffer();
		for(int i=0; i<nofPad; i++){
			sb.append(charToPad);
		}
		
		return sb.toString()+str;
	}
	
	public static String rightPad(String str, char charToPad, int nofPad){
		StringBuffer sb = new StringBuffer();
		for(int i=0; i<nofPad; i++){
			sb.append(charToPad);
		}
		
		return str+sb.toString();
	}
	
	public static String toCamelCase(String s) {
		String[] parts = s.split("_");
		String camelCaseString = "";
		for (String part : parts) {
			camelCaseString = camelCaseString + toProperCase(part);
		}
		return camelCaseString;
	}

	public static String toProperCase(String s) {
		return s.substring(0, 1).toUpperCase() + s.substring(1).toLowerCase();
	}
	
	public static boolean isAtoZ (char c) {
		return (c >= 'A') && (c <= 'Z');
	}
	
	public static boolean isAtoZ (String data, int init, int end){
		
			for (int i = init; i < end; i++) {
				if (data.charAt(i) < 'A' || data.charAt(i) > 'Z') 
					return false;
			}
		
		return true;
	}
		
	public static boolean isNumeric (char c) {
		return (c >= '0') && (c <= '9');
	}
	
	public static boolean isNumeric (String data, int init, int end) {
		
			for (int i = init; i < end; i++) {
				if (data.charAt(i) < '0' || data.charAt(i) > '9') 
					return false;
			}

		return true;
	}
	
	public static boolean ishaspoint (String data, int init, int end){
		int cnt_point=0;
		for (int i = init; i < end; i++) {
			if (data.charAt(i) < '.' ) 
				cnt_point++;
		}
			if (cnt_point==1)
				return true;
			else
				return false;	
	}
	
	public static boolean isdecformat(String data){
		int dec;
		dec = data.length()-data.indexOf(".");
		if (dec==2)
			return true;
		else
			return false;
	}
	
	public static boolean isEmpty(String s) {
		if ((s != null) && (s.trim().length() > 0))
	        return false;
	    else
	        return true;
	}
	
	public static boolean isEmptyWithFullWidthSpace(String s) {
	    if ((s != null) && (trimFullWidthSpace(s).length() > 0))
	        return false;
	    else
	        return true;
	}
	
	public static String toNonNullString(String s) {
		if (s == null)
			return "";
		return s;
	}
	
	public static boolean isStartingWith(String s, String[] compareStringArr){
		boolean isStarting = false;
		
		if(!isEmpty(s)){
			for(String compareString : compareStringArr){
				if(s.startsWith(compareString)){
					isStarting = true;
					break;
				}
			}
		}
		
		return isStarting;
	}
	
	public static boolean isTrue(String s){
		boolean result = false;
		if(!isEmpty(s)){
			s = s.trim();
			if("YES".equalsIgnoreCase(s) || "Y".equalsIgnoreCase(s)){
				result = true;
			}
		}
		
		return result;
	}
	
	public static String jsEncode(String s) {
		StringBuffer sb = new StringBuffer();
		
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			
			if (c == '"') {
				sb.append("&quot;");
			} else if (c == '\\') {
				sb.append("\\\\");
			} else if (c == '\'') {
				sb.append("\\\'");
			} else {
				sb.append(c);
			}
		}
		
		return sb.toString();
	}
	
	public static String htmlEncodeForUnicode(String input) {
		
		StringBuffer sb = new StringBuffer();
		int codepoint = 0;
		for (int i = 0; i < input.length(); i++) {
			if (Character.isHighSurrogate(input.charAt(i)) && (i < input.length() - 1)) {
				codepoint = Character.toCodePoint(input.charAt(i), input.charAt(i + 1));
				int[] codePts = {codepoint};
				sb.append(new String(codePts, 0, 1));
			} else if (Character.isLowSurrogate(input.charAt(i))) {
				continue;
			} else {
				sb.append(StringEscapeUtils.escapeHtml(Character.toString(input.charAt(i))));
			}
		}
		return sb.toString();
	}
	
	public static String trimFullWidthSpace(String input, String trimOption) {
		
		StringBuffer sb = new StringBuffer();
		int codepoint = 0;
		for (int i = 0; i < input.length(); i++) {
			if (Character.isHighSurrogate(input.charAt(i)) && (i < input.length() - 1)) {
				codepoint = Character.toCodePoint(input.charAt(i), input.charAt(i + 1));
				int[] codePts = {codepoint};
				sb.append(new String(codePts, 0, 1));
			} else if (Character.isLowSurrogate(input.charAt(i))) {
				continue;
			} else {
				char tmpChar;
				if (input.charAt(i) == 0x3000)
					tmpChar = 0x20;
				else
					tmpChar = input.charAt(i);
				sb.append(tmpChar);
			}
		}
		
		String result = null;
		if ("L".equalsIgnoreCase(trimOption)) {
			result = sb.toString().replaceAll("^\\s+","");
		} else if ("R".equalsIgnoreCase(trimOption)) {
			result = sb.toString().replaceAll("\\s+$","");
		} else {
			result = sb.toString().trim();
		}
		
		sb = new StringBuffer();
		for (int j = 0; j < result.length(); j++) {
			char tmpChar;
			if (result.charAt(j) == 0x20) {
				tmpChar = 0x3000;
			} else {
				tmpChar = result.charAt(j);
			}
			sb.append(tmpChar);
		}
		return sb.toString();
	}
	
	public static String trimFullWidthSpace(String input) {
		return trimFullWidthSpace(input, "");
	}
	
	public static String replaceGroup(String regex, String source, int groupToReplace, String replacement) {
	    return replaceGroup(regex, source, groupToReplace, 1, replacement);
	}

	public static String replaceGroup(String regex, String source, int groupToReplace, int groupOccurrence, String replacement) {
	    Matcher m = Pattern.compile(regex).matcher(source);
	    for (int i = 0; i < groupOccurrence; i++)
	        if (!m.find()) return source;
	    
	    return new StringBuilder(source).replace(m.start(groupToReplace), m.end(groupToReplace), replacement).toString();
	}
	
	/**
	 * @author mliu
	 * @param input string of english / non-english
	 * @return string array of each characters / non-english characters
	 * @throws Exception
	 */
	public static String[] getStringArrayByNonEnglishString(String input) throws Exception{
		List<String> strList = new ArrayList<String>();
		
		for (int i = 0; i < input.length(); i++){
			int codepoint = 0;
			if (Character.isHighSurrogate(input.charAt(i)) && (i < input.length() - 1)){
				codepoint = Character.toCodePoint(input.charAt(i), input.charAt(i + 1));
			}
			else if (Character.isLowSurrogate(input.charAt(i))){
				continue;
			}
			else{
				codepoint = Character.codePointAt(input, i);
			}
			
			strList.add(new String(new int[]{codepoint}, 0, 1));
		}
		
		return strList.toArray(new String[strList.size()]);
	}
	
	/**
	 * @author mliu
	 * @param input string of english / non-english
	 * @return number of characters
	 * @throws Exception
	 */
	@SuppressWarnings("unused")
	public static int getStringCountByNonEnglishString(String input) throws Exception{
		int count = 0;
		
		for (int i = 0; i < input.length(); i++){
			int codepoint = 0;
			if (Character.isHighSurrogate(input.charAt(i)) && (i < input.length() - 1)){
				codepoint = Character.toCodePoint(input.charAt(i), input.charAt(i + 1));
			}
			else if (Character.isLowSurrogate(input.charAt(i))){
				continue;
			}
			else{
				codepoint = Character.codePointAt(input, i);
			}
			
			count++;
		}
		
		return count;
	}
	
	public static String leftPadSpaceWithCalculatedLength(String string, int longestValue){
		if(!StringUtils.isEmpty(string)){
			int spacingToAdd = 0;
			int stringLength = string.length();
			if(longestValue > stringLength){
				spacingToAdd = longestValue - stringLength;
			}
			
			return StringUtils.leftPad(string, ' ', spacingToAdd);
		}
		
		return "";
	}
	
	public static String rightPadSpaceWithCalculatedLength(String string, int longestValue){
		if(!StringUtils.isEmpty(string)){
			int spacingToAdd = 0;
			int stringLength = string.length();
			if(longestValue > stringLength){
				spacingToAdd = longestValue - stringLength;
			}
			
			return StringUtils.rightPad(string, ' ', spacingToAdd);
		}
		
		return "";
	}
	
	public static String rightPadSpaceWithCalculatedLength(String string, int longestValue, boolean disableEmptyChecking){
		boolean isEmpty = StringUtils.isEmpty(string);

		if(disableEmptyChecking){
			isEmpty = false;
		}
		
		if(!isEmpty){
			int spacingToAdd = 0;
			int stringLength = string.length();
			if(longestValue > stringLength){
				spacingToAdd = longestValue - stringLength;
			}
			
			return StringUtils.rightPad(string, ' ', spacingToAdd);
		}
		
		return "";
	}
	
	public static String leftPadCharWithCalculatedLength(String string, char charToBePadded, int longestValue){
		return padCharWithCalculatedLength("left", string, charToBePadded, longestValue);
	}
	
	public static String rightPadCharWithCalculatedLength(String string, char charToBePadded, int longestValue){
		return padCharWithCalculatedLength("right", string, charToBePadded, longestValue);
	}
	
	private static String padCharWithCalculatedLength(String padType, String string, char charToBePadded, int longestValue) {
		if(!StringUtils.isEmpty(string)){
			int spacingToAdd = 0;
			int stringLength = string.length();
			if(longestValue > stringLength){
				spacingToAdd = longestValue - stringLength;
			}
			
			if(padType.equals("left")){
				return StringUtils.leftPad(string, charToBePadded, spacingToAdd);
			}
			else{
				return StringUtils.rightPad(string, charToBePadded, spacingToAdd);
			}
			
		}
		
		return "";
	}
	
	/***********************************************
	 * To replace the substring regardless of regular expression pattern
	 ***********************************************/
	public static String exactReplace(String s, String oldstr, String newstr) {
		if ((oldstr == null) || oldstr.equals("") || (newstr == null) || (s == null) || s.equals("")) 
			return s;
		String result = "";
		int pos = 0;
		int offset = 0;
		do {
			pos = s.indexOf(oldstr, offset);
			if (pos > -1) {
				result += s.substring(offset, pos) + newstr;
				offset = pos + oldstr.length();
				if (offset >= s.length()) break;
			} else {
				result += s.substring(offset, s.length());
			}
		} while (pos > -1);
		return result;
	}
	
	/***********************************************
	 * To replace the first occurrence of substring regardless of regular expression pattern
	 ***********************************************/
	public static String exactReplaceFirst(String s, String oldstr, String newstr) {
		if ((oldstr == null) || oldstr.equals("") || (newstr == null) || (s == null) || s.equals("")) 
			return s;
		String result = "";
		int pos = s.indexOf(oldstr, 0);
		if (pos > -1) {
			result += s.substring(0, pos) + newstr;
			result += s.substring(pos + oldstr.length());
		} else {
			result = s;
		}
		return result;
	}
	
	/***********************************************
	 * To return the text string wrapped by space
	 ***********************************************/
	public static String wrapText(String s, int maxlen, String br) {
		return wrapText(s, maxlen, br, true);
	}
	
	/***********************************************
	 * To return the text string wrapped by space
	 ***********************************************/
	private static String wrapText(String s, int maxlen, String br, boolean isFirst) {
		//If less then input length, return original string
		if(s.length() <= maxlen)
			return s;
		
		int len;
		//First word will not be wrapped if exceed max length
		if (isFirst == true && s.lastIndexOf(" ", maxlen) == -1) {
			len = s.length();
		} else {
			len = maxlen;
		}
		
		//If next length contains newline, split there
		if(s.substring(0, maxlen).contains("\n"))
			return s.substring(0, s.indexOf("\n")) + wrapText(s.substring(s.indexOf("\n") + 1), len, br, false);
		
		//Otherwise, split along nearest previous Space
		int spaceIndex = s.lastIndexOf(" ", len);
		int numOfSpace = 0;
		while (spaceIndex != -1 && s.length() > (spaceIndex + numOfSpace) && s.charAt(spaceIndex + numOfSpace)==' ') {
			numOfSpace++;
		};
		
		//If no nearest space, split at length
		if(spaceIndex == -1)
			spaceIndex = len;
		else
			spaceIndex += numOfSpace;
		
		//Split into lines
		String text = wrapText(s.substring(spaceIndex), len, br, false);
		String result = "";
		if (!text.equals(""))
			result = s.substring(0, spaceIndex) + br + text;
		else
			result = s.substring(0, spaceIndex);
		
		return result;
	}

	//public static void convertToEmptyStringIfNull(Object obj, String propertyName){
//		if(ReflectionUtil.getProperty(obj, propertyName) == null){
//			ReflectionUtil.setProperty(obj, propertyName, "");
//		}
//	}
	
	public static String toNbsp(String input){
		if(input == null || input.length() == 0)
			return input;
		
		String result = null;
		result = input.replaceAll(" ", "&nbsp;");
		
		return result;
	}
	
	/***********************************************
	 * To return the first x bytes of the string
	 ***********************************************/
	public static String getFirstXBytes(String s, int numberOfBytes, String encoding) throws Exception{
		if(s != null && s.getBytes(encoding).length>numberOfBytes){
			byte[] b = s.getBytes(encoding);
			byte[] temp = new byte[numberOfBytes];
			
			for(int i = 0; i<numberOfBytes; i++){
				temp[i] = b[i];
			}
			s = new String(temp);
		}
		return s;
	}
}
