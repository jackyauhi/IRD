import java.util.Random;

public class PunGenerator{
	public static String generate() throws Exception{
		String pun = generateDigit() + generateUnitCode();
		String checkDigit = generateCheckDigit(pun);
		return pun + checkDigit;
	}
	
	private static String generateDigit(){
		long digit = getRandomNumber(1, 1000000000000L);
		String num = digit+"";
		num = StringUtils.leftPad(digit+"", '0', 12-num.length());
		num = num.substring(0,12);

		return num;
	}
	
	private static String generateUnitCode(){
		Random rnd = new Random();
		int type = rnd.nextInt(2); //0=alphabet 1=number
		char c;
		if(type==0){
			//alphabet
			do{
				c = (char) (rnd.nextInt(26) + 'A');
			}while(c=='I'||c=='O'||c=='Z');
			
		}else{
			//number
			c = (char)(rnd.nextInt(10) + '0');
		}

		return String.valueOf(c);
	}
	
	private static String generateCheckDigit(String PUN) {
		
		String PUN_N = null, PUNUnitCode = null;
		char[] arrayPUN;
		short unit = 0;

	
			PUN_N = PUN.substring(0, 12);
			PUNUnitCode = PUN.substring(12, 13).toUpperCase();

		if (!PUNUnitCode.equals("0")) {
			if (Character.isDigit(PUNUnitCode.charAt(0)))
				unit = Short.parseShort(PUNUnitCode);
			switch (PUNUnitCode.charAt(0)) {
				case 'A':
				case 'K':
				case 'U':
					unit = 1;
					break;
				case 'B':
				case 'L':
				case 'V':
					unit = 2;
					break;
				case 'C':
				case 'M':
				case 'W':
					unit = 3;
					break;
				case 'D':
				case 'N':
				case 'X':
					unit = 4;
					break;
				case 'E':
				case 'O':
				case 'Y':
					unit = 5;
					break;
				case 'F':
				case 'P':
				case 'Z':
					unit = 6;
					break;
				case 'G':
				case 'Q':
					unit = 7;
					break;
				case 'H':
				case 'R':
					unit = 8;
					break;
				case 'I':
				case 'S':
					unit = 9;
					break;
				case 'J':
				case 'T':
					unit = 0;
					break;
				default:
					break;
			}
			if (PUNUnitCode.charAt(0) > 'S')
				unit += 20;
			else if (PUNUnitCode.charAt(0) > 'I')
				unit += 10;
		}
		arrayPUN = PUN_N.toCharArray();
		short total = 0;
		for (int i = 0; i < arrayPUN.length; i++) {
			if (i < 4)
				total += (Integer.parseInt(String.valueOf(arrayPUN[i]))) * (5 - i);
			else
				total += (Integer.parseInt(String.valueOf(arrayPUN[i]))) * (14 - i);
		}
		total += (unit * 2);

		int remainder = total % 11;
		if (remainder < 0)
			remainder += 11;

		String checkDigit;
		if (remainder == 10)
			checkDigit = "A";
		else
			checkDigit = Integer.toString(remainder);

		return checkDigit;
	}
	
	private static long getRandomNumber(long min, long max){
	    Random random = new Random();         
	    return random.nextLong() % (max - min) + max;
	}
	
}