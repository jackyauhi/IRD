import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class PrnGenerator {

	public static String generateCharacter(boolean needTwoCharacter) throws Exception{	
		
		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("A", 1);
		map.put("B", 2);
		map.put("C", 3);
		map.put("D", 4);
		map.put("E", 5);
		map.put("F", 6);
		map.put("G", 7);
		map.put("H", 8);
		map.put("I", 9);
		map.put("J", 10);
		map.put("K", 11);
		map.put("L", 12);
		map.put("M", 13);
		map.put("N", 14);
		map.put("O", 15);
		map.put("P", 16);
		map.put("Q", 17);
		map.put("R", 18);
		map.put("S", 19);
		map.put("T", 20);
		map.put("U", 21);
		map.put("V", 22);
		map.put("W", 23);
		map.put("X", 24);
		map.put("Y", 25);
		map.put("Z", 26);
		
		
		int mapNum;
		String mapChar;
		
		Random rand = new Random();
		char character = (char)(rand.nextInt(26) + 'A');
		int num;
		String numString;
		String sixRandomNumber=new String();
		String checkDigit =new String();
		String prn=new String();
		for (int i=0; i<6;i++){
			num = rand.nextInt(10);
			numString=Integer.toString(num);
			sixRandomNumber=sixRandomNumber+numString;
		}
		mapChar= Character.toString(character);
		mapNum=map.get(mapChar);
		int substringEnd=1;
		int substringStart=0;
		int multipleNum=9;
	    int calculate=0;
	    //int checking=0;
	        
	    /*For checking
	     * 
	    character ='A';
	    mapChar="A";
	    mapNum=map.get(mapChar);		
	    SixRandomNumber="680071";
	    secondCharacter ='A';
	    secondMapChar="A";
	    secondMapNum=map.get(secondMapChar);
	    secondCharacterString=Character.toString(secondCharacter);
	    */
	    int secondMapNum=0;
		String secondMapChar;
		
	    char secondCharacter = 0;
	    String secondCharacterString=new String();
	    
	    int vaildCharacter=0;
	    
	    if(needTwoCharacter==true){
	    while(vaildCharacter!=1){
	    	vaildCharacter=1;
	    secondCharacter = (char)(rand.nextInt(26) + 'A');
	    
	    secondMapChar= Character.toString(secondCharacter);
	    secondMapNum=map.get(secondMapChar);
	    secondCharacterString=Character.toString(secondCharacter);


	    if(secondCharacter=='Z'){
			if(!mapChar.equals('Z')||!mapChar.equals('Y')){
				character = (char)(rand.nextInt(26) + 'A');
				mapChar= Character.toString(character);
				mapNum=map.get(mapChar);
				vaildCharacter=0;
				}
			}
	    }
	    }
	    
		while(substringEnd!=7){
			int getNum;
			if(multipleNum==8){
				getNum=mapNum;
				calculate=calculate+getNum*multipleNum;
				
			}
			else if(multipleNum==9){
				getNum=secondMapNum;
				calculate=calculate+getNum*multipleNum;
				
			}
			else{
			getNum=Integer.parseInt(sixRandomNumber.substring(substringStart,substringEnd));
			calculate=calculate+getNum*multipleNum;
			
			substringStart++;
			substringEnd++;
			}
			/*For checking
			System.out.println("getNum = "+getNum);
			System.out.println("multipleNum = "+multipleNum);
			System.out.println("calculate checking = " +checking);
			System.out.println("calculate = "+calculate);
			*/
			multipleNum--;

		}
		int getCheckDigit;
		getCheckDigit=calculate%11;
		if(needTwoCharacter==true){
			int resultNum;
			resultNum=11-getCheckDigit+1;
			if(resultNum==10){
				checkDigit="A";
			}
			else if(resultNum==12){
				checkDigit="1";
			}
			else if(resultNum==11){
				checkDigit="0";
			}
			else{
				checkDigit= Integer.toString(resultNum);
			}
		}
		else {
			int resultNum;
			if(getCheckDigit==0){
				checkDigit="0";
				}
			else{
				resultNum=11-getCheckDigit;
				if(resultNum==10){
					checkDigit="A";
				}
				else{
					checkDigit= Integer.toString(resultNum);
				}
			}
		}
		
		
		prn= secondCharacterString+character+sixRandomNumber+checkDigit;
		/*For checking
		System.out.println("==========================================================================");
		System.out.println("result");
		System.out.println("==========================================================================");
		System.out.println("multipleNum = "+multipleNum);
		System.out.println("calculate = "+calculate);
		System.out.println("getCheckDigit = "+getCheckDigit);
		System.out.println("checkDigit = "+checkDigit);
		System.out.println("SixRandomNumber = "+SixRandomNumber);
		System.out.println("Character ="+character);
		System.out.println("Represent Character Number Get in Map = " +mapNum);
		System.out.println("PRN = " +PRN);
		

		 
		//PRN="AA1234566";11
		//PRN="AB1234569";12
		//PRN="BB1234560";7
		//PRN="ZY1234567";
		//PRN="GY2321590";
		//PRN="UU1923761";
		//PRN="ZB2059195";
		
		if(!PrnValidator.validate(PRN).isSuccess()){
			System.out.println("PRN not Success");
			
		}
		else{
			System.out.println("PRN Success");
		}
		*/

		return prn;

	}
	
}