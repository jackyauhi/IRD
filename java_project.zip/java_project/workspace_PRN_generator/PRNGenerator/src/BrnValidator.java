

/**
 * Common class to validate the brn and return the error code
 * 
 * Required methods for automated validator:
 * 
 * 1) validate() method that returns an integer
 * 2) getDefaultErrorCode() method that returns a default error code for displaying the error message
 * 
 * 
 * @author mliu
 *
 *
 *******************************************************************************
 * Amendment log
 * -------------
 * 
 * Ref no.    Date       Amended by     Description
 * -------  ----------   ----------     ---------------------------------------
 *                                                                         
 ******************************************************************************
 *
 */
public class BrnValidator {
	static final int[] BRN_WEIGHT_TABLE = {0,8,1,2,3,6,7,8};
	static final int TOTAL_BRN_LENGTH = 9;
	static final String DEFAULT_ERROR_CODE = "message.2001";
	
	public static ValidationResult validate(String brn) {
		
		int errorCode = IrdValidConstant.NORMAL_BRN;
		if (StringUtils.isEmpty(brn)) {
			return new ValidationResult(true, "", errorCode, "");
		} else {
			brn = (brn != null) ? brn.trim() : "";
			if (!"".equals(brn) && (StringUtils.isNumeric(brn))) {
				try {
					if (Integer.parseInt(brn) < 1) {
						errorCode = IrdValidConstant.INVALID_BRN;
					} else {	
						String formattedBrn = StringUtils.leftPad(brn, '0', TOTAL_BRN_LENGTH - brn.length()); //added by william
						
						String checkDigit = generateCheckDigit(formattedBrn);
						String inputCheckDigit = formattedBrn.substring(TOTAL_BRN_LENGTH - 1);
						
						if (!checkDigit.equals(inputCheckDigit))
							errorCode = IrdValidConstant.INVALID_BRN_CHECK_DIGIT;
						else
							brn = formattedBrn.substring(1, TOTAL_BRN_LENGTH);
					}
				} catch (NumberFormatException ex) {
					errorCode = IrdValidConstant.INVALID_BRN;
				}
			} else {
				errorCode = IrdValidConstant.INVALID_BRN;
			}
		}
		return new ValidationResult((errorCode == IrdValidConstant.NORMAL_BRN), brn, errorCode, DEFAULT_ERROR_CODE);
	}
	
	public static String generateCheckDigit(String brn) {
		brn = brn.substring(0, 8);
		char[] arrayBRN = brn.toCharArray();
		int total = 0;
		
		for (int i = 0; i < BRN_WEIGHT_TABLE.length; i++) {
			total += Integer.parseInt(String.valueOf(arrayBRN[i])) * BRN_WEIGHT_TABLE[i];
		}
			
		String checkDigit = String.valueOf(total);
		checkDigit = checkDigit.substring(checkDigit.length() - 1);
		return checkDigit;
	}
	
	public static Boolean isNeedCheckDigit(String brn) {	
		return false;
	}
}
