import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class test {
public static void main(String[] args) {
	String inputPath ="D:\\testFindXml\\TestJavaConvertor\\BrbpbrinfDao.java";
	String outputPath ="T:\\jackyau\\BrbpbrinfDao.java";
	String oldContent =null;
	
	try {
		oldContent = new String(Files.readAllBytes(Paths.get(inputPath)));
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
//	boolean ReDoWhileLoop=true;
//	String withoutSpaceContent =oldContent;
//	withoutSpaceContent = withoutSpaceContent.replaceAll(" ", "");
//	withoutSpaceContent = withoutSpaceContent.replaceAll("\t", "");	
//	String searchContent =oldContent;
//	ReDoWhileLoop=true;
//	while(ReDoWhileLoop==true) {
//	String[] searchData=searchContent.split("public",2);
//	String[] RequiredData=searchData[1].split("{",2);
//	String checkRequiredData=null;
//	checkRequiredData=RequiredData[0].replaceAll("\t", " ");
//	String[] findVarible=checkRequiredData.split(" ");
//	for(int i=0; i<findVarible.length;i++) {
//		if(findVarible[i].equals("interface")) {
//			ReDoWhileLoop=false;
//		}
//	}
//	if(ReDoWhileLoop==true) {
//		searchContent=searchData[0]+ searchData[0];
//	}
//	}
	String realContent = null;
	boolean requiredContent=false;
	try {
		BufferedReader fileReader = new BufferedReader(new FileReader(inputPath));
		String readListLine=null;
		
	    try {
			while ((readListLine = fileReader.readLine()) != null)
			{	
				requiredContent=false;
				if(!readListLine.contains("extends")) {
					if(readListLine.contains("interface")||readListLine.contains("class")&&readListLine.contains("implements")) {
						if(readListLine.contains("interface")) {
							String importBaseDao = "import ird.taas2.data.dao.BaseDao;";
							if(!oldContent.contains(importBaseDao)) {
								String[] keepFrontData=oldContent.split("import",2);
								String[] keepBackData=keepFrontData[1].split(";",2);
								oldContent=keepFrontData[0]+importBaseDao+"\n"+"import"+keepBackData[0]+";"+keepBackData[1];
							}
						}
						else if(readListLine.contains("class")&&readListLine.contains("implements")) {
							String importBaseDao = "import ird.taas2.data.dao.impl.BaseDaoIbatisImpl;";
							if(!oldContent.contains(importBaseDao)) {
								String[] keepFrontData=oldContent.split("import",2);
								String[] keepBackData=keepFrontData[1].split(";",2);
								oldContent=keepFrontData[0]+importBaseDao+"\n"+"import"+keepBackData[0]+";"+keepBackData[1];
							}
						}
				//remove all space and tab
				String[] findVarible=readListLine.split("\\s+"); 
				for(int i=0; i<findVarible.length;i++) {
					if(findVarible[i].equals("interface")) {
						requiredContent=true;
					}
					if(findVarible[i].equals("implements")) {
						requiredContent=true;
					}
				}
				if(requiredContent==true) {
					String DaoVarible = "";
					realContent="";
					for(int i=0; i<findVarible.length;i++) {
						if(findVarible[i].endsWith("Dao")&&!findVarible[i].equals("BaseDao")) {
							DaoVarible=findVarible[i].substring(0,findVarible[i].length()-3);
							realContent=realContent+findVarible[i]+" "+ "extends BaseDao<"+DaoVarible+">";
						}
						else if(findVarible[i].endsWith("DaoImpl")) {
							DaoVarible=findVarible[i].substring(0,findVarible[i].length()-7);
							realContent=realContent+findVarible[i]+" "+ "extends BaseDaoIbatisImpl<"+DaoVarible+">";
						}
						else {
						realContent=realContent+findVarible[i]+" ";
						}
					}
					oldContent=oldContent.replaceAll(Pattern.quote(readListLine), Matcher.quoteReplacement(realContent));
				}
				}
				}
				
			}
			fileReader.close();
		} 
	    catch (IOException e1) {
			e1.printStackTrace();
		}
	} 
		catch (FileNotFoundException e1) {
		e1.printStackTrace();
	}

	System.out.println("oldContent here:\n"+oldContent);
//	try {       
//   		FileWriter fileWriter = new FileWriter(outputConvertPath);
//    	for(int i=0; i<outputPathList.size();i++) {
//   		fileWriter.write(outputPathList.get(i).toString()+"\n");
//    	}
//   		fileWriter.close();
//   	}catch (IOException iox) {
//   		iox.printStackTrace();
//   		System.out.println("File can not save any data in outputPathList");
//   	}
}
}