import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class testCase {
public static void main(String[] args) {
	String inputPath ="D:\\testFindXml\\TestJavaConvertor\\BrbpbrinfDao.java";
	String outputPath ="T:\\jackyau\\BrbpbrinfDao.java";
	String content =null;

	try {
		content = new String(Files.readAllBytes(Paths.get(inputPath)));
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}


	Pattern contentPattern = Pattern.compile("(?:public\\s)?(?:.*\\s)?(class|interface|enum)\\s+([$_a-zA-Z][$_a-zA-Z0-9]*)");
	Matcher matcher = contentPattern.matcher(content);
	String daoClassName= null;
	String daoclassReplaceString =null;
	if (matcher.find()) {
		daoClassName = matcher.group(2);
		daoclassReplaceString= matcher.group();
		System.out.println(daoClassName);
		String modelName=null;
		if(daoClassName.toUpperCase().endsWith("DAOIMPL")) {
			modelName = daoClassName.replaceAll("(?i)(DaoImpl)", "");
			System.out.println(modelName);
		}
		else if(daoClassName.toUpperCase().endsWith("DAO")) {
			modelName = daoClassName.replaceAll("(?i)(Dao)", "");
			System.out.println(modelName);
		}
		System.out.println(matcher.group());
		content=content.replaceAll(daoclassReplaceString, daoclassReplaceString + " extends BasoDaoImpl<"+modelName+">");
	}
	if(daoClassName.toUpperCase().endsWith("DAOIMPL")) {
	String importBaseDao = "import ird.taas2.data.dao.impl.BaseDaoIbatisImpl;";
	Pattern removePattern = Pattern.compile("private\\s+SqlMapClient\\s+sqlMapClient?(?:.*\\s)?;");
	content = removePattern.matcher(content).replaceAll(Matcher.quoteReplacement(""));
	if(!content.contains(importBaseDao)) {
		String[] keepFrontData=content.split("import",2);
		String[] keepBackData=keepFrontData[1].split(";",2);
		content=keepFrontData[0]+importBaseDao+"\n"+"import"+keepBackData[0]+";"+keepBackData[1];
	}
	Pattern removePattern1 = Pattern.compile("public\\s+([a-zA-Z0-9]+)DaoImpl(?:.*\\s)?((?:.*\\s)?)(?:.*\\s)?");
	Matcher removePattern1Matcher=removePattern1.matcher(content);
	String storeVarible1 =null;
	if (removePattern1Matcher.find()){
		storeVarible1 = removePattern1Matcher.group();
		String[] keepFrontData=content.split(Pattern.quote(storeVarible1),2);
		String[] keepBackData=keepFrontData[1].split(Pattern.quote("}"),2);
		content=keepFrontData[0]+keepBackData[1];
	}
	Pattern removePattern2 = Pattern.compile("public\\s+void\\s+setSqlMapClient");
	Matcher removePattern2Matcher=removePattern2.matcher(content);
	String storeVarible2 =null;
	if (removePattern2Matcher.find()){
		storeVarible2 = removePattern2Matcher.group();
		String[] keepFrontData=content.split(Pattern.quote(storeVarible2),2);
		String[] keepBackData=keepFrontData[1].split(Pattern.quote("}"),2);
		content=keepFrontData[0]+keepBackData[1];
	}
	Pattern removePattern3 = Pattern.compile("public\\s+SqlMapClient\\s+getSqlMapClient");
	Matcher removePattern3Matcher=removePattern3.matcher(content);
	String storeVarible3 =null;
	if (removePattern3Matcher.find()){
		storeVarible3 = removePattern3Matcher.group();
		String[] keepFrontData=content.split(Pattern.quote(storeVarible3),2);
		String[] keepBackData=keepFrontData[1].split(Pattern.quote("}"),2);
		content=keepFrontData[0]+keepBackData[1];
	}
	}
	else if(daoClassName.toUpperCase().endsWith("DAO")) {
	String importBaseDao = "import ird.taas2.data.dao.BaseDao;";
	if(!content.contains(importBaseDao)) {
		String[] keepFrontData=content.split("import",2);
		String[] keepBackData=keepFrontData[1].split(";",2);
		content=keepFrontData[0]+importBaseDao+"\n"+"import"+keepBackData[0]+";"+keepBackData[1];
	}
	}
	
	System.out.println("content here:\n"+content);
	try {       
   		FileWriter fileWriter = new FileWriter(outputPath);
   		fileWriter.write(content);  	
   		fileWriter.close();
   	}catch (IOException iox) {
   		iox.printStackTrace();
   		System.out.println("File can not save any data in outputPathList");
   	}
  }
}