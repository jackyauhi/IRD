//Use for Auto Convertor  !!!
/**
 * 
 */
package ird.taas2.tools;

import ird.taas2.tools.converter.DefaultCloudConverter;
import ird.taas2.tools.converter.MyBatis2To3Converter;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.io.FilenameUtils;

/**
 * @author mliu
 * @author jackyau
 */
public class CloudConverterMain {
	private static String ENABLE_JAVA_CONVETERS[] = { 
		"ird.taas2.tools.converter.MyBatis2To3Converter",
		"ird.taas2.tools.converter.MissingSqlMapClientDefinitionConverter",
		"ird.taas2.tools.converter.RemovingTypeConverter"
	};
	
	/**
	 * @param args
	 * @throws Exception 
	 */
	public static ArrayList<String> errorInputList = new ArrayList<String>();
	public static boolean errorHappen=false;
	public static String fileErrorPath="";
	public static int countError;
	public static ArrayList<String> latestFileList = new ArrayList<String>();
	public static MyBatis2To3Converter myBatis2To3Converter=new MyBatis2To3Converter();
	public static String timeStamps = new String();
	
	public static String startFolder = "\\PRD_Application";
	public static void main(String[] args) throws Exception {
		countError=0;
//		String inputDirStr = args[0];
		String destDirStr = args[0];
		String convertorFilePath=args[1];
		String requireCsvFile =convertorFilePath+"\\outputRequiredFileMain.csv";
		String timeStampsFolderFile =convertorFilePath+"\\OutputFiles_TimeStamps.txt";
		int countLine=0;
		try {
			BufferedReader fileReader = new BufferedReader(new FileReader(requireCsvFile));
			String line=null;
		    try {
				while ((line = fileReader.readLine()) != null)
				{	
					String[] dataStore = line.split(",");
					latestFileList.add(dataStore[1]);
			
				}
				fileReader.close();
			} 
		    catch (IOException e1) {
				e1.printStackTrace();
			}
			} 
	   	catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
		try {
			BufferedReader fileReader = new BufferedReader(new FileReader(timeStampsFolderFile));
			String line=null;
		    try {
				while ((line = fileReader.readLine()) != null)
				{	
					if(countLine==0) {
						timeStamps=line;
					}
					countLine++;
				}
				fileReader.close();
			} 
		    catch (IOException e1) {
				e1.printStackTrace();
			}
			} 
	   		catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
		String outputConvertPath =convertorFilePath+"\\outputConvert.txt";
		String errorInputPath =convertorFilePath+"\\errorInput.txt";
		String tempTextFile=convertorFilePath+"\\tempTextFile.txt";
		File fileToDelete;
		fileToDelete=new File(outputConvertPath);
	    if (fileToDelete.exists()) {
	     	fileToDelete.delete();
	    	}
		fileToDelete=new File(errorInputPath);
	    if (fileToDelete.exists()) {
	     	fileToDelete.delete();
	    	}
		int countFile=0;
		ArrayList<String> outputPathList = new ArrayList<String>(); 


		File destDir = null;
		File destDirParent = null;

		
		List<DefaultCloudConverter> cloudConverterList = null;
		try {
			
			cloudConverterList = constructCloudConverters(ENABLE_JAVA_CONVETERS);
			
		} catch (Exception e) {
			errorHappen=true;
			errorInputList.add(fileErrorPath);
			errorInputList.add(e.toString());
			fileErrorPath="";
			throw e;
		}
		

		System.out.println("Cloud Migration programs conversion started ...");
		System.out.println();
		
		Instant start = Instant.now();
		
		try {
			for (int i = 0; i < latestFileList.size(); i++) {
	   			String classifyFile=latestFileList.get(i).toString();
	   			String[] javaFilePath = classifyFile.split(",");
	   			
	   			String[] prdApplicationFolderPath = latestFileList.get(i).toString().split(Pattern.quote(startFolder),2);

				destDir = new File(destDirStr+"\\"+timeStamps+startFolder+prdApplicationFolderPath[1]);
				destDirParent=new File(destDir.getParent());
				if (!destDirParent.exists()) {
					destDirParent.mkdirs();
				}
				File javaFileObj = new File(javaFilePath[0]);
				String fileName =javaFileObj.getName();
				if (fileName.toLowerCase().endsWith(".java")) {
				String fileContent = new String ( Files.readAllBytes( Paths.get(javaFilePath[0]) ) );
				
				boolean javaChange = false;

				fileErrorPath =javaFileObj.getAbsolutePath();

				for(DefaultCloudConverter cloudConverter : cloudConverterList){
					System.out.println("cloudConverterList.size() = " + cloudConverterList.size());
					System.out.println("cloudConverter = " + cloudConverter);

					fileContent = cloudConverter.convert(fileContent, javaFileObj);
				}
				javaChange=myBatis2To3Converter.javaChange;
				if(javaChange==true) {
				BufferedWriter writer = new BufferedWriter(new FileWriter(destDir.getAbsolutePath()));
			    writer.write(fileContent);
			    writer.close();
			    System.out.println("Processing " + javaFileObj.getAbsolutePath());
			    System.out.println("Updated: " + destDir.getAbsolutePath());
			    System.out.println();
			    outputPathList.add(destDir.getAbsolutePath());
			    countFile++;
				}
			}
		}
		} catch (IOException e) {
			errorHappen=true;
			errorInputList.add(fileErrorPath);
			errorInputList.add(e.toString());
			fileErrorPath="";
			countError++;
			throw e;
		}
		
		Instant finish = Instant.now();
		long timeElapsed = Duration.between(start, finish).toMillis();
		
		System.out.println("Java files conversion completed");
		System.out.println();
		int totalCount = countError+outputPathList.size();
		try {       
       		FileWriter fileWriter = new FileWriter(tempTextFile);
       		fileWriter.write(System.lineSeparator());
       		fileWriter.write("Java Files Count :"+totalCount+System.lineSeparator());
       		fileWriter.write("Convert Java Files Count :"+outputPathList.size()+System.lineSeparator());
       		fileWriter.write("The java files convert list is put in ("+outputConvertPath+")"+System.lineSeparator());
        	if(errorHappen==true) {
        		fileWriter.write("The Error Input List is put in ("+errorInputPath+")");
        	}
       		fileWriter.close();
       	}catch (IOException iox) {
       		iox.printStackTrace();
       		System.out.println("File can not save any data in tempTextFile");
			errorHappen=true;
			errorInputList.add(fileErrorPath);
			errorInputList.add(iox.toString());
			fileErrorPath="";
			countError++;
       	}
		try {       
       		FileWriter fileWriter = new FileWriter(outputConvertPath);
	    	for(int i=0; i<outputPathList.size();i++) {
       		fileWriter.write(outputPathList.get(i).toString()+System.lineSeparator());
	    	}
       		fileWriter.close();
       	}catch (IOException iox) {
       		iox.printStackTrace();
       		System.out.println("File can not save any data in outputPathList");
			errorHappen=true;
			errorInputList.add(fileErrorPath);
			errorInputList.add(iox.toString());
			fileErrorPath="";
			countError++;
       	}
    	if(errorHappen==true) {
    	try {       
       		FileWriter fileWriter = new FileWriter(errorInputPath);
	    	for(int i=0; i<errorInputList.size();i++) {
       		fileWriter.write(errorInputList.get(i).toString()+System.lineSeparator());
	    	}
       		fileWriter.close();
       	}catch (IOException iox) {
       		iox.printStackTrace();
       		System.out.println("File can not save any data in errorInputList");
       	}		        	
    	}

	}

	private static File constructDestPath(File destPath, String javaFilePath) throws Exception{
		try{
			File dest = new File(FilenameUtils.concat(destPath.getAbsolutePath(), FilenameUtils.getPath(javaFilePath)));
			if(!dest.exists()){
				dest.mkdirs();
			}
			
			return dest;
		}catch(Exception e){
			errorHappen=true;
			errorInputList.add(fileErrorPath);
			errorInputList.add(e.toString());
			fileErrorPath="";
			countError++;
			throw e;
		}
	}
	
	private static List<DefaultCloudConverter> constructCloudConverters(String []enabledConverters) throws Exception{
		List<DefaultCloudConverter> cloudConverterList = new ArrayList<DefaultCloudConverter>();
		for(String converter : enabledConverters){
			cloudConverterList.add(constructCloudConverter(converter));
		}
		
		return cloudConverterList;
	}
	private static DefaultCloudConverter constructCloudConverter(String fullQualName) throws Exception{
		return (DefaultCloudConverter)Class.forName(fullQualName).newInstance();
	}
}
