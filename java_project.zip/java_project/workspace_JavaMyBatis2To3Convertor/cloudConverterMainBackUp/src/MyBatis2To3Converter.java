/**
 * 
 */


import java.io.File;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.stream.events.EndDocument;

import ird.taas2.tools.CloudConverterMain;



/**
 * @author mliu
 * @author jackyau
 */

public class MyBatis2To3Converter implements DefaultCloudConverter {
	public static CloudConverterMain cloudConverterMain=new CloudConverterMain();
	
public static boolean javaChange=false;
	@Override
	public String convert(String fileContent, File inputFile) throws Exception {
		String replacedFileContent=fileContent;

		javaChange=false;
		Pattern removeImportPattern = Pattern.compile("import\\s+com\\s*[.]\\s*ibatis\\s*[.]\\s*sqlmap\\s*[.]\\s*client\\s*[.]\\s*SqlMapClient\\s*[;]");
		Matcher removeImportPatternMatcher=removeImportPattern.matcher(replacedFileContent);
		if (removeImportPatternMatcher.find()){
			replacedFileContent = removeImportPattern.matcher(replacedFileContent).replaceAll("");
			javaChange=true;
		}
		Pattern removeImportPattern1 = Pattern.compile("import\\s+com\\s*[.]\\s*ibatis\\s*[.]\\s*sqlmap\\s*[.]\\s*engine\\s*[.]\\s*execution\\s*[.]\\s*BatchResult\\s*[;]");
		Matcher removeImportPattern1Matcher=removeImportPattern1.matcher(replacedFileContent);
		if (removeImportPattern1Matcher.find()){
			replacedFileContent = removeImportPattern1.matcher(replacedFileContent).replaceAll(Matcher.quoteReplacement("import org.apache.ibatis.executor.BatchResult;"));
			javaChange=true;
		}
		
		//Dao and DaoImpl java content change 
//		System.out.println("inputFile.getName() = "+inputFile.getName());
		if(inputFile.getName().toLowerCase().endsWith("dao.java")||inputFile.getName().toLowerCase().endsWith("daoimpl.java")) {
			Pattern removeImportPattern2 = Pattern.compile("import\\s+org\\s*[.]\\s*springframework\\s*[.]\\s*orm\\s*[.]\\s*ibatis\\s*[.]\\s*support\\s*[.]\\s*SqlMapClientDaoSupport\\s*[;]");
			Matcher removeImportPattern2Matcher=removeImportPattern2.matcher(replacedFileContent);
			if (removeImportPattern2Matcher.find()){
				replacedFileContent = removeImportPattern2.matcher(replacedFileContent).replaceAll("");
				javaChange=true;
			}
			if (replacedFileContent.contains("SqlMapClientDaoSupport")){
				replacedFileContent=replacedFileContent.replaceAll("SqlMapClientDaoSupport", "BaseDaoIbatisImpl");
				javaChange=true;
			}
			Pattern removeDataSourcePattern = Pattern.compile("@Autowired\\s*((\r\\n)|(\n)|(\r))*\\s*([a-zA-Z0-9]*)\\s*DataSource\\s*dataSource\\s*[;]");
			Matcher removeDataSourceMatcher=removeDataSourcePattern.matcher(replacedFileContent);
			if (removeDataSourceMatcher.find()){
				String testContent=replacedFileContent;
				testContent.replaceAll("\r", " ");
				testContent.replaceAll("\n", " ");
				String[] findContent =testContent.split("\\s");
				int countDataSource=0;
				for(int i=0; i<findContent.length;i++) {
				if(findContent[i].contains("dataSource")) {
					countDataSource++;
				}
				}
				if(countDataSource==1) {
					replacedFileContent = removeDataSourcePattern.matcher(replacedFileContent).replaceAll("");
				}
				javaChange=true;
			}
			if (replacedFileContent.contains("@Autowired DataSource dataSource")){
				replacedFileContent=replacedFileContent.replaceAll(Pattern.quote("@Autowired DataSource dataSource"), Matcher.quoteReplacement("//@Autowired DataSource dataSource"));
				javaChange=true;
			}

			Pattern contentPattern = Pattern.compile("public\\s+(class|interface|enum)\\s+([$_a-zA-Z][$_a-zA-Z0-9]*)");
			Matcher matcher = contentPattern.matcher(replacedFileContent);
			Pattern contentPatternExtendsExist = Pattern.compile("public\\s+(class|interface|enum)\\s+([$_a-zA-Z][$_a-zA-Z0-9]*)\\s+extends");
			Matcher matcherExtendsExist = contentPatternExtendsExist.matcher(replacedFileContent);
			
			
			Pattern contentPatternExtendsExistBaseDaoIbatisImpl = Pattern.compile("public\\s+(class|interface|enum)\\s+([$_a-zA-Z][$_a-zA-Z0-9]*)\\s+extends\\s+BaseDaoIbatisImpl");
			Matcher matcherExtendsExistBaseDaoIbatisImpl = contentPatternExtendsExistBaseDaoIbatisImpl.matcher(replacedFileContent);
			Pattern contentPatternExtendsExistBaseDaoIbatisImplModel = Pattern.compile("public\\s+(class|interface|enum)\\s+([$_a-zA-Z][$_a-zA-Z0-9]*)\\s+extends\\s+BaseDaoIbatisImpl\\s*[<]");
			Matcher matcherExtendsExistBaseDaoIbatisImplModel = contentPatternExtendsExistBaseDaoIbatisImplModel.matcher(replacedFileContent);

			
			
			Pattern contentPatternExtendsExistBaseDao = Pattern.compile("public\\s+(class|interface|enum)\\s+([$_a-zA-Z][$_a-zA-Z0-9]*)\\s+extends\\s+BaseDao");
			Matcher matcherExtendsExistBaseDao = contentPatternExtendsExistBaseDao.matcher(replacedFileContent);
			Pattern contentPatternExtendsExistBaseDaoModel = Pattern.compile("public\\s+(class|interface|enum)\\s+([$_a-zA-Z][$_a-zA-Z0-9]*)\\s+extends\\s+BaseDao\\s*[<]");
			Matcher matcherExtendsExistBaseDaoModel = contentPatternExtendsExistBaseDaoModel.matcher(replacedFileContent);

			
			String daoClassReplaceString ="";
			String baseDaoIbatisImplClassReplaceString ="";
			String baseDaoClassReplaceString ="";
			
			if (matcher.find()) {
				daoClassReplaceString= matcher.group();
				String modelName="";
				if(cloudConverterMain.haveModelName==true) {
					if(inputFile.getName().contains("Dao")) {
					String[] fileName =inputFile.getName().split("Dao");
					modelName = "<"+fileName[0]+">";
					}
					else if(inputFile.getName().contains("DAO")) {
						String[] fileName =inputFile.getName().split("DAO");
						modelName = "<"+fileName[0]+">";
					}
				}
//				System.out.println(modelName);
				if(inputFile.getName().toLowerCase().endsWith("daoimpl.java")) {
					if(!matcherExtendsExist.find()) {
						replacedFileContent=replacedFileContent.replaceAll(daoClassReplaceString, daoClassReplaceString + " extends BaseDaoIbatisImpl"+modelName);

					}

					else if(matcherExtendsExistBaseDaoIbatisImpl.find()) {
						baseDaoIbatisImplClassReplaceString= matcherExtendsExistBaseDaoIbatisImpl.group();
//						System.out.println("baseDaoIbatisImplClassReplaceString ="+baseDaoIbatisImplClassReplaceString);
						if(!matcherExtendsExistBaseDaoIbatisImplModel.find()) {
//							System.out.println("baseDaoIbatisImplClassReplaceStringModel ="+matcherExtendsExistBaseDaoIbatisImplModel.group());
							replacedFileContent=replacedFileContent.replaceAll(baseDaoIbatisImplClassReplaceString, baseDaoIbatisImplClassReplaceString +modelName);
						}
					}
				}
				else {
					if(matcherExtendsExistBaseDao.find()) {
						baseDaoClassReplaceString= matcherExtendsExistBaseDao.group();
//						System.out.println("baseDaoClassReplaceString ="+baseDaoClassReplaceString);
						if(!matcherExtendsExistBaseDaoModel.find()) {
							replacedFileContent=replacedFileContent.replaceAll(baseDaoClassReplaceString, baseDaoClassReplaceString +modelName);
						}
					}

					else if(cloudConverterMain.haveModelName==true) {//haveImportModel  , //haveModelName
						if(!matcherExtendsExist.find()) {
							replacedFileContent=replacedFileContent.replaceAll(daoClassReplaceString, daoClassReplaceString + " extends BaseDao"+modelName);
						}
					}
					
				}
				javaChange=true;				
			}
			if(inputFile.getName().toLowerCase().endsWith("daoimpl.java")) {
				String importBaseDao = "import ird.taas2.data.dao.impl.BaseDaoIbatisImpl;";
				if(!replacedFileContent.contains(importBaseDao)) {
					String[] keepFrontData=replacedFileContent.split("import",2);
					String[] keepBackData=keepFrontData[1].split(";",2);
					replacedFileContent=keepFrontData[0]+importBaseDao+System.lineSeparator()+"import"+keepBackData[0]+";"+keepBackData[1];
					javaChange=true;
					}
				}
			else {

				if(matcherExtendsExist.find()) {
					String importBaseDao = "import ird.taas2.data.dao.BaseDao;";
					if(!replacedFileContent.contains(importBaseDao)) {
						String[] keepFrontData=replacedFileContent.split("import",2);
						if(keepFrontData.length==2) {
							String[] keepBackData=keepFrontData[1].split(";",2);
							replacedFileContent=keepFrontData[0]+importBaseDao+System.lineSeparator()+"import"+keepBackData[0]+";"+keepBackData[1];
						}
						else {
							String[] keepData=replacedFileContent.split("public",2);
							replacedFileContent=keepData[0]+System.lineSeparator()+importBaseDao+System.lineSeparator()+"public"+keepData[1];
						}
						javaChange=true;
							}
				  }
				else if(cloudConverterMain.haveModelName==true) {//haveImportModel  , //haveModelName
					String importBaseDao = "import ird.taas2.data.dao.BaseDao;";
					if(!replacedFileContent.contains(importBaseDao)) {
						String[] keepFrontData=replacedFileContent.split("import",2);
						if(keepFrontData.length==2) {
							String[] keepBackData=keepFrontData[1].split(";",2);
							replacedFileContent=keepFrontData[0]+importBaseDao+System.lineSeparator()+"import"+keepBackData[0]+";"+keepBackData[1];
						}
						else {
							String[] keepData=replacedFileContent.split("public",2);
							replacedFileContent=keepData[0]+System.lineSeparator()+importBaseDao+System.lineSeparator()+"public"+keepData[1];
						}
						javaChange=true;
							}
				 }
				}
		Pattern removePattern = Pattern.compile("@Autowired\\s*((\r\\n)|(\n)|(\r))*\\s*([a-zA-Z0-9]*)\\s*SqlMapClient\\s*sqlMapClient\\s*[;]");
		Matcher removePatternMatcher=removePattern.matcher(replacedFileContent);
		if (removePatternMatcher.find()){
			replacedFileContent = removePattern.matcher(replacedFileContent).replaceAll(Matcher.quoteReplacement(""));
			javaChange=true;
			}
		if (replacedFileContent.contains("private SqlMapClient getSqlMapClientTemplate;")){
			replacedFileContent=replacedFileContent.replaceAll("private SqlMapClient getSqlMapClientTemplate;", "");
			javaChange=true;
			}
		if (replacedFileContent.contains("void setSqlMapClient(SqlMapClient sqlMapClient);")){
			replacedFileContent=replacedFileContent.replaceAll(Pattern.quote("void setSqlMapClient(SqlMapClient sqlMapClient);"), "");
			javaChange=true;
			}
		if (replacedFileContent.contains("SqlMapClient getSqlMapClient();")){
			replacedFileContent=replacedFileContent.replaceAll(Pattern.quote("SqlMapClient getSqlMapClient();"), "");
			javaChange=true;
			}
		if (replacedFileContent.contains("private SqlMapClientTemplate sqlMapClient = getSqlMapClientTemplate();")){
			replacedFileContent=replacedFileContent.replaceAll(Pattern.quote("private SqlMapClientTemplate sqlMapClient = getSqlMapClientTemplate();"), "");
			javaChange=true;
			}
		if (replacedFileContent.contains("private SqlMapClient getSqlMapClientTemplateTemplate;")){
			replacedFileContent=replacedFileContent.replaceAll("private SqlMapClient getSqlMapClientTemplateTemplate;", "");
			javaChange=true;
			}
		
		Pattern removePattern1 = Pattern.compile("public\\s+([a-zA-Z0-9]+)DaoImpl\\s*[(]\\s*[)]\\s*[{]");
		Matcher removePattern1Matcher=removePattern1.matcher(replacedFileContent);
		String storeVarible1 =null;
		if (removePattern1Matcher.find()){
			storeVarible1 = removePattern1Matcher.group();
			String[] keepFrontData=replacedFileContent.split(Pattern.quote(storeVarible1),2);
			String[] keepBackData=keepFrontData[1].split(Pattern.quote("}"),2);
			replacedFileContent=keepFrontData[0]+keepBackData[1];
			javaChange=true;
			}
		Pattern removePattern11 = Pattern.compile("public\\s+([a-zA-Z0-9]+)DAOImpl\\s*[(]\\s*[)]\\s*[{]");
		Matcher removePattern11Matcher=removePattern11.matcher(replacedFileContent);
		String storeVarible11 =null;
		if (removePattern11Matcher.find()){
			storeVarible11 = removePattern11Matcher.group();
			String[] keepFrontData=replacedFileContent.split(Pattern.quote(storeVarible11),2);
			String[] keepBackData=keepFrontData[1].split(Pattern.quote("}"),2);
			replacedFileContent=keepFrontData[0]+keepBackData[1];
			javaChange=true;
			}
		Pattern removePattern2 = Pattern.compile("public\\s+void\\s+setSqlMapClient");
		Matcher removePattern2Matcher=removePattern2.matcher(replacedFileContent);
		String storeVarible2 =null;
		if (removePattern2Matcher.find()){
			storeVarible2 = removePattern2Matcher.group();
			String[] keepFrontData=replacedFileContent.split(Pattern.quote(storeVarible2),2);
			String[] keepBackData=keepFrontData[1].split(Pattern.quote("}"),2);
			replacedFileContent=keepFrontData[0]+keepBackData[1];
			javaChange=true;
			}
		Pattern removePattern3 = Pattern.compile("public\\s+SqlMapClient\\s+getSqlMapClient");
		Matcher removePattern3Matcher=removePattern3.matcher(replacedFileContent);
		String storeVarible3 =null;
		if (removePattern3Matcher.find()){
			storeVarible3 = removePattern3Matcher.group();
			String[] keepFrontData=replacedFileContent.split(Pattern.quote(storeVarible3),2);
			String[] keepBackData=keepFrontData[1].split(Pattern.quote("}"),2);
			replacedFileContent=keepFrontData[0]+keepBackData[1];
			javaChange=true;
			}
		Pattern removePattern5 = Pattern.compile("([a-zA-Z0-9]*)\\s*SqlMapClient\\s+sqlMapClient\\s*[;]");
		Matcher removePattern5Matcher=removePattern5.matcher(replacedFileContent);
		if (removePattern5Matcher.find()){
			replacedFileContent = removePattern5.matcher(replacedFileContent).replaceAll(Matcher.quoteReplacement(""));
			javaChange=true;
			}
		Pattern removePattern6 = Pattern.compile("getSqlMapClientTemplate\\s*[(]\\s*[)]\\s*((\r\n)|(\n)|(\r))*\\s*[.]\\s*([Dd])elete");
		Matcher removePattern6Matcher=removePattern6.matcher(replacedFileContent);
		if (removePattern6Matcher.find()){
			replacedFileContent = removePattern6.matcher(replacedFileContent).replaceAll(Matcher.quoteReplacement("getSqlMapClientTemplate().uncheckedDelete"));
			javaChange=true;
			}
		Pattern removePattern7 = Pattern.compile("getSqlMapClient\\s*[(]\\s*[)]\\s*((\r\n)|(\n)|(\r))*\\s*[.]\\s*([Dd])elete");
		Matcher removePattern7Matcher=removePattern7.matcher(replacedFileContent);

		if (removePattern7Matcher.find()){
			replacedFileContent = removePattern7.matcher(replacedFileContent).replaceAll(Matcher.quoteReplacement("getSqlMapClient().uncheckedDelete"));
			javaChange=true;
				}
		
		Pattern removePattern4 = Pattern.compile("sqlMapClient\\s*((\r\n)|(\n)|(\r))*\\s*[.]\\s*[Dd]elete");
		Matcher removePattern4Matcher=removePattern4.matcher(replacedFileContent);
		if (removePattern4Matcher.find()){
			replacedFileContent = removePattern4.matcher(replacedFileContent).replaceAll(Matcher.quoteReplacement("uncheckedDelete"));
			javaChange=true;
			}

		}//end of if(inputFile.getName().toLowerCase().endsWith("dao.java")||inputFile.getName().toLowerCase().endsWith("daoimpl.java")) {
		
		if (replacedFileContent.contains("import org.springframework.orm.ibatis.SqlMapClientTemplate;")){
			replacedFileContent=replacedFileContent.replaceAll("import org.springframework.orm.ibatis.SqlMapClientTemplate;", "");
			javaChange=true;
			}
		
		if (replacedFileContent.contains("import antlr.collections.List;")){
			replacedFileContent=replacedFileContent.replaceAll("import antlr.collections.List;", "");
			javaChange=true;
		}
		if (replacedFileContent.contains("import com.ibm.security.util.calendar.BaseCalendar.Date;")){
			replacedFileContent=replacedFileContent.replaceAll("import com.ibm.security.util.calendar.BaseCalendar.Date;", "");
			javaChange=true;
		}
		if (replacedFileContent.contains("import org.apache.xalan.templates.ElemMessage;")){
			replacedFileContent=replacedFileContent.replaceAll("import org.apache.xalan.templates.ElemMessage;", "");
			javaChange=true;
		}
		if (replacedFileContent.contains("import com.ibm.security.krb5.internal.crypto.bb;")){
			replacedFileContent=replacedFileContent.replaceAll("import com.ibm.security.krb5.internal.crypto.bb;", "");
			javaChange=true;
		}
		if (replacedFileContent.contains("import org.apache.commons.httpclient.util.DateUtil;")){
			replacedFileContent=replacedFileContent.replaceAll("import org.apache.commons.httpclient.util.DateUtil;", "");
			javaChange=true;
		}
		if (replacedFileContent.contains("import com.ibm.jsse2.util.e;")){
			replacedFileContent=replacedFileContent.replaceAll("import com.ibm.jsse2.util.e;", "");
			javaChange=true;
		}
		if (replacedFileContent.contains("import com.sun.xml.internal.ws.util.StringUtils;")){
			replacedFileContent=replacedFileContent.replaceAll("import com.sun.xml.internal.ws.util.StringUtils;", "");
			javaChange=true;
		}

		if (replacedFileContent.contains("import sun.security.util.BigInt;")){
			replacedFileContent=replacedFileContent.replaceAll("import sun.security.util.BigInt;", "import java.math.BigInteger;");
			javaChange=true;
		}
		if (replacedFileContent.contains("import com.ibm.jsse2.t;")){
			replacedFileContent=replacedFileContent.replaceAll("import com.ibm.jsse2.t;", "");
			javaChange=true;
		}
		if (replacedFileContent.contains("import org.jfree.util.Log;")){
			replacedFileContent=replacedFileContent.replaceAll("import org.jfree.util.Log;", "");
			replacedFileContent=replacedFileContent.replaceAll("Log[.]", "logger.");
			javaChange=true;
		}
		if (replacedFileContent.contains("import com.ibm.math.BigDecimal;")){
			replacedFileContent=replacedFileContent.replaceAll("import com.ibm.math.BigDecimal;", "import java.math.BigDecimal;");
			javaChange=true;
		}
		if (replacedFileContent.contains("import com.ibatis.sqlmap.engine.type.SimpleDateFormatter;")){
			replacedFileContent=replacedFileContent.replaceAll("import com.ibatis.sqlmap.engine.type.SimpleDateFormatter;", "");
			javaChange=true;
		}
		if (replacedFileContent.contains("import com.ibm.jsse2.t;")){
			replacedFileContent=replacedFileContent.replaceAll("import com.ibm.jsse2.t;", "");
			javaChange=true;
		}
		if (replacedFileContent.contains("import com.ibatis.sqlmap.client.SqlMapException;")){
			replacedFileContent=replacedFileContent.replaceAll("import com.ibatis.sqlmap.client.SqlMapException;", "import org.apache.ibatis.type.JdbcType;");
			javaChange=true;
		}
		if (replacedFileContent.contains("import com.ibatis.sqlmap.engine.type.BaseTypeHandler;")){
			replacedFileContent=replacedFileContent.replaceAll("import com.ibatis.sqlmap.engine.type.BaseTypeHandler;", "import org.apache.ibatis.type.TypeHandler;");
			javaChange=true;
		}
		if (replacedFileContent.contains("import com.ibm.xtq.ast.parsers.xpath.ParseException;")){
			replacedFileContent=replacedFileContent.replaceAll("import com.ibm.xtq.ast.parsers.xpath.ParseException;", "");
			javaChange=true;
		}
		if (replacedFileContent.contains("import org.apache.xpath.operations.Equals;")){
			replacedFileContent=replacedFileContent.replaceAll("import org.apache.xpath.operations.Equals;", "");
			javaChange=true;
		}
		if (replacedFileContent.contains("import com.ibm.security.capi.Key;")){
			replacedFileContent=replacedFileContent.replaceAll("import com.ibm.security.capi.Key;", "");
			javaChange=true;
		}
		if (replacedFileContent.contains("import org.apache.poi.util.StringUtil;")){
			replacedFileContent=replacedFileContent.replaceAll("import org.apache.poi.util.StringUtil;", "");
			javaChange=true;
		}
		if (replacedFileContent.contains("import org.springframework.retry.backoff.Sleeper;")){
			replacedFileContent=replacedFileContent.replaceAll("import org.springframework.retry.backoff.Sleeper;", "");
			javaChange=true;
		}
		if (replacedFileContent.contains("import com.ibm.rmi.util.list.LinkedList;")){
			replacedFileContent=replacedFileContent.replaceAll("import com.ibm.rmi.util.list.LinkedList;", "");
			javaChange=true;
		}
		if (replacedFileContent.contains("import antlr.collections.List;")){
			replacedFileContent=replacedFileContent.replaceAll("import antlr.collections.List;", "");
			javaChange=true;
		}
		if (replacedFileContent.contains("import com.ibm.security.krb5.internal.crypto.bb;")){
			replacedFileContent=replacedFileContent.replaceAll("import com.ibm.security.krb5.internal.crypto.bb;", "");
			javaChange=true;
		}
		if (replacedFileContent.contains("import com.ibm.security.util.calendar.BaseCalendar.Date;")){
			replacedFileContent=replacedFileContent.replaceAll("import com.ibm.security.util.calendar.BaseCalendar.Date;", "");
			javaChange=true;
		}
		if (replacedFileContent.contains("import org.apache.xalan.templates.ElemMessage;")){
			replacedFileContent=replacedFileContent.replaceAll("import org.apache.xalan.templates.ElemMessage;", "");
			javaChange=true;
		}
		if (replacedFileContent.contains("import com.ibatis.common.jdbc.exception.NestedSQLException;")){
			if (!replacedFileContent.contains("import java.sql.SQLException;")){
				replacedFileContent=replacedFileContent.replaceAll("import com.ibatis.common.jdbc.exception.NestedSQLException;", "import java.sql.SQLException;");
			}
			else {
				replacedFileContent=replacedFileContent.replaceAll("import com.ibatis.common.jdbc.exception.NestedSQLException;", "");
			}
			replacedFileContent=replacedFileContent.replaceAll("NestedSQLException", "SQLException");
			javaChange=true;
		}
		if (replacedFileContent.contains("org.apache.commons.lang.StringUtils")){
			replacedFileContent=replacedFileContent.replaceAll("org.apache.commons.lang.StringUtils.isEmpty", "ird.taas2.utils.StringUtils.isEmptyWithoutTrim");
			replacedFileContent=replacedFileContent.replaceAll("org.apache.commons.lang.StringUtils.isNumeric", "ird.taas2.utils.StringUtils.isNumericWithStrictChecking");
			replacedFileContent=replacedFileContent.replaceAll("ird.taas2.utils.StringUtils.isEmpty", "ird.taas2.utils.StringUtils.NoNeedToReplaceThis_isEmpty");
			replacedFileContent=replacedFileContent.replaceAll("ird.taas2.utils.StringUtils.isNumeric", "ird.taas2.utils.StringUtils.NoNeedToReplaceThis_isNumeric");
			if(replacedFileContent.contains("//import org.apache.commons.lang.StringUtils;")) {
				System.out.println("//import org.apache.commons.lang.StringUtils;");
			}
			else if(replacedFileContent.contains("import org.apache.commons.lang.StringUtils;")) {
				replacedFileContent=replacedFileContent.replaceAll("import org.apache.commons.lang.StringUtils;", "import ird.taas2.utils.StringUtils;");
				replacedFileContent=replacedFileContent.replaceAll("StringUtils.isEmptyWithFullWidthSpace", "StringUtils.NoNeedToReplaceThis_isEmptyWithFullWidthSpace");
				replacedFileContent=replacedFileContent.replaceAll("StringUtils.isNumericSpace", "StringUtils.NoNeedToReplaceThis_isNumericSpace");
				replacedFileContent=replacedFileContent.replaceAll("StringUtils.isNumeric", "StringUtils.isNumericWithStrictChecking");
				replacedFileContent=replacedFileContent.replaceAll("StringUtils.isEmpty", "StringUtils.isEmptyWithoutTrim");
				replacedFileContent=replacedFileContent.replaceAll("StringUtils.NoNeedToReplaceThis_isEmptyWithFullWidthSpace", "StringUtils.isEmptyWithFullWidthSpace");
				replacedFileContent=replacedFileContent.replaceAll("StringUtils.NoNeedToReplaceThis_isNumericSpace", "StringUtils.isNumericSpace");
			}
			replacedFileContent=replacedFileContent.replaceAll("org.apache.commons.lang.StringUtils", "ird.taas2.utils.StringUtils");
			replacedFileContent=replacedFileContent.replaceAll("ird.taas2.utils.StringUtils.NoNeedToReplaceThis_isEmpty", "ird.taas2.utils.StringUtils.isEmpty");
			replacedFileContent=replacedFileContent.replaceAll("ird.taas2.utils.StringUtils.NoNeedToReplaceThis_isNumeric", "ird.taas2.utils.StringUtils.isNumeric");
			javaChange=true;
		}
		if(replacedFileContent.contains("org.springframework.util.StringUtils")) {
			replacedFileContent=replacedFileContent.replaceAll("org.springframework.util.StringUtils.isEmpty", "ird.taas2.utils.StringUtils.isEmptyWithoutTrim");
			replacedFileContent=replacedFileContent.replaceAll("ird.taas2.utils.StringUtils.isEmpty", "ird.taas2.utils.StringUtils.NoNeedToReplaceThis_isEmpty");
			if(replacedFileContent.contains("//import org.springframework.util.StringUtils;")) {
				System.out.println("//import org.springframework.util.StringUtils;");
			}
			else if(replacedFileContent.contains("import org.springframework.util.StringUtils;")) {
				replacedFileContent=replacedFileContent.replaceAll("import org.springframework.util.StringUtils;","import ird.taas2.utils.StringUtils;");
				replacedFileContent=replacedFileContent.replaceAll("StringUtils.isEmpty", "StringUtils.isEmptyWithoutTrim");
			}
			replacedFileContent=replacedFileContent.replaceAll("org.springframework.util.StringUtils","ird.taas2.utils.StringUtils");
			replacedFileContent=replacedFileContent.replaceAll("ird.taas2.utils.StringUtils.NoNeedToReplaceThis_isEmpty", "ird.taas2.utils.StringUtils.isEmpty");
			javaChange=true;
			
		}
		if(!replacedFileContent.contains("import ird.taas2.utils.StringUtils;")) {
			if (replacedFileContent.contains("import com.opensymphony.oscache.util.StringUtil;")){
				replacedFileContent=replacedFileContent.replaceAll("import com.opensymphony.oscache.util.StringUtil;", "import ird.taas2.utils.StringUtils;");
				replacedFileContent=replacedFileContent.replaceAll("StringUtil", "StringUtils");
				replacedFileContent=replacedFileContent.replaceAll("StringUtilss", "StringUtils");
				javaChange=true;
			}
			if(replacedFileContent.contains("com.opensymphony.oscache.util.StringUtil")){
				replacedFileContent=replacedFileContent.replaceAll("com.opensymphony.oscache.util.StringUtil", "ird.taas2.utils.StringUtils");
				javaChange=true;
			}
		}
		if (replacedFileContent.contains("import com.opensymphony.oscache.util.StringUtil;")){
			replacedFileContent=replacedFileContent.replaceAll("import com.opensymphony.oscache.util.StringUtil;", "");
			replacedFileContent=replacedFileContent.replaceAll("StringUtil", "StringUtils");
			replacedFileContent=replacedFileContent.replaceAll("StringUtilss", "StringUtils");
			javaChange=true;
		}
		return replacedFileContent;

	}
	
	
}
