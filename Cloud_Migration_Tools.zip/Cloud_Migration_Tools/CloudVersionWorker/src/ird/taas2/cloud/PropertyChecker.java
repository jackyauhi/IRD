package ird.taas2.cloud;

import java.io.File;
import java.nio.file.Files;

public class PropertyChecker {
	private void process(File aixFolder, File cloudFolder, File cloudRoot)throws Exception{
		if (cloudFolder.isDirectory()) {
			File[] childs = cloudFolder.listFiles();
			for(File child: childs) {
				process(aixFolder, child, cloudRoot);
			}
			return;
		}
		File cloudFile = cloudFolder;
		if (!cloudFile.getName().toLowerCase().endsWith(".xml")) {
			return;
		}
		String batchPath = new File(aixFolder, "Batch").getAbsolutePath();
		String onlinePath = new File(aixFolder, "Online").getAbsolutePath();
		String filePath = cloudFile.getAbsolutePath();
		File fileInBatch = new File(filePath.replace(cloudRoot.getAbsolutePath(), batchPath)+"@@\\main\\BAT_PRD");
		File fileInOnline = new File(filePath.replace(cloudRoot.getAbsolutePath(), onlinePath)+"@@\\main\\WAS_PRD");
		cloudFile = new File(cloudFile.getAbsolutePath()+"@@\\main\\BAT_CDEV");
		
		if (!filePath.toLowerCase().contains("src")) {
			return;
		}
		if (fileInBatch.exists() && fileInOnline.exists()) {
			checkCommon(fileInBatch, fileInOnline, cloudFile);
			return;
		}
		if (fileInBatch.exists() && !fileInOnline.exists()) {
			checkBatch(fileInBatch, cloudFile);
			return;
		}
		if (!fileInBatch.exists() && fileInOnline.exists()) {
			checkOnline(fileInOnline, cloudFile);
			return;
		}
		System.out.println("??"+filePath);
	}
	
	private void checkOnline(File fileInOnline, File cloudFile) throws Exception{
		String onlineContent = new String(Files.readAllBytes(fileInOnline.toPath()));
		String cloudContent = new String(Files.readAllBytes(cloudFile.toPath()));

		if (!onlineContent.toLowerCase().contains("propertyavailable")) {
			return;
		}
	
		if (!cloudContent.toLowerCase().contains("containskey")) {
			System.out.println("Check "+cloudFile.getAbsolutePath());
		}
	}
	
	private void checkBatch(File fileInBatch, File cloudFile) throws Exception{
		String batchContent = new String(Files.readAllBytes(fileInBatch.toPath()));
		String cloudContent = new String(Files.readAllBytes(cloudFile.toPath()));

		if (!batchContent.toLowerCase().contains("propertyavailable")) {
			return;
		}
	
		if (!cloudContent.toLowerCase().contains("containskey")) {
			System.out.println("Check "+cloudFile.getAbsolutePath());
		}
	}
	
	private void checkCommon(File fileInBatch, File fileInOnline, File cloudFile) throws Exception{
				
		String batchContent = new String(Files.readAllBytes(fileInBatch.toPath()));
		String onlineContent = new String(Files.readAllBytes(fileInOnline.toPath()));
		String cloudContent = new String(Files.readAllBytes(cloudFile.toPath()));

		if (!batchContent.toLowerCase().contains("propertyavailable") &&
			!onlineContent.toLowerCase().contains("propertyavailable")) {
			return;
		}
	
		if (!cloudContent.toLowerCase().contains("containskey")) {
			System.out.println("Check "+cloudFile.getAbsolutePath());
		}
	}
	
	public static void main(String[] args)throws Exception{
		PropertyChecker pc = new PropertyChecker();
		File aixFolder, cloudFolder;
		aixFolder = new File("R:\\taas2_view\\TAAS2_DEV\\PRD_Application");
		cloudFolder = new File("R:\\taas2_view\\TAAS2_UAT\\CloudMigration\\Application");
		pc.process(aixFolder, cloudFolder, cloudFolder);
	}
}
