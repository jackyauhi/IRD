package ird.taas2.cloud;

import java.io.File;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.apache.log4j.Logger;

import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.PackageDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.expr.ObjectCreationExpr;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

public class OverrideFinder {
private Logger logger = Logger.getLogger(OverrideFinder.class);
	
	public static void main(String[] args) throws Exception {
		OverrideFinder mf = new OverrideFinder();
		mf.process(new File(args[0]), new File(args[0]));
	}

	class FileRecord{
		private String path;
		private Map<String, Set<String>> map;
		public String getPath() {
			return path;
		}
		public void setPath(String path) {
			this.path = path;
		}
		public Map<String, Set<String>> getMap() {
			return map;
		}
		public void setMap(Map<String, Set<String>> map) {
			this.map = map;
		}
		
	}
	
	class MethodStruct {    
	    String parentNodes; 
	    String returnType;  
	    String methodName;  
	    String parameters;  
	    public MethodStruct(String parentNodes, String returnType, String methodName, String parameters) {
	    	this.parentNodes = parentNodes;
	    	this.returnType = returnType;
	    	this.methodName = methodName;
	    	this.parameters = parameters;
	    }
	}
	
	class MethodVisitor extends VoidVisitorAdapter<List<MethodStruct>> {
				
        @Override
        public void visit(MethodDeclaration declaration, List<MethodStruct> methodStructs) {
        	String methodName = declaration.getName().toString();
        	if (!methodName.equalsIgnoreCase("updateByExample")) {
        		return;
        	}
        	Boolean isOverride = declaration.getAnnotations().size() != 0 && declaration.isAnnotationPresent("Override");
    		logger.info(getParents(declaration)+"."+methodName+" have override?\t"+isOverride);
        }
                
        String getParents(final Node declaration) {
            final StringBuilder path = new StringBuilder();

            declaration.walk(Node.TreeTraversal.PARENTS, node -> {
                if (node instanceof ClassOrInterfaceDeclaration) {
                    path.insert(0, ((ClassOrInterfaceDeclaration) node).getNameAsString());
                    path.insert(0, '$');
                }
                if (node instanceof ObjectCreationExpr) {
                    path.insert(0, ((ObjectCreationExpr) node).getType().getNameAsString());
                    path.insert(0, '$');
                }
                if (node instanceof MethodDeclaration) {
                    path.insert(0, ((MethodDeclaration) node).getNameAsString());
                    path.insert(0, '#');
                }
                if (node instanceof CompilationUnit) {
                    final Optional<PackageDeclaration> pkg = ((CompilationUnit) node).getPackageDeclaration();
                    if (pkg.isPresent()) {
                        path.replace(0, 1, ".");
                        path.insert(0, pkg.get().getNameAsString());
                    }
                }
            });

            // convert StringBuilder into String and return the String
            return path.toString();
        }
    }

	private void process(File dir, File root) throws Exception{
		if (dir.isDirectory()) {
			File[] childs = dir.listFiles();
			for (File child: childs) {
				process(child, root);
			}
		}
				
		File file = new File(dir.getAbsolutePath());
		
		if (!file.getName().toLowerCase().endsWith(".java")) {
			return;
		}
		
		scan(file);
	}
	
	public void scan(File file)throws Exception{
		
	    CompilationUnit cu = StaticJavaParser.parse(new String(Files.readAllBytes(file.toPath()), Charset.defaultCharset()));

	    List<MethodStruct> methodStructs = new LinkedList<>();
        cu.accept(new MethodVisitor(), methodStructs);
        
	}
}
