package ird.taas2.cloud;

import java.io.File;
import java.nio.file.Files;
import java.util.HashSet;
import java.util.Set;

public class JobFinder {
	
	public static void main(String[] args)throws Exception{
		JobFinder jf = new JobFinder();
		jf.getJobName(new File(args[0]), new File(args[1]));
	}
	
	public String getJobName(String className, File folder)throws Exception{
		File[] childs = folder.listFiles();
		Set<String> applicationFolders = new HashSet<>();
		applicationFolders.add("--Batch--");
		applicationFolders.add("--Online--");
		String jobName = null;
		for (File child: childs) {
			
			Boolean isApplicationFile = false;
			for (String applicationFolder : applicationFolders) {
				if (child.getName().startsWith(applicationFolder)) {
					isApplicationFile = true;
					break;
				}
			}
			if (!isApplicationFile) {
				continue;
			}
			
			if (!child.getName().endsWith(".java")) {
				continue;
			}
			String [] parts = child.getName().split("--");
			String fileClassName = parts[parts.length-1].substring(0, parts[parts.length-1].indexOf(".java"));
			if (!className.equals(fileClassName)) {
				continue;
			}
			jobName = (parts[parts.length-2].toUpperCase()+"."+fileClassName);
			if (child.getName().startsWith("--Batch--")) {
				StringBuffer sb = new StringBuffer();
				for (String jobCharacter : jobName.split("")) {
					String regex = "[0-9]+";
					if(jobCharacter.matches(regex)) {
						break;
					}
					sb.append(jobCharacter);
				}
				jobName = sb.toString();
			}
			break;
		}
		return jobName;
	}
	
	private void getJobName(File listFile, File folder)throws Exception{
		Set<String> lineSet = new HashSet<>(Files.readAllLines(listFile.toPath()));
		
		for (String line: lineSet) {
			getJobName(line, folder);
		}
	}
}
