package ird.taas2.cloud;

import java.io.File;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.List;

public class FileChecker {
	public static void main(String[] args)throws Exception {
		FileChecker fc = new FileChecker();
		fc.process(new File(args[0]));
	}
	
	private void process(File fileList)throws Exception{
		List<String> lines = Files.readAllLines(fileList.toPath(), Charset.defaultCharset());
		for (String line: lines) {
			if (line.trim().length() == 0) {
				continue;
			}
			File file = new File(line);
			if (!file.exists() || file.isDirectory()) {
				continue;
			}
			
			int versionNumber = 0;
			
			File versionFile = null;
			
			do {
				versionFile = new File(line+"@@\\main\\"+versionNumber);
				if (versionFile.exists()) {
					versionNumber++;
				}else {
					versionNumber--;
					versionFile = new File(line+"@@\\main\\"+versionNumber);
					break;
				}
			}while(true);
			
			System.out.println(versionFile.getAbsolutePath());
		}
	}
}
