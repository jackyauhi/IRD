package ird.taas2.cloud;

import java.io.File;
import java.io.FileWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.Map.Entry;

import org.apache.log4j.Logger;

import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.PackageDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.Parameter;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.expr.ObjectCreationExpr;
import com.github.javaparser.ast.stmt.Statement;

import ird.taas2.cloud.JobFinder;
import ird.taas2.cloud.ParameterMap;

public class ContentSearcher {

	private Logger logger = Logger.getLogger(ContentSearcher.class);

	public static void main(String[] args) throws Exception {
		ContentSearcher cs = new ContentSearcher();
		cs.process(ParameterMap.getParameterMap(args));
	}

	private void process(ParameterMap parameterMap) throws Exception {

		File folder = new File(parameterMap.get("dir"));
		String keywords = parameterMap.getDefault("keywords", "");

		File inFile = new File(parameterMap.getDefault("in", ""));

		if (!folder.exists()) {
			throw new Exception("index files folder not exists");
		}
		if (keywords.trim().length() == 0 && !inFile.exists()) {
			throw new Exception("keyword not specified");
		}

		String types = parameterMap.getDefault("types", "");
		Boolean isSimpleOutput = parameterMap.getDefault("format", "simple").equals("simple");

		Set<String> keywordSet = new HashSet<>();
		if (keywords.contains(",")) {
			keywordSet = new HashSet<>(Arrays.asList(keywords.split(",")));
		} else {
			keywordSet.add(keywords);
		}

		if (inFile.exists()) {
			List<String> keywordLines = Files.readAllLines(inFile.toPath());
			for (String keywordLine : keywordLines) {
				keywordSet.add(keywordLine.trim());
			}
		}

		File outputFile = new File("content_worker_" + new Date().getTime() + ".txt");

		for (String keyword : keywordSet) {
			if (keyword.trim().length() == 0) {
				continue;
			}
			if (keyword.contains(".")) {
				continue;
			}
			throw new Exception("Please provide keyword as CALLER.METHOD (e.g. foo.bar), " + keyword + " found");
		}

		Set<String> tmpSet = new HashSet<>();
		for (String keyword : keywordSet) {
			if (keyword.trim().length() == 0) {
				continue;
			}
			tmpSet.add(keyword.trim());
		}
		keywordSet = tmpSet;

		Set<String> typeSet = new HashSet<>();

		if (types.trim().length() != 0) {
			if (types.contains(",")) {
				typeSet = new HashSet<>(Arrays.asList(types.split(",")));
			} else {
				typeSet.add(types);
			}
		}

		scan(folder, keywordSet, typeSet, isSimpleOutput, outputFile, parameterMap.get("appDir"));
	}
	
	private Set<Keyword> getInitialKeywords(Set<String> keywordSet, String appDir, File[] files)throws Exception{
		Set<Keyword> keywords = new HashSet<>();
		
		for (File pathFile: files) {
			File modelFile = new File(appDir, pathFile.getName().replace("--", File.separator));
			CompilationUnit cu = StaticJavaParser.parse(modelFile);

			List<MethodDeclaration> methods = cu.findAll(MethodDeclaration.class);
			for (MethodDeclaration method : methods) {
				String classNameFromPackage = getClassFromPackage(getParents(method));
				Boolean isKeywordFound = false;
				for (String keyword: keywordSet) {
					String keywordClassMethod = keyword;
					String keywordClassName = keywordClassMethod.split("\\.")[0];
					String keywordMethodName = keywordClassMethod.split("\\.")[1];
					if (!method.getNameAsString().equals(keywordMethodName) || !classNameFromPackage.equals(keywordClassName)) {
						continue;
					}
					
					Keyword newKeyword = new Keyword();
					newKeyword.setChain(new ArrayList<>());
					newKeyword.setFile(modelFile.getName());
					newKeyword.setKeyword(keyword);
					
					keywords.add(newKeyword);
					isKeywordFound = true;
					break;
				}
				if (!isKeywordFound) {
					continue;
				}

				break;
			}
		}
		
		return keywords;
	}

	private void scan(File folder, Set<String> keywordSet, Set<String> typeSet, Boolean isSimpleOutput, File outputFile,
			String appDir) throws Exception {
		File[] files = folder.listFiles();

		Integer handleCount = 2500;

		JobFinder jf = new JobFinder();

		List<MatchResult> previousMatchResult = null;

		TreeMap<String, Set<String>> jobInvokeMap = new TreeMap<>();

		Set<Keyword> keywords = getInitialKeywords(keywordSet, appDir, files);

		do {

			logger.info("===================" + keywordSet + "===================");

			List<MatchResult> newMatchResult = new ArrayList<>();
			
			List<SearchThread> threads = new ArrayList<>();
			
			for (int i = 0; i < ((int)(files.length / handleCount))+1; i++) {
				Integer start = i * handleCount;
				Integer end = (i * handleCount) + handleCount;
				if (i * handleCount > files.length) {
					end = null;
				}
				SearchThread st = new SearchThread(typeSet);
				st.setEnd(end);
				st.setStart(start);
				st.setFiles(files);
				st.setKeywords(keywords);
				st.setAppDir(appDir);
				st.start();
				threads.add(st);
			}
			
			for (SearchThread thread: threads) {
				thread.join();
				newMatchResult.addAll(thread.getMatchResults());
			}
			
			logger.info(newMatchResult.size() + " match result found");

			if (previousMatchResult != null && isMatchResultsEquals(previousMatchResult, newMatchResult)) {
				logger.info("NO MORE RECORD");
				break;
			}

			keywords = new HashSet<>();
			keywordSet = new HashSet<>();

			for (MatchResult result : newMatchResult) {

				String possibleClassMethod = result.getNextKeyword().getKeyword();
				String possibleClassName = possibleClassMethod.split("\\.")[0];

				logger.info(result.toString());

				Keyword matchedKeyword = result.getMatchedKeyword();
				String matchedContent = matchedKeyword.getChain().size() == 0 ? matchedKeyword.getKeyword()
						: matchedKeyword.getChain().get(0).getKeyword();

				String jobName = jf.getJobName(possibleClassName, folder);
				
				if (jobName == null) {
					logger.info(result.getMatchedKeyword().getKeyword()+" match upper keyword "+ matchedContent);
					logger.info("produce new keyword "+result.getNextKeyword().getKeyword()+" for keyword "+ result.getMatchedKeyword().getKeyword());
					
					keywords.add(result.getNextKeyword());
					keywordSet.add(result.getNextKeyword().getKeyword());
					continue;
				}
				
				logger.info(result.getMatchedKeyword().getKeyword()+" match upper keyword "+ matchedContent);
				logger.info("Found job "+jobName+" for keyword "+ result.getMatchedKeyword().getKeyword());
				
				String job = jobName.split("\\.")[0];
				if (jobInvokeMap.get(job) == null) {
					jobInvokeMap.put(job, new HashSet<>());
				}
				String sourceFile = result.getMatchedKeyword().getChain().get(0).file;
				jobInvokeMap.get(job).add(sourceFile+" via "+result.getMatchedKeyword());
			}

			previousMatchResult = newMatchResult;

			if (keywordSet.size() == 0) {
				logger.info("NO MORE RECORD");
				break;
			}

		} while (true);

		logger.info("=========================[BATCH JOB / TC EFFECTED]============================");

		FileWriter fw = new FileWriter(outputFile, false);

		for (Entry<String, Set<String>> jobInvokeEntry : jobInvokeMap.entrySet()) {

			if (isSimpleOutput) {
				Set<String> fileList = new HashSet<>();
				for (String filename : jobInvokeEntry.getValue()) {

					fileList.add(filename);
				}
				logger.info(jobInvokeEntry.getKey() + "\t" + String.join(", ", fileList));
				fw.append(jobInvokeEntry.getKey() + "\t" + String.join(", ", fileList) + System.lineSeparator());
			} else {

				logger.info(jobInvokeEntry.getKey() + "\t" + jobInvokeEntry.getValue());
			}
		}

		fw.close();

		logger.info("Exported to " + outputFile.getAbsolutePath());
	}
	
	private class SearchThread extends Thread {

		private File[] files;
		private Integer start;
		private Integer end;
		private List<MatchResult> matchResults;
		private Set<Keyword> keywords;
		private String appDir;

		public SearchThread(Set<String> criteriaSet) {
			super();
			matchResults = new ArrayList<>();
		}

		public void setFiles(File[] files) {
			this.files = files;
		}

		public void setStart(Integer start) {
			this.start = start;
		}

		public void setEnd(Integer end) {
			this.end = end;
		}
		
		public List<MatchResult> getMatchResults() {
			return matchResults;
		}

		public void setKeywords(Set<Keyword> keywords) {
			this.keywords = keywords;
		}

		public void setAppDir(String appDir) {
			this.appDir = appDir;
		}

		@Override
		public void run() {
			if (end == null) {
				end = files.length;
			}
			
			logger.info("START Searching "+start+" to "+end+" files");
			
			for (; start < end; start++) {
				if (start >= files.length) {
					continue;
				}
				try {
					getMatchResultInFile(files[start]);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			logger.info("FINISH Searching "+start+" to "+end+" files");
		}
		
		private void getMatchResultInFile(File pathFile)
				throws Exception {

			File modelFile = new File(appDir, pathFile.getName().replace("--", File.separator));

			Set<Keyword> newKeywords = construtsKeywordList(pathFile, modelFile, keywords);

			Boolean showMsg = newKeywords.size() != keywords.size();
			
			if (showMsg) {
				List<String> searchKeywords = new ArrayList<>();
				for (Keyword newKeyword: newKeywords) {
					searchKeywords.add(newKeyword.getKeyword());
				}
			}

			CompilationUnit cu = StaticJavaParser.parse(modelFile);

			List<MethodDeclaration> methods = cu.findAll(MethodDeclaration.class);
			for (MethodDeclaration method : methods) {
				method.getBody().ifPresent(blockStatement -> {

					for (Statement tmp : blockStatement.getStatements()) {
						tmp.removeComment();
						String line = tmp.toString();

						Keyword matchedKeyword = null;

						for (Keyword keyword : newKeywords) {
							
							if (!line.toLowerCase().contains(keyword.getKeyword().toLowerCase())) {
								continue;
							}

							if (matchedKeyword == null
									|| matchedKeyword.getKeyword().length() < keyword.getKeyword().length()) {
								matchedKeyword = keyword;
							}
						}

						if (matchedKeyword == null) {
							continue;
						}
												
						Keyword nextKeyword = new Keyword();
						
						String classNameFromPackage = getClassFromPackage(getParents(method));
						
						List<String> classNames = new ArrayList<>();
						classNames.add(classNameFromPackage);
						if (classNameFromPackage.toLowerCase().endsWith("impl")){
							classNames.add(classNameFromPackage.substring(0, classNameFromPackage.length() - 4));
						}
						
						for (String className: classNames) {

							String nextKeywordStr = className+"."+method.getNameAsString();
							
							logger.info(modelFile.getName()+" found Keyword "+matchedKeyword);
							logger.info("\tnext keyword: "+nextKeywordStr);
							
							nextKeyword.setKeyword(nextKeywordStr);
							nextKeyword.setChain(matchedKeyword.getChain());
							nextKeyword.getChain().add(matchedKeyword);
							nextKeyword.setFile(modelFile.getName());
							
							MatchResult matchResult = new MatchResult();
							matchResult.setMatchedKeyword(matchedKeyword);
							matchResult.setFile(modelFile.getName());
							matchResult.setNextKeyword(nextKeyword);
							matchResults.add(matchResult);
						}
						
					}
				});

			}
		}


	}
	
	private String getClassFromPackage(String fullPackage) {
		return fullPackage.split("\\.")[fullPackage.split("\\.").length-1];
	}
	
	String getParents(final Node declaration) {
        final StringBuilder path = new StringBuilder();

        declaration.walk(Node.TreeTraversal.PARENTS, node -> {
            if (node instanceof ClassOrInterfaceDeclaration) {
                path.insert(0, ((ClassOrInterfaceDeclaration) node).getNameAsString());
                path.insert(0, '$');
            }
            if (node instanceof ObjectCreationExpr) {
                path.insert(0, ((ObjectCreationExpr) node).getType().getNameAsString());
                path.insert(0, '$');
            }
            if (node instanceof MethodDeclaration) {
                path.insert(0, ((MethodDeclaration) node).getNameAsString());
                path.insert(0, '#');
            }
            if (node instanceof CompilationUnit) {
                final Optional<PackageDeclaration> pkg = ((CompilationUnit) node).getPackageDeclaration();
                if (pkg.isPresent()) {
                    path.replace(0, 1, ".");
                    path.insert(0, pkg.get().getNameAsString());
                }
            }
        });

        // convert StringBuilder into String and return the String
        return path.toString();
    }

    String getParameterAsString(NodeList<Parameter> parameters) {
        // easy task! convert parameter string list
        // into a single string (comma separated)
    	return parameters.toString();
    }

	private boolean isMatchResultsEquals(List<MatchResult> one, List<MatchResult> two) {
		if (one == null && two == null) {
			return true;
		}

		if ((one == null && two != null) || one != null && two == null || one.size() != two.size()) {
			return false;
		}

		// to avoid messing the order of the lists we will use a copy
		// as noted in comments by A. R. S.
		List<String> oneChainList = new ArrayList<>();
		List<String> twoChainList = new ArrayList<>();
		for (MatchResult record : one) {
			oneChainList.add(record.toString());
		}
		for (MatchResult record : two) {
			twoChainList.add(record.toString());
		}

		return String.join(",", oneChainList).equals(String.join(",", twoChainList));
	}

	private boolean isChainListEquals(List<Keyword> one, List<Keyword> two) {
		if (one == null && two == null) {
			return true;
		}

		if ((one == null && two != null) || one != null && two == null || one.size() != two.size()) {
			return false;
		}

		// to avoid messing the order of the lists we will use a copy
		// as noted in comments by A. R. S.
		List<String> oneChainList = new ArrayList<>();
		List<String> twoChainList = new ArrayList<>();
		for (Keyword keyword : one) {
			oneChainList.add(keyword.getKeyword());
		}
		for (Keyword keyword : two) {
			twoChainList.add(keyword.getKeyword());
		}

		return String.join(",", oneChainList).equals(String.join(",", twoChainList));
	}

	class ClassMethod {
		private String className;
		private String methodName;

		public ClassMethod(String matchLine) {
			matchLine.substring(matchLine.indexOf("|") + 1);
			String classAction = matchLine.substring(matchLine.indexOf("]") + 1);
			classAction = classAction.substring(0, classAction.indexOf("==>"));
			String[] packageName = classAction.split("\\.");
			classAction = packageName[packageName.length - 1];
			classAction = classAction.replace("#", ".");

			className = classAction.split("\\.")[0];
			methodName = classAction.split("\\.")[1];
		}

		public String getClassName() {
			return className;
		}

		public void setClassName(String className) {
			this.className = className;
		}

		public String getMethodName() {
			return methodName;
		}

		public void setMethodName(String methodName) {
			this.methodName = methodName;
		}

	}

	class Keyword {

		private String keyword;
		private List<Keyword> chain;
		private String file;
		private String originalClass;
		
		public String getOriginalClass() {
			return originalClass;
		}

		public void setOriginalClass(String originalClass) {
			this.originalClass = originalClass;
		}

		public Keyword() {
			chain = new ArrayList<>();
		}

		public String getKeyword() {
			return keyword;
		}

		public void setKeyword(String keyword) {
			this.keyword = keyword;
		}

		public List<Keyword> getChain() {
			return chain;
		}

		public void setChain(List<Keyword> chain) {
			this.chain = chain;
		}

		public String getFile() {
			return file;
		}

		public void setFile(String file) {
			this.file = file;
		}

		@Override
		public String toString() {
			List<String> chainList = new ArrayList<>();
			for (Keyword keyword: chain) {
				chainList.add(keyword.getKeyword());
			}
			Collections.reverse(chainList);
			return "Keyword [keyword=" + keyword + ", chain=" + String.join(" ==> ", chainList) + ", file=" + file + ", originalClass="
					+ originalClass + "]";
		}
		
	}

	class MatchResult {
		private Keyword matchedKeyword;
		private String file;
		private Keyword nextKeyword;
		
		public Keyword getNextKeyword() {
			return nextKeyword;
		}

		public void setNextKeyword(Keyword nextKeyword) {
			this.nextKeyword = nextKeyword;
		}
		
		public Keyword getMatchedKeyword() {
			return matchedKeyword;
		}

		public void setMatchedKeyword(Keyword matchedKeyword) {
			this.matchedKeyword = matchedKeyword;
		}

		public String getFile() {
			return file;
		}

		public void setFile(String file) {
			this.file = file;
		}

		@Override
		public String toString() {
			return "MatchResult [matchedKeyword=" + matchedKeyword + ", file=" + file + ", nextKeyword=" + nextKeyword + "]";
		}

		

	}

	private Set<Keyword> construtsKeywordList(File file, File modelFile, Set<Keyword> keywords) throws Exception {

		List<String> lines = Files.readAllLines(file.toPath(), Charset.defaultCharset());

		Set<Keyword> _keywords = new HashSet<>(keywords);
		for (Keyword keyword : keywords) {
			String keywordClassName = keyword.getKeyword().split("\\.")[0];
			String actionName = keyword.getKeyword().split("\\.")[1];

			if (!keywordClassName.toLowerCase().endsWith("impl")) {
				continue;
			}
			String className = keywordClassName.substring(0, keywordClassName.length() - 4);
			Keyword newKeyword = new Keyword();
			newKeyword.setKeyword(className + "." + actionName);
			newKeyword.setFile(keyword.getFile());
			newKeyword.setChain(keyword.getChain());
			_keywords.add(newKeyword);
		}

		Set<Keyword> newKeywords = new HashSet<>(keywords);

		for (Keyword keyword : keywords) {

			String keywordClassName = keyword.getKeyword().split("\\.")[0];
			String actionName = keyword.getKeyword().split("\\.")[1];

			Set<Keyword> tmpKeywordSet = new HashSet<>(keywords);

			Map<String, List<String>> classInstanceMap = new HashMap<>();
			for (String line : lines) {
				if (!line.contains("[OBJECT VARIABLE]") && !line.contains("[METHOD VARIABLE]")) {
					continue;
				}

				String variableLine = line.substring(line.indexOf("==>") + "==>".length());
				if (!variableLine.contains(" ")) {
					continue;
				}
				String className = variableLine.split(" ")[0];
				String instanceName = variableLine.split(" ")[1];

				if (!keywordClassName.equals(className)) {
					continue;
				}
				if (classInstanceMap.get(className) == null) {
					classInstanceMap.put(className, new ArrayList<>());
				}

				classInstanceMap.get(className).add(instanceName);

			}

			if (classInstanceMap.get(keywordClassName) == null) {
				continue;
			}

			for (String instanceName : classInstanceMap.get(keywordClassName)) {
				String instanceMethodCall = instanceName + "." + actionName;
				Boolean isAleadyExists = false;

				Keyword newKeyword = new Keyword();
				newKeyword.setKeyword(instanceMethodCall);
				newKeyword.setChain(keyword.getChain());
				newKeyword.getChain().add(keyword);
				newKeyword.setFile(modelFile.getName());
				newKeyword.setOriginalClass(keywordClassName);

				for (Keyword tmpKeyword : tmpKeywordSet) {
					if (!tmpKeyword.getKeyword().equals(instanceMethodCall)
							|| !isChainListEquals(tmpKeyword.getChain(), newKeyword.getChain())) {
						continue;
					}
					isAleadyExists = true;
					break;
				}
				if (isAleadyExists) {
					continue;
				}
				tmpKeywordSet.add(newKeyword);
				logger.debug("[ADD]" +newKeyword);
			}

			newKeywords.addAll(tmpKeywordSet);
		}
		
		keywords = new HashSet<>( newKeywords);
				
		CompilationUnit cu = StaticJavaParser.parse(modelFile);
		
		List<VariableDeclarator>variables = cu.findAll(VariableDeclarator.class);
		
		for (VariableDeclarator variable: variables){
			
			for (Keyword keyword : keywords) {
				
				Boolean isAleadyExists = false;

				String keywordClassName = keyword.getKeyword().split("\\.")[0];
				String actionName = keyword.getKeyword().split("\\.")[1];
			
				if (!keywordClassName.equals(variable.getTypeAsString())) {
					continue;
				}
				
				String instanceMethodCall = variable.getNameAsString()+"."+actionName;
				Keyword newKeyword = new Keyword();
				newKeyword.setKeyword(instanceMethodCall);
				newKeyword.setChain(keyword.getChain());
				newKeyword.getChain().add(keyword);
				newKeyword.setFile(modelFile.getName());
				newKeyword.setOriginalClass(keywordClassName);

				for (Keyword tmpKeyword : newKeywords) {
					if (!tmpKeyword.getKeyword().equals(instanceMethodCall)
							|| !isChainListEquals(tmpKeyword.getChain(), newKeyword.getChain())) {
						continue;
					}
					isAleadyExists = true;
					break;
				}
				if (isAleadyExists) {
					continue;
				}
				newKeywords.add(newKeyword);
				logger.debug("[ADD]" + newKeyword);
			}
			
		}

		return newKeywords;
	}

}
