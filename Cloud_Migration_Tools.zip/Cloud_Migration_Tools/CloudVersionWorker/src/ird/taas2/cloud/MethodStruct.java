package ird.taas2.cloud;

public class MethodStruct {    
    String parentNodes; 
    String returnType;  
    String methodName;  
    String parameters;  
    public MethodStruct(String parentNodes, String returnType, String methodName, String parameters) {
    	this.parentNodes = parentNodes;
    	this.returnType = returnType;
    	this.methodName = methodName;
    	this.parameters = parameters;
    }
}
