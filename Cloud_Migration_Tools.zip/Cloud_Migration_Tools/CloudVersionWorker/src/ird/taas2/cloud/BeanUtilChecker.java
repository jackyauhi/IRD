package ird.taas2.cloud;

import java.io.File;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.HashSet;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class BeanUtilChecker {
	public static void main(String[] args)throws Exception{
		BeanUtilChecker c = new BeanUtilChecker();
		c.process(new File(args[0]), new File(args[1]));
		
	}
	
	private void process(File beanUtilsFile, File programFolder) throws Exception{
		TreeMap<String, TreeSet<String>> jobSet = new TreeMap<>();
		
		scan(beanUtilsFile, programFolder, jobSet);

		for (Entry<String, TreeSet<String>> job: jobSet.entrySet()) {
			String jobname = job.getKey();
			for (String file: job.getValue()) {
				System.out.println(jobname+"\t"+file);
				jobname = "";
			}
		}
	}
	
	private void scan(File beanUtilsFile, File programFolder, TreeMap<String, TreeSet<String>> jobSet) throws Exception{
		
		if (programFolder.isDirectory()) {
			File[] files = programFolder.listFiles();
			for (File file: files) {
				scan(beanUtilsFile, file, jobSet);
			}
			return;
		}
				
		Set<String> beanFiles = new HashSet<>(Files.readAllLines(beanUtilsFile.toPath(), Charset.defaultCharset()));
		
		File programFile = programFolder;
		List<String> lines = Files.readAllLines(programFile.toPath(), Charset.defaultCharset());
		for (String line: lines) {
			for (String beanFile : beanFiles) {
				if (!line.contains(beanFile)) {
					line = line.trim();
					beanFile = beanFile.trim();
					continue;
				}
				String filename = programFolder.getName();
				filename = filename.replace("FullProgramList_SCAN_TC_ALL_", "");
				filename = filename.substring(0, filename.indexOf("_"));
				if (jobSet.get(filename) == null) {
					jobSet.put(filename, new TreeSet<>());
				}
				jobSet.get(filename).add(line);

				System.out.println(filename);
				break;
			}
		}
	}
	
	
}
