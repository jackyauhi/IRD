package ird.taas2.cloud;

import java.io.File;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.Set;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;

public class ContentChecker {
	public static void main(String[] args)throws Exception{
		ContentChecker cc = new ContentChecker();
		cc.process(new File(args[0]), new File(args[1]));
		
	}
	
	private void process(File fullFile, File deltaFile)throws Exception{
		Set<String> fullSet = new HashSet<>(Files.readAllLines(fullFile.toPath(), Charset.defaultCharset()));
		Set<String> deltaSet = new HashSet<>(Files.readAllLines(deltaFile.toPath(), Charset.defaultCharset()));
		
		List<String> newManual = new LinkedList<>();
		for (String delta: deltaSet) {
			if (!fullSet.contains(delta)) {
				newManual.add(delta);
				continue;
			}
			System.out.println(delta);
		}

		System.out.println("==========");
		
		for (String newManualItem: newManual) {
			System.out.println(newManualItem);
		}
	}
}
