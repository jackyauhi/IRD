package ird.taas2.cloud;


import java.io.File;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class ResultMapWorker {

	private Logger logger = Logger.getLogger(ResultMapWorker.class);
	
	public static void main(String[] args) throws Exception {
		ResultMapWorker c = new ResultMapWorker();
		c.process(new File(args[0]));
	}
	
	private void process(File folder)throws Exception{
		if (folder.isDirectory()) {
			File[] childs = folder.listFiles();
			for (File child: childs) {
				process(child);
			}
			return ;
		}
		if (!folder.getName().toLowerCase().endsWith(".xml")) {
			return;
		}
		try {

			constructSqlMap(folder);
		}catch(Exception e) {
			e.printStackTrace();
			logger.error(e);
		}
	}

	private void constructSqlMap(File sqlMapFile) throws Exception {
		
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		dbFactory.setValidating(false);
		dbFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);

		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document doc = dBuilder.parse(sqlMapFile);

		doc.getDocumentElement().normalize();

		NodeList docList = doc.getElementsByTagName("mapper");

		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");

		DOMSource all = new DOMSource(docList.item(0));
		StreamResult allConsoleResult = new StreamResult(new StringWriter());
		transformer.transform(all, allConsoleResult);
		
		if (doc.getElementsByTagName("mapper").getLength() == 0) {
			//logger.debug("No mapper element in "+sqlMapFile);
			return;
		}

		String nameSpace = ((Element) doc.getElementsByTagName("mapper").item(0)).getAttribute("namespace").trim();

		NodeList nList = doc.getElementsByTagName("mapper").item(0).getChildNodes();

		Map<String, String> map = new HashMap<>();
		Map<String, Node> nodeMap = new HashMap<>();
		
		for (int temp = 0; temp < nList.getLength(); temp++) {
			Node nNode = nList.item(temp);
			if (nNode.getNodeType() == Node.ELEMENT_NODE) {
				Element eElement = (Element) nNode;

				String id = (eElement.getAttribute("id")).trim();
				map.put(id, nodeToString(nNode));
				nodeMap.put(id, nNode);

			}
		}
		
		Map<String, ResultMap> resultMaps = new HashMap<>();
		
		try {
			resultMaps = getResultMaps(nameSpace, nList);
		}catch(Exception e) {
			e.printStackTrace();
			
		}
		
		for (Entry<String, Node> nodeEntry : nodeMap.entrySet()) {
			Node nNode = nodeEntry.getValue();
			try{
				Element eElement = (Element) nNode;
				
				String queryId = eElement.getAttribute("id").trim();
				String actionType = nNode.getNodeName();
				
				if (actionType.equalsIgnoreCase("resultMap")) {
					continue;
				}

				String resultMapId = eElement.getAttribute("resultMap").trim();
				
				if (resultMapId.contains(".")) {
					//logger.info(resultMapId+ " ==> "+resultMapId.substring(resultMapId.lastIndexOf(".")+1));
					resultMapId = resultMapId.substring(resultMapId.lastIndexOf(".")+1);
				}
				
				if (resultMaps.get(resultMapId) == null || resultMaps.get(resultMapId).get("extends") == null ) {
					continue;
				}

				logger.info(nameSpace + "." + queryId + " (" + actionType + ")" + " use "+resultMapId);
			}catch(Exception e) {
				logger.error(e);
			}
		}
	}

	private Map<String, ResultMap> getResultMaps(String namespace, NodeList nList) {
		Map<String, ResultMap> resultMaps = new HashMap<>();

		for (int temp = 0; temp < nList.getLength(); temp++) {
			Node nNode = nList.item(temp);
			if (nNode.getNodeType() != Node.ELEMENT_NODE) {
				continue;
			}
			Element eElement = (Element) nNode;

			if (!nNode.getNodeName().equalsIgnoreCase("resultMap")) {
				continue;
			}
			
			String resultMapId = eElement.getAttribute("id").trim();
			
			ResultMap resultMap = new ResultMap();
			
			String extendsAttribute = null;
			
			try {
				extendsAttribute = eElement.getAttribute("extends").trim();
				if (extendsAttribute == null || extendsAttribute.trim().length() == 0) {
					extendsAttribute = null;
				}
			}catch(Exception e) {}

			if (extendsAttribute != null) {
				resultMap.put("extends", extendsAttribute);
			}
			
			NodeList resultNodes = nNode.getChildNodes();
			
			for (int resultNodeIdx = 0; resultNodeIdx < resultNodes.getLength(); resultNodeIdx++) {
				
				Node resultNode = resultNodes.item(resultNodeIdx);
				
				if (resultNode.getNodeType() != Node.ELEMENT_NODE) {
					continue;
				}
				
				String nodeStr = this.nodeToString(resultNode);
				if (nodeStr.trim().length() == 0) {
					continue;
				}
				Element resultNodeElement = (Element) resultNode;
				String property = resultNodeElement.getAttribute("property").trim();
				String jdbcType = resultNodeElement.getAttribute("jdbcType").trim();
				
				resultMap.put(property, jdbcType);
				
			}

			
			if (resultMapId.contains(".")) {

				//logger.info(resultMapId+ " ==> "+resultMapId.substring(resultMapId.lastIndexOf(".")+1));
				resultMapId = resultMapId.substring(resultMapId.lastIndexOf(".")+1);
			}
			resultMaps.put(resultMapId, resultMap);
		}

		return resultMaps;
	}
	
	private String mapSubSql(String content) {
		content = content.substring(content.indexOf(">")+1);
		content = content.substring(0, content.lastIndexOf("</"));
		return content;
	}

	private String nodeToString(Node node, Boolean needParent) {
		StringWriter sw = new StringWriter();
		try {
			Transformer t = TransformerFactory.newInstance().newTransformer();
			t.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
			t.transform(new DOMSource(node), new StreamResult(sw));
		} catch (TransformerException te) {
			logger.error("nodeToString Transformer Exception");
		}
		if (needParent)
			return sw.toString();
		String content = sw.toString();
		content = content.substring(content.indexOf(">")+1);
		content = content.substring(0, content.lastIndexOf("</"));
		return content;
	}

	private String nodeToString(Node node) {
		return nodeToString(node, true);
	}
	
	private List<Node> getCollectionStack(Node node){
		List<Node> nodeList = new ArrayList<>();
		NodeList childNodes = node.getChildNodes();
		if (childNodes.getLength() == 0) {
			return nodeList;
		}
		for (int childNodeIdx = 0; childNodeIdx < childNodes.getLength(); childNodeIdx++) {
			nodeList.addAll(this.getCollectionStack(childNodes.item(childNodeIdx)));
			break;
		}
		return nodeList;
	}
	
	@SuppressWarnings("serial")
	class ResultMap extends HashMap<String, String>{}
}
