package ird.taas2.cloud;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.log4j.Logger;

import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.Modifier.Keyword;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.stmt.ReturnStmt;
import com.github.javaparser.ast.stmt.ExpressionStmt;

public class ModelWorker {

	private Logger logger = Logger.getLogger(ModelWorker.class);

	public static void main(String[] args) throws Exception {
		ModelWorker mw = new ModelWorker();
		mw.process(ParameterMap.getParameterMap(args));
	}

	public void process(ParameterMap parameterMap) throws Exception {

		File folder = new File(parameterMap.get("dir"));
		if(!folder.isDirectory()) {
			throw new Exception("Please specify a valid directory");
		}
		
		scan(folder, false);
	}

	private void scan(File folder, Boolean isUnderModelPackage)throws Exception {
		if (folder.isDirectory()) {
			if (folder.getName().equals("model")) {
				isUnderModelPackage = true;
			}
			if (isUnderModelPackage) {
				logger.info("Check "+folder.getAbsolutePath());
			}
			File[] childs = folder.listFiles();
			for (File child: childs) {
				scan(child, isUnderModelPackage);
			}
			return;
		}
		if (!isUnderModelPackage) {
			return;
		}
		File modelFile = folder;
		
		if (!modelFile.getName().toLowerCase().endsWith(".java")) {
			return;
		}
		if (modelFile.getName().toLowerCase().endsWith("example.java")) {
			return;
		}
		
		if (modelFile.getName().equals("TmpCtfwochgWithCtchchrgeCtchcsodoDetail.java")) {
			logger.info("START");
		}
		
		checkGetter(modelFile);
		checkSetter(modelFile);
		
		if (modelFile.getName().equals("TmpCtfwochgWithCtchchrgeCtchcsodoDetail.java")) {
			logger.info("END");
		}
	}
	
	public Boolean checkGetter(File modelFile) throws Exception {
		
		String modelFilename = modelFile.getName();

		CompilationUnit cu = StaticJavaParser.parse(modelFile);
		Map<FieldDeclaration, String> variableTypeMap = new HashMap<>();
		cu.findAll(FieldDeclaration.class).forEach(field -> {
			if (field.hasModifier(Keyword.FINAL)) {
				return;
			}
			variableTypeMap.put(field, field.getElementType().asString());
			logger.info(modelFilename+ " have "+field);
		});

		List<MethodDeclaration> methods = cu.findAll(MethodDeclaration.class);
		
		Map<String, List<MethodDeclaration>> variableGetterMap = new HashMap<>();
		
		for(Entry<FieldDeclaration, String> fieldTypeEntry: variableTypeMap.entrySet()) {
			FieldDeclaration field = fieldTypeEntry.getKey();
			
			String variableName = null;
			
			List<String > getterMethodNames = new ArrayList<>();
			for (VariableDeclarator variable : field.getVariables()) {
				variableName = variable.getNameAsString();
				getterMethodNames.add("get"+variableName.substring(0, 1).toUpperCase() + variableName.substring(1));
				getterMethodNames.add("get"+variableName);
			}
			
			if (variableName == null) {
				continue;
			}
			
			MethodDeclaration getterMethod = null;
			
			for(MethodDeclaration method: methods){
				for (String getterMethodName : getterMethodNames) {
					if (!method.getNameAsString().equals(getterMethodName)) {
						continue;
					}
					getterMethod = method;
				}
				if (getterMethod == null) {
					continue;
				}
				
				if (variableGetterMap.get(variableName) != null) {
					logger.debug(modelFilename+" Multi getter method "+method.getNameAsString()+" found");
				}else {
					variableGetterMap.put(variableName, new ArrayList<>());
				}
				variableGetterMap.get(variableName).add(method);
			}
			
			if (getterMethod != null) {
				continue;
			}
			
			logger.warn(modelFilename+" cannot found getter for variable "+variableName);
		}
		
		if (variableGetterMap.size() != variableTypeMap.size()) {
			logger.debug(modelFilename+" Getter for following properties is not exist: "+modelFile.getAbsolutePath());
			for(Entry<FieldDeclaration, String> fieldTypeEntry: variableTypeMap.entrySet()) {
				FieldDeclaration field = fieldTypeEntry.getKey();
				String variableName = field.getVariable(0).getNameAsString();
				if (variableGetterMap.get(variableName) != null) {
					continue;
				}
				logger.debug("\t"+field);
			}
		}
		
		for (Entry<String, List<MethodDeclaration>> variableGetterEntry: variableGetterMap.entrySet()) {
			String variableName = variableGetterEntry.getKey();
			
			List<MethodDeclaration> getterMethodsWithoutGettingVariable = new ArrayList<>();
			
			Boolean isValidGetterFound = false;
			
			for (MethodDeclaration getterMethod : variableGetterEntry.getValue()) {
				if (getterMethod.getParameters().size() > 1) {
					logger.warn(modelFilename+" Getter "+getterMethod.getNameAsString()+" have multi-parameter "+getterMethod.getParameters());
				}
				
				String thisVariable = "this."+variableName;
				
				Boolean isGuessedVariableUsed = false;
				
				List<ReturnStmt> returnStmts = getterMethod.findAll(ReturnStmt.class);
				
				for (ReturnStmt returnStmt: returnStmts) {
					returnStmt.removeComment();
					String returnStmtStr = returnStmt.toString();
					if (!returnStmtStr.contains(thisVariable) && !returnStmtStr.contains(variableName)) {
						logger.debug(modelFilename+" Skip "+returnStmtStr+" for "+variableName+"/"+thisVariable);
						continue;
					}
					logger.debug(modelFilename+" found return statement "+returnStmtStr+" for "+variableName+"/"+thisVariable);
					isGuessedVariableUsed = true;
				}
				
				if (isGuessedVariableUsed) {
					isValidGetterFound = true;
					continue;
				}
				
				getterMethodsWithoutGettingVariable.add(getterMethod);
			}
			
			if (isValidGetterFound) {
				continue;
			}
			
			for (MethodDeclaration getterMethod : getterMethodsWithoutGettingVariable) {
				List<ReturnStmt> returnStmts = getterMethod.findAll(ReturnStmt.class);
				logger.warn(modelFilename+" [CHECK]"+getterMethod.getNameAsString());
				logger.info("\t"+getterMethod.getTypeAsString() + " " + getterMethod.getName()+" should get "+variableName);
				for (ReturnStmt returnStmt: returnStmts) {
					returnStmt.removeComment();
					logger.warn("\t "+returnStmt);
				}
			}
		}
		return false;
	}
	
	private String guessVariableName(MethodDeclaration getterSetterMethod, Boolean lowerFirst) {
		String methodName = getterSetterMethod.getNameAsString();
		String guessVariable = methodName.substring(3);
		if (!lowerFirst) {
			return guessVariable;
		}
		logger.info(guessVariable);
		return guessVariable.substring(0, 1).toLowerCase() + guessVariable.substring(1);
	}
	
	private String guessVariableName(MethodDeclaration getterSetterMethod) {
		return guessVariableName(getterSetterMethod, true);
	}

	public Boolean checkSetter(File modelFile) throws Exception {
		
		String modelFilename = modelFile.getName();

		CompilationUnit cu = StaticJavaParser.parse(modelFile);
		Map<FieldDeclaration, String> variableTypeMap = new HashMap<>();
		cu.findAll(FieldDeclaration.class).forEach(field -> {
			if (field.hasModifier(Keyword.FINAL)) {
				return;
			}
			logger.info(modelFilename+ " have "+field);
			variableTypeMap.put(field, field.getElementType().asString());
		});

		List<MethodDeclaration> methods = cu.findAll(MethodDeclaration.class);
		
		Map<String, List<MethodDeclaration>> variableSetterMap = new HashMap<>();
		
		for(Entry<FieldDeclaration, String> fieldTypeEntry: variableTypeMap.entrySet()) {
			FieldDeclaration field = fieldTypeEntry.getKey();
			
			String variableName = null;
			
			List<String > setterMethodNames = new ArrayList<>();
			for (VariableDeclarator variable : field.getVariables()) {
				variableName = variable.getNameAsString();
				setterMethodNames.add("set"+variableName.substring(0, 1).toUpperCase() + variableName.substring(1));
				setterMethodNames.add("set"+variableName);
			}
			
			if (variableName == null) {
				continue;
			}
			
			MethodDeclaration setterMethod = null;
			
			for(MethodDeclaration method: methods){
				for (String setterMethodName : setterMethodNames) {
					if (!method.getNameAsString().equals(setterMethodName)) {
						continue;
					}
					setterMethod = method;
				}
				if (setterMethod == null) {
					continue;
				}
				
				if (variableSetterMap.get(variableName) != null) {
					logger.debug(modelFilename+" Multi setter method "+method.getNameAsString()+" found");
				}else {
					variableSetterMap.put(variableName, new ArrayList<>());
				}
				variableSetterMap.get(variableName).add(method);
			}
			
			if (setterMethod != null) {
				continue;
			}
			
			logger.warn(modelFilename+" cannot found setter for variable "+variableName);
		}
		
		if (variableSetterMap.size() != variableTypeMap.size()) {
			logger.debug(modelFilename+" Setter for following properties is not exist: "+modelFile.getAbsolutePath());
			for(Entry<FieldDeclaration, String> fieldTypeEntry: variableTypeMap.entrySet()) {
				FieldDeclaration field = fieldTypeEntry.getKey();
				String variableName = field.getVariable(0).getNameAsString();
				if (variableSetterMap.get(variableName) != null) {
					continue;
				}
				logger.debug("\t"+field);
			}
		}
		
		for (Entry<String, List<MethodDeclaration>> variableSetterEntry: variableSetterMap.entrySet()) {
			String variableName = variableSetterEntry.getKey();
			
			List<MethodDeclaration> setterMethodsWithoutSettingVariable = new ArrayList<>();
			
			Boolean isValidSetterFound = false;
			
			for (MethodDeclaration setterMethod : variableSetterEntry.getValue()) {
				if (setterMethod.getParameters().size() > 1) {
					logger.warn(modelFilename+" Setter "+setterMethod.getNameAsString()+" have multi-parameter "+setterMethod.getParameters());
				}
				
				String thisVariable = "this."+variableName;
				
				Boolean isGuessedVariableUsed = false;
				
				List<ExpressionStmt> expressionStmts = setterMethod.findAll(ExpressionStmt.class);
				
				for (ExpressionStmt expressionStmt: expressionStmts) {
					expressionStmt.removeComment();
					String expressionStmtStr = expressionStmt.toString();
					if (!expressionStmtStr.contains("=")) {
						logger.debug(modelFilename+" Skip expression stmt: "+expressionStmtStr);
						continue;
					}
					String assignTo = expressionStmtStr.substring(0, expressionStmtStr.indexOf("=")).trim();
					if (!assignTo.startsWith(thisVariable) && !assignTo.startsWith(variableName)) {
						logger.debug(modelFilename+" Skip "+expressionStmtStr+" for "+variableName+"/"+thisVariable);
						continue;
					}
					logger.debug(modelFilename+" found expression statement "+expressionStmtStr+" for "+variableName+"/"+thisVariable);
					isGuessedVariableUsed = true;
				}
				
				if (isGuessedVariableUsed) {
					isValidSetterFound = true;
					continue;
				}
				
				setterMethodsWithoutSettingVariable.add(setterMethod);
			}
			
			if (isValidSetterFound) {
				continue;
			}
			
			for (MethodDeclaration setterMethod : setterMethodsWithoutSettingVariable) {
				List<ExpressionStmt> expressionStmts = setterMethod.findAll(ExpressionStmt.class);
				logger.warn(modelFilename+" [CHECK]"+setterMethod.getNameAsString());
				logger.info("\t"+setterMethod.getTypeAsString() + " " + setterMethod.getName()+" should set "+variableName);
				for (ExpressionStmt expressionStmt: expressionStmts) {
					expressionStmt.removeComment();
					logger.warn("\t "+expressionStmt);
				}
			}
		}
		return false;
	}
}
