package ird.taas2.cloud;

public class FileVersion {
	private String file;
	private VersionType versionType;
	public String getFile() {
		return file;
	}
	public void setFile(String file) {
		this.file = file;
	}
	public VersionType getVersionType() {
		return versionType;
	}
	public void setVersionType(VersionType versionType) {
		this.versionType = versionType;
	}
}
