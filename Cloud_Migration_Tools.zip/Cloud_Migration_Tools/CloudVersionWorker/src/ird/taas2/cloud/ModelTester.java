package ird.taas2.cloud;

public class ModelTester {
	public static void main(String[] args) {
		Package[] packages = Package.getPackages();
		for (Package _package : packages) {
			System.out.println(_package.getName());
		}
	}
}
