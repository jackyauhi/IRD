package ird.taas2.cloud;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.util.HashMap;
import java.util.TreeMap;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class CloudVersionWorker {
	private int COLUMN_FILENAME = 9;
	private int COLUMN_VERSIONTYPE = 26;
	private int ROW_START_INDEX = 2;
	
	private Logger logger = Logger.getLogger(CloudVersionWorker.class);
	
	private String[] trimList = {
			"\\TAAS2_DEV\\PRD_Application\\Online",
			"\\TAAS2_DEV\\PRD_Application\\Batch"
	};
	
	public static void main(String[] args) throws Exception {
		CloudVersionWorker cvw = new CloudVersionWorker();
		cvw.process(cvw.getParameterMap(args));
	}
	
	public void process(ParameterMap parm) throws Exception {

		if (parm.get("dir") == null) {
			throw new Exception("File directory not specified");
		}
		
		File directory = new File(parm.get("dir"));
		
		if (!directory.isDirectory()) {
			throw new Exception(String.format("Invalid directory ", directory.getAbsolutePath()));
		}
		
		Boolean isRecursive = parm.get("r") != null && parm.get("r").equalsIgnoreCase("true");

		if (parm.get("out") == null) {
			throw new Exception("Output file not specified");
		}
		
		String prefix = parm.get("prefix");

		if (parm.get("vIdx") == null) {
			throw new Exception("Version column not specified");
		}
		
		if (parm.get("pIdx") == null) {
			throw new Exception("File column not specified");
		}
		
		COLUMN_FILENAME = Integer.valueOf(parm.get("pIdx"));
		COLUMN_VERSIONTYPE = Integer.valueOf(parm.get("vIdx"));
		
		TreeMap<String, VersionType> fileVersionsMap = new TreeMap<>();
		
		parseFileVersions(directory, prefix, isRecursive, fileVersionsMap);
		
		generateResult(fileVersionsMap, new File(parm.get("out")));
	} 
	
	private void generateResult(TreeMap<String, VersionType> fileVersions, File outputFile) throws Exception{
		FileWriter fw = new FileWriter(outputFile, false);
		for (Entry<String, VersionType> entry: fileVersions.entrySet()) {
			fw.append(String.format("%s\t%s\n", entry.getValue().getValue(), entry.getKey()));
		}
		fw.close();
		
		logger.info(String.format("Result file: %s", outputFile.getAbsolutePath()));
	}
	
	private void parseFileVersions(File directory, String prefix, Boolean isRecursive, TreeMap<String, VersionType> fileVersionsMap){
		if (directory.isDirectory()) {
			File[] files = directory.listFiles();
			for (File file: files) {
				if (prefix != null && !file.getName().startsWith(prefix)) {
					logger.info("Skip not match prefix "+file.getName());
					continue;
				}
				if (file.isDirectory() && !isRecursive) {
					continue;
				}
				parseFileVersions(file, prefix, isRecursive, fileVersionsMap);
			}
		}else {
			if (prefix != null && !directory.getName().startsWith(prefix)) {
				logger.info("Skip not match prefix "+directory.getName());
			}else {
				try {
					parseFileVersion(directory, fileVersionsMap);
					logger.info(String.format("%s parsed successfully", directory.getAbsolutePath()));
				}catch(Exception e) {
					logger.error(e);
				}
			}
		}
		
	}
	
	private void parseFileVersion(File xlsFile, TreeMap<String, VersionType> fileVersionsMap) throws Exception {
		if (!xlsFile.exists()) {
			throw new Exception(String.format("SpreadSheet file %s not exists ", xlsFile.getAbsolutePath()));
		}
		
		Workbook workbook = null;
		try {
			workbook = WorkbookFactory.create(new FileInputStream(xlsFile));
		}catch(EncryptedDocumentException e) {
			throw new Exception(String.format("Cannot parse encrypted spreadSheet file %s", xlsFile.getAbsolutePath()));
		} catch(Exception e) {
			throw new Exception(String.format("Invalid spreadSheet file %s", xlsFile.getAbsolutePath()));
		} 
		
		Sheet sheet = workbook.getSheetAt(0);

		for (Row row : sheet) {
			try {

				if (row.getRowNum() < ROW_START_INDEX) {
					logger.info(String.format("Skip line[%s] in file %s", row.getRowNum(), xlsFile.getAbsolutePath()));
					continue;
				}
				Cell fileCell = row.getCell(COLUMN_FILENAME);
				if (fileCell == null)
					continue;
				Cell versionCell = row.getCell(COLUMN_VERSIONTYPE);
				if (versionCell == null)
					continue;
				String file = fileCell.getStringCellValue();
				String version = versionCell.getStringCellValue();
				if (version.trim().length() == 0) {
					version = VersionType.BLANK.getValue();
				}
				
				if (file.trim().length() == 0 || version.trim().length() == 0) {
					logger.warn(String.format("Skip line %s", row.getRowNum()));
				}
				
				for (String trim: trimList) {
					if (!file.startsWith(trim)) {
						continue;
					}
					file = file.substring(trim.length());
				}
				
				if (file.contains("@@")) {
					file = file.substring(0, file.indexOf("@@"));
				}
				
				VersionType versionType = parseFileVersion(file, version);
				
				if (fileVersionsMap.get(file) != null && 
					(versionType == VersionType.UNKNOWN ||
					versionType == VersionType.BLANK)) {
					logger.info(String.format("Skip selected version %s of file %s", versionType.getValue(), file));
					continue;
				}
				
				if (versionType == VersionType.UNKNOWN ||
					versionType == VersionType.BLANK) {
					logger.info(String.format("Skip unknown version %s of file %s", versionType.getValue(), file));
					continue;
				}
				
				fileVersionsMap.put(file, versionType);
			}catch(Exception e) {
				logger.error("Cannot parse "+row.getRowNum()+" ("+e.getMessage()+")");
			}
		}
	}
	
	private VersionType parseFileVersion(String file, String version) {
		VersionType versionType = VersionType.UNKNOWN;
		switch(version.toLowerCase()) {
			case "batch":
			case "bacth":
				versionType = VersionType.BATCH;
				break;
			case "online":
				versionType = VersionType.ONLINE;
				break;
			case "same":
				versionType = VersionType.SAME;
				break;
			case "blank":
				versionType = VersionType.BLANK;
				break;
			case "merge":
				versionType = VersionType.MERGE;
				break;
			case "manual":
			case "taas-irm172":
				versionType = VersionType.MANUAL;
				break;
			default:
				logger.info(String.format("Unknown version type: %s of file %s", version, file));
		}
		return versionType;
	}

	public ParameterMap getParameterMap(String[] args) {
		ParameterMap parameterMap = new ParameterMap();

		for (int argsIdx = 0; argsIdx < args.length; argsIdx++) {
			String arg = args[argsIdx];
			if (!arg.startsWith("-")) {
				continue;
			}
			String value = null;
			try {
				value = args[argsIdx + 1];
			} catch (Exception e) {
			}
			if (value == null || value.startsWith("-")) {
				parameterMap.put(arg.substring(1), "true");
			} else {
				parameterMap.put(arg.substring(1), value);
			}
		}

		return parameterMap;
	}

	class ParameterMap extends HashMap<String, String> {
		private Logger logger = Logger.getLogger(ParameterMap.class);

		private static final long serialVersionUID = 1L;

		public String get(String key) {
			if (super.get(key) == null) {
				logger.warn("param[" + key + "] not exists ");
			}
			return super.get(key);
		}

		public String getDefault(String key, String defaultValue) {
			if (super.get(key) == null) {
				logger.warn("param[" + key + "] not exists, use defaultValue " + defaultValue);
				return defaultValue;
			}
			logger.info("param[" + key + "]: " + super.get(key));
			return super.get(key);
		}
	}
}
