/* * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* @(#) PEN321_03Obj.java		16/11/2021				**/
/*                                              		**/
/* Property of Treasury Computer Branch, HKSARG 		**/
/* All Right Reserved                           		**/
/*                                              		**/
/* SYSTEM                                       		**/
/*       Pension                                		**/
/*                                              		**/
/* AMENDMENT HISTORY                            		**/
/*  George Lam    	 	 16/11/2021 - creation  		**/
/*  									                **/
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * */
package treasury.pension.report;

import treasury.pension.interfaces.ApplicantJson;
import treasury.pension.interfaces.SubmitJson;

public class PEN420_01Obj {
	
	/* Database Fields */
	private String iamSmartRefNo;
	private String iamSmartEmail;
	private String iamHkic;
	private String engName;
	private String chiName;
	private String submissionDate;
	private String submissionTime;
	private String hkic;
	private String penType;
	private String resAddress1;
	private String resAddress2;
	private String resAddress3;
	private String resCountryCode;
	private String sameAsRes;
	private String corAddress1;
	private String corAddress2;
	private String corAddress3;
	private String corCountryCode;
	private String phoneNo1;
	private String phoneNo2;
	private String faxNo;
	private String emailAddress;	
	private String uploadStatus;
	
	public PEN420_01Obj() {
		
	}
	
	public PEN420_01Obj(ApplicantJson json1,SubmitJson json2, String penTypeList) {
		 this.iamSmartRefNo = json2.getTrnId();
		 this.iamSmartEmail = json2.getEmail();
		 this.iamHkic = json1.getHkid().getId()+json1.getHkid().getCheckDigit();
		 this.engName = json1.getFullEnglishName();
		 this.chiName = json1.getChineseName();
		 this.submissionDate = json2.getSubmitTime().substring(0,10);
		 this.submissionTime = json2.getSubmitTime().substring(11,19);
		 this.hkic = json1.getHkid().getId()+json1.getHkid().getCheckDigit();
		 this.sameAsRes = json1.getSameAsResAddr();
		 
		 this.penType = penTypeList;
		 
		 if(json1.getResAddrLang()!=null) {
			 if("eng".equals(json1.getResAddrLang())) {
				 this.resAddress1 = json1.getEngResAddrLine1();
				 this.resAddress2 = json1.getEngResAddrLine2();
				 this.resAddress3 = json1.getEngResAddrLine3();
			 }else {
				 this.resAddress1 = json1.getChiResAddrLine1();
				 this.resAddress2 = json1.getChiResAddrLine2();
				 this.resAddress3 = json1.getChiResAddrLine3(); 
			 }	 
		 }
		 //Special handling from OGCIO eForm for the key CorrAddrLang and CorrAddrLang2. 
		 //Either CorrAddrLang or CorrAddrLang2 will be existed in the uploaded JSON files.
		 //When Both Residential Address and Correspondence Address are input in the OGCIO eForm, the key CorrAddrLang2 will be appeared in the JSON files
		 //When only one kind of Address(Residential or Correpsondence) is input in the OGCIO eForm, the key CorrAddrLang will be appeared in the JSON files
		 //The key CorrAddrLang and CorrAddrLang2 will not be existed at the same time in the same JSON files.
		 if(json1.getCorrAddrLang()!=null) {
			 if("eng".equals(json1.getCorrAddrLang())) {
				 this.corAddress1 = json1.getEngCorrAddrLine1();
				 this.corAddress2 = json1.getEngCorrAddrLine2();
				 this.corAddress3 = json1.getEngCorrAddrLine3();
			 }else {
				 this.corAddress1 = json1.getChiCorrAddrLine1();
				 this.corAddress2 = json1.getChiCorrAddrLine2();
				 this.corAddress3 = json1.getChiCorrAddrLine3(); 
			 }
		 }
		 if(json1.getCorrAddrLang2()!=null) {
			 if("eng".equals(json1.getCorrAddrLang2())) {
				 this.corAddress1 = json1.getEngCorrAddrLine1();
				 this.corAddress2 = json1.getEngCorrAddrLine2();
				 this.corAddress3 = json1.getEngCorrAddrLine3();
			 }else {
				 this.corAddress1 = json1.getChiCorrAddrLine1();
				 this.corAddress2 = json1.getChiCorrAddrLine2();
				 this.corAddress3 = json1.getChiCorrAddrLine3(); 
			 }
		 }
		 this.phoneNo1 = json1.getPhone1()!=null?json1.getPhone1():null;
		 this.phoneNo2 = json1.getPhone2()!=null?json1.getPhone2():null;
		 this.faxNo = json1.getFax()!=null?json1.getFax():null;
		 this.emailAddress = json1.getEmail()!=null?json1.getEmail():null;	
		 this.uploadStatus = "Success";
		 this.resCountryCode = json1.getResCountryRegion()!=null?json1.getResCountryRegion():null;
		 this.corCountryCode = json1.getCorrCountryRegion()!=null?json1.getCorrCountryRegion():null;
	}
	
	public String getSameAsRes() {
		return sameAsRes;
	}
	public void setSameAsRes(String sameAsRes) {
		this.sameAsRes = sameAsRes;
	}
	public String getIamSmartRefNo() {
		return iamSmartRefNo;
	}
	public void setIamSmartRefNo(String iamSmartRefNo) {
		this.iamSmartRefNo = iamSmartRefNo;
	}
	public String getIamSmartEmail() {
		return iamSmartEmail;
	}
	public void setIamSmartEmail(String iamSmartEmail) {
		this.iamSmartEmail = iamSmartEmail;
	}
	public String getIamHkic() {
		return iamHkic;
	}
	public void setIamHkic(String iamHkic) {
		this.iamHkic = iamHkic;
	}
	public String getEngName() {
		return engName;
	}
	public void setEngName(String engName) {
		this.engName = engName;
	}
	public String getChiName() {
		return chiName;
	}
	public void setChiName(String chiName) {
		this.chiName = chiName;
	}
	public String getSubmissionDate() {
		return submissionDate;
	}
	public void setSubmissionDate(String submissionDate) {
		this.submissionDate = submissionDate;
	}
	public String getSubmissionTime() {
		return submissionTime;
	}
	public void setSubmissionTime(String submissionTime) {
		this.submissionTime = submissionTime;
	}
	public String getHkic() {
		return hkic;
	}
	public void setHkic(String hkic) {
		this.hkic = hkic;
	}
	public String getPenType() {
		return penType;
	}
	public void setPenType(String penType) {
		this.penType = penType;
	}
	public String getResAddress1() {
		return resAddress1;
	}
	public void setResAddress1(String resAddress1) {
		this.resAddress1 = resAddress1;
	}
	public String getResAddress2() {
		return resAddress2;
	}
	public void setResAddress2(String resAddress2) {
		this.resAddress2 = resAddress2;
	}
	public String getResAddress3() {
		return resAddress3;
	}
	public void setResAddress3(String resAddress3) {
		this.resAddress3 = resAddress3;
	}
	public String getCorAddress1() {
		return corAddress1;
	}
	public void setCorAddress1(String corAddress1) {
		this.corAddress1 = corAddress1;
	}
	public String getCorAddress2() {
		return corAddress2;
	}
	public void setCorAddress2(String corAddress2) {
		this.corAddress2 = corAddress2;
	}
	public String getCorAddress3() {
		return corAddress3;
	}
	public void setCorAddress3(String corAddress3) {
		this.corAddress3 = corAddress3;
	}
	public String getPhoneNo1() {
		return phoneNo1;
	}
	public void setPhoneNo1(String phoneNo1) {
		this.phoneNo1 = phoneNo1;
	}
	public String getPhoneNo2() {
		return phoneNo2;
	}
	public void setPhoneNo2(String phoneNo2) {
		this.phoneNo2 = phoneNo2;
	}
	public String getFaxNo() {
		return faxNo;
	}
	public void setFaxNo(String faxNo) {
		this.faxNo = faxNo;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getUploadStatus() {
		return uploadStatus;
	}
	public void setUploadStatus(String uploadStatus) {
		this.uploadStatus = uploadStatus;
	}

	public String getResCountryCode() {
		return resCountryCode;
	}

	public void setResCountryCode(String resCountryCode) {
		this.resCountryCode = resCountryCode;
	}

	public String getCorCountryCode() {
		return corCountryCode;
	}

	public void setCorCountryCode(String corCountryCode) {
		this.corCountryCode = corCountryCode;
	}

	@Override
	public String toString() {
		return "PEN420_01Obj [iamSmartRefNo=" + iamSmartRefNo + ", iamSmartEmail=" + iamSmartEmail + ", iamHkic="
				+ iamHkic + ", engName=" + engName + ", chiName=" + chiName + ", submissionDate=" + submissionDate
				+ ", submissionTime=" + submissionTime + ", hkic=" + hkic + ", penType=" + penType + ", resAddress1="
				+ resAddress1 + ", resAddress2=" + resAddress2 + ", resAddress3=" + resAddress3 + ", resCountryCode="
				+ resCountryCode + ", sameAsRes=" + sameAsRes + ", corAddress1=" + corAddress1 + ", corAddress2="
				+ corAddress2 + ", corAddress3=" + corAddress3 + ", corCountryCode=" + corCountryCode + ", phoneNo1="
				+ phoneNo1 + ", phoneNo2=" + phoneNo2 + ", faxNo=" + faxNo + ", emailAddress=" + emailAddress
				+ ", uploadStatus=" + uploadStatus + "]";
	}
	
}
