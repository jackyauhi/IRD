/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* @(#) PenDtl.java                 	       11/2004  	**/
/*                                              			**/
/* Property of Treasury Computer Branch, HKSARG 			**/
/* All Right Reserved                           			**/
/*                                              			**/
/* SYSTEM                                       			**/
/*       PENSION                                     		**/
/*                                              			**/
/* AMENDMENT HISTORY                            			**/
/*  Carmen Yu  15/1/2015 - add column Appointment Term Code	**/
/*Agnes Chow PMS-15-024 - 03/11/2015 add field Dept Code for Distribution of Pension Paper **/ 
/*Agnes Chow PMS-15-013 - 07/10/2015 revise Pension Notification Forms GF539, GF540, GF29 and GF29B**/
/*  Thomas Chan 26/8/2016 - revert changes in version 325   **/
/*  Thomas Chan 26/8/2016 - re-apply changes in version 325 **/
/*  Connie LAM  21/04/2020 - Extension of Statutory         **/
/*                           Retirement Ages of JJO         **/
/*                           New Retire Scheme A, B, C, D, E**/
/*  Connie LAM  01/12/2020 - Do NOT generate Hardcopy and   **/
/*							 Email to Designated Pensioners **/
/*                           who are in the Statement       **/
/*                           Exclusion List                 **/
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package treasury.pension.pendtl;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.Types;
import java.util.Collections;
import java.util.List;
import java.util.Vector;

import treasury.payroll.common.DBObject;
import treasury.payroll.common.DBObjectException;
import treasury.payroll.common.DBSecurityException;
import treasury.payroll.common.PaysError;
import treasury.payroll.common.PaysErrors;
import treasury.payroll.common.User;
import treasury.payroll.udlcommon.UdcIsMultipleOf;
import treasury.payroll.util.DateUtil;
import treasury.payroll.util.GettersComparator;
import treasury.payroll.util.PaysLocale;
import treasury.payroll.util.SqlRunner;
import treasury.payroll.util.StringUtil;
import treasury.pension.batch.ProcessWmpRev;
import treasury.pension.common.AbstractPenDtlObject;
import treasury.pension.control.AuthPay;
import treasury.pension.pays.PaysApptTerm;
import treasury.pension.pensioner.PenProfile;
import treasury.pension.pp.Pnpp01Process;
import treasury.pension.pp.Pnpp02Process;
import treasury.pension.pp.Pnpp03Process;
import treasury.pension.pp.Pnpp05Process;
import treasury.pension.pp.Pnpp06Process;
import treasury.pension.pp.Pnpp07Process;
import treasury.pension.pp.Pnpp08Process;
import treasury.pension.tm.Pntm01Process;
import treasury.pension.tm.Pntm02Process;
import treasury.pension.tm.Pntm03Process;
import treasury.pension.tm.Pntm04Process;
import treasury.pension.updlog.StmtExclList;
import treasury.pension.util.PensHkicUtil;

/**
 * Pension Detail Object
 * @author  Team 4
 * @version 1.0
 */
public class PenDtl extends AbstractPenDtlObject{

	/**
	 * constant serial version UID make sure always the same
	 */
	public static final String UID = DB_PENS + new PenDtl().getDBTableName();
	public static final long serialVersionUID = UID.hashCode();

	/**
	 * simple DDL for pension details
	 */
	public static final String DG_NOM_IND_0 = "0";
	public static final String DG_NOM_IND_1 = "1";
	public static final String DG_NOM_IND_2 = "2";
	public static final String DG_NOM_IND_3 = "3";
	public static final String DG_NOM_IND_4 = "4";
	public static final String[] DG_NOM_IND = {DG_NOM_IND_0, DG_NOM_IND_1, DG_NOM_IND_2, DG_NOM_IND_3, DG_NOM_IND_4};

	public static final String RETIRE_CAUSE_01 = "01";
	public static final String RETIRE_CAUSE_02 = "02";
	public static final String RETIRE_CAUSE_03 = "03";
	public static final String RETIRE_CAUSE_04 = "04";
	public static final String RETIRE_CAUSE_08 = "08";
	public static final String RETIRE_CAUSE_09 = "09";
	public static final String RETIRE_CAUSE_15 = "15";
	public static final String[] RETIRE_CAUSE = {RETIRE_CAUSE_01, RETIRE_CAUSE_02, RETIRE_CAUSE_03, RETIRE_CAUSE_04, RETIRE_CAUSE_08, RETIRE_CAUSE_09, RETIRE_CAUSE_15};
	
	public static final String PEN_TERM_CODE_DECEASED		= "DC";
	public static final String PEN_TERM_CODE_AGE_LIMIT 		= "AL";
	public static final String PEN_TERM_CODE_REMARRIED 		= "RM";
	public static final String PEN_TERM_CODE_CANCELLATION 	= "CN";
	public static final String PEN_TERM_CODE_DECEASED_BEFORE_PENSION_DUE = "DP";
	public static final String PEN_TERM_CODE_ONE_TIME = "OG";
	public static final String[] PEN_TERM_CODE = {PEN_TERM_CODE_DECEASED, PEN_TERM_CODE_AGE_LIMIT, PEN_TERM_CODE_REMARRIED, PEN_TERM_CODE_CANCELLATION, PEN_TERM_CODE_DECEASED_BEFORE_PENSION_DUE};
	
	public static final String PYMT_TYPE_ONETIME = "O";
	public static final String PYMT_TYPE_MONTHLY = "M";	
	
	public static final String ELECTRON_SIGN = "E";
	public static final String MANUAL_SIGN = "S";

	public static final String CONFIRM_DEPTTYPE_DEPT = "D";
	public static final String CONFIRM_DEPTTYPE_HOG = "H";

	public static final String[] RESIGNED_OFFICER = {"A3", "A4", "A5", "A6"};
	public static final String[] SC_SPOUSE_PEN_TYPE = {"S1"};
	public static final String[] SC_CHILD_PEN_TYPE = {"S2", "S3", "S4", "S5", "S6", "S7", "S8", "S9"};
	public static final String[] WO_SPOUSE_PEN_TYPE = {"H1", "H2", "H3"};
	public static final String[] WO_CHILD_PEN_TYPE = {"H5", "H6", "H7", "H8", "H9"};
	public final static String[] Z_PENTYPE = { "Z0" }; 	
	public final static String[] J_SELF_PENTYPE = { "J1" }; 		
	public final static String[] J_CHILD_PENTYPE = { "J2", "J3", "J4", "J5", "J6", "J7" }; 
	public final static String[] J_PARENT_PENTYPE = { "J8", "J9" }; 	
	public final static String[] J_SINGLE_PARENT_PENTYPE = { "J8"}; 		
	public final static String[] C_PENTYPE = { "C1", "C2", "C3", "C4" }; 					
	public static final String[] B_CHILD_PEN_TYPE = {"B2", "B3", "B4", "B5", "B6"};	
	public static final String[] T_CHILD_PEN_TYPE = {"T3", "T4", "T5", "T6", "T7", "T8"};
	
	public static final String[] O_SELF_PEN_TYPE = {"B1", "D1", "D2", "E1", "F1", 
		"F9", "G1", "M0", "T1", "W1"};
	public static final String[] O_SPOUSE_PEN_TYPE = {"B7", "F2", "G2"};
	public static final String[] O_CHILD_PEN_TYPE = {"B2", "B3", "B4", "B5", "B6", "G3", 
		"T3", "T4", "T5", "T6", "T7", "T8"};
	public static final String[] O_DEPENDANT_PEN_TYPE = {"E2"};
	public static final String[] O_PARENT_PEN_TYPE = {"T9"};
	
	public static final String[] O_SPOUSE_PARENT_PEN_TYPE = {"T2"};
	
	public final static String[] WOSC_PEN_TYPE = {"H", "S", "R"};
	
	public final static String[] ALL_SELF_PEN_TYPE = { "A1", "A2", "A3", "A4", "A5", "A6", "A7", "A8", "A9",
													   "B1", "C1", "C2", "C3", "C4", "D1", "D2", "E1", "F1",
													   "F9", "G1", "M0", "T1", "W1", "R1", "R2", "Z0"
													 };
	
	public final static String[] ALL_SPOUSE_PEN_TYPE = { "B7", "F2", "G2", "H1", "H2", "H3", "J1", "S1", "T2", "W2"
													 };

	public final static Date MATERIAL_DT_UPPER = DateUtil.parse("31/12/1988");	
	public final static Date MATERIAL_DT_LOWER = DateUtil.parse("01/04/1987");			
	
	public final static String[][] INJURYDT_DED_PERC =     {{null, "1.5", "50"},
															{"1.5", "2.5", "45"},
															{"2.5", "3.5", "40"},															
															{"3.5", "4.5", "30"},															
															{"4.5", "5.5", "20"},															
															{"5.5", "6.5", "15"},															
															{"6.5", "7.5", "10"},															
															{"7.5", null, "0"} };
															
	public final static Date INJURY_DT_CUTOFF = DateUtil.parse("01/02/1993");			
 
	/* HKIC No. */
	private String hkic;

	/* Pension Type */
	private String penType;

	/* Pension Detail Serial No */
	private BigDecimal penInputNum;

	/* Start Date */
	private Date sdt;

	/* End Date */
	private Date edt;

	/* Appt Start Date */
	private Date apptSdt;

	/* Appt End Date */
	private Date apptEdt;

	/* Date of Retire/Resignation/Death */
	private Date penDt;

	/* Last Department Code */
	private String lastDeptCode;

	/* Termin Code */
	private String terminCode;

	/* Appointment Term Code */
	private String apptTermCode;

	/* Authority of Payment */
	private String authPymt;

	/* Cause of Pension */
	private String penCause;

	/* Date of Commencement in an Established Office */
	private Date commPeDt;

	/* Date of Confirmation in an Established Office */
	private Date confirmPeDt;

	/* Material Date for re-opting from 90% to 100 % */
	private Date materialDt;

	/* Retirement Scheme Code */
	private String retireScheme;

	/* Pensionability Code */
	private String pensionability;

	/* Annual Pension Option % */
	private BigDecimal penOptPerc;

	/* Pension Deduction % */
	private BigDecimal penDedPerc;

	/* Highest Pensionable Emoluments */
	private BigDecimal penHpe;

	/* Highest Pensionable Emoluments Attained Date */
	private Date penHpeDt;

	/* Highest Pensionable Emoluments for calculation */
	private BigDecimal calHpe;

	/* Last Substantive Salary */
	private BigDecimal lastSal;

	/* Transfer Term */
	private String xfTerm;

	/* Unauthorized Absence */
//	private BigDecimal unauthAbs;
	private BigDecimal unauthAbsYy;
	private BigDecimal unauthAbsMm;
	private BigDecimal unauthAbsDd;

	/* Injured Approval Date */
	private BigDecimal noPayLeav;

	/* Untaken Leave */
	private BigDecimal untakenLeav;

	/* Date of Medical Board */
	private Date medBoardDt;

	/* Injured Percentage */
	private BigDecimal injuPerc;
	
	/* Injury Type */
	private String injuType;
	
	/* Accelerate Indicator */
	private String accelerateInd;
	
	/* Reassess Date */
	private Date reassessDt;
	
	/* Nominated spouse */
	private String dgNomInd;

	/* Entitle Amount (for type Bx, Fx, Gx, Tx, Wx only) */
	private BigDecimal ettlAmt;

	/* Pension Payment Type (for type Bx, Fx, Gx, Tx, Wx only) */
	private String pymtType;

	/* Scheme Start Date (for type Hx, Sx, Rx only)*/
	private Date schemeSdt;

	/* Scheme End Date (for type Hx, Sx, Rx only)*/
	private Date schemeEdt;

	/* Acquire Minimum Benefit (for type Sx only)*/
	private String acqMinBenefit;

	/* Pensionable Personal Allowance  */
	private String ppaApprInd;
	
	/* Notify Remarks*/
	private String notifyRemarks;
	
	/* Payee ID */
	private String payeeId;

	/* First Input Date */
	private Date firstInputDt;

	/* First Input Id */
	private String firstInputId;

	/* Confirm Input Date */
	private Date confirmInpDt;

	/* Confirm Id */
	private String confirmId;

	/* Signature Type */
	private String signType;

	/* Route to Sign User ID */
	private String toSignId;

	/* Notify Sign Date */
	private Date notifySignDt;

	/* Sign Date */
	private Date signDt;

	/* Sign Id */
	private String signId;

	/* Cancel Notification Date */
//	private Date cancelInputDt;
	private Date cancelInpDt;

	/* Last Amend Date of Pension Details */
	private Date lastAmendDt;

	/* Amend Count of Pension Details */
	private BigDecimal amendCnt;

	/* Confirm Details Date */
	private Date confirmDtlDt;

	/* Route to Confirm User ID */
	private String toConfirmId;

	/* Confirm Department Code */
//	private String confirmDept;

	/* Confirm Department Type */
//	private String confirmDeptTy;

	/* Pension Termination Code */
	private String penTermCode;

	/* Pension Termination Date */
	private Date penTermDt;
	
	/* Pension Termination Input Date */
	private Date penTermInpDt;

	/* Cancel Pension Termination Date */
	private Date cancelTermDt;
	
	/* Cancel Pension Termination User ID */
	private String cancelTermId;

	/* Remarks */
	private String remarks;
	
	/*Conv Rec Ind */
	private String convRecInd;
	
	/* Pension Type Group */
	private String penGroup;
 
	//AC20151007 start
	private Date commQualServDt; 
	private String noOneOffLumpSum;	 
	private String memoRef; 
	private Date memoRefSubmitDt;
	private Date certifyDt;
	//AC20151007 end	
 
	//AC20151103 start
	/* Department Code for Distribution of Pension Paper */
	private String deptDistPenPaper;
	//AC20151103 end
	
	//YS20170517 start
	private String penPymtMethod;
	private String pymtFreq;
	private String barCode;
	//YS20170517 end
	
	/* constructor */
	public PenDtl() {
	}

	/* constructor */
	public PenDtl(String hkic, String penType) {
		this.hkic = hkic;
		this.penType = penType;
	}

	public String getDBTableName() {
		return "t40pen_dtl";
	}

	public String[] getDBColumnNames() {
		String[] columns =
			{
			"c40hkic",
			"c40pen_type",
			"c40pen_input_num",
			"c40sdt",
			"c40edt",
			"c40pen_dt",
			"c40appt_sdt",
			"c40appt_edt",
			"c40last_dept_code",
			"c40termin_code",
			"c40appt_term_code",
			"c40auth_pymt",
			"c40pen_cause",
			"c40comm_pe_dt",
			"c40confirm_pe_dt",
			"c40material_dt",
			"c40retire_scheme",
			"c40pensionability",
			"c40pen_opt_perc",
			"c40pen_ded_perc",
			"c40pen_hpe",
			"c40pen_hpe_dt",
			"c40cal_hpe",
			"c40last_sal",
			"c40xf_term",
//			"c40unauth_abs",
			"c40unauth_abs_yy",
			"c40unauth_abs_mm",
			"c40unauth_abs_dd",
			"c40no_pay_leav",
			"c40untaken_leav",
			"c40med_board_dt",
			"c40inju_perc",
			"c40inju_type",
			"c40accelerate_ind",
			"c40reassess_dt",
			"c40dg_nom_ind",
			"c40ettl_amt",
			"c40pymt_type",
			"c40scheme_sdt",
			"c40scheme_edt",
			"c40acq_min_benefit",
			"c40ppa_appr_ind",
			"c40notify_remarks",
			"c40payee_id",
			"c40first_input_dt",
			"c40first_input_id",
			"c40to_confirm_id",
			"c40confirm_inp_dt",
			"c40confirm_id",
			"c40sign_type",
			"c40to_sign_id",
			"c40notify_sign_dt",
			"c40sign_dt",
			"c40sign_id",
			"c40cancel_inp_dt",
			"c40last_amend_dt",
			"c40amend_cnt",
			"c40confirm_dtl_dt",
			"c40pen_term_code",
			"c40pen_term_dt",
			"c40pen_term_inp_dt",
			"c40cancel_term_dt",
			"c40cancel_term_id", 
			"c40conv_rec_ind",
			"c40comm_qual_serv_dt",     //AC20151007
			"C40no_oneoff_lumpsum",     //AC20151007			 
			"c40memo_ref_submit_dt",    //AC20151007
			"c40memo_ref",			    //AC20151007			
			"c40certify_dt",		    //AC20151007
			"c40dept_dist_penpaper"     //AC20151103
			};
		return columns;
	}

	public String[] getFieldNames() {
		String[] fields =
			{
				"Hkic",
				"PenType",
				"PenInputNum",
				"Sdt",
				"Edt",
				"PenDt",
				"ApptSdt",
				"ApptEdt",
				"LastDeptCode",
				"TerminCode",
				"ApptTermCode",
				"AuthPymt",
				"PenCause",
				"CommPeDt",
				"ConfirmPeDt",
				"MaterialDt",
				"RetireScheme",
				"Pensionability",
				"PenOptPerc",
				"PenDedPerc",
				"PenHpe",
				"PenHpeDt",
				"CalHpe",
				"LastSal",
				"XfTerm",
//				"UnauthAbs",
				"UnauthAbsYy",
				"UnauthAbsMm",
				"UnauthAbsDd",
				"NoPayLeav",
				"UntakenLeav",
				"MedBoardDt",
				"InjuPerc",
				"InjuType",
				"AccelerateInd",
				"ReassessDt",
				"DgNomInd",
				"EttlAmt",
				"PymtType",
				"SchemeSdt",
				"SchemeEdt",
				"AcqMinBenefit",
				"PpaApprInd",
				"NotifyRemarks",
				"PayeeId",
				"FirstInputDt",
				"FirstInputId",
				"ToConfirmId",
				"ConfirmInpDt",
				"ConfirmId",
				"SignType",
				"ToSignId",
				"NotifySignDt",
				"SignDt",
				"SignId",
//				"CancelInputDt",
				"CancelInpDt",
				"LastAmendDt",
				"AmendCnt",
				"ConfirmDtlDt",
				"PenTermCode",
				"PenTermDt",
				"PenTermInpDt",
				"CancelTermDt",
				"CancelTermId", 
				"ConvRecInd",
				"CommQualServDt", 		//AC20151007
				"NoOneOffLumpSum", 		//AC20151007				 
				"MemoRefSubmitDt",		//AC20151007
				"MemoRef",   		    //AC20151007 				
				"CertifyDt",			//AC20151007 
				"DeptDistPenPaper"		//AC20151103
				};
		return fields;
	}

	public String key() {
		return "";
	}

	public String[] getPKey() {
		String[] pkey = { "Hkic", "PenType", "PenInputNum"};
		return pkey;
	}

	// getters setters
	/* PPN */
	public String getPpn() {
		return this.hkic + "-" + this.penType;
	}

	public void setPpn(String Ppn) {
		setHkic(Ppn.substring(0, Ppn.indexOf("-")));
		setPenType(Ppn.substring(Ppn.indexOf("-") + 1, Ppn.length()));
	}

	public static String getHkicFrPpn(String Ppn) {
		return Ppn.substring(0, Ppn.indexOf("-"));
	}

	public static String getPenTypeFrPpn(String Ppn) {
		return Ppn.substring(Ppn.indexOf("-") + 1, Ppn.length());
	}

	/* HKIC No. */
	public void setHkic(String hkic) {
		this.hkic = hkic;
	}
	public String getHkic() {
		return this.hkic;
	}

	/* Pension Type */
	public void setPenType(String penType) {
		this.penType = penType;
	}
	public String getPenType() {
		return this.penType;
	}

	public void setPenInputNum(BigDecimal penInputNum) {
		this.penInputNum = penInputNum;
	}
	public BigDecimal getPenInputNum() {
		return this.penInputNum;
	}

	/* Start Date */
	public void setSdt(Date sdt) {
		this.sdt = sdt;
	}
	public Date getSdt() {
		return this.sdt;
	}

	/* End Date */
	public void setEdt(Date edt) {
		this.edt = edt;
	}
	public Date getEdt() {
		return this.edt;
	}

	/* Pension Start Date */
	public void setPenDt(Date penDt) {
		this.penDt = penDt;
	}
	public Date getPenDt() {
		return this.penDt;
	}

	/* Appt Start Date */
	public void setApptSdt(Date apptSdt) {
		this.apptSdt = apptSdt;
	}
	public Date getApptSdt() {
		return this.apptSdt;
	}

	/* Appt End Date */
	public void setApptEdt(Date apptEdt) {
		this.apptEdt = apptEdt;
	}
	public Date getApptEdt() {
		return this.apptEdt;
	}

	/* Last Department Code */
	public void setLastDeptCode(String lastDeptCode) {
		this.lastDeptCode = lastDeptCode;
	}
	public String getLastDeptCode() {
		return this.lastDeptCode;
	}

	/* Termin Code */
	public void setTerminCode(String terminCode) {
		this.terminCode = terminCode;
	}
	public String getTerminCode() {
		return this.terminCode;
	}

	/* Appointment Term Code */
	public void setApptTermCode(String apptTermCode) {
		this.apptTermCode = apptTermCode;
	}
	public String getApptTermCode() {
		return this.apptTermCode;
	}

	/* Authority of Payment */
	public void setAuthPymt(String authPymt) {
		this.authPymt = authPymt;
	}
	public String getAuthPymt() {
		return this.authPymt;
	}

	/* Cause of Pension */
	public void setPenCause(String penCause) {
		this.penCause = penCause;
	}
	public String getPenCause() {
		return this.penCause;
	}

	/* Date of Commencement in an Established Office */
	public void setCommPeDt(Date commPeDt) {
		this.commPeDt = commPeDt;
	}
	public Date getCommPeDt() {
		return this.commPeDt;
	}

	/* Date of Confirmation in an Established Office */
	public void setConfirmPeDt(Date confirmPeDt) {
		this.confirmPeDt = confirmPeDt;
	}
	public Date getConfirmPeDt() {
		return this.confirmPeDt;
	}

	/* Material Date for re-opting from 90% to 100 % */
	public void setMaterialDt(Date materialDt) {
		this.materialDt = materialDt;
	}
	public Date getMaterialDt() {
		return this.materialDt;
	}

	/* Retirement Scheme Code */
	public void setRetireScheme(String retireScheme) {
		this.retireScheme = retireScheme;
	}
	public String getRetireScheme() {
		return this.retireScheme;
	}

	/* Pensionability Code */
	public void setPensionability(String pensionability) {
		this.pensionability = pensionability;
	}
	public String getPensionability() {
		return this.pensionability;
	}

	/* Annual Pension Option % */
	public void setPenOptPerc(BigDecimal penOptPerc) {
		this.penOptPerc = penOptPerc;
	}
	public BigDecimal getPenOptPerc() {
		return this.penOptPerc;
	}

	/* Pension Deduction % */
	public void setPenDedPerc(BigDecimal penDedPerc) {
		this.penDedPerc = penDedPerc;
	}
	public BigDecimal getPenDedPerc() {
		return this.penDedPerc;
	}

	/* Highest Pensionable Emoluments */
	public void setPenHpe(BigDecimal penHpe) {
		this.penHpe = penHpe;
	}
	public BigDecimal getPenHpe() {
		return this.penHpe;
	}

	/* Highest Pensionable Emoluments Attained Date */
	public void setPenHpeDt(Date penHpeDt) {
		this.penHpeDt = penHpeDt;
	}
	public Date getPenHpeDt() {
		return this.penHpeDt;
	}

	/* Highest Pensionable Emoluments for calculation */
	public void setCalHpe(BigDecimal calHpe) {
		this.calHpe = calHpe;
	}
	public BigDecimal getCalHpe() {
		return this.calHpe;
	}

	/* Last Substantive Salary */
	public void setLastSal(BigDecimal lastSal) {
		this.lastSal = lastSal;
	}
	public BigDecimal getLastSal() {
		return this.lastSal;
	}

	/* Transfer Term */
	public void setXfTerm(String xfTerm) {
		this.xfTerm = xfTerm;
	}
	public String getXfTerm() {
		return this.xfTerm;
	}

	/* Unauthorized Absence */
//	public void setUnauthAbs(BigDecimal unauthAbs) {
//		this.unauthAbs = unauthAbs;
//	}
//	public BigDecimal getUnauthAbs() {
//		return this.unauthAbs;
//	}

	public void setUnauthAbsYy(BigDecimal unauthAbsYy) {
		this.unauthAbsYy = unauthAbsYy;
	}
	public BigDecimal getUnauthAbsYy() {
		return this.unauthAbsYy;
	}

	public void setUnauthAbsMm(BigDecimal unauthAbsMm) {
		this.unauthAbsMm = unauthAbsMm;
	}
	public BigDecimal getUnauthAbsMm() {
		return this.unauthAbsMm;
	}

	public void setUnauthAbsDd(BigDecimal unauthAbsDd) {
		this.unauthAbsDd = unauthAbsDd;
	}
	public BigDecimal getUnauthAbsDd() {
		return this.unauthAbsDd;
	}

	/* Injured Approval Date */
	public void setNoPayLeav(BigDecimal noPayLeav) {
		this.noPayLeav = noPayLeav;
	}
	public BigDecimal getNoPayLeav() {
		return this.noPayLeav;
	}

	/* Untaken Leave */
	public void setUntakenLeav(BigDecimal untakenLeav) {
		this.untakenLeav = untakenLeav;
	}
	public BigDecimal getUntakenLeav() {
		return this.untakenLeav;
	}

	/* Date of Medical Board */
	public void setMedBoardDt(Date medBoardDt) {
		this.medBoardDt = medBoardDt;
	}
	public Date getMedBoardDt() {
		return this.medBoardDt;
	}

	/* Injured Percentage */
	public void setInjuPerc(BigDecimal injuPerc) {
		this.injuPerc = injuPerc;
	}
	public BigDecimal getInjuPerc() {
		return this.injuPerc;
	}

	/* Injury Type */
	public void setInjuType(String injuType) {
		this.injuType = injuType;
	}
	public String getInjuType() {
		return this.injuType;
	}
	
	/* Accelerate Indicator */
	public void setAccelerateInd(String accelerateInd) {
		this.accelerateInd = accelerateInd;
	}
	public String getAccelerateInd() {
		return this.accelerateInd;
	}
	
	/* Reassess Date */
	public void setReassessDt(Date reassessDt) {
		this.reassessDt = reassessDt;
	}
	public Date getReassessDt() {
		return this.reassessDt;
	}

	/* Nominated spouse */
	public void setDgNomInd(String dgNomInd) {
		this.dgNomInd = dgNomInd;
	}
	public String getDgNomInd() {
		return this.dgNomInd;
	}

	/* Entitle Amount (for type Bx, Fx, Gx, Tx, Wx only) */
	public void setEttlAmt(BigDecimal ettlAmt) {
		this.ettlAmt = ettlAmt;
	}
	public BigDecimal getEttlAmt() {
		return this.ettlAmt;
	}

	/* Pension Payment Type (for type Bx, Fx, Gx, Tx, Wx only) */
	public void setPymtType(String pymtType) {
		this.pymtType = pymtType;
	}
	public String getPymtType() {
		return this.pymtType;
	}

	/* Scheme Start Date (for type Hx, Sx, Rx only) */
	public void setSchemeSdt(Date schemeSdt) {
		this.schemeSdt = schemeSdt;
	}
	public Date getSchemeSdt() {
		return this.schemeSdt;
	}

	/* Scheme End Date (for type Hx, Sx, Rx only) */
	public void setSchemeEdt(Date schemeEdt) {
		this.schemeEdt = schemeEdt;
	}
	public Date getSchemeEdt() {
		return this.schemeEdt;
	}

	/* Acquire Minmum Benefit (for type Sx only) */
	public void setAcqMinBenefit(String acqMinBenefit) {
		this.acqMinBenefit = acqMinBenefit;
	}
	public String getAcqMinBenefit() {
		return this.acqMinBenefit;
	}
	
	/* Pensionable Personal Allowance  */
	public void setPpaApprInd(String ppaApprInd) {
		this.ppaApprInd = ppaApprInd;
	}
	public String getPpaApprInd() {
		return this.ppaApprInd;
	}
	
	/* Notify Remarks */
	public void setNotifyRemarks(String notifyRemarks) {
		this.notifyRemarks = notifyRemarks;
	}
	public String getNotifyRemarks() {
		return this.notifyRemarks;
	}
	
	/* Payee ID */
	public void setPayeeId(String payeeId) {
		this.payeeId = payeeId;
	}
	public String getPayeeId() {
		return this.payeeId;
	}

	/* First Input Date */
	public void setFirstInputDt(Date firstInputDt) {
		this.firstInputDt = firstInputDt;
	}
	public Date getFirstInputDt() {
		return this.firstInputDt;
	}

	/* First Input Id */
	public void setFirstInputId(String firstInputId) {
		this.firstInputId = firstInputId;
	}
	public String getFirstInputId() {
		return this.firstInputId;
	}

	/* Confirm Input Date */
	public void setConfirmInpDt(Date confirmInpDt) {
		this.confirmInpDt = confirmInpDt;
	}
	public Date getConfirmInpDt() {
		return this.confirmInpDt;
	}

	/* Confirm Id */
	public void setConfirmId(String confirmId) {
		this.confirmId = confirmId;
	}
	public String getConfirmId() {
		return this.confirmId;
	}

	/* Signature Type */
	public void setSignType(String signType) {
		this.signType = signType;
	}
	public String getSignType() {
		return this.signType;
	}

	/* Route to Sign User ID */
	public void setToSignId(String toSignId) {
		this.toSignId = toSignId;
	}
	public String getToSignId() {
		return this.toSignId;
	}

	/* Notify Sign Date */
	public void setNotifySignDt(Date notifySignDt) {
		this.notifySignDt = notifySignDt;
	}
	public Date getNotifySignDt() {
		return this.notifySignDt;
	}

	/* Sign Date */
	public void setSignDt(Date signDt) {
		this.signDt = signDt;
	}
	public Date getSignDt() {
		return this.signDt;
	}

	/* Sign Id */
	public void setSignId(String signId) {
		this.signId = signId;
	}
	public String getSignId() {
		return this.signId;
	}
	
	/* Cancel Notification Date */
//	public void setCancelInputDt(Date cancelInputDt) {
//		this.cancelInputDt = cancelInputDt;
//	}
//	public Date getCancelInputDt() {
//		return this.cancelInputDt;
//	}
	public void setCancelInpDt(Date cancelInpDt) {
		this.cancelInpDt = cancelInpDt;
	}
	public Date getCancelInpDt() {
		return this.cancelInpDt;
	}


	/* Last Amend Date of Pension Details */
	public void setLastAmendDt(Date lastAmendDt) {
		this.lastAmendDt = lastAmendDt;
	}
	public Date getLastAmendDt() {
		return this.lastAmendDt;
	}

	/* Amend Count of Pension Details */
	public void setAmendCnt(BigDecimal amendCnt) {
		this.amendCnt = amendCnt;
	}
	public BigDecimal getAmendCnt() {
		return this.amendCnt;
	}

	/* Confirm Details Date */
	public void setConfirmDtlDt(Date confirmDtlDt) {
		this.confirmDtlDt = confirmDtlDt;
	}
	public Date getConfirmDtlDt() {
		return this.confirmDtlDt;
	}

	/* Route to Confirm User ID */
	public void setToConfirmId(String toConfirmId) {
		this.toConfirmId = toConfirmId;
	}
	public String getToConfirmId() {
		return this.toConfirmId;
	}

	/* Confirm Department Code */
/*	public void setConfirmDept(String confirmDept) {
		this.confirmDept = confirmDept;
	}
	public String getConfirmDept() {
		return this.confirmDept;
	}
*/
	/* Confirm Department Type */
/*	public void setConfirmDeptTy(String confirmDeptTy) {
		this.confirmDeptTy = confirmDeptTy;
	}
	public String getConfirmDeptTy() {
		return this.confirmDeptTy;
	}
*/
	/* Pension Termination Code */
	public void setPenTermCode(String penTermCode) {
		this.penTermCode = penTermCode;
	}
	public String getPenTermCode() {
		return this.penTermCode;
	}

	/* Pension Termination Date */
	public void setPenTermDt(Date penTermDt) {
		this.penTermDt = penTermDt;
	}
	public Date getPenTermDt() {
		return this.penTermDt;
	}
	
	/* Pension Termination Input Date */
	public void setPenTermInpDt(Date penTermInpDt) {
		this.penTermInpDt = penTermInpDt;
	}
	public Date getPenTermInpDt() {
		return this.penTermInpDt;
	}
	
	/* Cancel Pension Termination Date */
	public void setCancelTermDt(Date cancelTermDt) {
		this.cancelTermDt = cancelTermDt;
	}
	public Date getCancelTermDt() {
		return this.cancelTermDt;
	}

	/* Cancel Pension Termination User ID */
	public void setCancelTermId(String cancelTermId) {
		this.cancelTermId = cancelTermId;
	}
	public String getCancelTermId() {
		return this.cancelTermId;
	}

	/* Conv Rec Ind */
	public void setConvRecInd(String convRecInd) {
		this.convRecInd = convRecInd;
	}
	
	public String getConvRecInd() {
		return this.convRecInd;
	}
	
	/* Pension Type Group */
	public String getPenGroup() {
		return penGroup;
	}
	public void setPenGroup(String penGroup) {
		this.penGroup = penGroup;
	}

	
 //AC20151007 start
	/* Date of Commencement of Qualifying Service */
	public void setCommQualServDt(Date commQualServDt) {
		this.commQualServDt = commQualServDt;
	}
	public Date getCommQualServDt() {
		return this.commQualServDt;
	}

	/* Full Pension/Annual Allowance that may be granted */
	public void setNoOneOffLumpSum(String noOneOffLumpSum) {
		this.noOneOffLumpSum = noOneOffLumpSum;
	}
	public String getNoOneOffLumpSum() {
		return this.noOneOffLumpSum;
	}
	/* Memo Ref */
	public void setMemoRef(String memoRef) {
		this.memoRef = memoRef;
	}
	public String getMemoRef() {
		return this.memoRef;
	}
	
	/* Memo Ref Submission Date */
	public void setMemoRefSubmitDt(Date memoRefSubmitDt) {
		this.memoRefSubmitDt = memoRefSubmitDt;
	}
	public Date getMemoRefSubmitDt() {
		return this.memoRefSubmitDt;
	}	 
	
	/* Certify Date */
	public void setCertifyDt(Date certifyDt) {
		this.certifyDt = certifyDt;
	}
	public Date getCertifyDt() {
		return this.certifyDt;
	}	
    //AC20151007 end
 
	//AC20151103 start
	/* Department Code for Distribution of Pension Paper */	
	public String getDeptDistPenPaper() {
		return this.deptDistPenPaper;
	}
	public void setDeptDistPenPaper(String deptDistPenPaper) {
		this.deptDistPenPaper = deptDistPenPaper;
	}
	//AC20151103 end 
	/**
	 * Define criteria on hkic
	 * Get the not cancelled 
 	 * @param String hkic
 	 * @return
	 */
	public void defineCriteria(String hkic) {
		storeCriteria("c40hkic = " + StringUtil.addQuote(hkic)
						+ " AND c40cancel_inp_dt is null");
	}

	/**
	 * Define criteria on hkic
	 * Get the not cancelled 
 	 * @param String hkic
 	 * @return
	 */
	public void defineCriteriaAllIncludeDeleted(String hkic) {
		storeCriteria("c40hkic = " + StringUtil.addQuote(hkic));
	}
	
	/**
	 * Define criteria on hkic, penType
	 *
 	 * @param String hkic
 	 * @param String penType
 	 * @return
	 */
	public void defineCriteria(String hkic, String penType) {
		storeCriteria("c40hkic = " + StringUtil.addQuote(hkic) + 
	 				  " AND c40pen_type =" + StringUtil.addQuote(penType) + 
	 				  " AND c40cancel_inp_dt is null");
	}
	
	/**
	 * Define criteria on key
	 *
 	 * @param String hkic
 	 * @param String penType
 	 * @return
	 */
	public void defineCriteriaOnKey(String hkic, String penType, BigDecimal penInputNum) {
		storeCriteria("c40hkic = " + StringUtil.addQuote(hkic) + 
					  " AND c40pen_type =" + StringUtil.addQuote(penType) + 
					  " AND c40pen_input_num = " + penInputNum);
	}		
	
	/**
	 * Define criteria on key
	 *
 	 * @param String hkic
 	 * @param String penType
 	 * @return
	 */
	public void defineCriteria(String hkic, String penType, BigDecimal penInputNum) {
		storeCriteria("c40hkic = " + StringUtil.addQuote(hkic) + 
					  " AND c40pen_type =" + StringUtil.addQuote(penType) + 
					  " AND c40pen_input_num = " + penInputNum + 
					  " AND c40cancel_inp_dt is null");
	}	

	/**
	 * Define criteria on hkic, apptSdt, sdt
	 *
 	 * @param String hkic
 	 * @param String penType
 	 * @return
	 */
	public void defineCriteria(String hkic, String penType, Date apptSdt, Date apptEdt, Date sdt) {
		String sql = "c40hkic = " + StringUtil.addQuote(hkic);

		if (penType != null) {
			if (StringUtil.containWildCard(penType)) {
				sql += " AND c40pen_type LIKE " + StringUtil.addQuote(penType);
			} else {
				sql += " AND c40pen_type = " + StringUtil.addQuote(penType);
			}
		}

		if (apptSdt != null)
			sql += " AND c40appt_sdt = " + StringUtil.addQuote(apptSdt);

		if (apptEdt != null)
			sql += " AND c40appt_edt = " + StringUtil.addQuote(apptEdt);

		if (sdt != null)
			sql += " AND c40sdt = " + StringUtil.addQuote(sdt);

		sql += " AND c40cancel_inp_dt is null";

		storeCriteria(sql);
	}
	
	/**
	 * get penDtl records which appt_edt within the specified date
	 *
 	 * @param String hkic
 	 * @param Date apptDate
 	 * @return
	 */
	public void defineCriteria(String hkic, Date apptSdt, Date apptEdt) {
		String sql = "c40hkic = " + StringUtil.addQuote(hkic);

		if (apptEdt != null) 
			sql += " AND c40appt_edt >= " + StringUtil.addQuote(apptEdt);
		else 
			sql += " AND c40appt_edt is null";

		sql += " AND c40appt_sdt <= " + StringUtil.addQuote(apptSdt);		

		sql += " AND c40cancel_inp_dt is null";

		storeCriteria(sql);
	}	

	/**
	 * Define criteria on with otherCriteria
	 *
 	 * @param String hkic
 	 * @param String penType
 	 * @param String otherCriteria
 	 * @return
	 */
	public void defineCriteria(String hkic, String penType, String otherCriteria) {
		String sql="";

		if (StringUtil.containWildCard(penType)) {
			sql = "c40hkic = " + StringUtil.addQuote(hkic) + " AND c40pen_type LIKE " + StringUtil.addQuote(penType);
		} else {
			sql = "c40hkic = " + StringUtil.addQuote(hkic) + " AND c40pen_type = " + StringUtil.addQuote(penType);
		}

		if (!StringUtil.isEmpty(otherCriteria)) {
			sql += " " + otherCriteria;
		}

		storeCriteria(sql);
	}
	
	/**
	 * Define criteria
	 * 
 	 * @param String hkic
 	 * @param String penType
 	 * @return
	 */
	public void defineCriteria(String hkic, String[] penTypes) {
		String sql = "c40hkic = " + StringUtil.addQuote(hkic) + 
			  " AND c40pen_type in (" + StringUtil.addQuote(penTypes) + ") " + 
			  " AND c40cancel_inp_dt is null";
		storeCriteria(sql);
	}			

	/**
	 * Define criteria to find pendtl with first char match with input
	 * 
 	 * @param String hkic
 	 * @param String penType
 	 * @return
	 */
	public void defineCriteriaValidOnPenTypFstChar(String hkic, String[] chars) {
		String sql = "";

		sql = "c40hkic = " + StringUtil.addQuote(hkic) + 
				" AND substr(c40pen_type,1,1) IN (" + 
				StringUtil.addQuote(chars) + ")";

		sql += " AND c40cancel_inp_dt is null";

		storeCriteria(sql);
	}
	
	/**
	 * Define criteria
	 * 
 	 * @param String hkic
 	 * @param String penType
 	 * @return
	 */
	public void defineCriteria(String hkic, String[] penTypes, String penType) {
		String sql = "c40hkic = " + StringUtil.addQuote(hkic) + 
			  " AND c40pen_type in (" + StringUtil.addQuote(penTypes) + ") " + 
			  " AND c40pen_type <> " + StringUtil.addQuote(penType) + 
			  " AND c40confirm_inp_dt is not null AND c40cancel_inp_dt is null";
		storeCriteria(sql);
	}		

	/**
	 * Define criteria for not ended 
	 * @param hkic
	 * @param penTypes
	 * @param penType
	 */
	public void defineCriteriaNotEnded(String hkic, String[] penTypes, String penType) {
		String sql = "c40hkic = " + StringUtil.addQuote(hkic) + 
			  " AND c40pen_type in (" + StringUtil.addQuote(penTypes) + ") " + 
			  " AND c40pen_type <> " + StringUtil.addQuote(penType) + 
			  " AND c40edt is null " +
			  " AND c40confirm_inp_dt is not null AND c40cancel_inp_dt is null";
		storeCriteria(sql);
	}		
	
//ic20050520
	/**
	 * Define criteria on with otherCriteria
	 *
 	 * @param String hkic
 	 * @param String otherCriteria
 	 * @return
	 */
	public void defineCriteriaOnOther(String hkic, String otherCriteria) {
		String sql="";

		sql = "c40hkic = " + StringUtil.addQuote(hkic);


		if (!StringUtil.isEmpty(otherCriteria)) {
			sql += " " + otherCriteria;
		}

		storeCriteria(sql);
	}

	/**
	 * Define criteria for confirmed notification
	 *
 	 * @param String hkic
 	 * @param String penType
 	 * @return
	 */
	public void defineCriteriaInputConfirmed(String hkic, String penType) {
		defineCriteria(hkic, penType,
			" AND c40confirm_inp_dt is not null " +
			"AND c40cancel_inp_dt is null");
	}
	
	/**
	 * Define criteria for not ended and confirmed notification
	 *
 	 * @param String hkic
 	 * @param String penType
 	 * @return
	 */
	public void defineCriteriaNotEndedAndInputConfirmed(String hkic, String penType) {
		defineCriteria(hkic, penType,
			" AND c40edt is null " +
			" AND c40confirm_inp_dt is not null " +
			"AND c40cancel_inp_dt is null");
	}
	
	/**
	 * Define criteria for confirmed notification
	 *
 	 * @param String hkic
 	 * @param String penType
 	 * @return
	 */
	public void defineCriteriaInputNotConfirmed(String hkic, String penType) {
		defineCriteria(hkic, penType,
			" AND c40confirm_inp_dt is null " +
			"AND c40cancel_inp_dt is null");
	}	

	/**
	 * Define criteria for signed notification
	 *
 	 * @param String hkic
 	 * @param String penType
 	 * @return
	 */
	public void defineCriteriaInputSigned(String hkic, String penType) {
		defineCriteria(hkic, penType,
			" AND c40sign_dt is not null " +
			"AND c40cancel_inp_dt is null");
	}
	
	/**
	 * Define criteria for signed notification
	 *
 	 * @param String hkic
 	 * @param String penType
 	 * @return
	 */
	public void defineCriteriaInputSignedByHkic(String hkic) {
		defineCriteriaOnOther(hkic, 
			" AND c40sign_dt is not null " +
			"AND c40cancel_inp_dt is null" + 
			" ORDER BY c40pen_type");
	}

	/**
	 * Define criteria on to search record for PNPD, PNPC AND PNPP functions
	 *
 	 * @param String hkic
 	 * @param String penType
 	 * @param String funcId
 	 * @return
	 */
	public void defineCriteriaByFunc(String hkic, String penType, String funcId) {
//		if (funcId.equals(Pnpd01Process.FUNC))
//			defineCriteria(hkic, penType, "AND c40confirm_inp_dt is null AND c40cancel_inp_dt is null");
//		else if (funcId.equals(Pnpd02Process.FUNC))
//			defineCriteria(hkic, penType, " AND C40CONFIRM_INP_DT is null AND C40SIGN_DT is null AND c40confirm_dtl_dt is null AND c40cancel_inp_dt is null");
//		else if (funcId.equals(Pnpd03Process.FUNC))
//			defineCriteria(hkic, penType, " AND C40CONFIRM_INP_DT is NOT null AND C40SIGN_DT is null AND c40confirm_dtl_dt is null AND c40cancel_inp_dt is null");
//		else if (funcId.equals(Pnpd06Process.FUNC))
//			defineCriteriaInputSigned(hkic, penType);
//		else if (funcId.equals(Pnpd07Process.FUNC))
//			defineCriteria(hkic, penType, " AND C40SIGN_DT is NOT null AND c40confirm_dtl_dt is null AND c40cancel_inp_dt is null");
//		else if (funcId.equals(Pnpd08Process.FUNC))
//			defineCriteriaInputConfirmed(hkic, penType);
		if (funcId.equals(Pnpp01Process.FUNC))
			defineCriteriaInputSigned(hkic, penType);
		else if (funcId.equals(Pnpp02Process.FUNC))
			defineCriteriaInputSigned(hkic, penType);
		else if (funcId.equals(Pnpp03Process.FUNC))
			defineCriteriaInputSigned(hkic, penType);
		else if (funcId.equals(Pnpp05Process.FUNC))
			defineCriteriaInputConfirmed(hkic, penType);
		else if (funcId.equals(Pnpp06Process.FUNC))
			defineCriteriaInputConfirmed(hkic, penType);
		else if (funcId.equals(Pnpp07Process.FUNC))
			defineCriteriaInputConfirmed(hkic, penType);
		else if (funcId.equals(Pnpp08Process.FUNC))
			defineCriteriaInputSigned(hkic, penType);
		else if (funcId.equals(Pntm01Process.FUNC))
			defineCriteriaInputSigned(hkic, penType);
		else if (funcId.equals(Pntm02Process.FUNC))
			defineCriteriaInputSigned(hkic, penType);
		else if (funcId.equals(Pntm03Process.FUNC))
			defineCriteriaInputSigned(hkic, penType);
		else if (funcId.equals(Pntm04Process.FUNC))
			defineCriteriaInputSigned(hkic, penType);			
//		else if (funcId.startsWith("PNPC") || funcId.startsWith("PNAU"))
//			defineCriteria(hkic, penType, " AND c40confirm_dtl_dt is not null AND c40cancel_inp_dt is null");

	}

	/**
	 * Define criteria on to search record for Common Header
	 *
 	 * @param String hkic
 	 * @param String penType
 	 * @return
	 */
	public void defineCriteriaCommonHeader(String hkic, String penType) {
		defineCriteria(hkic, penType, " AND C40CONFIRM_INP_DT is NOT null AND C40SIGN_DT is NOT null AND c40cancel_inp_dt is null");
	}

	/**
	 * Define criteria to search penType A* other than A0
	 *
 	 * @param String hkic
 	 * @param String penType
 	 * @param String otherCriteria
 	 * @return
	 */
	public void defineCriteriaSearchPenTypeA(String hkic) {
			defineCriteria(hkic, "A%", " AND C40PEN_TYPE not in ('A0')");
	}

	/**
	 * Define criteria on key
	 *
 	 * @param String penType
 	 * @return
	 */
	public void defineCriteriaForPnct01(String penType) {
		storeCriteria("c40pen_type =" + StringUtil.addQuote(penType));
	}

	/**
	 * Define criteria on key, for PNPD04
	 *
 	 * @param String hkic, penType, deptCode
 	 * @return
	 */
	public void defineCriteriaForPnpd04(String hkic, String penType, String deptCode) {
		String sql="";
		if (!StringUtil.isEmpty(hkic)) {
			sql = "c40hkic = " + StringUtil.addQuote(hkic);
			if (!StringUtil.isEmpty(penType)) {
				if (StringUtil.containWildCard(penType)) {
					sql += " AND c40pen_type LIKE " + StringUtil.addQuote(penType);
				} else {
					sql += " AND c40pen_type = " + StringUtil.addQuote(penType);
				}
			}
			if (!StringUtil.isEmpty(deptCode)) {
				sql += " AND c40last_dept_code = " + StringUtil.addQuote(deptCode);
			}
		} else {
			if (!StringUtil.isEmpty(penType)) {
				if (StringUtil.containWildCard(penType)) {
					sql = "c40pen_type LIKE " + StringUtil.addQuote(penType);
				} else {
					sql = "c40pen_type = " + StringUtil.addQuote(penType);
				}
				if (!StringUtil.isEmpty(deptCode)) {
					sql += " AND c40last_dept_code = " + StringUtil.addQuote(deptCode);
				}
			} else
				sql = "c40last_dept_code = " + StringUtil.addQuote(deptCode);
			}

		sql += " AND c40cancel_inp_dt is null";
		sql += " ORDER BY c40hkic ";
		storeCriteria(sql);
	}

	/**
	 * Define criteria on key
	 *
 	 * @param String payeeId
 	 * @return
	 */
	public void defineCriteriaByPayee(String payeeId) {
		storeCriteria("c40payee_Id = " + StringUtil.addQuote(payeeId)
						+ " AND c40cancel_inp_dt is null");
	}
	
	/**
	 * Define criteria on key
	 *
 	 * @param String payeeId
 	 * @return
	 */
	public void defineCriteriaByPayeeSorted(String payeeId) {
		defineCriteriaByPayee(payeeId);
		storeOrder("c40pen_type asc");
	}
	
//ic20050531	
	/**
	 * Define criteria signed pension by payee
	 * 
 	 * @param String payeeId
 	 * @return
	 */
	public void defineCriteriaInputSignedByPayee(String payeeId) {
		storeCriteria("c40payee_Id = " + StringUtil.addQuote(payeeId) +
					  " AND c40sign_dt is not null " + 
					  "AND c40cancel_inp_dt is null" +
					  " ORDER BY c40pen_type");
	}

	/**
	 * Define criteria on key<br>
	 * 
 	 * @param hkic
 	 * @param penType
 	 * @return
	 * @throws 
	 */
	public void defineCriteriaOtherType(String hkic, String penType, boolean group) {
		String sql = "lower(c40hkic) = " + StringUtil.addQuote(hkic.toLowerCase()) +
						" AND lower(c40pen_type) <> " + StringUtil.addQuote(penType.toLowerCase());
		if (group) 
			sql += " AND c40pen_type not like 'J%' AND c40pen_type not like 'W%' AND c40pen_type not like 'S%' ";
		else
			sql += " AND (c40pen_type like 'J%' OR c40pen_type like 'W%' OR c40pen_type like 'S%' )";
		
		sql += " AND c40confirm_inp_dt is not null AND c40cancel_inp_dt is null";
		sql += " ORDER BY c40pen_type";
		storeCriteria(sql);
		
	}

	public void defineCriteriaOtherPenType(String hkic, String penType, boolean group) {
		String sql = "lower(c40hkic) = " + StringUtil.addQuote(hkic.toLowerCase()) +
						" AND lower(c40pen_type) <> " + StringUtil.addQuote(penType.toLowerCase());
		
		sql += " ORDER BY c40pen_type";
		storeCriteria(sql);
		
	}
	
	public static List defineCriteriaForCaPiLetr(Date stmtDate, Connection conn, User user) throws DBObjectException, DBSecurityException {
		
		PenDtl penDtl = new PenDtl();
		SqlRunner sqlRunner = null;
		List allResults = new Vector();
		
		sqlRunner = new SqlRunner(new CostDtl().getClass());
		sqlRunner.append( "SELECT distinct C41PYMT_PAYEE_ID " +
				" FROM <SCHEMA>."+penDtl.getDBTableName()+", <SCHEMA>."+new PenPymtDtl().getDBTableName()+",<SCHEMA>."+new PenPaper().getDBTableName()+
				" WHERE (C40HKIC=C41HKIC AND C40PEN_TYPE=C41PEN_TYPE AND C41HKIC=C60HKIC AND C41PEN_TYPE=C60PEN_TYPE ) "+
				" AND (  (substr(C40PEN_TYPE,1,1)  not in ('G','W','T','Z') AND C60APPR_DT is not null AND C60CONFIRM_DEL_DT is null AND C60CONFIRM_DT is not null "+
				" AND (c40edt >= '"+DateUtil.date2Str(DateUtil.lastDate(stmtDate),"yyyy-MM-dd")+"' OR c40edt IS NULL)" +
				" AND (c41pi_pymt_sdt <='"+DateUtil.date2Str(DateUtil.lastDate(stmtDate),"yyyy-MM-dd")+"') "+ 
				" AND C41PEN_PYMT_METHOD='O'))" +
				" order by C41PYMT_PAYEE_ID asc ");		

		sqlRunner.execute(user, conn);
		allResults.addAll(sqlRunner.getResults());

		return allResults;
	}
	
	
	/**
	 * Load on key<br>
	 *
 	 * @param String hkic
 	 * @param String penType

 	 * @param Connection conn
 	 * @param User user
 	 * @return PenDtl
	 * @throws DBObjectException, DBSecurityException
	 */
	public static PenDtl load(String hkic, String penType, Connection conn, User user)
					throws DBObjectException, DBSecurityException {
		PenDtl penDtl = new PenDtl();
		penDtl.defineCriteria(hkic, penType);
		penDtl.load(conn, user);
		return penDtl;	
	}

	/**
	 * Load on key<br>
	 *
 	 * @param String hkic
 	 * @param String penType
 	 * @param String penInputNum
 	 * @param Connection conn
 	 * @param User user
 	 * @return PenDtl
	 * @throws DBObjectException, DBSecurityException
	 */
	public static PenDtl load(String hkic, String penType, BigDecimal penInputNum, Connection conn, User user)
					throws DBObjectException, DBSecurityException {
		PenDtl penDtl = new PenDtl();
		penDtl.defineCriteria(hkic, penType, penInputNum);
		penDtl.load(conn, user);
		return penDtl;
	}	
	
	/**
	 * Load on key<br>
	 *
 	 * @param String hkic
 	 * @param String penType
 	 * @param String penInputNum
 	 * @param Connection conn
 	 * @param User user
 	 * @return PenDtl
	 * @throws DBObjectException, DBSecurityException
	 */
	public static PenDtl loadOnKey(String hkic, String penType, BigDecimal penInputNum, Connection conn, User user)
					throws DBObjectException, DBSecurityException {
		PenDtl penDtl = new PenDtl();
		penDtl.defineCriteriaOnKey(hkic, penType, penInputNum);
		penDtl.load(conn, user);
		return penDtl;
	}		

	/**
	 * LoadList on HKIC no matter deleted or not <br>
	 *
 	 * @param String hkic
 	 * @param Connection conn
 	 * @param User user
 	 * @return List
	 * @throws DBObjectException, DBSecurityException
	 */
	public static List loadListAllIncludeDeleted(String hkic, Connection conn, User user)
					throws DBObjectException, DBSecurityException {
		PenDtl penDtl = new PenDtl();
		penDtl.defineCriteriaAllIncludeDeleted(hkic);
		return penDtl.loadList(conn, user);
	}

	/**
	 * LoadList on HKIC, apptSdt, apptEdt, Sdt<br>
	 *
 	 * @param String hkic
 	 * @param String penType
 	 * @param Date apptSdt
 	 * @param Date apptEdt
 	 * @param Date sdt
 	 * @param Connection conn
 	 * @param User user
 	 * @return List
	 * @throws DBObjectException, DBSecurityException
	 */
	public static List loadList(String hkic, String penType, Date apptSdt, Date apptEdt, Date sdt, Connection conn, User user)
					throws DBObjectException, DBSecurityException {
		PenDtl penDtl = new PenDtl();
		penDtl.defineCriteria(hkic, penType, apptSdt, apptEdt, sdt);
		return penDtl.loadList(conn, user);
	}
	
	/**
	 * LoadList on HKIC, apptDate
	 *
 	 * @param String hkic
 	 * @param Date apptDate
 	 * @param Connection conn
 	 * @param User user
 	 * @return List
	 * @throws DBObjectException, DBSecurityException
	 */
	public static List loadList(String hkic, Date apptSdt, Date apptEdt, Connection conn, User user)
					throws DBObjectException, DBSecurityException {
		PenDtl penDtl = new PenDtl();
		penDtl.defineCriteria(hkic, apptSdt, apptEdt);
		return penDtl.loadList(conn, user);
	}

	/**
	 * LoadList on HKIC, penType<br>
	 *
 	 * @param String hkic
 	 * @param String penType
 	 * @param String otherCriteria
 	 * @param Connection conn
 	 * @param User user
 	 * @return List
	 * @throws DBObjectException, DBSecurityException
	 */
	public static List loadList(String hkic, String penType, String otherCriteria, Connection conn, User user)
					throws DBObjectException, DBSecurityException {
		PenDtl penDtl = new PenDtl();
		penDtl.defineCriteria(hkic, penType, otherCriteria);
		return penDtl.loadList(conn, user);
	}
	
	/**
	 * LoadList on HKIC, penType<br>
	 *
 	 * @param String hkic
 	 * @param String penType
 	 * @param String otherCriteria
 	 * @param Connection conn
 	 * @param User user
 	 * @param String func
 	 * @return List
	 * @throws DBObjectException, DBSecurityException
	 */
	public static List loadList(String hkic, String penType, String otherCriteria, Connection conn, User user, String func)
					throws DBObjectException, DBSecurityException {
		PenDtl penDtl = new PenDtl();
		penDtl.defineCriteria(hkic, penType, otherCriteria);
		return penDtl.loadList(conn, user, func);
	}
	
	/**
	 * LoadList
	 *
 	 * @param String hkic
 	 * @param String[] penTypes
 	 * @param Connection conn
 	 * @param User user
 	 * @return List
	 * @throws DBObjectException, DBSecurityException
	 */
	public static List loadList(String hkic, String[] penTypes, Connection conn, User user)
					throws DBObjectException, DBSecurityException {
		PenDtl penDtl = new PenDtl();
		penDtl.defineCriteria(hkic, penTypes);
		return penDtl.loadList(conn, user);
	}	

	/**
	 * LoadList
	 *
 	 * @param String hkic
 	 * @param String[] penTypes
 	 * @param String penType
 	 * @param Connection conn
 	 * @param User user
 	 * @return List
	 * @throws DBObjectException, DBSecurityException
	 */
	public static List loadList(String hkic, String[] penTypes, String penType, Connection conn, User user)
					throws DBObjectException, DBSecurityException {
		PenDtl penDtl = new PenDtl();
		penDtl.defineCriteria(hkic, penTypes, penType);
		return penDtl.loadList(conn, user);
	}

	/**
	 * Load List of Not Ended
	 * @param hkic
	 * @param penTypes
	 * @param penType
	 * @param conn
	 * @param user
	 * @return
	 * @throws DBObjectException
	 * @throws DBSecurityException
	 */
	public static List loadListNotEnded(String hkic, String[] penTypes, String penType, 
										Connection conn, User user) throws DBObjectException, DBSecurityException {
		PenDtl penDtl = new PenDtl();
		penDtl.defineCriteriaNotEnded(hkic, penTypes, penType);
		return penDtl.loadList(conn, user);
	}
	
	
	/**
	 * LoadList on HKIC, penType, deptCode or payeeId<br>
	 * combination can be either
	 * 1) payee Id only
	 * 2) hkic only
	 * 3) hkic, penType, deptCode
	 * 
 	 * @param String hkic
 	 * @param String penType
 	 * @param String deptCode
 	 * @param Connection conn
 	 * @param User user
 	 * @return List
	 * @throws DBObjectException, DBSecurityException
	 */
	public static List loadListForPnpd04(String hkic, String penType, String deptCode, String payeeId, Connection conn, User user)
					throws DBObjectException, DBSecurityException {
		PenDtl penDtl = new PenDtl();

		if (!StringUtil.isEmpty(payeeId)) 
			penDtl.defineCriteriaByPayee(payeeId);
		else if ((!StringUtil.isEmpty(hkic)) && (StringUtil.isEmpty(penType)) && (StringUtil.isEmpty(deptCode)))
			penDtl.defineCriteria(hkic);
		else
			penDtl.defineCriteriaForPnpd04(hkic, penType, deptCode);

		List penDtls = penDtl.loadList(conn, user);
		if (penDtls.size()<=0) {
			if (penDtl.getLoadStatus()==DBObject.NORMAL) {
			} else {
				throw new DBSecurityException(PaysLocale.getMessage(user, "error.dbsecurity.general"));
			}
		}

		return penDtls;
	}

	/**
	 * LoadList on PayeeId<br>
	 *
 	 * @param String payeeId
	 * @param Connection conn
 	 * @param User user
 	 * @return List
	 * @throws DBObjectException, DBSecurityException
	 */
	public static List loadListByPayee(String payeeId, Connection conn, User user)
					throws DBObjectException, DBSecurityException {
		PenDtl penDtl = new PenDtl();
		penDtl.defineCriteriaByPayee(payeeId);
		return penDtl.loadList(conn, user);
	}


	/**
	 * Check the input penType if is Dependent Pension
	 *
 	 * @param String penType
 	 * @return boolean
	 */
	public static boolean checkDependantPension (String penType) {
		if (!penType.startsWith("A")
					&& !penType.startsWith("C")
					&& !penType.startsWith("R")
					&& !penType.startsWith("Z")
					&& !penType.startsWith("R")
					&& !penType.startsWith("B1")
					&& !penType.startsWith("D")
					&& !penType.startsWith("E1")
					&& !penType.startsWith("F1")
					&& !penType.startsWith("F9")
					&& !penType.startsWith("G1")
					&& !penType.startsWith("M0")
					&& !penType.startsWith("T1")
					&& !penType.startsWith("W1")																														
					) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Check if pension type is child pension
	 * if pension type = H5-H9, S2-S9, J2-J7, B2(?)-B6, E2, G3, T3-T8			
 	 * @param String penType
 	 * @return boolean
	 */
	public static boolean checkChildPension (String penType) {
		if (StringUtil.existIn(penType, WO_CHILD_PEN_TYPE) ||
		    StringUtil.existIn(penType, SC_CHILD_PEN_TYPE) ||
		    StringUtil.existIn(penType, J_CHILD_PENTYPE) ||
		    StringUtil.existIn(penType, B_CHILD_PEN_TYPE) ||		    
		    StringUtil.existIn(penType, T_CHILD_PEN_TYPE) ||		    		    
			penType.equals("E2") ||
			penType.equals("G3")) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Check the input penType if is Others Pension
	 *
 	 * @param String penType
 	 * @return boolean
	 */
	public static boolean checkOthersPension (String penType) {
		if (!penType.startsWith("A")
					&& !penType.startsWith("C")
					&& !penType.startsWith("J")
					&& !penType.startsWith("Z")) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Check the input penType if is system approve
	 *
 	 * @param String penType
 	 * @return boolean
	 */
	public static boolean checkSysApprovePension (String penType) {
		if (penType.startsWith("B")
					|| penType.startsWith("E")
					|| penType.startsWith("F")
					|| penType.startsWith("G")
					|| penType.startsWith("T")
					|| penType.startsWith("W")
					|| penType.startsWith("M")
					|| penType.startsWith("R")) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Check if the input penType is deferred pension
	 *
 	 * @param String penType
 	 * @return boolean
	 */
	public static boolean isDeferredPension (String penType) {
		if (penType.equals("A3") || 
			penType.equals("A4") || 
			penType.equals("A5") || 
			penType.equals("A6") || 			
			penType.equals("A8")) {
			return true;
		} else {
			return false;
		}
	}
	
	
	/**
	 * get the PenDt lable
 	 * @param String penType
 	 * @return String
	 */
	public static String getPenDtlPenDtLabel (String penType) {
		if (StringUtil.existIn(penType, RESIGNED_OFFICER)) {
			return "pn.label.resignDt";
		} else if (penType.startsWith("Z")) {
			return "pn.label.deathDt";
		} else {
			return "pn.label.retireDt";
		}
	}

	/**
	 * Validation for Pension Detail Object
	 *
 	 * @param String hkic
 	 * @param Connection conn
 	 * @param User user
 	 * @return PaysErrors
	 * @throws DBObjectException, DBSecurityException
	 */
	public PaysErrors validate (Connection conn, User user)
			throws DBObjectException, DBSecurityException {

		PaysErrors errors = new PaysErrors();
		PaysError msg = null;

		errors.merge(checkLengths());
		errors.merge(validateLastSal());
		errors.merge(validatePenHpe());
		errors.merge(validateUnauthAbs());		
		errors.merge(validatePymtType());		

		if (penType.startsWith("A") || penType.startsWith("Z")) {
				if (penOptPerc != null) {
					if (penType.equals("A0")) {
						msg = new PaysError("error.invalid", "pn.label.annPenOptPerc");
						msg.setObjType(PaysError.KEY);
						errors.addError("annPenOptPerc", msg);
						errors.addErrIndicator("annPenOptPercInd");
					}

					if ((penOptPerc.compareTo(new BigDecimal("0")) < 0)	||  (penOptPerc.compareTo(new BigDecimal("100.00")) > 0)) {
				 		msg = new PaysError("error.beyondRange", "pn.label.annPenOptPerc", "0", "100");
						msg.setObjType(PaysError.KEY, PaysError.KEY, PaysError.KEY);
						errors.addError("annPenOptPerc", msg);
						errors.addErrIndicator("annPenOptPercInd");
					} else {
						if (!penType.equals("A0")) {
							if (retireScheme.equals("0") || retireScheme.equals("2") || 
								retireScheme.equals(PaysApptTerm.RETIRE_SCHEME_A) || retireScheme.equals(PaysApptTerm.RETIRE_SCHEME_B) || retireScheme.equals(PaysApptTerm.RETIRE_SCHEME_D)) {
								errors.merge(validatePenOptPerc(new BigDecimal("50"), new BigDecimal("100")));
							} else if (retireScheme.equals("3")) {
								errors.merge(validatePenOptPerc(new BigDecimal("75"), new BigDecimal("100")));								
							}
						}
					}
				}

				errors.merge(validateAuthPymt());
				errors.merge(validatePenDedPerc());
				errors.merge(validateNoPayLeav());	
				errors.merge(validateUntakenLeav());	
				
				// valudate commPeDt, confirmPeDt
				if (commPeDt != null) {
					errors.merge(validateBeforeApptSdt(commPeDt, "pn.label.penCommDt", "pn.label.apptSdt", "penCommDt", "error.cannotLess"));			
					errors.merge(validateAfterApptEdt(commPeDt, "pn.label.penCommDt", "pn.label.apptEdt", "penCommDt", "error.cannotGreater"));															
				}
				if (confirmPeDt != null) { 
					errors.merge(validateBeforeApptSdt(confirmPeDt, "pn.label.penConfirmDt", "pn.label.apptSdt", "penConfirmDt", "error.cannotLess"));			
					errors.merge(validateAfterApptEdt(confirmPeDt, "pn.label.penConfirmDt", "pn.label.apptEdt", "penConfirmDt", "error.cannotGreater"));																				
				}
				if (commPeDt != null && confirmPeDt != null) {
					if (DateUtil.before(confirmPeDt, commPeDt)) {
						msg = new PaysError("error.cannotLess", "pn.label.penConfirmDt", "pn.label.penCommDt");
						msg.setObjType(PaysError.KEY, PaysError.KEY);
						errors.addError("penConfirmDt", msg);
						errors.addErrIndicator("penConfirmDtInd");
					}													
				}
				
				// validate material date
				errors.merge(validateMaterialDt());

				if (penType.startsWith("A")) {
//					errors.merge(validateBeforeApptEdt(penDt, "pn.label.penPayableDt", getPenDtlSdtLabel(penType), "penPayableDt", "error.cannotLess"));											
					if (sdt != null && penDt != null) {
						if (DateUtil.before(sdt, penDt)) {
							msg = new PaysError("error.cannotLess", "pn.label.penPayableDt", getPenDtlPenDtLabel(penType));
							msg.setObjType(PaysError.KEY, PaysError.KEY);
							errors.addError("penPayableDt", msg);
							errors.addErrIndicator("penPayableDtInd");
						}																		
					}
				}
				
		} else if (penType.startsWith("C")) {
				errors.merge(validateInjuPerc());				
				errors.merge(validatePenDedPerc());				
				errors.merge(validatePenDedPercForPenTypeC());		
				errors.merge(validateBeforeApptSdt(penDt, "pn.label.injuryDt", "", "penDt", "pn.error.notWithinServ"));			
				errors.merge(validateAfterApptEdt(penDt, "pn.label.injuryDt", "", "penDt", "pn.error.notWithinServ"));										
				errors.merge(validateBeforeApptSdt(medBoardDt, "pn.label.medBoardDt", "pn.label.apptSdt", "medBoardDt", "error.cannotLess"));			
				
				if (DateUtil.before(medBoardDt, penDt)) {
						msg = new PaysError("error.cannotLess", "pn.label.medBoardDt", "pn.label.injuryDt");
						msg.setObjType(PaysError.KEY, PaysError.KEY);
						errors.addError("medBoardDt", msg);
						errors.addErrIndicator("medBoardDtInd");
				}
				
		} else if (penType.startsWith("J")) {
			errors.merge(validatePenDedPerc());
			errors.merge(validateBeforeApptSdt(penDt, "pn.label.injuryDt", "", "injuryDt", "pn.error.notWithinServ"));			
			errors.merge(validateAfterApptEdt(penDt, "pn.label.injuryDt", "", "injuryDt", "pn.error.notWithinServ"));						

		} else if (penType.startsWith("R")) {
			errors.merge(validateBeforeApptSdt(penDt, "pn.label.refundSdt", "pn.label.enterSchemeDt", "refundSdt", "error.cannotLess"));
			errors.merge(validateAfterApptEdt(penDt, "pn.label.refundSdt", "pn.label.terminDt", "refundSdt", "error.cannotGreater"));			
			errors.merge(validateBeforeApptEdt(sdt, "pn.label.penPayableDt", "pn.label.terminDt", "penPayableDt", "error.cannotLess"));						

		}else if (penType.startsWith("H") || penType.startsWith("S")) {

		}

		return errors;
	}

	/**
	 * Validation for Pension HPE Date
	 *
 	 * @param String exCivil
 	 * @param Connection conn
 	 * @param User user
 	 * @return PaysErrors
	 * @throws DBObjectException, DBSecurityException
	 */
	public PaysErrors validatePenHpeDt (boolean isExCivil, Connection conn, User user)
			throws DBObjectException, DBSecurityException {

		PaysErrors errors = new PaysErrors();
		PaysError msg = null;

		if (penType.startsWith("A") || penType.startsWith("Z")) {
			
			errors.merge(validateBeforeApptSdt(penHpeDt, "pn.label.penHpeDt", "", "penHpeDt", "pn.error.notWithinServ"));			

// originally for exivil servant, allow = retire date
// later request by user to allow civil servant also
//			if (!isExCivil) {
//				errors.merge(validateAfterApptEdt(penHpeDt, "pn.label.penHpeDt", "", "penHpeDt", "pn.error.notWithinServ"));							
//			} else {
				if (DateUtil.after(penHpeDt, DateUtil.addDate(apptEdt, 0, 1))) {
					msg = new PaysError("pn.error.notWithinServ", "pn.label.penHpeDt");
					msg.setObjType(PaysError.KEY);
					errors.addError("penHpeDt", msg);
					errors.addErrIndicator("penHpeDtInd");
				}
//			}
		}

		if (penType.startsWith("J")) {
			
			errors.merge(validateBeforeApptSdt(penHpeDt, "pn.label.injuryDt", "", "penHpeDt", "pn.error.notWithinServ"));

			if (!isExCivil) {
				errors.merge(validateAfterApptEdt(penHpeDt, "pn.label.injuryDt", "", "penHpeDt", "pn.error.notWithinServ"));
			} else {
				if (DateUtil.after(penHpeDt, DateUtil.addDate(apptEdt, 0, 1))) {
					msg = new PaysError("pn.error.notWithinServ", "pn.label.injuryDt");
					msg.setObjType(PaysError.KEY);
					errors.addError("penHpeDt", msg);
					errors.addErrIndicator("penHpeDtInd");
				}
			}
		}

		return errors;

	}

	/**
	 * for penType H,S, must be >= end date of other pension Type A* & Z* of the same HKID
	 *
 	 * @param Connection conn
 	 * @param User user
 	 * @return PaysErrors
	 * @throws DBObjectException, DBSecurityException
	 */
	public PaysErrors validatePenSdt (Connection conn, User user)
			throws DBObjectException, DBSecurityException {

		PaysErrors errors = new PaysErrors();
		PaysError msg = null;

		if (penType.startsWith("H") || penType.startsWith("S")) {

//cc20060728			List penDtls = loadList(hkic, "A%", null, conn, user);
			List penDtls = loadList(hkic, "A%", " AND c40cancel_inp_dt is null", conn, user);
			if (!penDtls.isEmpty()) {
				for (int i=0; i< penDtls.size(); i++) {
					// return error if end Date < pension sdt
					PenDtl tmpPenDtl = (PenDtl)penDtls.get(i);
					if (DateUtil.before(sdt, tmpPenDtl.getEdt())) {
						msg = new PaysError("error.cannotLess", "pn.label.penSdt", "pn.label.penEdtDeathDate");
						msg.setObjType(PaysError.KEY, PaysError.KEY);
						errors.addError("sdt", msg);
						errors.addErrIndicator("sdtInd");
						return errors;
					}
				}
			}

//cc20060728			penDtls = loadList(hkic, "Z%", null, conn, user);
			penDtls = loadList(hkic, "Z%", " AND c40cancel_inp_dt is null", conn, user);
			if (!penDtls.isEmpty()) {
				for (int i=0; i< penDtls.size(); i++) {
					// return error if end Date < pension sdt
					PenDtl tmpPenDtl = (PenDtl)penDtls.get(i);
					if (DateUtil.before(sdt, tmpPenDtl.getEdt())) {
						msg = new PaysError("error.cannotLess", "pn.label.penSdt", "pn.label.penEdtDeathDate");
						msg.setObjType(PaysError.KEY, PaysError.KEY);
						errors.addError("sdt", msg);
						errors.addErrIndicator("sdtInd");
						return errors;
					}
				}
			}
		}

		return errors;

	}
	
	/**
	 * Validate PenDedPerc
	 *
 	 * @param Connection conn
 	 * @param User user
 	 * @return PaysErrors
	 * @throws DBObjectException, DBSecurityException
	 */
	public PaysErrors validatePenDedPerc() {

		PaysErrors errors = new PaysErrors();
		PaysError msg = null;	
	
		if (penDedPerc != null) {
			if ((penDedPerc.compareTo(new BigDecimal("0")) < 0)	||  (penDedPerc.compareTo(new BigDecimal("100.00")) > 0)) {
		 		msg = new PaysError("error.beyondRange", "pn.label.penDedPerc", "0", "100");
				msg.setObjType(PaysError.KEY, PaysError.KEY, PaysError.KEY);
				errors.addError("penDedPerc", msg);
				errors.addErrIndicator("penDedPercInd");
			}
		}		
		
		return errors;
	
	}
	
	/**
	 * Validate PenDedPerc for PenType C only
	 *
 	 * @param Connection conn
 	 * @param User user
 	 * @return PaysErrors
	 * @throws DBObjectException, DBSecurityException
	 */
	public PaysErrors validatePenDedPercForPenTypeC() {

		PaysErrors errors = new PaysErrors();
		PaysError msg = null;		
	
		// validate pension deduction %, special handling for penType C
		if (injuPerc != null && penDedPerc != null) {
			if (DateUtil.before(penDt, INJURY_DT_CUTOFF)) {
				for (int i=0; i<INJURYDT_DED_PERC.length; i++) {
					BigDecimal lowerRange = null;
					BigDecimal upperRange = null;
					
					if (INJURYDT_DED_PERC[i][0] != null)
						lowerRange = new BigDecimal(INJURYDT_DED_PERC[i][0]);
					if (INJURYDT_DED_PERC[i][1] != null)								
						upperRange = new BigDecimal(INJURYDT_DED_PERC[i][1]);						
	
					BigDecimal value = new BigDecimal(INJURYDT_DED_PERC[i][2]);												
							
					if ((lowerRange == null || injuPerc.compareTo(lowerRange) >= 0) &&
						(upperRange == null || injuPerc.compareTo(upperRange) < 0))	
					{
						if (penDedPerc.compareTo(value) != 0) {
							msg = new PaysError("pn.error.shouldBe", "pn.label.penDedPerc", INJURYDT_DED_PERC[i][2]);
							msg.setObjType(PaysError.KEY, PaysError.KEY);
							errors.addError("penDedPerc", msg);
							errors.addErrIndicator("penDedPercInd");
						}
						break;								
					}	
				}					
			} else {
				// penDedPerc must be 0
				if (penDedPerc.compareTo(new BigDecimal(0)) != 0) {
					msg = new PaysError("pn.error.shouldBe", "pn.label.penDedPerc", "0");
					msg.setObjType(PaysError.KEY, PaysError.KEY);
					errors.addError("penDedPerc", msg);
					errors.addErrIndicator("penDedPercInd");									
				}
			}
		}	
		return errors;
	
	}				
	
	/**
	 * Validate penHpe
	 *
 	 * @param Connection conn
 	 * @param User user
 	 * @return PaysErrors
	 * @throws DBObjectException, DBSecurityException
	 */
	public PaysErrors validatePenHpe() {

		PaysErrors errors = new PaysErrors();
		PaysError msg = null;	
	
		
		if (penHpe != null) {
			// HPE must be positive
			if (penHpe.compareTo(new BigDecimal(0)) < 0) {
				msg = new PaysError("pn.error.mustBePositive", "pn.label.penHpe.sal");
				msg.setObjType(PaysError.KEY);
				errors.addError("penHpe", msg);
				errors.addErrIndicator("penHpeInd");				
			}
		}	
		
		return errors;
	
	}	
	
	/**
	 * Validate last salary
	 *
 	 * @param Connection conn
 	 * @param User user
 	 * @return PaysErrors
	 * @throws DBObjectException, DBSecurityException
	 */
	public PaysErrors validateLastSal() {

		PaysErrors errors = new PaysErrors();
		PaysError msg = null;	
	
		
		if (lastSal != null) {
			// last salary must be positive
			if (lastSal.compareTo(new BigDecimal(0)) < 0) {
				msg = new PaysError("pn.error.mustBePositive", "pn.label.lastSal");
				msg.setObjType(PaysError.KEY);
				errors.addError("lastSal", msg);
				errors.addErrIndicator("lastSalInd");				
			}
		}	
		
		return errors;
	
	}	
	
	/**
	 * Validate unauthAbs
	 *
 	 * @param Connection conn
 	 * @param User user
 	 * @return PaysErrors
	 * @throws DBObjectException, DBSecurityException
	 */
	public PaysErrors validateUnauthAbs() {

		PaysErrors errors = new PaysErrors();
		PaysError msg = null;	
		
		if (unauthAbsYy != null && unauthAbsMm != null && unauthAbsDd != null) {
			// unauthAbs must be positive
			if (unauthAbsYy.compareTo(new BigDecimal(0)) < 0 ||
				unauthAbsMm.compareTo(new BigDecimal(0)) < 0 ||
				unauthAbsDd.compareTo(new BigDecimal(0)) < 0) {
				msg = new PaysError("pn.error.mustBePositive", "pn.label.unauthAbs");
				msg.setObjType(PaysError.KEY);
				errors.addError("unauthAbs", msg);
				errors.addErrIndicator("unauthAbsInd");				
			}
		}	
		
		return errors;
	
	}		

	/**
	 * Validate untakenLeav
	 *
 	 * @param Connection conn
 	 * @param User user
 	 * @return PaysErrors
	 * @throws DBObjectException, DBSecurityException
	 */
	public PaysErrors validateUntakenLeav() {

		PaysErrors errors = new PaysErrors();
		PaysError msg = null;	
		
		if (untakenLeav != null) {
			// untakenLeav must be positive
			if (untakenLeav.compareTo(new BigDecimal(0)) < 0) {
				msg = new PaysError("pn.error.mustBePositive", "pn.label.untakenLeave");
				msg.setObjType(PaysError.KEY);
				errors.addError("untakenLeave'", msg);
				errors.addErrIndicator("untakenLeaveInd'");				
			}
		}	
		
		return errors;
	
	}		
	
	/**
	 * Validate noPayLeav
	 *
 	 * @param Connection conn
 	 * @param User user
 	 * @return PaysErrors
	 * @throws DBObjectException, DBSecurityException
	 */
	public PaysErrors validateNoPayLeav() {

		PaysErrors errors = new PaysErrors();
		PaysError msg = null;	
	
		
		if (noPayLeav != null) {
			// No pay leave must be positive
			if (noPayLeav.compareTo(new BigDecimal(0)) < 0) {
				msg = new PaysError("pn.error.mustBePositive", "pn.label.noPayLeave");
				msg.setObjType(PaysError.KEY);
				errors.addError("noPayLeave", msg);
				errors.addErrIndicator("noPayLeaveInd");				
			}

			// No pay leave taken only accept multiples of 0.5 days				
			try {
				UdcIsMultipleOf isMultipleOf = new UdcIsMultipleOf();
				isMultipleOf.setIndex(new BigDecimal(0.5));
				isMultipleOf.setAmount(noPayLeav);
				if (((String)isMultipleOf.getValue()).equals("FALSE")) {
					msg = new PaysError("error.invalid", "pn.label.noPayLeave");
					msg.setObjType(PaysError.KEY);
					errors.addError("noPayLeave", msg);
					errors.addErrIndicator("noPayLeaveInd");
				}
			} catch (Exception e) {}
		}	
		
		return errors;
	
	}	
	
	/**
	 * Validate penOptPerc
	 *
 	 * @param Connection conn
 	 * @param User user
 	 * @return PaysErrors
	 * @throws DBObjectException, DBSecurityException
	 */
	public PaysErrors validatePenOptPerc(BigDecimal upperLimit, BigDecimal lowerLimit) {

		PaysErrors errors = new PaysErrors();
		PaysError msg = null;		
	
		if ((penOptPerc.compareTo(upperLimit) < 0)	||  (penOptPerc.compareTo(lowerLimit) > 0)) {
			msg = new PaysError("error.invalid", "pn.label.annPenOptPerc");
			msg.setObjType(PaysError.KEY);
			errors.addError("annPenOptPerc", msg);
			errors.addErrIndicator("annPenOptPercInd");
		} else {
			try {
				UdcIsMultipleOf isMultipleOf = new UdcIsMultipleOf();
				isMultipleOf.setIndex(new BigDecimal(5));
				isMultipleOf.setAmount(penOptPerc);

				if (((String)isMultipleOf.getValue()).equals("FALSE")) {
					msg = new PaysError("pn.error.shouldBeMultipleOf", "pn.label.annPenOptPerc", "5%", lowerLimit +"%", upperLimit+"%");
					msg.setObjType(PaysError.KEY, PaysError.KEY, PaysError.KEY, PaysError.KEY);
					errors.addError("annPenOptPerc", msg);
					errors.addErrIndicator("annPenOptPercInd");
				}
			} catch (Exception e) {}
		}		
		
		return errors;
	
	}									

	/**
	 * Validate penOptPerc for other object having same field
	 *
 	 * @param Connection conn
 	 * @param User user
 	 * @return PaysErrors
	 * @throws DBObjectException, DBSecurityException
	 */
	public static PaysErrors validatePenOptPerc(BigDecimal penOptPerc, String retireScheme) {
		PaysErrors errors = new PaysErrors();
		PaysError msg = null;		

		if (penOptPerc == null) {
			return errors;
		}

		if (retireScheme == null) {
			return errors;
		}
		
		PenDtl tmpPenDtl = new PenDtl();
		tmpPenDtl.setPenOptPerc(penOptPerc);
		
		if ((penOptPerc.compareTo(new BigDecimal("0")) < 0)	||  (penOptPerc.compareTo(new BigDecimal("100.00")) > 0)) {
	 		msg = new PaysError("error.beyondRange", "pn.label.annPenOptPerc", "0", "100");
			msg.setObjType(PaysError.KEY, PaysError.KEY, PaysError.KEY);
			errors.addError("annPenOptPerc", msg);
			errors.addErrIndicator("annPenOptPercInd");
		} else {
			if (retireScheme.equals("0") || retireScheme.equals("2") || 
				retireScheme.equals(PaysApptTerm.RETIRE_SCHEME_A) || retireScheme.equals(PaysApptTerm.RETIRE_SCHEME_B) || retireScheme.equals(PaysApptTerm.RETIRE_SCHEME_D)) {
				errors.merge(tmpPenDtl.validatePenOptPerc(new BigDecimal("50"), new BigDecimal("100")));
			} else if (retireScheme.equals("3")) {
				errors.merge(tmpPenDtl.validatePenOptPerc(new BigDecimal("75"), new BigDecimal("100")));								
			}
		}
		
		return errors;
	}
	
	/**
	 * Validate Before ApptSdt
	 *
 	 * @param Connection conn
 	 * @param User user
 	 * @return PaysErrors
	 * @throws DBObjectException, DBSecurityException
	 */
	public PaysErrors validateBeforeApptSdt(Date compareDt, String compareDtLabel, String apptSdtLabel, String errorInd, String chkSdtErrMsg) {

		PaysErrors errors = new PaysErrors();
		PaysError msg = null;	
	
		if (DateUtil.before(compareDt, apptSdt)) {
			msg = new PaysError(chkSdtErrMsg, compareDtLabel, apptSdtLabel);
			msg.setObjType(PaysError.KEY, PaysError.KEY);
			errors.addError(errorInd, msg);
			errors.addErrIndicator(errorInd + "Ind");
		}

		return errors;
	
	}	
	
	/**
	 * Validate After ApptEdt
	 *
 	 * @param Connection conn
 	 * @param User user
 	 * @return PaysErrors
	 * @throws DBObjectException, DBSecurityException
	 */
	public PaysErrors validateAfterApptEdt(Date compareDt, String compareDtLabel, String apptEdtLabel, String errorInd, String chkEdtErrMsg) {

		PaysErrors errors = new PaysErrors();
		PaysError msg = null;	

		if (DateUtil.after(compareDt, apptEdt)) {
			msg = new PaysError(chkEdtErrMsg, compareDtLabel, apptEdtLabel);
			msg.setObjType(PaysError.KEY, PaysError.KEY);
			errors.addError(errorInd, msg);
			errors.addErrIndicator(errorInd + "Ind");
		}	
		
		return errors;
	
	}	
	
	/**
	 * Validate Before ApptEdt
	 *
 	 * @param Connection conn
 	 * @param User user
 	 * @return PaysErrors
	 * @throws DBObjectException, DBSecurityException
	 */
	public PaysErrors validateBeforeApptEdt(Date compareDt, String compareDtLabel, String apptEdtLabel, String errorInd, String chkEdtErrMsg) {

		PaysErrors errors = new PaysErrors();
		PaysError msg = null;	
	
		if (DateUtil.before(compareDt, apptEdt)) {
			msg = new PaysError(chkEdtErrMsg, compareDtLabel, apptEdtLabel);
			msg.setObjType(PaysError.KEY, PaysError.KEY);
			errors.addError(errorInd, msg);
			errors.addErrIndicator(errorInd + "Ind");
		}

		return errors;
	
	}		
	
	/**
	 * Validate Before ApptEdt
	 *
 	 * @param Connection conn
 	 * @param User user
 	 * @return PaysErrors
	 * @throws DBObjectException, DBSecurityException
	 */
	public PaysErrors validateMaterialDt() {

		PaysErrors errors = new PaysErrors();
		PaysError msg = null;	
		
		if (materialDt != null) {		
	
			errors.merge(validateBeforeApptSdt(materialDt, "pn.label.pdMaterialDt", "pn.label.apptSdt", "materialDt", "error.cannotLess"));							
			
			if (retireScheme.equals("3")) {
				if (materialDt != null) {
					msg = new PaysError("error.field.mustBlank", "pn.label.pdMaterialDt");
					msg.setObjType(PaysError.KEY);
					errors.addError("materialDt", msg);
					errors.addErrIndicator("materialDtInd");
				}
			}	
	
			if (DateUtil.before(materialDt, MATERIAL_DT_LOWER)) {
				msg = new PaysError("error.cannotLess", "pn.label.pdMaterialDt", MATERIAL_DT_LOWER.toString());
				msg.setObjType(PaysError.KEY, PaysError.KEY);
				errors.addError("materialDt", msg);
				errors.addErrIndicator("materialDtInd");
			} 		
			
			if (DateUtil.after(materialDt, MATERIAL_DT_UPPER)) {
				msg = new PaysError("error.cannotGreater", "pn.label.pdMaterialDt", MATERIAL_DT_UPPER.toString());
				msg.setObjType(PaysError.KEY, PaysError.KEY);
				errors.addError("materialDt", msg);
				errors.addErrIndicator("materialDtInd");
			}		
		
		}
		
		return errors;
	
	}
			
	/**
	 * Validate injuPerc
	 *
 	 * @param Connection conn
 	 * @param User user
 	 * @return PaysErrors
	 * @throws DBObjectException, DBSecurityException
	 */
	public PaysErrors validateInjuPerc() {

		PaysErrors errors = new PaysErrors();
		PaysError msg = null;		

		if (injuPerc != null) {
			if ((injuPerc.compareTo(new BigDecimal("0")) < 0)	||  (injuPerc.compareTo(new BigDecimal("100.00")) > 0)) {
		 		msg = new PaysError("error.beyondRange", "pn.label.injuryPerc", "0", "100");
				msg.setObjType(PaysError.KEY, PaysError.KEY, PaysError.KEY);
				errors.addError("injuryPerc", msg);
				errors.addErrIndicator("injuryPercInd");
			}
			if (injuPerc.compareTo(new BigDecimal("0")) == 0) {
		 		msg = new PaysError("pn.error.unacceptedValue", "pn.label.injuryPerc", "0");
				msg.setObjType(PaysError.KEY, PaysError.KEY, PaysError.VALUE);
				errors.addError("injuryPerc", msg);
				errors.addErrIndicator("injuryPercInd");
			}
		}	
		return errors;
	
	}	
	
	/**
	 * Validate auth payment
	 *
 	 * @param Connection conn
 	 * @param User user
 	 * @return PaysErrors
	 * @throws DBObjectException, DBSecurityException
	 */
	public PaysErrors validateAuthPymt() {

		PaysErrors errors = new PaysErrors();
		PaysError msg = null;		

		if (authPymt != null) {
			if (!AuthPay.validate(authPymt, retireScheme)) {
		 		msg = new PaysError("error.notMatch", "pn.label.retireScheme", "pn.label.authPayment");
				msg.setObjType(PaysError.KEY, PaysError.KEY, PaysError.KEY);
				errors.addError("authPayment", msg);
				errors.addErrIndicator("authPaymentInd");
			}
		}	
		return errors;
	
	}

	/**
	 * Validate payment type
	 *
 	 * @param Connection conn
 	 * @param User user
 	 * @return PaysErrors
	 * @throws DBObjectException, DBSecurityException
	 */
	public PaysErrors validatePymtType() {

		PaysErrors errors = new PaysErrors();
		PaysError msg = null;		

		if (pymtType != null) {
			if (pymtType.equals(PYMT_TYPE_ONETIME)) {
				if (penType.startsWith("B") ||
					penType.startsWith("D") ||
					penType.startsWith("E") ||
					penType.startsWith("F") ||
					penType.startsWith("G") ||
					penType.startsWith("T") ||
					penType.startsWith("W")) {
					
			 		msg = new PaysError("error.notEligible", "pn.label.pymtType.O", "pn.label.payment");
					msg.setObjType(PaysError.KEY, PaysError.KEY, PaysError.KEY);
					errors.addError("pymtType", msg);
					errors.addErrIndicator("pymtTypeInd");
				}
			}
			if (pymtType.equals(PYMT_TYPE_MONTHLY)) {
				if (penType.startsWith("M")) {
					
			 		msg = new PaysError("error.notEligible", "pn.label.pymtType.M", "pn.label.payment");
					msg.setObjType(PaysError.KEY, PaysError.KEY, PaysError.KEY);
					errors.addError("pymtType", msg);
					errors.addErrIndicator("pymtTypeInd");
				}
			}

		}	
		return errors;
	
	}
	
	/**
	 * Define criteria on key, for PNPD05 and get the notification record
 	 * @param String hkic
 	 * @param String penType
	 */
	public void defineCriteriaForPnpd05Notify(String hkic, String penType) {		
		String[] defPenType = {"A%", "C%", "J%", "Z%"};		
		if (!StringUtil.isEmpty(penType)) {
			if (!checkOthersPension(penType)) 
				defPenType = new String[]{penType};			
			else
				defPenType = new String[]{};
		} 

		String sql="";
		
		if (defPenType.length == 0) {
			sql = "1 <> 1";			
		} else {

			sql = "c40hkic = " + StringUtil.addQuote(hkic);
			sql += " AND (";
	
			for (int a=0;a<defPenType.length;a++) {		
				if (StringUtil.containWildCard(defPenType[a])) {
					sql += " c40pen_type LIKE " + StringUtil.addQuote(defPenType[a]);
				} else {
					sql += " c40pen_type = " + StringUtil.addQuote(defPenType[a]);				
				}
				if (a != defPenType.length-1) {
					sql += " OR ";
				}
			}
	
			sql += " ) AND c40confirm_inp_dt IS NOT NULL";
		}
		
		storeCriteria(sql);
		storeOrder("c40hkic");
	}
	
	/**
	 * Load list for Pnpd05 Notify
	 * @param String hkic
	 * @param String penType
	 * @param Connection conn
	 * @param User user
	 * @return List list
	 * @throws DBObjectException, DBSecurityException
	 */
	public List loadListForPnpd05Notify(String hkic, String penType, Connection conn, User user)
					throws DBObjectException, DBSecurityException {
		defineCriteriaForPnpd05Notify(hkic, penType);
		return loadList(conn, user);
	}

	/**
	 * Load list for select distinct hkic, pentype
	 * @param String hkic
	 * @param String penType
	 * @param Connection conn
	 * @param User user
	 * @return List list
	 * @throws DBObjectException, DBSecurityException
	 */
	public static List loadListDistPenType(String hkic, Connection conn, User user) throws DBSecurityException, DBObjectException {
		String[] fields = {"Hkic", "PenType"};
		SqlRunner sql = new SqlRunner(PenDtl.class, fields);
		
		sql.append("SELECT DISTINCT c40hkic, c40pen_type"
					+ " FROM <SCHEMA>." + new PenDtl().getDBTableName()
					+ " WHERE c40hkic = " + StringUtil.addQuote(hkic)					
					+ " ORDER BY c40pen_type ASC");
		sql.execute(user, conn);
		return sql.getResults();
	}

	/**
	 * Load list for select distinct hkic, pentype
	 * @param String hkic
	 * @param String penType
	 * @param Connection conn
	 * @param User user
	 * @return List list
	 * @throws DBObjectException, DBSecurityException
	 */
	public static List loadListDistPenTypeWithCancelInputDtIsNull(String hkic, Connection conn, User user) throws DBSecurityException, DBObjectException {
		String[] fields = {"Hkic", "PenType","CancelInpDt"};
		SqlRunner sql = new SqlRunner(PenDtl.class, fields);
		
		sql.append("SELECT DISTINCT c40hkic, c40pen_type"
					+ " FROM <SCHEMA>." + new PenDtl().getDBTableName()
					+ " WHERE c40hkic = " + StringUtil.addQuote(hkic)
					+ " AND c40cancel_inp_dt is null "
					+ " ORDER BY c40pen_type ASC");
		sql.execute(user, conn);
		return sql.getResults();
	}
	

	/**
	 * Load list for report PEN305-01
	 * @param Connection conn
	 * @param User user
	 * @return List list
	 * @throws DBObjectException, DBSecurityException
	 */
	public static List loadListRpt305(Date effDt, Connection conn, User user) throws DBSecurityException, DBObjectException {

		PenDtl penDtl = new PenDtl();
		String[] fields = penDtl.getFieldNames();
		String[] columns = penDtl.getDBColumnNames();
		StringBuffer buf = new StringBuffer("SELECT ");
		for(int i=0; i<columns.length; i++){
			if (i != 0)
				buf.append(", ");
			buf.append(columns[i]);
		}
		
		SqlRunner sqlRunner = new SqlRunner(PenDtl.class, fields);
		
		buf.append(" FROM <SCHEMA>."+penDtl.getDBTableName()+", <SCHEMA>."+new PenPymtDtl().getDBTableName());
		buf.append(" WHERE c40hkic = c41hkic AND c40pen_type = c41pen_type");
		buf.append(" AND c41pi_last_dt = '").append(effDt).append("'");
		buf.append(" AND c40cancel_inp_dt is null");
		buf.append(" ORDER BY c40hkic, c40pen_type");

		sqlRunner.append(buf.toString());
		sqlRunner.execute(user, conn);
		
		List list = sqlRunner.getResults();
		return list;	
	}
	
	/**
	 * Load list for report PEN305-03
	 * @param Connection conn
	 * @param User user
	 * @return List list
	 * @throws DBObjectException, DBSecurityException
	 */
	public static List loadListRpt305Wmp(Date effDt, Connection conn, User user) throws DBSecurityException, DBObjectException {

		PenDtl penDtl = new PenDtl();
		String[] fields = penDtl.getFieldNames();
		String[] columns = penDtl.getDBColumnNames();
		StringBuffer buf = new StringBuffer("SELECT ");
		for(int i=0; i<columns.length; i++){
			if (i != 0)
				buf.append(", ");
			buf.append(columns[i]);
		}
		
		SqlRunner sqlRunner = new SqlRunner(PenDtl.class, fields);
		
		buf.append(" FROM <SCHEMA>."+penDtl.getDBTableName()+", <SCHEMA>."+new PenPymtDtl().getDBTableName());
		buf.append(" WHERE c40hkic = c41hkic AND c40pen_type = c41pen_type");
		buf.append(" AND c40pen_type like '").append(ProcessWmpRev.WMP_ELIG_PEN_TYPE).append("%'");
		buf.append(" AND c41pi_last_dt = '").append(effDt).append("'");
		buf.append(" AND c40cancel_inp_dt is null");
		buf.append(" ORDER BY c40hkic, c40pen_type");

		sqlRunner.append(buf.toString());
		sqlRunner.execute(user, conn);
		
		List list = sqlRunner.getResults();
		return list;	
	}
	

	
	/**
	 * Load list for report PEN307-01
	 * @param Connection conn
	 * @param User user
	 * @return List list
	 * @throws DBObjectException, DBSecurityException
	 */
/* TC - 18/12/2015 - start
	public static List loadListRpt307(Date apprDt, Connection conn, User user) throws DBSecurityException, DBObjectException {

		PenDtl penDtl = new PenDtl();
		String[] fields = penDtl.getFieldNames();
		String[] columns = penDtl.getDBColumnNames();
		StringBuffer buf = new StringBuffer("SELECT ");
		for(int i=0; i<columns.length; i++){
			if (i != 0)
				buf.append(", ");
			buf.append(columns[i]);
		}
		
		SqlRunner sqlRunner = new SqlRunner(PenDtl.class, fields);
		
		buf.append(" FROM <SCHEMA>."+penDtl.getDBTableName()+", <SCHEMA>."+new PenPaper().getDBTableName());
		buf.append(" WHERE c40hkic = c60hkic AND c40pen_type = c60pen_type");
		buf.append(" and c60appr_dt = ? and c60confirm_del_dt is null");
		buf.append(" and c40cancel_inp_dt is null");

		sqlRunner.append(buf.toString());
		sqlRunner.addParam(apprDt);
		
		
		buf = new StringBuffer(" UNION SELECT ");
		for(int i=0; i<columns.length; i++){
			if (i != 0)
				buf.append(", ");
			buf.append(columns[i]);
		}
			
		buf.append(" FROM <SCHEMA>."+penDtl.getDBTableName()+", <SCHEMA>."+new PenPaperRecal().getDBTableName()).
		append(" WHERE c40hkic = c63hkic AND c40pen_type = c63pen_type").
		append(" and c63appr_dt = ? and c63confirm_del_dt is null").
		append(" and c40cancel_inp_dt is null").
		append(" ORDER BY c40hkic, c40pen_type, c40first_input_dt ");

		sqlRunner.append(buf.toString());
		sqlRunner.addParam(apprDt);
		
		sqlRunner.execute(user, conn);
		
		List list = sqlRunner.getResults();
		
		// remove those system approve
		for (int i=0; i < list.size(); i++) {
			PenDtl tempPenDtl = (PenDtl) list.get(i);
			if (PenDtl.checkSysApprovePension (tempPenDtl.getPenType()))	{
				list.remove(i);
				i--;
			}
		}
		return list;	
	}
*/ //TC - 18/12/2015 - end

//TC - 18/12/2015 - start
	/**
	 * Load list for report PEN307-01
	 * @param Connection conn
	 * @param User user
	 * @return List list
	 * @throws DBObjectException, DBSecurityException
	 */
	public static List loadListRpt307(Date apprDt, Connection conn, User user) throws DBSecurityException, DBObjectException {
		List returnList = new Vector();
		
		PenDtl penDtl = new PenDtl();
		String dbColNames = StringUtil.joinWithComma(penDtl.getDBColumnNames());
		String withoutPensionability = StringUtil.addQuote(treasury.pension.pensioner.ApptDtl.RETIRE_SCHEME_WITHOUT_PENSIONABILITY);
		String withPensionability = StringUtil.addQuote(treasury.pension.pensioner.ApptDtl.RETIRE_SCHEME_WITH_PENSIONABILITY);
		//String allPenTypes = StringUtil.addQuote(PenPaper.PEN_TYPES_GEN_IN_TFTS) + "," + StringUtil.addQuote(PenPaper.PEN_TYPES_GEN_IN_RB);
		String allPenTypes = StringUtil.addQuote(PenPaper.PEN_TYPES_GEN_IN_RB); //Retrieve only audited pension papers for B/D to download only
		
		SqlRunner sqlRunner = new SqlRunner(penDtl.getClass(), penDtl.getFieldNames());
		
		sqlRunner.append(" SELECT " + dbColNames);
		sqlRunner.append(" FROM   <SCHEMA>." + penDtl.getDBTableName() + ", <SCHEMA>." + (new PenPaper()).getDBTableName());
		sqlRunner.append(" WHERE  c40hkic = c60hkic");
		sqlRunner.append(" AND    c40pen_type = c60pen_type");
		sqlRunner.append(" AND    c40cancel_inp_dt IS NULL");
		sqlRunner.append(" AND    c60confirm_del_dt IS NULL");
		sqlRunner.append(" AND    ((c60confirm_dt = ? AND c60pen_type = ? AND c40retire_scheme IN (" + withoutPensionability + "))").addParam(apprDt).addParam("Z0");
		sqlRunner.append(" OR     (c60appr_dt = ? AND c60pen_type = ? AND c40retire_scheme IN (" + withPensionability + "))").addParam(apprDt).addParam("Z0");
		sqlRunner.append(" OR     (c60appr_dt = ? AND SUBSTR(c60pen_type, 1, 1) IN (" + allPenTypes + ")))").addParam(apprDt);
		
		sqlRunner.execute(user, conn);
		
		List penPaperList = sqlRunner.getResults();
		List<String> stmtExclPayeeIds = StmtExclList.retrievePayeeIdsForStmtExclusion(apprDt, conn, user);
		
		for (int i=0; i < penPaperList.size(); i++) {
			PenDtl tempPenDtl = (PenDtl) penPaperList.get(i);
			
			if(stmtExclPayeeIds!=null && stmtExclPayeeIds.size()>0){
				//Skip the Pensioner who are in the Statement Exclusion List
				if(StringUtil.existIn(tempPenDtl.getPayeeId(), stmtExclPayeeIds)){
					continue;
				}
			}
			
			String deptDistPenPaper = PenPaper.deterDeptForAuditPPDistr(tempPenDtl.getHkic(), tempPenDtl.getPenType(), tempPenDtl, conn, user);
			tempPenDtl.setDeptDistPenPaper(deptDistPenPaper);
			returnList.add(tempPenDtl);
		}
		
		//sqlRunner = new SqlRunner(penDtl.getClass(), penDtl.getFieldNames());
		
		//sqlRunner.append(" SELECT " + dbColNames);
		//sqlRunner.append(" FROM   <SCHEMA>." + penDtl.getDBTableName() + ", <SCHEMA>." + (new PenPaperRecal()).getDBTableName());
		//sqlRunner.append(" WHERE  c40hkic = c63hkic");
		//sqlRunner.append(" AND    c40pen_type = c63pen_type");
		//sqlRunner.append(" AND    c40cancel_inp_dt IS NULL");
		//sqlRunner.append(" AND    c63confirm_del_dt IS NULL");
		//sqlRunner.append(" AND    c63appr_dt = ?").addParam(apprDt);
		
		//sqlRunner.execute(user, conn);
		
		//List penPaperRecalList = sqlRunner.getResults();
		//for (int i=0; i < penPaperRecalList.size(); i++) {
		//	PenDtl tempPenDtl = (PenDtl) penPaperRecalList.get(i);
			// remove those system approve
		//	if (PenDtl.checkSysApprovePension(tempPenDtl.getPenType())) {
		//		penPaperRecalList.remove(i);
		//		i--;
		//		continue;
		//	}
			
			// set last department code as the department code for distribution to B/D
		//	tempPenDtl.setDeptDistPenPaper(tempPenDtl.getLastDeptCode());
		//	returnList.add(tempPenDtl);
		//}
		
		String[] sortedFields = {"Hkic", "PenType", "FirstInputDt"};
		Collections.sort(returnList, new GettersComparator(sortedFields));
		
		return returnList;	
	}
//TC - 18/12/2015 - end
	
	/**
	 * Load list for report PEN315-01
	 * @param Connection conn
	 * @param User user
	 * @return List list
	 * @throws DBObjectException, DBSecurityException
	 */
	public static List loadListRpt315(Connection conn, User user) 
	throws DBSecurityException, DBObjectException {
		PenDtl penDtl = new PenDtl();
//		String[] fields = penDtl.getFieldNames();
		//String[] fields = {"Sdt","Hkic","PenType","TerminCode","LastDeptCode","SignDt"};
		String[] fields = {"Sdt","Hkic","PenType","TerminCode","ApptTermCode", "LastDeptCode","SignDt"};
		
//		String[] columns = penDtl.getDBColumnNames();
		//String[] columns = {"c40sdt", "c40hkic","c40pen_type","c40termin_code",
		//	"c40last_dept_code", "c40sign_dt"};
		String[] columns = {"c40sdt", "c40hkic","c40pen_type","c40termin_code", "c40appt_term_code", "c40last_dept_code", "c40sign_dt"};
		StringBuffer buf = new StringBuffer("SELECT ");
		StringBuffer cols = new StringBuffer();
		for(int i=0; i<columns.length; i++){
			if (i != 0)
				cols.append(", ");
			cols.append(columns[i]);
		}
		
		SqlRunner sqlRunner = new SqlRunner(PenDtl.class, fields);
		buf.append(cols.toString()).
		append(" FROM <SCHEMA>."+penDtl.getDBTableName()+" LEFT OUTER JOIN <SCHEMA>."+new PenPaper().getDBTableName()+" ON ").
		append(" c40hkic = c60hkic AND c40pen_type = c60pen_type ").
		append(" WHERE (c60hkic is null or c60confirm_del_dt is not null) ").
		append(" and c40sign_dt is not null ").
		append(" and c40cancel_inp_dt is null ").
		append(" and not exists ( SELECT 1 FROM <SCHEMA>."+new PenPaper().getDBTableName()+" t60 ").
		append(" WHERE t60.c60hkic=c40hkic and t60.c60hkic=c40hkic ").
		append(" and t60.c60pen_type=c40pen_type ").
		append(" and t60.c60confirm_del_dt is null)").
		append(" GROUP BY ").append(cols.toString()).
		append(" ORDER BY c40pen_type, c40termin_code, c40sdt, c40hkic ");

		sqlRunner.append(buf.toString());
		sqlRunner.execute(user, conn);
		
		List list = sqlRunner.getResults();
		
		return list;	
	}
	
	
	/**
	 * Load list for online function PNPS02
	 * @param Connection conn
	 * @param User user
	 * @return List list
	 * @throws DBObjectException, DBSecurityException
	 */
	public static List loadListForPnps02(String hkic, String penType, Connection conn, User user) 
	throws DBSecurityException, DBObjectException {
		PenDtl penDtl = new PenDtl();
		PenPymtDtl pymtDtl = new PenPymtDtl();
		
		SqlRunner sqlRunner = new SqlRunner(PenDtl.class, penDtl.getFieldNames());
		sqlRunner.append(" SELECT " + StringUtil.joinWithComma(penDtl.getDBColumnNames())).
		append(" FROM <SCHEMA>."+penDtl.getDBTableName() + " m ").
		append(" WHERE c40cancel_inp_dt is null ").
		append(" AND EXISTS ( SELECT 1 FROM <SCHEMA>."+penDtl.getDBTableName() + " d ").
			append(" WHERE d.c40hkic=m.c40hkic ").
			append(" AND d.c40payee_id=m.c40payee_id ").
			append(" AND d.c40cancel_inp_dt IS NULL ").
			append(" AND d.c40hkic="+StringUtil.addQuote(PensHkicUtil.formatHkic(hkic))).
			append(" AND d.c40pen_type="+StringUtil.addQuote(penType)+")").
		append(" AND EXISTS (SELECT 1 FROM <SCHEMA>."+pymtDtl.getDBTableName()).
			append(" WHERE c40hkic=c41hkic").
			append(" AND c40pen_type=c41pen_type").
			append(" AND c41pen_pymt_method = "+StringUtil.addQuote(PenProfile.PYMT_METHOD_LOCAL_BANK_AUTOPAY)).
			append(" AND c41confirm_pymt_dt IS NOT NULL)").
		append(" ORDER BY c40hkic, c40pen_type, c40sdt");
		sqlRunner.execute(user, conn);
		
		List list = sqlRunner.getResults();
		
		return list;	
		
	}
	
	
	/**
	 * Load list for batch job process pi grat
	 * @param Date sdt
	 * @param Date edt
	 * @param Date implDt
	 * @param Connection conn
	 * @param User user
	 * @return List list
	 * @throws DBObjectException, DBSecurityException
	 */
	public static List loadListForProcessPiGrat(Date sdt, Date edt, Date implDt, Date effDt, Connection conn, User user) 
	throws DBSecurityException, DBObjectException {
		PenDtl penDtl = new PenDtl();
		PenPymtDtl pymtDtl = new PenPymtDtl();
		PenPaperRecal recal = new PenPaperRecal();
		
		SqlRunner sqlRunner = new SqlRunner(PenDtl.class, penDtl.getFieldNames());
		sqlRunner.append(" SELECT " + StringUtil.joinWithComma(penDtl.getDBColumnNames())).
		append(" FROM <SCHEMA>."+penDtl.getDBTableName()+", <SCHEMA>."+pymtDtl.getDBTableName()).
		append(" WHERE EXISTS ( SELECT 1 FROM <SCHEMA>."+recal.getDBTableName()).
			append(" WHERE c40hkic=c63hkic ").
			append(" AND c40pen_type=c63pen_type ").
			append(" AND c63appr_dt IS NOT NULL ").
			append(" AND c63req_dt <= ? ").
			append(" AND c63pen_opt_perc != 100 ").
			append(" AND c63confirm_del_dt is NULL )").
		append(" AND c40cancel_inp_dt IS NULL ").
		append(" AND c41pi_elig_dt <= ? ").
		append(" AND c40hkic=c41hkic AND c40pen_type=c41pen_type").
		append(" AND c40sdt between ? AND ?").
		append(" AND (c40edt IS NULL OR c40edt>=c40sdt)").
		append(" ORDER BY c40hkic, c40pen_type, c40sdt");
		sqlRunner.addParam(implDt, Types.DATE).addParam(effDt, Types.DATE).addParam(sdt, Types.DATE).addParam(edt, Types.DATE);
		sqlRunner.execute(user, conn);
		
		List list = sqlRunner.getResults();
		
		return list;	
		
	}
	
	/**
	 * Load list for batch job GenPen305_05, GenPen305_06
	 * @param Date runDate
	 * @param Connection conn
	 * @param User user
	 * @return List list
	 * @throws DBObjectException, DBSecurityException
	 */
	public static List loadListForRpt305_0506(Date runDate, Connection conn, User user) 
	throws DBSecurityException, DBObjectException {
		PenDtl penDtl = new PenDtl();
		PenPaperRecal recal = new PenPaperRecal();
		
		SqlRunner sqlRunner = new SqlRunner(PenDtl.class, penDtl.getFieldNames());
		sqlRunner.append(" SELECT " + StringUtil.joinWithComma(penDtl.getDBColumnNames())).
		append(" FROM <SCHEMA>."+penDtl.getDBTableName()).
		append(" WHERE EXISTS ( SELECT 1 FROM <SCHEMA>."+recal.getDBTableName()).		
			append(" WHERE c63confirm_dt=? ").
			append(" AND c63revision_ind = ? ").
			append(" AND c63hkic=c40hkic ").
			append(" AND c63pen_type=c40pen_type )").
		append(" AND c40cancel_inp_dt IS NULL ").
		addParam(runDate, Types.DATE).
		addParam(PenPaperRecal.REV_IND_R, Types.CHAR);

		sqlRunner.append(" ORDER BY c40last_dept_code, c40hkic, c40pen_type ");
		sqlRunner.execute(user, conn);
				
		List list = sqlRunner.getResults();
		
		return list;
		
	}
	
	/**
	 * Load list for batch job Process Salary Revision
	 * @param Date sdt
	 * @param Date edt
	 * @param Connection conn
	 * @param User user
	 * @return List list
	 * @throws DBObjectException, DBSecurityException
	 */
	public static List loadListForProcessSalaryRevision(Date sdt, Date edt, Connection conn, User user) 
	throws DBSecurityException, DBObjectException {
		PenDtl penDtl = new PenDtl();
		PenPaper penPaper = new PenPaper();
		
		SqlRunner sqlRunner = new SqlRunner(PenDtl.class, penDtl.getFieldNames());
		sqlRunner.append(" SELECT " + StringUtil.joinWithComma(penDtl.getDBColumnNames())).
		append(" FROM <SCHEMA>."+penDtl.getDBTableName()).
		append(" WHERE EXISTS ( SELECT 1 FROM <SCHEMA>."+penPaper.getDBTableName()).
			append(" WHERE c40hkic=c60hkic ").
			append(" AND c40pen_type=c60pen_type ").
			append(" AND c60confirm_del_dt is NULL )").
		append(" AND c40cancel_inp_dt IS NULL ").
		append(" AND (c40pen_type like 'A%' OR c40pen_type like 'Z%' ) ").
		append(" AND c40appt_edt between ? AND ?").
		append(" ORDER BY c40hkic, c40pen_type, c40sdt");
//sqlRunner.append(" FETCH FIRST 100 ROWS ONLY ");
		sqlRunner.addParam(sdt, Types.DATE).addParam(edt, Types.DATE);
		sqlRunner.execute(user, conn);
		
		List list = sqlRunner.getResults();
		
		return list;	
		
	}
	
	/**
	 * Load PenDtl for batch job Process Salary Revision
	 * @param String hkic
	 * @param String penType
	 * @param Date penDt
	 * @param Date sdt
	 * @param Date edt
	 * @param Connection conn
	 * @param User user
	 * @return List list
	 * @throws DBObjectException, DBSecurityException
	 */
	public static PenDtl loadPenDtlForProcessSalaryRevision(String hkic, String penType, Date sdt, Date edt, Connection conn, User user) 
	throws DBSecurityException, DBObjectException {
		PenDtl penDtl = new PenDtl();
		PenPaper penPaper = new PenPaper();
		
		SqlRunner sqlRunner = new SqlRunner(PenDtl.class, penDtl.getFieldNames());
		sqlRunner.append(" SELECT " + StringUtil.joinWithComma(penDtl.getDBColumnNames())).
		append(" FROM <SCHEMA>."+penDtl.getDBTableName()).
		append(" WHERE EXISTS ( SELECT 1 FROM <SCHEMA>."+penPaper.getDBTableName()).
			append(" WHERE c40hkic=c60hkic ").
			append(" AND c40pen_type=c60pen_type ").
			append(" AND c60confirm_del_dt is NULL )").
		append(" AND c40cancel_inp_dt IS NULL ").
		append(" AND (c40pen_type like 'A%' OR c40pen_type like 'Z%' ) ").
		append(" AND c40hkic = ?").
		append(" AND c40pen_type = ?").
		append(" AND c40appt_edt between ? AND ?").
		append(" ORDER BY c40hkic, c40pen_type, c40sdt");
		sqlRunner.addParam(hkic);
		sqlRunner.addParam(penType);
		sqlRunner.addParam(sdt, Types.DATE).addParam(edt, Types.DATE);
		sqlRunner.execute(user, conn);
		
		List list = sqlRunner.getResults();
		
		if (list.size() > 0)
			return (PenDtl)list.get(0);
		else
			return null;
		
	}
	
	/**
	 * Load list for batch job GenPenPotentialSalAdjRpts
	 * @param Date sdt
	 * @param Date edt
	 * @param Connection conn
	 * @param User user
	 * @return List list
	 * @throws DBObjectException, DBSecurityException
	 */
	public static List loadListForProcessSalaryRevision325(Date sdt, Date edt, Connection conn, User user) 
	throws DBSecurityException, DBObjectException {
		PenDtl penDtl = new PenDtl();
		PenPaper penPaper = new PenPaper();
		
		SqlRunner sqlRunner = new SqlRunner(PenDtl.class, penDtl.getFieldNames());
		sqlRunner.append(" SELECT " + StringUtil.joinWithComma(penDtl.getDBColumnNames())).
		append(" FROM <SCHEMA>."+penDtl.getDBTableName()).
		append(" WHERE EXISTS ( SELECT 1 FROM <SCHEMA>."+penPaper.getDBTableName()).
			append(" WHERE c40hkic=c60hkic ").
			append(" AND c40pen_type=c60pen_type ").
			append(" AND c60confirm_del_dt is NULL )").
		append(" AND c40cancel_inp_dt IS NULL ").
		append(" AND (c40pen_type like 'A%' OR c40pen_type like 'Z%' ) ").
		append(" AND c40pen_dt between ? AND ?").
		append(" ORDER BY c40pen_type, c40hkic");
		sqlRunner.addParam(sdt, Types.DATE).addParam(edt, Types.DATE);
		sqlRunner.execute(user, conn);
		
		List list = sqlRunner.getResults();
		
		return list;	
		
	}
	
	/**
	 * Load list for batch job Process Salary Revision
	 * @param Date sdt
	 * @param Date edt
	 * @param Connection conn
	 * @param User user
	 * @return List list
	 * @throws DBObjectException, DBSecurityException
	 */
	public static List loadListForRpt325(Date runDate, Connection conn, User user) 
	throws DBSecurityException, DBObjectException {
		PenDtl penDtl = new PenDtl();
		PenPaper penPaper = new PenPaper();
		PenPaperRecal recal = new PenPaperRecal();
		
		SqlRunner sqlRunner = new SqlRunner(PenDtl.class, penDtl.getFieldNames());
		sqlRunner.append(" SELECT " + StringUtil.joinWithComma(penDtl.getDBColumnNames())).
		append(" FROM <SCHEMA>."+penDtl.getDBTableName()).
		append(" WHERE EXISTS ( SELECT 1 FROM <SCHEMA>."+penPaper.getDBTableName()).		
			append(" WHERE c60confirm_dt=? ").
			append(" AND c60revision_ind = ? ").
			append(" AND c60hkic=c40hkic ").
			append(" AND c60pen_type=c40pen_type )").
		append(" AND c40cancel_inp_dt IS NULL ").
		addParam(runDate, Types.DATE).
		addParam(PenPaper.REV_IND_R, Types.CHAR);

		sqlRunner.append(" ORDER BY c40pen_type, c40hkic ");
		sqlRunner.execute(user, conn);
				
		List list = sqlRunner.getResults();
		
		return list;
	}
	
	
	/**
	 * Load list for report of UpdateHSS, i.e. PEN326-01
	 * @param String hkic
	 * @param Connection conn
	 * @param User user
	 * @return List list
	 * @throws DBObjectException, DBSecurityException
	 */
	public static List loadListForUpdateHSS(String hkic, Connection conn, User user) 
	throws DBSecurityException, DBObjectException {
		PenDtl penDtl = new PenDtl();
		penDtl.defineCriteriaForUpdateHSS(hkic);
		List list = penDtl.loadList(conn, user);
		return list;
	}
	
	public void defineCriteriaForUpdateHSS (String hkic) {
		storeCriteria(" upper(c40hkic) = " + StringUtil.addQuote(hkic) + 
		" AND (c40Conv_Rec_Ind != 'Y' OR c40Conv_Rec_Ind IS NULL) AND c40cancel_inp_dt IS NULL " +
		" AND (c40pen_type like 'A%' OR c40pen_type='Z0')");
		storeOrder("c40hkic, c40pen_type");
	}
	
	/**
	 * Load list for batch job Generate the Initial Medical Acknowledgement
	 * @param String startHkic
	 * @param String endHkic
	 * @param String lastHkic
	 * @param String lastPenType
	 * @param BigDecimal lastPenInputNum
	 * @param int batchSize
	 * @param Connection conn
	 * @param User user
	 * @return List list
	 * @throws DBObjectException, DBSecurityException
	 */
	public static List loadListForGenMedAck(String startHkic, String endHkic, String lastHkic, String lastPenType, BigDecimal lastPenInputNum, int batchSize, Connection conn, User user) throws DBSecurityException, DBObjectException {
		PenDtl penDtl = new PenDtl();
		
		SqlRunner sqlRunner = new SqlRunner(PenDtl.class, penDtl.getFieldNames());
		sqlRunner.append(" SELECT " + StringUtil.joinWithComma(penDtl.getDBColumnNames()));
		sqlRunner.append(" FROM <SCHEMA>."+penDtl.getDBTableName());
		sqlRunner.append(" WHERE c40hkic BETWEEN " + StringUtil.addQuote(startHkic) + " AND " + StringUtil.addQuote(endHkic));
		sqlRunner.append(" AND c40sign_dt is not null");
		sqlRunner.append(" AND c40cancel_inp_dt is null");
		
		if (!StringUtil.isEmpty(lastHkic) && !StringUtil.isEmpty(lastPenType) && lastPenInputNum != null) {
			sqlRunner.append(" AND ");
			sqlRunner.append(" (c40hkic > " + StringUtil.addQuote(lastHkic) + " or (c40hkic = " + StringUtil.addQuote(lastHkic) + " and ");
			sqlRunner.append(" (c40pen_type > " + StringUtil.addQuote(lastPenType) + " or (c40pen_type = " + StringUtil.addQuote(lastPenType) + " and ");
			sqlRunner.append(" (c40pen_input_num > " + StringUtil.addQuote(lastPenInputNum));
			sqlRunner.append(" ))))) ");
		}
		
		sqlRunner.append(" ORDER BY c40hkic, c40pen_type, c40pen_input_num");
		
		if (batchSize > 0) {
			sqlRunner.append(" FETCH FIRST " + batchSize + " ROWS ONLY ");
		}
		
		sqlRunner.execute(user, conn);
		
		List list = sqlRunner.getResults();
		
		return list;
	}
	
	/**
	 * Load list for batch job Generate the Initial Medical Acknowledgement for Sign
	 * @param Date startSdt
	 * @param Date endSdt
	 * @param Date startProcDt
	 * @param Date endProcDt
	 * @param Connection conn
	 * @param User user
	 * @return List list
	 * @throws DBObjectException, DBSecurityException
	 */
	public static List loadListForGenMedAckForSign(Date startSdt, Date endSdt, Date startProcDt, Date endProcDt, Connection conn, User user) throws DBSecurityException, DBObjectException {
		PenDtl penDtl = new PenDtl();
		
		SqlRunner sqlRunner = new SqlRunner(PenDtl.class, penDtl.getFieldNames());
		sqlRunner.append(" SELECT " + StringUtil.joinWithComma(penDtl.getDBColumnNames()));
		sqlRunner.append(" FROM <SCHEMA>."+penDtl.getDBTableName());
		sqlRunner.append(" WHERE (");
		sqlRunner.append(" c40sdt BETWEEN ? AND ?");
		sqlRunner.append(" AND c40pen_type like 'A%'");
		sqlRunner.append(" AND c40sign_dt is not null");
		sqlRunner.append(" AND c40cancel_inp_dt is null");
		sqlRunner.append(" ) OR (");
		sqlRunner.append(" c40sdt < ?");
		sqlRunner.append(" AND c40pen_type like 'A%'");
		sqlRunner.append(" AND c40sign_dt BETWEEN ? AND ?");
		sqlRunner.append(" AND c40cancel_inp_dt is null");
		sqlRunner.append(" )");
		sqlRunner.append(" ORDER BY c40hkic, c40pen_type, c40pen_input_num");
		
		sqlRunner.addParam(startSdt, Types.DATE).addParam(endSdt, Types.DATE);
		sqlRunner.addParam(endSdt, Types.DATE).addParam(startProcDt, Types.DATE).addParam(endProcDt, Types.DATE);
		
		sqlRunner.execute(user, conn);
		
		List list = sqlRunner.getResults();
		
		return list;
	}
	
	/**
	 * Load list for batch job Generate Deferred Pension Letter
	 * @param Date runDt
	 * @param Connection conn
	 * @param User user
	 * @return List list
	 * @throws DBObjectException, DBSecurityException
	 */
	public static List loadListForGenDeferPenLetter (Date startDt, Date endDt, Connection conn, User user) throws DBSecurityException, DBObjectException {
		PenDtl penDtl = new PenDtl();
		PenPaper penPaper = new PenPaper();
		
		SqlRunner sqlRunner = new SqlRunner(PenDtl.class, penDtl.getFieldNames())
		.append(" SELECT " + StringUtil.joinWithComma(penDtl.getDBColumnNames()))
		.append(" FROM <SCHEMA>."+penDtl.getDBTableName() + ", <SCHEMA>."+ penPaper.getDBTableName() )
		.append(" WHERE c40hkic=c60hkic AND c40pen_type = c60pen_type")
		.append(" AND c60pen_type in ('A3','A4','A5','A6','A8')")
		.append(" AND c60confirm_del_dt is NULL")
		.append(" AND c40termin_code in ('01', '04')")
		.append(" AND c40confirm_inp_dt IS NOT NULL")
		.append(" AND c40cancel_inp_dt IS NULL")
		.append(" AND c40sdt between ? AND ? ")
		.append(" ORDER BY c40hkic, c40pen_type, c40pen_input_num");
		
		sqlRunner.addParam(startDt, Types.DATE);
		sqlRunner.addParam(endDt, Types.DATE);
		
		sqlRunner.execute(user, conn);
		
		List list = sqlRunner.getResults();
		
		return list;
	}
	/**
	 * Load list for Tax Payer
	 * @param String HKIC
	 * @param Connection conn
	 * @param User user
	 * @return int 
	 * @throws DBObjectException, DBSecurityException
	 */
	public static int LoadForTaxPayer (String hkic, Connection conn, User user) throws DBSecurityException, DBObjectException {
		PenDtl penDtl = new PenDtl();
		PenProfile penProfile = new PenProfile();
		SqlRunner sqlRunner = new SqlRunner(); 
		sqlRunner.append("SELECT COUNT(1) FROM <SCHEMA>." + penDtl.getDBTableName() + ",<SCHEMA>."+ penProfile.getDBTableName()+
								" WHERE cg0payee_id = c40payee_id and cg0hkic = ? " );
			sqlRunner.addParam(hkic);			 	
			sqlRunner.execute(user, conn);	
			return sqlRunner.getResult();
	}
	
	//YS20170517 start
	/**
	 * Load list for batch job GenPrelimSampleList
	 * @param String hkic
	 * @param String penType
	 * @param Connection conn
	 * @param User user
	 * @return List list
	 * @throws DBObjectException, DBSecurityException
	 */
	public static List loadListForGenPrelimSampleList(String hkic, String penType, Connection conn, User user) throws DBSecurityException, DBObjectException {
		String[] fields = {"Hkic", "PenType", "PenPymtMethod", "PymtFreq", "BarCode", "CurrPiAmt"};
		SqlRunner sqlRunner = new SqlRunner(PenPymtDtl.class, fields);
		
		sqlRunner.append("SELECT c40hkic, c40pen_type, c41pen_pymt_method, c41pymt_freq, c41bar_code, c41curr_pi_amt"
					+ " FROM <SCHEMA>." + new PenDtl().getDBTableName()
					+ ", <SCHEMA>."+ new PenPymtDtl().getDBTableName()
					+ " WHERE c40hkic = c41hkic"
					+ " AND c40pen_type = c41pen_type" 
					+ " AND c40hkic = ?"
					+ " AND c40pen_type = ?"
					+ " AND c40confirm_inp_dt IS NOT NULL" 
					+ " AND c40cancel_inp_dt IS NULL" 
					+ " AND c40edt IS NULL");
		sqlRunner.addParam(hkic);
		sqlRunner.addParam(penType);
		sqlRunner.execute(user, conn);
		
		return sqlRunner.getResults();
	}

	/**
	 * Load distinct matched hkic list for PNPP10 by masked HKIC
	 * @param String maskedhkic
	 * @param String lastDeptCode
	 * @param Connection conn
	 * @param User user
	 * @return List list
	 * @throws DBObjectException, DBSecurityException
	 */
	public static List loadListByMaskedHkic(String maskedHkic, String lastDeptCode, Connection conn, User user) throws DBObjectException, DBSecurityException {

		// Replace the "***" to "%" and pad to nine digits
		maskedHkic = StringUtil.padL(maskedHkic, 9, ' ');
		maskedHkic = maskedHkic.replace("***", "%");

		String[] fields = { "Hkic", "LastDeptCode" };
		String[] columnNames = { "c40hkic", "c40last_dept_code" };

		SqlRunner sqlRunner = new SqlRunner(PenDtl.class, fields);
		sqlRunner.append("SELECT DISTINCT ").append(columnNames[0]);
		for (int i = 1; i < columnNames.length; i++) {
			sqlRunner.append(", ").append(columnNames[i]);
		}
		sqlRunner.append(" FROM <SCHEMA>.").append(new PenDtl().getDBTableName());
		sqlRunner.append(" WHERE c40hkic LIKE '").append(maskedHkic).append("'");
		if (!StringUtil.isEmpty(lastDeptCode)) {
			sqlRunner.append(" AND c40last_dept_code = '").append(lastDeptCode).append("'");
		}

		sqlRunner.append(" ORDER BY c40hkic");
		
		sqlRunner.execute(user, conn);

		return sqlRunner.getResults();
	}
	
	public static boolean isDesignatedPensioner(String hkic, String penType, List<String> exclPayeeIds, Connection conn, User user){
		/**
		 * This function is to determine whether Statement/Email will be printed/mailed (PN06, TRY443).
		 * Return true if Pensioner are in the Statement Exclusion List
		 */
		boolean isDesginated = false;
		try {
			if(exclPayeeIds == null || exclPayeeIds.size() <= 0){
				return isDesginated;
			}
			PenDtl penDtl = PenDtl.load(hkic, penType, conn, user);
			return penDtl!=null && StringUtil.existIn(penDtl.getPayeeId(), exclPayeeIds);
		} catch (DBObjectException | DBSecurityException e) {
			return isDesginated;
		}
	}
	
	/**
	 * @return the penPymtMethod
	 */
	public String getPenPymtMethod() {
		return penPymtMethod;
	}

	/**
	 * @param penPymtMethod the penPymtMethod to set
	 */
	public void setPenPymtMethod(String penPymtMethod) {
		penPymtMethod = penPymtMethod;
	}

	/**
	 * @return the pymtFreq
	 */
	public String getPymtFreq() {
		return pymtFreq;
	}

	/**
	 * @param pymtFreq the pymtFreq to set
	 */
	public void setPymtFreq(String pymtFreq) {
		pymtFreq = pymtFreq;
	}

	/**
	 * @return the barCode
	 */
	public String getBarCode() {
		return barCode;
	}

	/**
	 * @param barCode the barCode to set
	 */
	public void setBarCode(String barCode) {
		this.barCode = barCode;
	}
	//YS20170517 end
	
	public String getApptEdtPlus1DayInYrMthFormat(){
		//For Report Sorting
		return DateUtil.date2Str(DateUtil.addDate(this.apptEdt, 0, 1), "yyyy/MM");
	}
	
	public String getPenDtInYrMthFormat(){
		//For Report Sorting (i.e. PEN325-11, PEN325-12, PEN325-13, PEN325-14)
		return DateUtil.date2Str(this.penDt, "yyyy/MM");
	}
	
	public static List loadListForIvrs(Connection conn, User user) 
	throws DBSecurityException, DBObjectException {
		
		PenDtl penDtl = new PenDtl();
		SqlRunner sqlRunner = new SqlRunner();
		
		sqlRunner.append("c40confirm_inp_dt is not null AND c40cancel_inp_dt is null");
		sqlRunner.append(" ORDER BY c40hkic, c40pen_type");
		penDtl.storeCriteria(sqlRunner);
		
		return penDtl.loadList(conn, user);
	}
	
}