package treasury.pension.batch;

import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import treasury.payroll.batchcommon.BatchException;
import treasury.payroll.batchcommon.BatchInitException;
import treasury.payroll.batchcommon.Journal;
import treasury.payroll.batchcommon.WriteJournalException;
import treasury.payroll.common.DBObjectException;
import treasury.payroll.common.DBSecurityException;
import treasury.payroll.common.User;
import treasury.payroll.common.ValidationException;
import treasury.payroll.util.BatchJobUtil;
import treasury.payroll.util.DateUtil;
import treasury.payroll.util.ReportGeneratorException;
import treasury.pension.batchcommon.PensCommonBatchJob;
import treasury.pension.report.PEN420_02;


/*
 * 
 */
public class GenPen420_01 extends PensCommonBatchJob{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public final String BATCH_NAME = "GenPen420_01";
	public final static int BATCH_INIT_STATUS = -9999;
//	private final static int NO_OF_ARGUMENTS = 4;

	//Input Parameters
	private Date runDt;
	private String uploadStartDt, uploadEndDt;
	private String runMode;
	
	private final static String DATE_FORMAT2 = "dd/MM/yyyy";
	
	public Date getRunDt() {
		return runDt;
	}

	public void setRunDt(Date runDt) {
		this.runDt = runDt;
	}
	
	public String getUploadStartDt() {
		return uploadStartDt;
	}

	public void setUploadStartDt(String uploadStartDt) {
		this.uploadStartDt = uploadStartDt;
	}

	public String getUploadEndDt() {
		return uploadEndDt;
	}

	public void setUploadEndDt(String uploadEndDt) {
		this.uploadEndDt = uploadEndDt;
	}
	
	public String getRunMode() {
		return runMode;
	}

	public void setRunMode(String runMode) {
		this.runMode = runMode;
	}

	/*
	 * Case 2 : "C:\rationalsdp_george\workspace\pensdev_rad\WebContent\conf\pensdev_rad.conf" 100 199 20/10/2021 12/2021- Monthly mode (For MM/YYYY)
	 * Case 3 : "C:\rationalsdp_george\workspace\pensdev_rad\WebContent\conf\pensdev_rad.conf" 100 199 20/10/2021 03/12/2021 - Adhoc mode for 1 day (on dd/MM/yyyy)
	 * Case 4 : "C:\rationalsdp_george\workspace\pensdev_rad\WebContent\conf\pensdev_rad.conf" 100 199 20/10/2021 03/12/2021 13/12/2021 - Adhoc mode for day range (from dd/mm/yyyy to dd/mm/yyyy)
	 */ 
	public static void main(String[] args){
		GenPen420_01 job = new GenPen420_01();
		try{
			if(!job.prepare(args)){
				throw new ValidationException("Validation Exception");
			}
			
			// include date in jobname if needed	
			job.setJobName(job.BATCH_NAME);

			// init batch job
			job.initPens();

			// run
			job.run();
			
		}catch (ValidationException e) {
			showUsage();
			Journal.outJournal(Journal.ERROR, e.getStackString());
		} catch (BatchInitException e) {
			Journal.outJournal(DEFAULT_ERROR, e.getStackString());
		} catch (BatchException e) {
			Journal.outJournal(DEFAULT_ERROR, e.getStackString());
		} catch (Exception e) {
			Journal.outJournal(DEFAULT_ERROR, e.getMessage());
		} finally{
			System.exit(job.getJobStatus());
		}
	}
	
	public static void showUsage(){
		//Monthly mode
		Journal.outJournal(Journal.ERROR,
				"Monthly mode Usage: [config_file] [start step] [end step] [run date] [report target month] ");
		Journal.outJournal(Journal.ERROR,
				"Process PEN420_01 Report \n "
				+ "Parameter rules: Start step (10) End step (20) run date (dd/mm/yyyy) report target month (mm/yyyy)") ;
		Journal.outJournal(Journal.ERROR,
				"e.g.: java PensUpdatePenProfile /tmp/pens.conf 10 20 03/05/2019 05/2019");
		//Adhoc mode - report on the specify date
		Journal.outJournal(Journal.ERROR,
				"Adhoc mode (report on the specify date) Usage: [config_file] [start step] [end step] [run date] [report target date]");
		Journal.outJournal(Journal.ERROR,
				"Process PEN420_01 Report \n " +
				"Parameter rules: Start step (10) End step (20) run date (dd/mm/yyyy) report target date (dd/mm/yyyy) ") ;
		Journal.outJournal(Journal.ERROR,
				"e.g.: java PensUpdatePenProfile /tmp/pens.conf 10 20 03/05/2019 02/05/2019");
		//Adhoc mode - report on the specify date range
		Journal.outJournal(Journal.ERROR,
				"Usage: [config_file] [start step] [end step] [run date] [report target date start] [report target date end] ");
		Journal.outJournal(Journal.ERROR,
				"Process PEN420_01 Report \n " +
				"Parameter rules: Start step (10) End step (20) run date (dd/mm/yyyy) report target date start (dd/mm/yyyy) report target date end (dd/mm/yyyy) ") ;
		Journal.outJournal(Journal.ERROR,
				"e.g.: java PensUpdatePenProfile /tmp/pens.conf 10 20 03/05/2019 01/05/2019 15/05/2019 ");

	}

	@Override
	public void pensBatchMain() throws BatchException, WriteJournalException {
		try{
			
			setJobStatus(BATCH_INIT_STATUS);
			
			User user = getUser();
			Connection pensConn = getConnForPens();
//			Connection paysConn = BatchUtil.getConn(this, DBObject.DB_PAYS);
//			Connection cprdConn = BatchUtil.getConn(this, DBObject.DB_CPRD);
			
			if(BatchJobUtil.writeStartJobStep(this, 10, getSjs(), getEjs())){
				runStep10(pensConn, user);
				BatchJobUtil.writeEndJobStep(this, 10, getSjs());
			}
			
			if(getJobStatus() == BATCH_INIT_STATUS){
				setJobStatus(JOB_STT_OK);
			}
			
		}catch(Exception e) {
			setJobStatus(JOB_STT_ERROR);
			writeJournal(Journal.ERROR, "[" + e.getClass().getSimpleName() + "]" + e.getMessage());
		}
	}

	@Override
	public void pensPrintActionParam() throws BatchException, WriteJournalException {
		writeJournal(Journal.INFO, "      Run Date        	   : " + DateUtil.date2Str(this.runDt));
	}
	
	private boolean prepare(String[] args){
		boolean pass = true;

		if (!(args.length>4&&args.length<7)) {
			return false;
		}

		pass = pensPrepareCommonParam(args);

		if (!DateUtil.validate(args[3])) {
			Journal.outJournal(Journal.ERROR, "Invalid Run Date: " + args[3]);
			pass = false;
		}
		
		if (args.length==5&&pass) {
			String str = args[4];
			//Monthly mode
			if(str.length()==7) {
				if(!"/".equals(str.substring(2, 3))) {
					Journal.outJournal(Journal.ERROR, "Invalid format in month mode input.");
					pass = false;
				}
				try {
					setRunDt(DateUtil.parse(args[3]));
					int month = Integer.parseInt(str.substring(0, 2));
					if(!(month>0&&month<13)) {
						Journal.outJournal(Journal.ERROR, "Invalid format in month mode input.");
						pass = false;
					}else {
						int year = Integer.parseInt(str.substring(3, 7));
						setUploadStartDt(getMonthStartDt(month,year));
						setUploadEndDt(getMonthEndDt(month,year));
						setRunMode("M");
					}
				}catch(Exception e) {
					Journal.outJournal(Journal.ERROR, "Invalid format in month mode input.");
					pass = false;
				}				
			}
			//Adhoc mode only one date input
			if(str.length()==10) {
				try {
					setRunDt(DateUtil.parse(args[3]));
					if (!DateUtil.validate(args[4])) {
						Journal.outJournal(Journal.ERROR, "Invalid Date format : " + args[4]);
						pass = false;
					}else {
						setRunDt(DateUtil.parse(args[3]));
						setUploadStartDt(args[4]);
						setUploadEndDt(args[4]);
						setRunMode("A");
					}
				}catch(Exception e) {
					Journal.outJournal(Journal.ERROR, "Invalid format in Adhoc mode input.");
					pass = false;
				}				
			}	
		}
		//Adhoc mode
		if (args.length==6&&pass) {
			if (!DateUtil.validate(args[4])) {
				Journal.outJournal(Journal.ERROR, "Invalid Date format : " + args[4]);
				pass = false;
			}
			if (!DateUtil.validate(args[5])) {
				Journal.outJournal(Journal.ERROR, "Invalid Date format : " + args[5]);
				pass = false;
			}
			if(pass) {
				setRunDt(DateUtil.parse(args[3]));
				setUploadStartDt(args[4]);
				setUploadEndDt(args[5]);
				setRunMode("A");
			}
		}

		return pass;

		
	};
	
	private String getMonthStartDt(int mm,int yyyy) {
        int dd =  15;
        mm--;

        Calendar cale = Calendar.getInstance();
//        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT2);
        cale = Calendar.getInstance();
        cale.set(yyyy, mm, dd);
        cale.add(Calendar.MONTH, 0);
        cale.set(Calendar.DAY_OF_MONTH, 1);
        return format.format(cale.getTime());
	}
	
	private String getMonthEndDt(int mm,int yyyy) {
        int dd =  15;
        mm--;

        Calendar cale = Calendar.getInstance();
        SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT2);
        cale = Calendar.getInstance();
        cale.set(yyyy, mm, dd);
        cale.add(Calendar.MONTH, 1);
        cale.set(Calendar.DAY_OF_MONTH, 0);
        return format.format(cale.getTime());
	}

	

	private void runStep10(Connection pensConn, User user) throws WriteJournalException, SQLException, BatchException{
		try{
			if("A".equals(runMode)) {
				if(uploadStartDt.equals(uploadEndDt)) {
					genRpt("ON "+uploadStartDt, pensConn, user);
				}else {
					genRpt("FROM "+uploadStartDt +" TO "+uploadEndDt , pensConn, user);	
				}
			}else if("M".equals(runMode)) {
				genRpt("FOR " + uploadStartDt.substring(3,10), pensConn, user);
			}
			
		} 
		catch (Exception e) { 
			pensConn.rollback();
			writeJournal(Journal.INFO, ">>>> Job : runStep10()");
			writeJournal(Journal.INFO, ">>>> Job Message : " + e.getMessage());
		}
	}
	
	private void genRpt(String rptTitleYear,Connection pensConn, User user) throws  DBObjectException, DBSecurityException, ReportGeneratorException, SQLException, ParseException, WriteJournalException{
		PEN420_02.writeReport(0, uploadStartDt, uploadEndDt,rptTitleYear, runDt,"M".equals(getRunMode())?true:false, this, pensConn, user);
	}
	
	

}
