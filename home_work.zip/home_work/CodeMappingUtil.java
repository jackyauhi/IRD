package treasury.pension.util;

public class CodeMappingUtil {
	
	
	public static String conutryCodetoPostalCode(String conutryCode) {
		String postalCode = "";
		switch(conutryCode)
	      {
	         case "420" ://"Hong Kong"
	        	postalCode = "00";
	            break;
	         case "001" :/*CAYMAN ISLANDS*/ case "110" :/*ALBANIA*/		case "115" :/*ALGERIA*/ case "120" :/*ANDORRA*/
	         case "125" :/*ANGOLA*/  case "127" :/*ANGUILLA*/  			case "130" :/*ANTIGUA AND BARBUDA*/	
	         case "135" :/*ARGENTINA*/ case "137" :/*ARUBA*/			case "138" :/*ASCENSION*/	case "140" :/*AUSTRALIA*/
	         case "145" :/*AUSTRIA*/case "148" :/*AZERBAIJAN*/			case "149" :/*AZORES*/  case "150" :/*BAHAMAS*/ 	
	         case "157" :/*BALEARIC ISLANDS*/ 							case "165" :/*BARBADOS*/ case "168" :/*BELARUS*/ case "170" :/*BELGIUM*/ 
	         case "175" :/*BELIZE*/ case "180" :/*BENIN*/ 				case "183" :/*BERMUDA*/
	         case "190" :/*BOLIVIA*/ case "193" :/*BOSNIA & HERZEGOVINA*/case "195" :/*BOTSWANA*/		case "200" :/*BRAZIL*/ 
	         case "203" :/*BR INDIAN OCEAN TERR*/ 						case "210" :/*BULGARIA*/
	         case "220" :/*BURUNDI*/ case "230" :/*CAMEROON*/			case "235" :/*CANADA*/ case "236" :/*CANARY ISLANDS*/ 
	         case "240" :/*CAPE VERDE*/ case "242" :/*CAROLINE ISLANDS*/case "245" :/*CENTRAL AFRICAN REP.*/ case "250" :/*CHAD*/  case "255" :/*CHILE*/ 
	         case "262" :/*CHRISTMAS ISLAND*/ case "264" :/*COCOS ISLANDS*/	case "265" :/*COLOMBIA*/
	         case "270" :/*COMOROS*/ case "275" :/*CONGO (REP.)*/       case "277" :/*COOK ISLANDS*/ case "278" :/*CORSICA*/ 
	         case "280" :/*COSTA RICA*/ case "283" :/*CROATIA*/         case "285" :/*CUBA*/ case "290" :/*CYPRUS*/		        
	         case "295" :/*CZECH REPUBLIC*/ case "300" :/*DENMARK*/
	         case "305" :/*DJIBOUTI*/ case "310" :/*DOMINICA*/			case "315" :/*DOMINICAN REPUBLIC*/ case "320" :/*ECUADOR*/
	         case "325" :/*EGYPT*/ case "330" :/*EL SALVADOR*/			case "335" :/*EQUATORIAL GUINEA*/ case "337" :/*ERITREA*/
	         case "338" :/*ESTONIA*/case "340" :/*ETHIOPIA*/			case "343" :/*SGSSI*/   case "344" :/*FAROE ISLANDS*/ 
	         case "345" :/*FIJI*/ case "350" :/*FINLAND*/	         	case "355" :/*FRANCE*/ case "356" :/*FRENCH GUIANA*/ case "357" :/*FRENCH POLYNESIA*/
	         case "360" :/*GABON*/	         case "365" :/*GAMBIA*/ 	case "367" :/*GAZA AND KHAN YUNIS*/ case "368" :/*GEORGIA*/
	         case "370" :/*GERMANY*/ case "380" :/*GHANA*/ 				case "383" :/*GIBRALTAR*/
	         case "385" :/*GREECE*/ case "387" :/*GREENLAND*/ 			case "390" :/*GRENADA*/	     case "392" :/*GUADELOUPE*/    	
	         case "393" :/*GUAM*/	 case "395" :/*GUATEMALA*/ 			case "400" :/*GUINEA*/
	         case "405" :/*GUINEA-BISSAU*/ case "410" :/*GUYANA*/		case "415" :/*HAITI*/ case "425" :/*HONDURAS*/
	         case "430" :/*HUNGARY*/ case "435" :/*ICELAND*/      		case "465" :/*ISRAEL*/ case "470" :/*ITALY*/
	         case "475" :/*IVORY COAST*/ case "480" :/*JAMAICA*/        case "493" :/*KAZAKHSTAN*/ case "495" :/*KENYA*/ case "500" :/*KIRIBATI*/
	         case "512" :/*KOSOVO*/ case "523" :/*LATVIA*/				case "530" :/*LESOTHO*/ case "535" :/*LIBERIA*/	        
	         case "540" :/*LIBYA*/ case "545" :/*LIECHTENSTEIN*/		case "547" :/*LITHUANIA*/
	         case "550" :/*LUXEMBOURG*/ case "555" :/*MADAGASCAR*/      case "557" :/*MADEIRA*/ case "560" :/*MALAWI*/ case "575" :/*MALI*/
	         case "580" :/*MALTA*/ case "581" :/*MARIANA ISLANDS*/		case "582" :/*MARSHALL ISLANDS*/ case "583" :/*MARTINIQUE*/
	         case "585" :/*MAURITANIA*/     case "590" :/*MAURITIUS*/ 	case "595" :/*MEXICO*/  case "597" :/*MICRONESIA*/ case "598" :/*MOLDOVA*/
	         case "600" :/*MONACO*/ case "607" :/*MONTENEGRO*/	 		case "608" :/*MONTSERRAT*/case "610" :/*MOROCCO*/	case "615" :/*MOZAMBIQUE*/ case "620" :/*NAMIBIA*/
	         case "625" :/*NAURU*/ case "632" :/*NETHERLANDS ANTILLES*/ case "635" :/*NETHERLANDS*/	case "638" :/*New Caledonia*/ case "640" :/*NEW ZEALAND*/
	         case "645" :/*NICARAGUA*/ case "650" :/*NIGER*/	       	case "655" :/*NIGERIA*/ case "658" :/*NIUE ISLAND*/ case "659" :/*NORFOLK ISLAND*/
	         case "660" :/*NORWAY*/ case "661" :/*NORTH MACEDONIA*/ 	case "672" :/*PALAU*/ case "675" :/*PANAMA*/	         	
	         case "680" :/*PAPUA NEW GUINEA*/ case "685" :/*PARAGUAY*/
	         case "690" :/*PERU*/ case "697" :/*PITCAIRN ISLANDS*/ 		case "700" :/*POLAND*/		case "705" :/*PORTUGAL*/ case "710" :/*PUERTO RICO*/
	         case "718" :/*RÉUNION*/ case "720" :/*ROMANIA*/ 			case "722" :/*RUSSIA*/ case "725" :/*RWANDA*/ case "728" :/*SAMOA*/
	         case "730" :/*ST. LUCIA*/ case "735" :/*ST. VINCENT AND THE GRENADINES*/
	         case "740" :/*SAN MARINO*/ case "745" :/*SAO TOME AND PRINCIPE*/ 
	         case "752" :/*ST KITTS AND NEVIS*/ case "753" :/*ST. HELENA*/ case "754" :/*ST PIERRE & MIQUELON*/				
	         case "755" :/*SENEGAL*/ case "757" :/*SERBIA*/ 			case "760" :/*SEYCHELLES*/
	         case "765" :/*SIERRA LEONE*/ case "772" :/*SLOVAKIA*/ 		case "773" :/*SLOVENIA*/ case "775" :/*SOLOMON ISLANDS*/ case "780" :/*SOMALIA*/
	         case "785" :/*SOUTH AFRICA*/ case "795" :/*SPAIN*/			case "797" :/*SPANISH NORTH AFRICA*/ case "798" :/*SPITSBERGEN*/ 
	         case "805" :/*SUDAN*/ case "810" :/*SURINAME*/
	         case "815" :/*ESWATINI*/      case "820" :/*SWEDEN*/		case "825" :/*SWITZERLAND*/ 		case "840" :/*TANZANIA*/
	         case "850" :/*TOGO*/ case "855" :/*TONGA*/	         		case "857" :/*BR. VIRGIN ISLANDS*/	
	         case "860" :/*TRINIDAD AND TOBAGO*/ 						case "862" :/*TRISTAN DA CUNHA*/ case "865" :/*TUNISIA*/
	         case "870" :/*TURKEY*/ case "873" :/*TURKS & CAICOS ISL*/	case "875" :/*TUVALU*/	         	
	         case "880" :/*UGANDA*/ case "892" :/*UKRAINE*/ 			case "900" :/*UNITED STATES OF AMERICA*/
	         case "905" :/*BURKINA FASO*/ 
	         case "910" :/*URUGUAY*/     	case "915" :/*VANUATU*/ 	case "920" :/*VATICAN*/
	         case "925" :/*VENEZUELA*/ case "932" :/*U.S. VIRGIN ISLANDS*/         
	         case "933" :/*WAKE ISLAND*/ case "934" :/*WALLIS & FUTUNA ISL*/ case "935" :/*SAHRAWI ARAB DEMOCRATIC REPUBLIC*/ 
	         case "955" :/*DEMOCRATIC REPUBLIC OF THE CONGO*/ 
	         case "960" :/*ZAMBIA*/ case "965" :/*ZIMBABWE*/
	        	 postalCode = "01";
	            break;
	         case "105" :/*AFGHANISTAN*/ case "136" :/*ARMENIA*/case "155" :/*BAHRAIN*/case "160" :/*BANGLADESH*/ case "185" :/*BHUTAN*/
	         case "205" :/*BRUNEI*/ case "215" :/*MYANMAR*/    	
	         case "225" :/*CAMBODIA*/ case "440" :/*BAHRAIN*/
	         case "445" :/*INDONESIA*/ case "450" :/*IRAN*/		case "455" :/*IRAQ*/
	         case "485" :/*JAPAN*/ case "490" :/*JORDAN*/		case "505" :/*NORTH KOREA*/ case "510" :/*SOUTH KOREA*/
	         case "515" :/*KUWAIT*/ case "518" :/*KYRGYZSTAN*/ case "520" :/*Lao People's Dem. Rep.*/case "525" :/*LEBANON*/ case "565" :/*MALAYSIA*/
	         case "570" :/*MALDIVES*/ case "605" :/*MONGOLIA*/  case "630" :/*NEPAL*/ case "665" :/*OMAN*/
	         case "670" :/*PAKISTAN*/ case "695" :/*PHILIPPINES*/case "715" :/*QATAR*/ case "750" :/*SAUDI ARABIA*/
	         case "770" :/*SINGAPORE*/ case "800" :/*SRI LANKA*/case "830" :/*SYRIA*/ case "835" :/*TAIWAN*/ case "837" :/*TAJIKISTAN*/
	         case "845" :/*THAILAND*/ case "847" :/*TIMOR-LESTE*/ case "872" :/*TURKMENISTAN*/ case "890" :/*UNITED ARAB EMIRATES*/
	         case "893" :/*UZBEKISTAN*/	 case "930" :/*VIETNAM*/ case "945" :/*YEMEN*/
	        	postalCode = "02";
	            break;
	         case "260" :/*CHINA*/ case "553" :/*MACAU*/
	        	 postalCode = "03";
	            break;
	         case "460" :/*IRELAND*/ case "895" :/*UNITED KINGDOM*/
	            postalCode = "05";
	            break;
	      }
		return postalCode;
	}
	
	public static String[] postalCodetoConutryCode(String postalCode) {
		String [] conutryCode = {};
		switch(postalCode)
	      {
	         case "00":
	        	 String[] firstList = { "420" };//"Hong Kong"
	        	 conutryCode = firstList;
	        	 break;
	         case "01":
	        	 String[] secondList = { 
	    			 "001" ,/*CAYMAN ISLANDS*/ "110" ,/*ALBANIA*/		 "115" ,/*ALGERIA*/ "120" ,/*ANDORRA*/
	    			 "125" ,/*ANGOLA*/   "127" ,/*ANGUILLA*/  			 "130" ,/*ANTIGUA AND BARBUDA*/	
	    			 "135" ,/*ARGENTINA*/  "137" ,/*ARUBA*/			 	 "138" ,/*ASCENSION*/	 "140" ,/*AUSTRALIA*/
	    			 "145" ,/*AUSTRIA*/ "148" ,/*AZERBAIJAN*/			 "149" ,/*AZORES*/   "150" ,/*BAHAMAS*/ 	
	    			 "157" ,/*BALEARIC ISLANDS*/ 						 "165" ,/*BARBADOS*/  "168" ,/*BELARUS*/  "170" ,/*BELGIUM*/ 
	    			 "175" ,/*BELIZE*/  "180" ,/*BENIN*/ 				 "183" ,/*BERMUDA*/
	    			 "190" ,/*BOLIVIA*/  "193" ,/*BOSNIA & HERZEGOVINA*/ "195" ,/*BOTSWANA*/		 "200" ,/*BRAZIL*/ 
	    			 "203" ,/*BR INDIAN OCEAN TERR*/ 					 "210" ,/*BULGARIA*/
	    			 "220" ,/*BURUNDI*/  "230" ,/*CAMEROON*/			 "235" ,/*CANADA*/  "236" ,/*CANARY ISLANDS*/ 
	    			 "240" ,/*CAPE VERDE*/  "242" ,/*CAROLINE ISLANDS*/  "245" ,/*CENTRAL AFRICAN REP.*/  "250" ,/*CHAD*/   "255" ,/*CHILE*/ 
	    			 "262" ,/*CHRISTMAS ISLAND*/  "264" ,/*COCOS ISLANDS*/"265" ,/*COLOMBIA*/
	    			 "270" ,/*COMOROS*/  "275" ,/*CONGO (REP.)*/         "277" ,/*COOK ISLANDS*/  "278" ,/*CORSICA*/ 
	    			 "280" ,/*COSTA RICA*/  "283" ,/*CROATIA*/           "285" ,/*CUBA*/  "290" ,/*CYPRUS*/		        
	    			 "295" ,/*CZECH REPUBLIC*/  "300" ,/*DENMARK*/
	    			 "305" ,/*DJIBOUTI*/  "310" ,/*DOMINICA*/			 "315" ,/*DOMINICAN REPUBLIC*/  "320" ,/*ECUADOR*/
	    			 "325" ,/*EGYPT*/  "330" ,/*EL SALVADOR*/			 "335" ,/*EQUATORIAL GUINEA*/  "337" ,/*ERITREA*/
	    			 "338" ,/*ESTONIA*/ "340" ,/*ETHIOPIA*/			 	 "343" ,/*SGSSI*/ "344" ,/*FAROE ISLANDS*/
	    			 "345" ,/*FIJI*/  "350" ,/*FINLAND*/	         	 "355" ,/*FRANCE*/  "356" ,/*FRENCH GUIANA*/  "357" ,/*FRENCH POLYNESIA*/
	    			 "360" ,/*GABON*/	          "365" ,/*GAMBIA*/ 	 "367" ,/*GAZA AND KHAN YUNIS*/  "368" ,/*GEORGIA*/
	    			 "370" ,/*GERMANY*/  "380" ,/*GHANA*/ 				 "383" ,/*GIBRALTAR*/
	    			 "385" ,/*GREECE*/  "387" ,/*GREENLAND*/ 			 "390" ,/*GRENADA*/	      "392" ,/*GUADELOUPE*/    	
	    			 "393" ,/*GUAM*/	  "395" ,/*GUATEMALA*/ 			 "400" ,/*GUINEA*/
	    			 "405" ,/*GUINEA-BISSAU*/  "410" ,/*GUYANA*/		 "415" ,/*HAITI*/  "425" ,/*HONDURAS*/
	    			 "430" ,/*HUNGARY*/  "435" ,/*ICELAND*/      		 "465" ,/*ISRAEL*/  "470" ,/*ITALY*/
	    			 "475" ,/*IVORY COAST*/  "480" ,/*JAMAICA*/          "493" ,/*KAZAKHSTAN*/  "495" ,/*KENYA*/  "500" ,/*KIRIBATI*/
	    			 "512" ,/*KOSOVO*/  "523" ,/*LATVIA*/				 "530" ,/*LESOTHO*/  "535" ,/*LIBERIA*/	        
	    			 "540" ,/*LIBYA*/  "545" ,/*LIECHTENSTEIN*/		     "547" ,/*LITHUANIA*/
	    			 "550" ,/*LUXEMBOURG*/  "555" ,/*MADAGASCAR*/        "557" ,/*MADEIRA*/  "560" ,/*MALAWI*/  "575" ,/*MALI*/
	    			 "580" ,/*MALTA*/  "581" ,/*MARIANA ISLANDS*/		 "582" ,/*MARSHALL ISLANDS*/  "583" ,/*MARTINIQUE*/
	    			 "585" ,/*MAURITANIA*/      "590" ,/*MAURITIUS*/ 	 "595" ,/*MEXICO*/   "597" ,/*MICRONESIA*/  "598" ,/*MOLDOVA*/
	    			 "600" ,/*MONACO*/  "607" ,/*MONTENEGRO*/	 		 "608" ,/*MONTSERRAT*/ "610" ,/*MOROCCO*/	 "615" ,/*MOZAMBIQUE*/  "620" ,/*NAMIBIA*/
	    			 "625" ,/*NAURU*/  "632" ,/*NETHERLANDS ANTILLES*/   "635" ,/*NETHERLANDS*/	 "638" ,/*New Caledonia*/  "640" ,/*NEW ZEALAND*/
	    			 "645" ,/*NICARAGUA*/  "650" ,/*NIGER*/	       	     "655" ,/*NIGERIA*/  "658" ,/*NIUE ISLAND*/  "659" ,/*NORFOLK ISLAND*/
	    			 "660" ,/*NORWAY*/  "661" ,/*NORTH MACEDONIA*/ 	 	 "672" ,/*PALAU*/  "675" ,/*PANAMA*/	         	
	    			 "680" ,/*PAPUA NEW GUINEA*/  "685" ,/*PARAGUAY*/
	    			 "690" ,/*PERU*/  "697" ,/*PITCAIRN ISLANDS*/ 		 "700" ,/*POLAND*/ "705" ,/*PORTUGAL*/  "710" ,/*PUERTO RICO*/
	    			 "718" ,/*RÉUNION*/  "720" ,/*ROMANIA*/ 			 "722" ,/*RUSSIA*/  "725" ,/*RWANDA*/  "728" ,/*SAMOA*/
	    			 "730" ,/*ST. LUCIA*/  "735" ,/*ST. VINCENT AND THE GRENADINES*/
	    			 "740" ,/*SAN MARINO*/  "745" ,/*SAO TOME AND PRINCIPE*/ 
	    			 "752" ,/*ST KITTS AND NEVIS*/  "753" ,/*ST. HELENA*/"754" ,/*ST PIERRE & MIQUELON*/				
	    			 "755" ,/*SENEGAL*/  "757" ,/*SERBIA*/ 			 "760" ,/*SEYCHELLES*/
	    			 "765" ,/*SIERRA LEONE*/  "772" ,/*SLOVAKIA*/ 		 "773" ,/*SLOVENIA*/  "775" ,/*SOLOMON ISLANDS*/  "780" ,/*SOMALIA*/
	    			 "785" ,/*SOUTH AFRICA*/  "795" ,/*SPAIN*/			 "797" ,/*SPANISH NORTH AFRICA*/  "798" ,/*SPITSBERGEN*/ 
	    			 "805" ,/*SUDAN*/  "810" ,/*SURINAME*/
	    			 "815" ,/*ESWATINI*/       "820" ,/*SWEDEN*/		 "825" ,/*SWITZERLAND*/ 		 "840" ,/*TANZANIA*/
	    			 "850" ,/*TOGO*/  "855" ,/*TONGA*/	         		 "857" ,/*BR. VIRGIN ISLANDS*/	
	    			 "860" ,/*TRINIDAD AND TOBAGO*/ 						 "862" ,/*TRISTAN DA CUNHA*/  "865" ,/*TUNISIA*/
	    			 "870" ,/*TURKEY*/  "873" ,/*TURKS & CAICOS ISL*/	 "875" ,/*TUVALU*/	         	
	    			 "880" ,/*UGANDA*/  "892" ,/*UKRAINE*/ 			 "900" ,/*UNITED STATES OF AMERICA*/
	    			 "905" ,/*BURKINA FASO*/ 
	    			 "910" ,/*URUGUAY*/     	 "915" ,/*VANUATU*/ 	 "920" ,/*VATICAN*/
	    			 "925" ,/*VENEZUELA*/  "932" ,/*U.S. VIRGIN ISLANDS*/         
	    			 "933" ,/*WAKE ISLAND*/  "934" ,/*WALLIS & FUTUNA ISL*/  "935" ,/*SAHRAWI ARAB DEMOCRATIC REPUBLIC*/ 
	    			 "955" ,/*DEMOCRATIC REPUBLIC OF THE CONGO*/ "960" ,/*ZAMBIA*/ "965" /*ZIMBABWE*/
	        	 };
	        	 conutryCode = secondList;
	        	 break;
	         case "02":
	        	 String[] thirdList = {
        			 "105" ,/*AFGHANISTAN*/  "136" ,/*ARMENIA*/ "155" ,/*BAHRAIN*/ "160" ,/*BANGLADESH*/  "185" ,/*BHUTAN*/
        			 "205" ,/*BRUNEI*/  "215" ,/*MYANMAR*/    	
        			 "225" ,/*CAMBODIA*/  "440" ,/*BAHRAIN*/
        			 "445" ,/*INDONESIA*/  "450" ,/*IRAN*/		 "455" ,/*IRAQ*/
        			 "485" ,/*JAPAN*/  "490" ,/*JORDAN*/		 "505" ,/*NORTH KOREA*/  "510" ,/*SOUTH KOREA*/
        			 "515" ,/*KUWAIT*/  "518" ,/*KYRGYZSTAN*/  "520" ,/*Lao People's Dem. Rep.*/ "525" ,/*LEBANON*/  "565" ,/*MALAYSIA*/
        			 "570" ,/*MALDIVES*/  "605" ,/*MONGOLIA*/   "630" ,/*NEPAL*/  "665" ,/*OMAN*/
        			 "670" ,/*PAKISTAN*/  "695" ,/*PHILIPPINES*/ "715" ,/*QATAR*/  "750" ,/*SAUDI ARABIA*/
        			 "770" ,/*SINGAPORE*/  "800" ,/*SRI LANKA*/ "830" ,/*SYRIA*/  "835" ,/*TAIWAN*/  "837" ,/*TAJIKISTAN*/
        			 "845" ,/*THAILAND*/  "847" ,/*TIMOR-LESTE*/  "872" ,/*TURKMENISTAN*/  "890" ,/*UNITED ARAB EMIRATES*/
        			 "893" ,/*UZBEKISTAN*/	  "930" ,/*VIETNAM*/  "945" /*YEMEN*/
	        	 };
	        	 conutryCode = thirdList;
	            break;
	         case "03":
	        	 String[] fourthList = {
	        	  "260" /*CHINA*/,  "553" /*MACAU*/
	        	 };
	        	 conutryCode = fourthList;
		         break;
	         case "05" :
	        	 String[] fifthList = {
	        	  "460" /*IRELAND*/,  "895" /*UNITED KINGDOM*/
	   	         };
	        	 conutryCode = fifthList;
	        	 break;
	      }
		return conutryCode;
	}
	

}
