/* * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* @(#) PEN321_03Obj.java		16/11/2021				**/
/*                                              		**/
/* Property of Treasury Computer Branch, HKSARG 		**/
/* All Right Reserved                           		**/
/*                                              		**/
/* SYSTEM                                       		**/
/*       Pension                                		**/
/*                                              		**/
/* AMENDMENT HISTORY                            		**/
/*  George Lam    	 	 16/11/2021 - creation  		**/
/*  									                **/
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * */
package treasury.pension.statement;

import java.sql.Connection;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.List;


import treasury.payroll.common.DBObjectException;
import treasury.payroll.common.DBSecurityException;
import treasury.payroll.common.User;
import treasury.payroll.util.SqlRunner;
import treasury.payroll.util.StringUtil;
import treasury.pension.common.AbstractPensDBObject;
import treasury.pension.pensioner.PenProfile;
import treasury.pension.report.PEN420_01Obj;

public class EformUpdPenProfileLog extends AbstractPensDBObject {
	/**
	 * constant serial version UID make sure always the same
	 */
	public static final String UID = DB_PENS+new EformUpdPenProfileLog().getDBTableName();
	public static final long serialVersionUID = UID.hashCode();
	
	@Override
	public String getDBTableName() {
		return "TDAEFORM_UPD_PEN_PROFILE_LOG";
	}
	@Override
	public String[] getDBColumnNames() {
		String[] columns =
			{
				"CDAIAMSMARTNO_REFNO",
				"CDAIAMSMART_EMAIL_ADDR",
				"CDAENG_NAME",
				"CDACHI_NAME",
				"CDAFORM_SUBMIT_DT",
				"CDAFORM_SUBMIT_TIME",
				"CDAHKIC",
				"CDAPEN_TYPE",
				"CDAADDR1_BEFORE",
				"CDAADDR2_BEFORE",
				"CDAADDR3_BEFORE",
				"CDAADDR1_CHIN_BEFORE",
				"CDAADDR2_CHIN_BEFORE",
				"CDAADDR3_CHIN_BEFORE",
				"CDACOUNTRY_CODE_BEFORE",		
				"CDAPOSTAL_ZONE_BEFORE",		
				"CDASAME_RESADDR_CORADDR_BEFORE",
				"CDACORR_ADDR1_BEFORE",			
				"CDACORR_ADDR2_BEFORE",			
				"CDACORR_ADDR3_BEFORE",			
				"CDACORR_ADDR1_CHIN_BEFORE",				
				"CDACORR_ADDR2_CHIN_BEFORE",				
				"CDACORR_ADDR3_CHIN_BEFORE",				
				"CDACORR_COUNTRY_CODE_BEFORE",
				"CDACORR_POSTAL_ZONE_BEFORE",
				"CDATEL_NUM_1_BEFORE",			
				"CDATEL_NUM_2_BEFORE",			
				"CDAFAX_NUM_BEFORE",			
				"CDAEMAIL_ADDR_BEFORE",
				"CDAADDR1",					
				"CDAADDR2",				
				"CDAADDR3",					
				"CDACOUNTRY_CODE",					
				"CDASAME_RESADDR_CORADDR",
				"CDACORR_ADDR1",			
				"CDACORR_ADDR2",			
				"CDACORR_ADDR3",			
				"CDACORR_COUNTRY_CODE",
				"CDATEL_NUM_1",			
				"CDATEL_NUM_2",			
				"CDAFAX_NUM",
				"CDAEMAIL_ADDR",
				"CDA_PROC_TIME"
			};
		return columns;
	}
	@Override
	public String[] getFieldNames() {
		String[] fields =
			{
				"IamSmartNoRefNo",
				"IamSmartEmailAddr",
				"EngName",
				"ChiName",
				"FormSubmitDt",
				"FormSubmitTime",
				"Hkic",
				"PenType",
				"Addr1Before",
				"Addr2Before",
				"Addr3Before",
				"Addr1ChinBefore",
				"Addr2ChinBefore",
				"Addr3ChinBefore",
				"CountryCodeBefore",		
				"PostalZoneBefore",		
				"SameResaddrCoraddrBefore",
				"CorrAddr1Before",			
				"CorrAddr2Before",			
				"CorrAddr3Before",			
				"CorrAddr1ChinBefore",				
				"CorrAddr2ChinBefore",				
				"CorrAddr3ChinBefore",				
				"CorrCountryCodeBefore",
				"CorrPostalZoneBefore",
				"TelNum1Before",			
				"TelNum2Before",			
				"FaxNumBefore",			
				"EmailAddrBefore",
				"Addr1",					
				"Addr2",				
				"Addr3",					
				"CountryCode",					
				"SameResaddrCoraddr",
				"CorrAddr1",			
				"CorrAddr2",			
				"CorrAddr3",			
				"CorrCountryCode",
				"TelNum1",			
				"TelNum2",			
				"FaxNum",
				"EmailAddr",
				"ProcTime"
			};
		return fields;
	}
	@Override
	public String[] getPKey() {
		String[] pkey = { "IamSmartRefNo" };
		return pkey;
	}
	
	/* Database Fields */
	private String iamSmartNoRefNo;
	private String iamSmartEmailAddr;
	private String engName;
	private String chiName;
	private Date formSubmitDt;
	private String formSubmitTime;
	private String hkic;
	private String penType;
	private String addr1Before;
	private String addr2Before;
	private String addr3Before;
	private String addr1ChinBefore;
	private String addr2ChinBefore;
	private String addr3ChinBefore;
	private String countryCodeBefore;		
	private String postalZoneBefore;		
	private String sameResaddrCoraddrBefore;
	private String corrAddr1Before;			
	private String corrAddr2Before;			
	private String corrAddr3Before;			
	private String corrAddr1ChinBefore;				
	private String corrAddr2ChinBefore;				
	private String corrAddr3ChinBefore;				
	private String corrCountryCodeBefore;
	private String corrPostalZoneBefore;
	private String telNum1Before;			
	private String telNum2Before;			
	private String faxNumBefore;			
	private String emailAddrBefore;
	private String addr1;					
	private String addr2;				
	private String addr3;					
	private String countryCode;					
	private String sameResaddrCoraddr;
	private String corrAddr1;			
	private String corrAddr2;			
	private String corrAddr3;			
	private String corrCountryCode;
	private String telNum1;			
	private String telNum2;			
	private String faxNum;
	private String emailAddr;
	private Timestamp procTime;
	
	public EformUpdPenProfileLog() {
		
	}
	public EformUpdPenProfileLog(PenProfile oldImage, PEN420_01Obj json,Timestamp ts) throws ParseException {
		this.iamSmartNoRefNo = json.getIamSmartRefNo();
		this.iamSmartEmailAddr = json.getIamSmartEmail();
		this.engName = json.getEngName();
		this.chiName = json.getChiName();
		this.formSubmitDt = Date.valueOf(json.getSubmissionDate());  
		this.formSubmitTime = json.getSubmissionTime();
		this.hkic = json.getHkic();
		this.penType = json.getPenType();
		this.addr1Before = oldImage.getAddr1();
		this.addr2Before = oldImage.getAddr2();
		this.addr3Before = oldImage.getAddr3();
		this.addr1ChinBefore = oldImage.getAddr1Chin();
		this.addr2ChinBefore = oldImage.getAddr2Chin();
		this.addr3ChinBefore = oldImage.getAddr3Chin();
		this.countryCodeBefore = oldImage.getCountryCode();
		if((oldImage.getAddr1Chin()!=null&&oldImage.getCorrAddr1Chin()!=null&&oldImage.getAddr1Chin().equals(oldImage.getCorrAddr1Chin()))
				||(oldImage.getAddr1()!=null&&oldImage.getCorrAddr1()!=null&&oldImage.getAddr1().equals(oldImage.getCorrAddr1()))) {
			this.sameResaddrCoraddrBefore = "Y";
		}else {
			this.sameResaddrCoraddrBefore = "N";
		}
		this.postalZoneBefore = oldImage.getPostalZone();
		this.corrAddr1Before = oldImage.getCorrAddr1();
		this.corrAddr2Before = oldImage.getCorrAddr2();
		this.corrAddr3Before = oldImage.getCorrAddr3();
		this.corrAddr1ChinBefore = oldImage.getCorrAddr1Chin();
		this.corrAddr2ChinBefore = oldImage.getCorrAddr2Chin();
		this.corrAddr3ChinBefore = oldImage.getCorrAddr3Chin();
		this.corrCountryCodeBefore = oldImage.getCorrCountryCode();
		this.corrPostalZoneBefore = oldImage.getCorrPostalZone();		
		this.telNum1Before = oldImage.getTelNum1();
		this.telNum2Before = oldImage.getTelNum2();
		this.faxNumBefore = oldImage.getFaxNum();
		this.emailAddrBefore = oldImage.getEmailAddr();
		this.addr1 = json.getResAddress1();
		this.addr2 = json.getResAddress2();
		this.addr3 = json.getResAddress3();
		this.countryCode = json.getResCountryCode();
		this.sameResaddrCoraddr = json.getSameAsRes();
		this.corrAddr1 = "y".equals(this.sameResaddrCoraddr)?json.getResAddress1():json.getCorAddress1();
		this.corrAddr2 = "y".equals(this.sameResaddrCoraddr)?json.getResAddress2():json.getCorAddress2();
		this.corrAddr3 = "y".equals(this.sameResaddrCoraddr)?json.getResAddress3():json.getCorAddress3();
		this.corrCountryCode = "y".equals(this.sameResaddrCoraddr)?json.getResCountryCode():json.getCorCountryCode();
		this.telNum1 = json.getPhoneNo1();
		this.telNum2 = json.getPhoneNo2();
		this.faxNum = json.getFaxNo();
		this.emailAddr= json.getEmailAddress();
		this.procTime = ts;

//		Logic that show existing data in DB record
//		this.addr1 = json.getResAddress1()!=null?json.getResAddress1():!StringUtil.isEmpty(oldImage.getAddr1())?oldImage.getAddr1():!StringUtil.isEmpty(oldImage.getAddr1Chin())?oldImage.getAddr1Chin():null;
//		this.addr2 = json.getResAddress2()!=null?json.getResAddress2():!StringUtil.isEmpty(oldImage.getAddr2())?oldImage.getAddr2():!StringUtil.isEmpty(oldImage.getAddr2Chin())?oldImage.getAddr2Chin():null;
//		this.addr3 = json.getResAddress3()!=null?json.getResAddress3():!StringUtil.isEmpty(oldImage.getAddr3())?oldImage.getAddr3():!StringUtil.isEmpty(oldImage.getAddr3Chin())?oldImage.getAddr3Chin():null;
//		this.countryCode = json.getResCountryCode()!=null?json.getResCountryCode():oldImage.getCountryCode();
//		if(json.getSameAsRes()!=null) {
//			this.sameResaddrCoraddr = json.getSameAsRes();
//			this.corrCountryCode = json.getResCountryCode();
//			if("y".equals(json.getSameAsRes())) {
//				this.corrAddr1 = json.getResAddress1();
//				this.corrAddr2 = json.getResAddress2();
//				this.corrAddr3 = json.getResAddress3();	
//			}else {
//				this.corrAddr1 = json.getCorAddress1();
//				this.corrAddr2 = json.getCorAddress2();
//				this.corrAddr3 = json.getCorAddress3();
//			}
//		}else {
//			this.corrAddr1 = !StringUtil.isEmpty(oldImage.getCorrAddr1())?oldImage.getCorrAddr1():!StringUtil.isEmpty(oldImage.getCorrAddr1Chin())?oldImage.getCorrAddr1Chin():null;
//			this.corrAddr2 = !StringUtil.isEmpty(oldImage.getCorrAddr2())?oldImage.getCorrAddr2():!StringUtil.isEmpty(oldImage.getCorrAddr2Chin())?oldImage.getCorrAddr2Chin():null;
//			this.corrAddr3 = !StringUtil.isEmpty(oldImage.getCorrAddr3())?oldImage.getCorrAddr3():!StringUtil.isEmpty(oldImage.getCorrAddr3Chin())?oldImage.getCorrAddr3Chin():null;
//			this.corrCountryCode = !StringUtil.isEmpty(oldImage.getCountryCode())?oldImage.getCountryCode():null;
//		}
//		this.sameResaddrCoraddr = this.sameResaddrCoraddr != null ?this.sameResaddrCoraddr:StringUtil.equals(this.addr1, this.corrAddr1)?"y":"n";
//		this.telNum1 = json.getPhoneNo1()!=null?json.getPhoneNo1():oldImage.getTelNum1();
//		this.telNum2 = json.getPhoneNo2()!=null?json.getPhoneNo2():oldImage.getTelNum2();
//		this.faxNum = json.getFaxNo()!=null?json.getFaxNo():oldImage.getFaxNum();
//		this.emailAddr= json.getEmailAddress()!=null?json.getEmailAddress():oldImage.getEmailAddr();
				
	}
	
	public int insert(Connection conn, User user) throws DBObjectException, DBSecurityException {
		SqlRunner sqlRunner = new SqlRunner();
		sqlRunner.append("INSERT INTO <SCHEMA>." + this.getDBTableName() + 
						"(CDAIAMSMARTNO_REFNO, CDAIAMSMART_EMAIL_ADDR," +
						"CDAENG_NAME,CDACHI_NAME,CDAFORM_SUBMIT_DT,CDAFORM_SUBMIT_TIME,CDAHKIC,"+
						"CDAPEN_TYPE,CDAADDR1_BEFORE,CDAADDR2_BEFORE,CDAADDR3_BEFORE,CDAADDR1_CHIN_BEFORE,CDAADDR2_CHIN_BEFORE,"+
						"CDAADDR3_CHIN_BEFORE,	CDACOUNTRY_CODE_BEFORE,	CDAPOSTAL_ZONE_BEFORE, CDASAME_RESADDR_CORADDR_BEFORE," +
						"CDACORR_ADDR1_BEFORE,	CDACORR_ADDR2_BEFORE,	CDACORR_ADDR3_BEFORE,  CDACORR_ADDR1_CHIN_BEFORE,"+				
						"CDACORR_ADDR2_CHIN_BEFORE,	CDACORR_ADDR3_CHIN_BEFORE, CDACORR_COUNTRY_CODE_BEFORE,	CDACORR_POSTAL_ZONE_BEFORE,"+
						"CDATEL_NUM_1_BEFORE, CDATEL_NUM_2_BEFORE, CDAFAX_NUM_BEFORE, CDAEMAIL_ADDR_BEFORE,	CDAADDR1, CDAADDR2,	CDAADDR3,"+					
						"CDACOUNTRY_CODE, CDASAME_RESADDR_CORADDR, CDACORR_ADDR1, CDACORR_ADDR2, CDACORR_ADDR3,	CDACORR_COUNTRY_CODE,"+
						"CDATEL_NUM_1,CDATEL_NUM_2,	CDAFAX_NUM, CDAEMAIL_ADDR, CDA_PROC_TIME"				
						+ ") VALUES (" + 
						StringUtil.addQuote(this.iamSmartNoRefNo) + ", " +
						StringUtil.addQuote(this.iamSmartEmailAddr) + ", " +
						StringUtil.addQuote(this.engName) + ", " +
						StringUtil.addQuote(this.chiName) + ", " +
						StringUtil.addQuote(this.formSubmitDt) + ", "+
						StringUtil.addQuote(this.formSubmitTime) + ", " +
						StringUtil.addQuote(this.hkic) + ", " +
						StringUtil.addQuote(this.penType) + ", " +
						StringUtil.addQuote(this.addr1Before) + ", " +
						StringUtil.addQuote(this.addr2Before) + ", " +
						StringUtil.addQuote(this.addr3Before) + ", " +
						StringUtil.addQuote(this.addr1ChinBefore) + ", " +
						StringUtil.addQuote(this.addr2ChinBefore) + ", " +
						StringUtil.addQuote(this.addr3ChinBefore) + ", " +
						StringUtil.addQuote(this.countryCodeBefore) + ", " +
						StringUtil.addQuote(this.postalZoneBefore) + ", " +
						StringUtil.addQuote(this.sameResaddrCoraddrBefore) + ", " +
						StringUtil.addQuote(this.corrAddr1Before) + ", " +
						StringUtil.addQuote(this.corrAddr2Before) + ", " +
						StringUtil.addQuote(this.corrAddr3Before) + ", " +
						StringUtil.addQuote(this.corrAddr1ChinBefore) + ", " +
						StringUtil.addQuote(this.corrAddr2ChinBefore) + ", " +
						StringUtil.addQuote(this.corrAddr3ChinBefore) + ", " +
						StringUtil.addQuote(this.corrCountryCodeBefore) + ", " +
						StringUtil.addQuote(this.corrPostalZoneBefore) + ", " +
						StringUtil.addQuote(this.telNum1Before) + ", " +
						StringUtil.addQuote(this.telNum2Before) + ", " +
						StringUtil.addQuote(this.faxNumBefore) + ", " +
						StringUtil.addQuote(this.emailAddrBefore) + ", " +	
						StringUtil.addQuote(this.addr1) + ", " +
						StringUtil.addQuote(this.addr2) + ", " +
						StringUtil.addQuote(this.addr3) + ", " +
						StringUtil.addQuote(this.countryCode) + ", " +
						StringUtil.addQuote(this.sameResaddrCoraddr) + ", " +
						StringUtil.addQuote(this.corrAddr1) + ", " +
						StringUtil.addQuote(this.corrAddr2) + ", " +
						StringUtil.addQuote(this.corrAddr3) + ", " +
						StringUtil.addQuote(this.corrCountryCode) + ", " +
						StringUtil.addQuote(this.telNum1) + ", " +
						StringUtil.addQuote(this.telNum2) + ", " +
						StringUtil.addQuote(this.faxNum) + ", " +
						StringUtil.addQuote(this.emailAddr) + ", " +
						StringUtil.addQuote(this.procTime) + ")");
		return sqlRunner.executeUpdate(user, conn);
	}
	
	
	public static List loadList( User user, Connection conn) 
			throws DBSecurityException, DBObjectException {
		if (conn == null || user == null) {
			throw new DBObjectException("Connection and User must be provided");
		}
		
		List hkic = null;
		
		SqlRunner sqlRunner = new SqlRunner(EformUpdPenProfileLog.class, new EformUpdPenProfileLog().getFieldNames());
		sqlRunner.append(new EformUpdPenProfileLog().getSELECT());
		sqlRunner.append(" FROM <SCHEMA>." + new EformUpdPenProfileLog().getDBTableName());
				
		sqlRunner.execute(user, conn);
		hkic = sqlRunner.getResults();
		
		return hkic;
	}
	
	public static List loadList(boolean isPostalZone09,Date uploadStartDt, Date uploadEndDt, Connection conn, User user) 
			throws DBObjectException, DBSecurityException{
		if ((conn == null) || (user == null)) {
			throw new DBObjectException("Null parameter in calling loadList [ conn = " + conn + ", user = " + user + "]");
		}
		
		EformUpdPenProfileLog eformUpdPenProfileLog = new EformUpdPenProfileLog();
		eformUpdPenProfileLog.defineCriteria(isPostalZone09, uploadStartDt, uploadEndDt);
		return eformUpdPenProfileLog.loadList(conn, user);
		
	}
	
	public void defineCriteria(boolean isPostalZone09,Date uploadStartDt, Date uploadEndDt) {
		String sql = " ";

		if (uploadStartDt!=null&&uploadEndDt!=null) {
			sql += " AND (CDAFORM_SUBMIT_DT BETWEEN " + StringUtil.addQuote(uploadStartDt) + " AND "+ StringUtil.addQuote(uploadEndDt)+")"; 
		}
		if (isPostalZone09) {
			sql += " AND (cdapostal_zone_before  = '09' OR cdacorr_postal_zone_before = '09')"; 
		}else {
			sql += " AND (cdapostal_zone_before is null OR cdapostal_zone_before != '09') "
					+ "AND (cdacorr_postal_zone_before is null OR cdacorr_postal_zone_before != '09')";
		}

		if(!StringUtil.isEmpty(sql)){
			sql = sql.substring(6);			
			storeCriteria(sql);
			storeOrder("CDAFORM_SUBMIT_DT, CDAFORM_SUBMIT_TIME");
		}
	}

	@Override
	public String toString() {
		return "EformUpdPenProfileLog [iamSmartNoRefNo=" + iamSmartNoRefNo + ", iamSmartEmailAddr=" + iamSmartEmailAddr
				+ ", engName=" + engName + ", chiName=" + chiName + ", formSubmitDt=" + formSubmitDt
				+ ", formSubmitTime=" + formSubmitTime + ", hkic=" + hkic + ", penType=" + penType + ", addr1Before="
				+ addr1Before + ", addr2Before=" + addr2Before + ", addr3Before=" + addr3Before + ", addr1ChinBefore="
				+ addr1ChinBefore + ", addr2ChinBefore=" + addr2ChinBefore + ", addr3ChinBefore=" + addr3ChinBefore
				+ ", countryCodeBefore=" + countryCodeBefore + ", postalZoneBefore=" + postalZoneBefore
				+ ", sameResaddrCoraddrBefore=" + sameResaddrCoraddrBefore + ", corrAddr1Before=" + corrAddr1Before
				+ ", corrAddr2Before=" + corrAddr2Before + ", corrAddr3Before=" + corrAddr3Before
				+ ", corrAddr1ChinBefore=" + corrAddr1ChinBefore + ", corrAddr2ChinBefore=" + corrAddr2ChinBefore
				+ ", corrAddr3ChinBefore=" + corrAddr3ChinBefore + ", corrCountryCodeBefore=" + corrCountryCodeBefore
				+ ", corrPostalZoneBefore=" + corrPostalZoneBefore + ", telNum1Before=" + telNum1Before
				+ ", telNum2Before=" + telNum2Before + ", faxNumBefore=" + faxNumBefore + ", emailAddrBefore="
				+ emailAddrBefore + ", addr1=" + addr1 + ", addr2=" + addr2 + ", addr3=" + addr3 + ", countryCode="
				+ countryCode + ", sameResaddrCoraddr=" + sameResaddrCoraddr + ", corrAddr1=" + corrAddr1
				+ ", corrAddr2=" + corrAddr2 + ", corrAddr3=" + corrAddr3 + ", corrCountryCode=" + corrCountryCode
				+ ", telNum1=" + telNum1 + ", telNum2=" + telNum2 + ", faxNum=" + faxNum + ", emailAddr=" + emailAddr
				+ ", procTime=" + procTime + "]";
	}
	
	public String getIamSmartNoRefNo() {
		return iamSmartNoRefNo;
	}
	public void setIamSmartNoRefNo(String iamSmartNoRefNo) {
		this.iamSmartNoRefNo = iamSmartNoRefNo;
	}
	public String getIamSmartEmailAddr() {
		return iamSmartEmailAddr;
	}
	public void setIamSmartEmailAddr(String iamSmartEmailAddr) {
		this.iamSmartEmailAddr = iamSmartEmailAddr;
	}
	public String getEngName() {
		return engName;
	}
	public void setEngName(String engName) {
		this.engName = engName;
	}
	public String getChiName() {
		return chiName;
	}
	public void setChiName(String chiName) {
		this.chiName = chiName;
	}
	public Date getFormSubmitDt() {
		return formSubmitDt;
	}
	public void setFormSubmitDt(Date formSubmitDt) {
		this.formSubmitDt = formSubmitDt;
	}
	public String getFormSubmitTime() {
		return formSubmitTime;
	}
	public void setFormSubmitTime(String formSubmitTime) {
		this.formSubmitTime = formSubmitTime;
	}
	public String getHkic() {
		return hkic;
	}
	public void setHkic(String hkic) {
		this.hkic = hkic;
	}
	public String getPenType() {
		return penType;
	}
	public void setPenType(String penType) {
		this.penType = penType;
	}
	public String getAddr1Before() {
		return addr1Before;
	}
	public void setAddr1Before(String addr1Before) {
		this.addr1Before = addr1Before;
	}
	public String getAddr2Before() {
		return addr2Before;
	}
	public void setAddr2Before(String addr2Before) {
		this.addr2Before = addr2Before;
	}
	public String getAddr3Before() {
		return addr3Before;
	}
	public void setAddr3Before(String addr3Before) {
		this.addr3Before = addr3Before;
	}
	public String getAddr1ChinBefore() {
		return addr1ChinBefore;
	}
	public void setAddr1ChinBefore(String addr1ChinBefore) {
		this.addr1ChinBefore = addr1ChinBefore;
	}
	public String getAddr2ChinBefore() {
		return addr2ChinBefore;
	}
	public void setAddr2ChinBefore(String addr2ChinBefore) {
		this.addr2ChinBefore = addr2ChinBefore;
	}
	public String getAddr3ChinBefore() {
		return addr3ChinBefore;
	}
	public void setAddr3ChinBefore(String addr3ChinBefore) {
		this.addr3ChinBefore = addr3ChinBefore;
	}
	public String getCountryCodeBefore() {
		return countryCodeBefore;
	}
	public void setCountryCodeBefore(String countryCodeBefore) {
		this.countryCodeBefore = countryCodeBefore;
	}
	public String getPostalZoneBefore() {
		return postalZoneBefore;
	}
	public void setPostalZoneBefore(String postalZoneBefore) {
		this.postalZoneBefore = postalZoneBefore;
	}
	public String getSameResaddrCoraddrBefore() {
		return sameResaddrCoraddrBefore;
	}
	public void setSameResaddrCoraddrBefore(String sameResaddrCoraddrBefore) {
		this.sameResaddrCoraddrBefore = sameResaddrCoraddrBefore;
	}
	public String getCorrAddr1Before() {
		return corrAddr1Before;
	}
	public void setCorrAddr1Before(String corrAddr1Before) {
		this.corrAddr1Before = corrAddr1Before;
	}
	public String getCorrAddr2Before() {
		return corrAddr2Before;
	}
	public void setCorrAddr2Before(String corrAddr2Before) {
		this.corrAddr2Before = corrAddr2Before;
	}
	public String getCorrAddr3Before() {
		return corrAddr3Before;
	}
	public void setCorrAddr3Before(String corrAddr3Before) {
		this.corrAddr3Before = corrAddr3Before;
	}
	public String getCorrAddr1ChinBefore() {
		return corrAddr1ChinBefore;
	}
	public void setCorrAddr1ChinBefore(String corrAddr1ChinBefore) {
		this.corrAddr1ChinBefore = corrAddr1ChinBefore;
	}
	public String getCorrAddr2ChinBefore() {
		return corrAddr2ChinBefore;
	}
	public void setCorrAddr2ChinBefore(String corrAddr2ChinBefore) {
		this.corrAddr2ChinBefore = corrAddr2ChinBefore;
	}
	public String getCorrAddr3ChinBefore() {
		return corrAddr3ChinBefore;
	}
	public void setCorrAddr3ChinBefore(String corrAddr3ChinBefore) {
		this.corrAddr3ChinBefore = corrAddr3ChinBefore;
	}
	public String getCorrCountryCodeBefore() {
		return corrCountryCodeBefore;
	}
	public void setCorrCountryCodeBefore(String corrCountryCodeBefore) {
		this.corrCountryCodeBefore = corrCountryCodeBefore;
	}
	public String getCorrPostalZoneBefore() {
		return corrPostalZoneBefore;
	}
	public void setCorrPostalZoneBefore(String corrPostalZoneBefore) {
		this.corrPostalZoneBefore = corrPostalZoneBefore;
	}
	public String getTelNum1Before() {
		return telNum1Before;
	}
	public void setTelNum1Before(String telNum1Before) {
		this.telNum1Before = telNum1Before;
	}
	public String getTelNum2Before() {
		return telNum2Before;
	}
	public void setTelNum2Before(String telNum2Before) {
		this.telNum2Before = telNum2Before;
	}
	public String getFaxNumBefore() {
		return faxNumBefore;
	}
	public void setFaxNumBefore(String faxNumBefore) {
		this.faxNumBefore = faxNumBefore;
	}
	public String getEmailAddrBefore() {
		return emailAddrBefore;
	}
	public void setEmailAddrBefore(String emailAddrBefore) {
		this.emailAddrBefore = emailAddrBefore;
	}
	public String getAddr1() {
		return addr1;
	}
	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}
	public String getAddr2() {
		return addr2;
	}
	public void setAddr2(String addr2) {
		this.addr2 = addr2;
	}
	public String getAddr3() {
		return addr3;
	}
	public void setAddr3(String addr3) {
		this.addr3 = addr3;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getSameResaddrCoraddr() {
		return sameResaddrCoraddr;
	}
	public void setSameResaddrCoraddr(String sameResaddrCoraddr) {
		this.sameResaddrCoraddr = sameResaddrCoraddr;
	}
	public String getCorrAddr1() {
		return corrAddr1;
	}
	public void setCorrAddr1(String corrAddr1) {
		this.corrAddr1 = corrAddr1;
	}
	public String getCorrAddr2() {
		return corrAddr2;
	}
	public void setCorrAddr2(String corrAddr2) {
		this.corrAddr2 = corrAddr2;
	}
	public String getCorrAddr3() {
		return corrAddr3;
	}
	public void setCorrAddr3(String corrAddr3) {
		this.corrAddr3 = corrAddr3;
	}
	public String getCorrCountryCode() {
		return corrCountryCode;
	}
	public void setCorrCountryCode(String corrCountryCode) {
		this.corrCountryCode = corrCountryCode;
	}
	public String getTelNum1() {
		return telNum1;
	}
	public void setTelNum1(String telNum1) {
		this.telNum1 = telNum1;
	}
	public String getTelNum2() {
		return telNum2;
	}
	public void setTelNum2(String telNum2) {
		this.telNum2 = telNum2;
	}
	public String getFaxNum() {
		return faxNum;
	}
	public void setFaxNum(String faxNum) {
		this.faxNum = faxNum;
	}
	public String getEmailAddr() {
		return emailAddr;
	}
	public void setEmailAddr(String emailAddr) {
		this.emailAddr = emailAddr;
	}
	public Timestamp getProcTime() {
		return procTime;
	}
	public void setProcTime(Timestamp procTime) {
		this.procTime = procTime;
	}
	
	
}
