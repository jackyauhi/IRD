/* * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* @(#) PEN321_03Obj.java		16/11/2021				**/
/*                                              		**/
/* Property of Treasury Computer Branch, HKSARG 		**/
/* All Right Reserved                           		**/
/*                                              		**/
/* SYSTEM                                       		**/
/*       Pension                                		**/
/*                                              		**/
/* AMENDMENT HISTORY                            		**/
/*  George Lam    	 	 16/11/2021 - creation  		**/
/*  									                **/
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * */
package treasury.pension.interfaces;

public class ApplicantJson {
	
	@Override
	public String toString() {
		return "ApplicantJson [hkid=" + hkid + ", fullEnglishName=" + fullEnglishName + ", chineseName=" + chineseName
				+ ", resAddr=" + resAddr + ", corrAddr=" + corrAddr + ", phone1=" + phone1 + ", phone2=" + phone2
				+ ", fax=" + fax + ", email=" + email + ", resAddrLang=" + resAddrLang + ", resCountryRegion="
				+ resCountryRegion + ", engResAddrLine1=" + engResAddrLine1 + ", engResAddrLine2=" + engResAddrLine2
				+ ", engResAddrLine3=" + engResAddrLine3 + ", chiResAddrLine1=" + chiResAddrLine1 + ", chiResAddrLine2="
				+ chiResAddrLine2 + ", chiResAddrLine3=" + chiResAddrLine3 + ", sameAsResAddr=" + sameAsResAddr
				+ ", corrAddrLang=" + corrAddrLang + ", corrCountryRegion=" + corrCountryRegion + ", engCorrAddrLine1="
				+ engCorrAddrLine1 + ", engCorrAddrLine2=" + engCorrAddrLine2 + ", engCorrAddrLine3=" + engCorrAddrLine3
				+ ", chiCorrAddrLine1=" + chiCorrAddrLine1 + ", chiCorrAddrLine2=" + chiCorrAddrLine2
				+ ", chiCorrAddrLine3=" + chiCorrAddrLine3 + "]";
	}

	/* Database Fields */
	private hkid hkid;
	private String fullEnglishName;
	private String chineseName;
	private String resAddr;
	private String corrAddr;
	private String phone1;
	private String phone2;
	private String fax;
	private String email;
	private String resAddrLang;
	private String resCountryRegion;
	private String engResAddrLine1;
	private String engResAddrLine2;
	private String engResAddrLine3;
	private String chiResAddrLine1;
	private String chiResAddrLine2;
	private String chiResAddrLine3;
	private String sameAsResAddr;
	//Special handling from OGCIO eForm for the key CorrAddrLang and CorrAddrLang2. 
	//Either CorrAddrLang or CorrAddrLang2 will be existed in the uploaded JSON files.
	//When Both Residential Address and Correspondence Address are input in the OGCIO eForm, the key CorrAddrLang2 will be appeared in the JSON files
	//When only one kind of Address(Residential or Correpsondence) is input in the OGCIO eForm, the key CorrAddrLang will be appeared in the JSON files
	//The key CorrAddrLang and CorrAddrLang2 will not be existed at the same time in the same JSON files.
	private String corrAddrLang;	
	private String corrAddrLang2;
	private String corrCountryRegion;
	private String engCorrAddrLine1;
	private String engCorrAddrLine2;
	private String engCorrAddrLine3;
	private String chiCorrAddrLine1;
	private String chiCorrAddrLine2;
	private String chiCorrAddrLine3;
	
	
	
	public String getCorrAddrLang2() {
		return corrAddrLang2;
	}

	public void setCorrAddrLang2(String corrAddrLang2) {
		this.corrAddrLang2 = corrAddrLang2;
	}

	public hkid getHkid() {
		return hkid;
	}

	public void setHkid(hkid hkid) {
		this.hkid = hkid;
	}

	public String getFullEnglishName() {
		return fullEnglishName;
	}

	public void setFullEnglishName(String fullEnglishName) {
		this.fullEnglishName = fullEnglishName;
	}

	public String getChineseName() {
		return chineseName;
	}

	public void setChineseName(String chineseName) {
		this.chineseName = chineseName;
	}

	public String getResAddr() {
		return resAddr;
	}

	public void setResAddr(String resAddr) {
		this.resAddr = resAddr;
	}

	public String getCorrAddr() {
		return corrAddr;
	}

	public void setCorrAddr(String corrAddr) {
		this.corrAddr = corrAddr;
	}

	public String getPhone1() {
		return phone1;
	}

	public void setPhone1(String phone1) {
		this.phone1 = phone1;
	}

	public String getPhone2() {
		return phone2;
	}

	public void setPhone2(String phone2) {
		this.phone2 = phone2;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getResAddrLang() {
		return resAddrLang;
	}

	public void setResAddrLang(String resAddrLang) {
		this.resAddrLang = resAddrLang;
	}

	public String getResCountryRegion() {
		return resCountryRegion;
	}

	public void setResCountryRegion(String resCountryRegion) {
		this.resCountryRegion = resCountryRegion;
	}

	public String getEngResAddrLine1() {
		return engResAddrLine1;
	}

	public void setEngResAddrLine1(String engResAddrLine1) {
		this.engResAddrLine1 = engResAddrLine1;
	}

	public String getEngResAddrLine2() {
		return engResAddrLine2;
	}

	public void setEngResAddrLine2(String engResAddrLine2) {
		this.engResAddrLine2 = engResAddrLine2;
	}

	public String getEngResAddrLine3() {
		return engResAddrLine3;
	}

	public void setEngResAddrLine3(String engResAddrLine3) {
		this.engResAddrLine3 = engResAddrLine3;
	}

	public String getChiResAddrLine1() {
		return chiResAddrLine1;
	}

	public void setChiResAddrLine1(String chiResAddrLine1) {
		this.chiResAddrLine1 = chiResAddrLine1;
	}

	public String getChiResAddrLine2() {
		return chiResAddrLine2;
	}

	public void setChiResAddrLine2(String chiResAddrLine2) {
		this.chiResAddrLine2 = chiResAddrLine2;
	}

	public String getChiResAddrLine3() {
		return chiResAddrLine3;
	}

	public void setChiResAddrLine3(String chiResAddrLine3) {
		this.chiResAddrLine3 = chiResAddrLine3;
	}

	public String getSameAsResAddr() {
		return sameAsResAddr;
	}

	public void setSameAsResAddr(String sameAsResAddr) {
		this.sameAsResAddr = sameAsResAddr;
	}

	public String getCorrAddrLang() {
		return corrAddrLang;
	}

	public void setCorrAddrLang(String corrAddrLang) {
		this.corrAddrLang = corrAddrLang;
	}

	public String getCorrCountryRegion() {
		return corrCountryRegion;
	}

	public void setCorrCountryRegion(String corrCountryRegion) {
		this.corrCountryRegion = corrCountryRegion;
	}

	public String getEngCorrAddrLine1() {
		return engCorrAddrLine1;
	}

	public void setEngCorrAddrLine1(String engCorrAddrLine1) {
		this.engCorrAddrLine1 = engCorrAddrLine1;
	}

	public String getEngCorrAddrLine2() {
		return engCorrAddrLine2;
	}

	public void setEngCorrAddrLine2(String engCorrAddrLine2) {
		this.engCorrAddrLine2 = engCorrAddrLine2;
	}

	public String getEngCorrAddrLine3() {
		return engCorrAddrLine3;
	}

	public void setEngCorrAddrLine3(String engCorrAddrLine3) {
		this.engCorrAddrLine3 = engCorrAddrLine3;
	}

	public String getChiCorrAddrLine1() {
		return chiCorrAddrLine1;
	}

	public void setChiCorrAddrLine1(String chiCorrAddrLine1) {
		this.chiCorrAddrLine1 = chiCorrAddrLine1;
	}

	public String getChiCorrAddrLine2() {
		return chiCorrAddrLine2;
	}

	public void setChiCorrAddrLine2(String chiCorrAddrLine2) {
		this.chiCorrAddrLine2 = chiCorrAddrLine2;
	}

	public String getChiCorrAddrLine3() {
		return chiCorrAddrLine3;
	}

	public void setChiCorrAddrLine3(String chiCorrAddrLine3) {
		this.chiCorrAddrLine3 = chiCorrAddrLine3;
	}

	public class hkid{
		private String id;
		private String checkDigit;
		
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getCheckDigit() {
			return checkDigit;
		}
		public void setCheckDigit(String checkDigit) {
			this.checkDigit = checkDigit;
		}		
	}
}
