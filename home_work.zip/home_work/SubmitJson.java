/* * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* @(#) PEN321_03Obj.java		16/11/2021				**/
/*                                              		**/
/* Property of Treasury Computer Branch, HKSARG 		**/
/* All Right Reserved                           		**/
/*                                              		**/
/* SYSTEM                                       		**/
/*       Pension                                		**/
/*                                              		**/
/* AMENDMENT HISTORY                            		**/
/*  George Lam    	 	 16/11/2021 - creation  		**/
/*  									                **/
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * */
package treasury.pension.interfaces;

public class SubmitJson {

	/* Database Fields */
	private String trnId;
	private String submitTime;
	private String email;
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTrnId() {
		return trnId;
	}
	public void setTrnId(String trnId) {
		this.trnId = trnId;
	}
	public String getSubmitTime() {
		return submitTime;
	}
	public void setSubmitTime(String submitTime) {
		this.submitTime = submitTime;
	}
	
}
