package treasury.pension.util;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;
import java.util.Vector;

import treasury.payroll.util.Log;
import treasury.payroll.util.StringUtilException;

/**
 * The program provides some common string functions
 * such as conversions and validations.
 * @author	  Quentin Wong
 * @version	 1.00 2001/05/15
 * 
 *   <h1>AMENDMENT HISTORY</h1>
 *   <br><h2>Date: 21/01/2016</h2>
 *   <br>By: Cathy Lee
 *   <br>Change Request NO.: PAYS-1601-0201-ESD
 *   <br>Activity Request NO.: PAYS-00-000885
 *   <br>Details: Enhance genRandomStr() that generate string having upper case, lower case and digit
 *   <hr>
 */
public class StringUtil {

	/**
	 * default encoding for StringUtil
	 */
	public static final String ENCODING_CP950 = "CP950";
	public static final String ENCODING_UTF8 = "UTF8";	
	public static final String DEFAULT_ENCODING = ENCODING_UTF8;
	public static final String DEFAULT_DB_ENCODING = ENCODING_UTF8;	
	public static final int    CHINESE_DESC_LENGTH = 10;

	private static final Character.UnicodeBlock[] UNICODE_BLOCK_LEN2 = {Character.UnicodeBlock.CJK_COMPATIBILITY, 
			Character.UnicodeBlock.CJK_COMPATIBILITY_FORMS,
	 		Character.UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS,
			Character.UnicodeBlock.CJK_SYMBOLS_AND_PUNCTUATION,
			Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS,
			Character.UnicodeBlock.CJK_RADICALS_SUPPLEMENT,
			Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A,
			Character.UnicodeBlock.ENCLOSED_CJK_LETTERS_AND_MONTHS,
			Character.UnicodeBlock.HALFWIDTH_AND_FULLWIDTH_FORMS,
			Character.UnicodeBlock.PRIVATE_USE_AREA};															   

	
	/**
	 * Checks if the input string contains all digits.  To check if the input
	 * string is a number, please use <b>BigDecimal.validate(String)</b>.
	 * @param str the string to be checked.
	 * @return <i>true</i> if the input string contains all digits.
	 */
	public static boolean isDigits(String str) {
		char c[] = str.toCharArray();

		for (int i = 0; i < c.length; i++) {
			if (!Character.isDigit(c[i])) {
				return false;
			}
		}
		return true;
	}


	/**
	 * Checks if the input string contains all letters.
	 * @param str the string to be checked.
	 * @return <i>true</i> if the input string contains all letters.
	 */
	public static boolean isLetters(String str) {
		char c[] = str.toCharArray();

		for (int i = 0; i < c.length; i++) {
			if (!Character.isLetter(c[i])) {
				return false;
			}
		}
		return true;
	}


	/**
	 * Checks if the input string contains all digits or letters.
	 * @param str the string to be checked.
	 * @return <i>true</i> if the input string contains all digits or letters.
	 */
	public static boolean isLettersOrDigits(String str) {
	    if(StringUtil.containNonBasicLatinChar(str))
	        return false;
	    
		char c[] = str.toCharArray();

		for (int i = 0; i < c.length; i++) {
			if (!Character.isLetterOrDigit(c[i])) {
				return false;
			}
		}
		return true;
	}


	/**
	 * Checks if the input string contains all whitespaces.
	 * @param str the string to be checked.
	 * @return <i>true</i> if the input string contains all whitespaces.
	 */
	public static boolean isWhitespaces(String str) {
		char c[] = str.toCharArray();

		for (int i = 0; i < c.length; i++) {
			if (!Character.isWhitespace(c[i])) {
				return false;
			}
		}
		return true;
	}
	

	/**
	 * Checks if the input string is a scientific number (eg. 0E1).
	 * @param str the string to be checked.
	 * @return <i>true</i> if the input string is a scientific number.
	 */
	public static boolean isScientificNum(String str) {
		String lhs = null;
		String rhs = null;
		
		if (isEmpty(str)) {
			return false;
		}
		
		int ind = str.indexOf("E");
		
		if (ind < 0) {
			ind = str.indexOf("e");
		}
		
		if (ind < 0) {
			return false;
		} else {
			lhs = str.substring(0, ind);
			rhs = str.substring(ind + 1);
			
			if (isEmpty(lhs) || isEmpty(rhs)) {
				return false;
			}
			
			if (!isDigits(lhs) || !isDigits(rhs)) {
				return false;
			}
		}
		
		return true;
	}


	/**
	 * Checks if the input string contains any whitespace.
	 * @param str the string to be checked.
	 * @return <i>true</i> if the input string contains whitespace.
	 */
	public static boolean containWhitespaces(String str) {
		boolean contained = false;
		char c[] = str.toCharArray();

		for (int i = 0; i < c.length; i++) {
			if ((Character.isWhitespace(c[i]))) {
				contained = true;
				break;
			}
		}
		return contained;
	}

	/**
	 * Returns the actual lenght of the string that would appear in database. Using default db encoding for Payroll
	 * @param str the input string.
	 * @return number of bytes.
	 */
	public static int getDbLength(String str) {
		int length=0;
		try {
			length = getDbLength(str, DEFAULT_DB_ENCODING);
		}
		catch (StringUtilException e) {
			Log.writeErrorLog("StringUtil", Log.FATAL, "UnsupportedEncodingException in getDbLength. Configuration Error!", e);
		}
		return length;
	}

	/**
	 * Returns the actual lenght of the string that would appear in database
	 * @param str the input string.
	 * @return number of bytes.
	 */
	public static int getDbLength(String str, String encoding) throws StringUtilException {
		if(str==null)
			return 0;
		int length = 0;
		try {
			length = str.getBytes(encoding).length;
		}
		catch (UnsupportedEncodingException e) {
			throw new StringUtilException("UnsupportedEncodingException in getDbLength", e);
		}
		return length;
	}
	
	
	/**
	 * Gets the length that the string display, the default encoding is CP950.
	 * If the input string contains any chinese character, 
	 * MUST use method getDisplayLength(String, String), and specific encoding to UTF8
	 * @return Returns a int
	 */	
	public static int getDisplayLength(String inStr) {
		return getDisplayLength(inStr, ENCODING_CP950);
	}
	
	/**
	 * Gets the length that the string display
	 * If the input string contains any chinese character, MUST specific encoding to UTF8
	 * @return Returns a int
	 */	
	public static int getDisplayLength(String inStr, String encoding) {
		int len = 0;
		
		if ((inStr == null) || (inStr.length() < 1))
			return 0;
		
		if (StringUtil.equals(encoding, ENCODING_CP950)) {
			try {
				len = inStr.getBytes(encoding).length;
			}
			catch (UnsupportedEncodingException e) {
				Log.writeErrorLog("StringUtil", Log.FATAL, "UnsupportedEncodingException in getDisplayLength. Configuration Error!", e);
			}			
			
		} else {
			for (int i = 0; i < inStr.length(); i++) {
				
				char aChar = inStr.charAt(i);
				len++;
				
				// Check if the character needs 2 space length to display
				for (int j = 0; j < UNICODE_BLOCK_LEN2.length; j++) {
					if (Character.UnicodeBlock.of(aChar).equals(UNICODE_BLOCK_LEN2[j])) {
						len++;
						break;
					}
				}
			}
			
		} 
		
		return len;
	}
	
	/**
	 * Returns a string with padding some given characters
	 * on the left of input string such that its final length
	 * is at least equal to the specified length.  If the length of
	 * the input string is not less than the specified length, the
	 * original input string will be returned without any modification.
	 * 
	 * The difference for padL and padLForDB is: 
	 * The lenth inputted in padL indicated the display length, where both cp950 and utf8 count 2
	 * The lenth inputted in padLForDB indicated the DB length, where cp950 count 2 and utf8 count 3
	 * 
	 * @param str the string to be padded.
	 * @param len the minimum length string.
	 * @param padc the padding character.
	 * @return the padded string.
	 */
	public static String padLForDB(String str, int len, char padc, String encoding) throws StringUtilException {
		String strL = "";
		String instr = "";
		int inlen = 0;

		if (str != null) {
			instr = str;
			inlen = getDbLength(str, encoding);
		}

		if (inlen > len) {
			return str;
		}

		for (int i = 0; i < len - inlen; i++) {
			strL += padc;
		}
		return strL + instr;
	}

	/**
	 * Returns a string with padding some given characters
	 * on the left of input string such that its final length
	 * is at least equal to the specified length.  If the length of
	 * the input string is not less than the specified length, the
	 * original input string will be returned without any modification.
	 * If the input string contains any chinese character, MUST specific encoding to UTF8 
	 * @param str the string to be padded.
	 * @param len the minimum length string.
	 * @param padc the padding character.
	 * @return the padded string.
	 */
	public static String padL(String str, int len, char padc, String encoding) throws StringUtilException {
		String strL = "";
		String instr = "";
		int inlen = 0;

		if (str != null) {
			instr = str;
			inlen = getDisplayLength(str, encoding);
		}

		if (inlen > len) {
			return str;
		}

		for (int i = 0; i < len - inlen; i++) {
			strL += padc;
		}
		return strL + instr;
	}

	/**
	 * Returns a string with padding some given characters
	 * on the left of input string such that its final length
	 * is at least equal to the specified length.  If the length of
	 * the input string is not less than the specified length, the
	 * original input string will be returned without any modification.
	 * If the input string contains any chinese character, 
	 * MUST use method padL(String, int, char, String) and specific encoding to UTF8 
	 * @param str the string to be padded.
	 * @param len the minimum length string.
	 * @param padc the padding character.
	 * @return the padded string.
	 */
	public static String padL(String str, int len, char padc) {
		String strL = "";
		String instr = "";
		int inlen = 0;

		if (str != null) {
			instr = str;
			inlen = getDisplayLength(str);
		}

		if (inlen > len) {
			return str;
		}

		for (int i = 0; i < len - inlen; i++) {
			strL += padc;
		}
		return strL + instr;
	}

	/**
	 * Returns a string with padding some given characters
	 * on the left of input string such that its final length
	 * is at least equal to the specified length.  If the length of
	 * the input string is not less than the specified length, the
	 * original input string will be returned without any modification.
	 * 
	 * The difference for padR and padRForDB is: 
	 * The lenth inputted in padR indicated the display length, where both cp950 and utf8 count 2
	 * The lenth inputted in padRForDB indicated the DB length, where cp950 count 2 and utf8 count 3
	 *  
	 * @param str the string to be padded.
	 * @param len the minimum length (byte) string.
	 * @param padc the padding character.
	 * @return the padded string.
	 */
	public static String padRForDB(String str, int len, char padc, String encoding) throws StringUtilException {
		String strR = "";
		String instr = "";
		int inlen = 0;

		if (str != null) {
			instr = str;
			inlen = getDbLength(str, encoding);
		}

		if (inlen > len) {
			return str;
		}

		for (int i = 0; i < len - inlen; i++) {
			strR += padc;
		}
		return instr + strR;
	}


	/**
	 * Returns a string with padding some given characters
	 * on the left of input string such that its final length
	 * is at least equal to the specified length.  If the length of
	 * the input string is not less than the specified length, the
	 * original input string will be returned without any modification.
	 * If the input string contains any chinese character, MUST specific encoding to UTF8 
	 * @param str the string to be padded.
	 * @param len the minimum length string.
	 * @param padc the padding character.
	 * @return the padded string.
	 */
	public static String padR(String str, int len, char padc, String encoding) throws StringUtilException {
		String strR = "";
		String instr = "";
		int inlen = 0;

		if (str != null) {
			instr = str;
			inlen = getDisplayLength(str, encoding);
		}

		if (inlen > len) {
			return str;
		}

		for (int i = 0; i < len - inlen; i++) {
			strR += padc;
		}
		return instr + strR;
	}

	/**
	 * Returns a string with padding some given characters
	 * on the left of input string such that its final length
	 * is at least equal to the specified length.  If the length of
	 * the input string is not less than the specified length, the
	 * original input string will be returned without any modification.
	 * If the input string contains any chinese character, 
	 * MUST use method padR(String, int, char, String) and specific encoding to UTF8 
	 * @param str the string to be padded.
	 * @param len the minimum length string.
	 * @param padc the padding character.
	 * @return the padded string.
	 */
	public static String padR(String str, int len, char padc) {
		String strR = "";
		String instr = "";
		int inlen = 0;

		if (str != null) {
			instr = str;
			inlen = getDisplayLength(str);
		}

		if (inlen > len) {
			return str;
		}

		for (int i = 0; i < len - inlen; i++) {
			strR += padc;
		}
		return instr + strR;
	}


	/**
	 * Returns a new string resulting from replacing all occurrences of
	 * oldSubStr in this string with newSubStr.
	 * @param inStr the input string.
	 * @param oldSubStr
	 * @param newSubStr
	 * @return a string derived from this string by replacing
	 * every occurrence of oldSubStr with newSubStr.
	 */
	public static String replace(String inStr, String oldSubStr, String newSubStr) {
		return replace(inStr, oldSubStr, newSubStr, -1);
   }

    /**
     * Replace a string with another string inside a larger string,
     * for the first <code>max</code> values of the search string.
     *
     * @param max  maximum number of values to replace, or
     * <code>-1</code> if no maximum
     */
    public static String replace(String input, String oldStr, String newStr,
                                 int max) {
        if (input == null) {
            return null;
        }
        return replace(new StringBuffer(input), oldStr, newStr, max).toString();

    }
    

    
    
    public static StringBuffer replace(StringBuffer input, String oldStr, String newStr, int max) {
        if (input == null) {
            return null;
        }
        if (oldStr == null || "".equals(oldStr)) {
        	return input;
        }
        
        if (newStr == null) {
        	newStr = "";
        }



        String text = input.toString();
        StringUtil.reset(input);
        int start = 0, end = 0;
        while ((end = text.indexOf(oldStr, start)) != -1) {
            input.append(text.substring(start, end)).append(newStr);
            start = end + oldStr.length();

            if (--max == 0) {
                break;
            }
        }
        input.append(text.substring(start));
        return input;
    }

    public static String replaceSpecialChar(String str) {
    	
    	String strOutput = new String(str);
    	
    	strOutput = StringUtil.replace(strOutput, "&", "&amp;");
    	strOutput = StringUtil.replace(strOutput, "\"", "&quot;");
    	strOutput = StringUtil.replace(strOutput, "'",  "&apos;");
    	strOutput = StringUtil.replace(strOutput, ">",  "&gt;");
    	strOutput = StringUtil.replace(strOutput, "<",  "&lt;");
    	
    	return strOutput;
    }
    
    public static StringBuffer replace(StringBuffer text, String repl, String with) {
    	return replace(text, repl, with, -1);
    }


	/**
	 * Converts a list of strings to csv string
	 * If size of list equals 0, "" will be returned
	 * @param alist a list to be converted to csv string
	 * 
	 * Example:
	 * List xx = {"AA","BB"};	
	 * 'AA','BB' = addQuote(xx);
	 * 
	 */
	public static String addQuote(List alist)
	{
		String result = "";
		
		for (int i=0; i<alist.size(); i++){
			if(i>=1)
				result += ",";
			result += StringUtil.addQuote((String) alist.get(i));
		}
			
		return result;
	}

	/**
	 * Converts a string array to csv string
	 * If length of string array equals 0, "" will be returned
	 * @param astrarr a string array to be converted to csv string
	 * 
	 * Example:
	 * String[] xx = {"AA","BB"};	
	 * 'AA','BB' = addQuote(xx);
	 * 
	 */
	public static String addQuote(String[] astrarr)
	{
		String result = "";
		
		for (int i=0; i<astrarr.length; i++){
			if(i>=1)
				result += ",";
			result += StringUtil.addQuote(astrarr[i]);
		}
			
		return result;
	}

	/**
	 * Returns a string ready for the use in building SQL by:
	 * replacing all single quotes in the input string with two, and
	 * prepending and appending single quote to the input string.
	 * @param str the input string
	 * @return the formatted string
	 */
	public static String addQuote(String str) {
		if (str == null)  //  not use isEmpty(str) as "" is acceptable
			return null;

		return "'" + replace(str, "'", "''") + "'";
	}


	/**
	 * Returns a string ready for the use in building SQL by:
	 * converting the input number to a string.
	 * @param num the input number
	 * @return the formatted string
	 */
	public static String addQuote(BigDecimal num) {
		return BigDecimalUtil.toString(num);
	}


	/**
	 * Returns a string ready for the use in building SQL by:
	 * converting the input date to a string, and prepending and
	 * appending quotes to the date string
	 * @param date the input date
	 * @return the formatted string
	 */
	public static String addQuote(Date date) {
		if (date == null)
			return null;

		return "'" + DateUtil.date2Str(date, "yyyy-MM-dd") + "'";
	}


	/**
	 * Returns a string ready for the use in building SQL by:
	 * converting the input timestamp to a string, and prepending and
	 * appending quotes to the timestamp string
	 * @param time the input timestamp
	 * @return the formatted string
	 */
	public static String addQuote(Timestamp time) {
		if (time == null)
			return null;

		return "'" + time.toString()+ "'";
	}

	/**
	 * Returns a string ready for the use in building SQL by:
	 * converting the input timestamp to a string, and prepending and
	 * appending quotes to the timestamp string
	 * @param time the input timestamp
	 * @return the formatted string
	 */
	public static String addQuote(Integer integer) {
		if (integer == null)
			return null;

		return integer.toString();
	}


	/**
	 * Returns a string ready for the use in building SQL.  Based on
	 * the class of the input object, corresponding methods is called.
	 * @param obj the input object
	 * @return the formatted string
	 */
	public static String addQuote(Object obj) {
		if (obj instanceof String)
			return addQuote((String) obj);
		else if (obj instanceof BigDecimal)
			return addQuote((BigDecimal) obj);
		else if (obj instanceof Date)
			return addQuote((Date) obj);
		else if (obj instanceof Timestamp)
			return addQuote((Timestamp) obj);
		else if (obj instanceof Integer)
			return addQuote((Integer) obj);
		else
			return null;
	}
	
	/**
	 * Returns a string ready for the use in MS Excel
	 * @param str the input string
	 * @return the formatted string
	 */
	public static String addQuote4Excel(String str) {
		if (isEmpty(str)) {
			return "\"\"";
		}
		
		if (isDigits(str) || isScientificNum(str)) {
			return "=\"" + str + "\"";
		}

		return "\"" + str + "\"";
	}		

	/**
	 * Checks if the input string is null or empty.
	 * @param str the input string
	 * @return <i>true</i> if str is null or empty.
	 */
	public static boolean isEmpty(String str) {
		return ((str == null) || (str.trim().length() < 1));
	}

	public static String giveOneSpace(String str) {
		return (str == null  ||  str.length() > 0) ? str : " ";
	}

	/**
	 * Checks if the input string exists in the input string array.
	 * @param str the input string.
	 * @param strArr the input string array.
	 * @return <i>true</i> if the input string exists in the input string array
	 */
	public static boolean existIn(String str, String[] strArr) {
		if (strArr == null)
			return false;

		for (int i = 0; i < strArr.length; i++) {
			if (str == null) {
				if (strArr[i] == null) {
					return true;
				}
			} else {
				if (str.equals(strArr[i])) {
					return true;
				}
			}
		}
		return false;
	}
	
	
	public static boolean existIn(String str, List strList) {
		if (strList == null)
			return false;

		for (int i = 0; i < strList.size(); i++) {
			if (str == null) {
				if (strList.get(i) == null) {
					return true;
				}
			} else {
				if (str.equals((String) strList.get(i))) {
					return true;
				}
			}
		}
		return false;
	}


	public static int getIndex(String str, String[] strArr) {
		if (strArr == null)
			return -1;

		for (int i = 0; i < strArr.length; i++) {
			if (str == null) {
				if (strArr[i] == null) {
					return i;
				}
			} else {
				if (str.equals(strArr[i])) {
					return i;
				}
			}
		}
		return -1;
	}

	/**
	 * Generate random string of length specified
	 * @param strLength int length of the string 
	 * @return String the random String object
	 */
	public static String genRandomStr(int strLength) {
		StringBuffer sb = new StringBuffer(strLength);

		int c = 'A';
		int randInt = 0;
		int previousChar = '\0';
		
		if (strLength <= 0)
			return "";
		
		for (int i = 0; i < strLength; i++) {

			randInt = (int) (Math.random() * 3);
			
			// manipulate last char to ensure output string 
			//   to be a mixture of letters and digits  
			// uppercase characters, lowercase characters and digits  
			if (i == 0) {
				randInt = 0;
			} else if (i == 1) {
				randInt = 1;
			} else if (i == 2) {
				randInt = 2;
			}
			
			do {				
				switch (randInt) {
					case 0:
						c = 'A' + (int) (Math.random() * 26);
						break;
					case 1:
						c = 'a' + (int) (Math.random() * 26);
						break;
					case 2:
						c = '0' + (int) (Math.random() * 10);
						break;
				}
			} while (c == previousChar);
			previousChar = c;
			sb.append( (char) c );
		}
		
		return sb.toString();
	}

	/**
	 * Returns null String if the input string is null or empty.
	 * @param str the input string
	 * @return <i>null</i> if str is null or empty, or str otherwise.
	 */
	public static String empty2Null(String str) {
		return isEmpty(str) ? null : str;
	}


	/**
	 * Returns blank String if the input string is null or empty.
	 * @param str the input string
	 * @return <i>null</i> if str is null or empty, or str otherwise.
	 */
	public static String empty2Blank(String str) {
		return isEmpty(str) ? "" : str;
	}


	/**
	 * Checks if the input string is Y or N.
	 * @param str the input string.
	 * @return <i>true</i> if str = Y or N.
	 */
	public static boolean isYN(String str) {
		return ("Y".equals(str)  ||  "N".equals(str));
	}


	/**
	 * Checks if the input string is Y, N or empty.
	 * @param str the input string.
	 * @return <i>true</i> if str = Y, N or empty.
	 */
	public static boolean isYNE(String str) {
		return (isEmpty(str)  ||  "Y".equals(str)  ||  "N".equals(str));
	}
	
	
	/**
	 * increase the string by certain value of integer
	 * @param str the input string
	 * @param num integer to be added
	 * @return 
	 */
	public static String add(String str, String num){
		try{
			int strInt = Integer.parseInt(str);
			int inc = Integer.parseInt(num);
			strInt = strInt + inc;
			return String.valueOf(strInt);
		}
		catch(NumberFormatException nfe){
			return null;
		}		
	}


	/**
	 * decrease the string by certain value of integer
	 * @param str the input string
	 * @param num integer to be substracted
	 * @return 
	 */
	public static String substract(String str, String num){
		try{
			int strInt = Integer.parseInt(str);
			int dec = Integer.parseInt(num);
			strInt = strInt - dec;
			return String.valueOf(strInt);
		}
		catch(NumberFormatException nfe){
			return null;
		}	
	}		

	/**
	 * separate the string with the specified <I>separator</I>
	 * @param str the input string.
	 * @return a str separated by separators
	 * <br><br> 
	 * Example:
	 *   String test = " aaa bb cccccc dds eeee ffff ggggggggggg  ";<br>
	 *	 addSeparator(test,20,"<br>"));<br>
	 * <br>
	 *   will return<br>
	 *   "aaa bb cccccc dds<br>eeee ffff<br>ggggggggggg"<br>
	 */
	public static String addSeparator(String str, int charNo, String separator) {
		int i=0;
		int j=0;
		String out = "";

		int index = 0;
		int count = 0;
		int endIndex = 0;
		
		if(isEmpty(str))
			return "";
		else
			str = str.trim();

		/* Determine the number of substrings */
		do {						
			++count;
			++index;
			index = str.indexOf(" ",index);	
		}
		while (index != -1);
		

		String[] subStr = new String[count];
		index = 0;

		for(i=0;i<count;i++){

			endIndex = str.indexOf(" ",index);
			
			if(endIndex == -1)
				subStr[i] = str.substring(index);
			else
				subStr[i] = str.substring(index, endIndex);
			
			index = endIndex + 1;
		}
		
		
		j=0;
		for(i=0; i < subStr.length; i++){
			
			if (j + subStr[i].length() > charNo-1) {
				out += separator + subStr[i];
				j = subStr[i].length();
			} else {
				if (out.equals("")) {
					out = subStr[i];
					j += subStr[i].length();
				} else {
					out += " " +  subStr[i];
					j += subStr[i].length() + 1;
				}
			}
			
		}
					
		return out;
	}
		
	/**
	 * compare two strings
	 * @return true if equal
	 */
	public static boolean equals(String s1, String s2) {
		if ((s1 == null) && (s2 == null)) return true;
		if (s1 != null) {
			return s1.equals(s2);
		}
		return false;
	}

	/**
	 * compare two strings (ignore case)
	 * @return true if equal
	 */
	public static boolean equalsIgnoreCase(String s1, String s2) {
		if ((s1 == null) && (s2 == null)) return true;
		if (s1 != null) {
			return s1.equalsIgnoreCase(s2);
		}
		return false;
	}

	/**
	 * extends the length of a string array
	 * @param strArray
	 * @param int
	 * @return StringArray
	 */
	public static String[] extendsArrayLength(String[] strArray, int length){
		length += strArray.length+length;
		String[] newArray = new String[length];
		for(int i=0; i<strArray.length; i++){
			newArray[i] = strArray[i];
		}
		return newArray;
	}
	
	/**
	 * set a StringBuffer to the integer value
	 */
	public static void setValue(StringBuffer s, int i) {
		s.delete(0, s.length());
		s.append(i);
	}
	
	/**
	 * set a StringBuffer to the integer value
	 */
	public static void reset(StringBuffer s) {
		s.delete(0, s.length());
	}
	/**
	 * check whether the StringBuffer has a value of i
	 */
	public static boolean hasValue(StringBuffer s, int i) {
		return s.toString().equals(Integer.toString(i));
	}
	
	/**
	 * returns a new String that is substring of the input string
	 * chinese character has been checked for the last byte
	 * example : input str = "ABCDEF", beginInd = 1, endInd = 3
	 * 			 String[0] = "BC"
	 * 			 String[1] = "DEF"
	 * 
	 * @param enc			The name of a supported character encoding
	 * @param str			input string
	 * @param beginInd		begin index of byte array of the input str
	 * @param endInd		end index of byte array of the input str
	 * @return String[]		String[0] - the substring within the beginInd and endInd
	 * 						String[1] - the substring after the endInd to the end of the input str		
	 * @throws StringUtilException
	 */
//	public static String[] substring(String enc, 
//								   String str, 
//								   int beginInd, 
//								   int endInd) 
//						throws StringUtilException {
//
//		try{
//			/*
//				basic validation for the input parameters
//			*/
//			if (StringUtil.isEmpty(str))
//				throw new StringUtilException("NULL Input in substring()");
//			if (beginInd < 0)
//				throw new StringUtilException("Begin Index smaller than zero");
//			if (beginInd > endInd)
//				throw new StringUtilException("Begin Index larger than End Index");
//
//			int length = getDbLength(str);	//same as oldByte.length
//			int count = 0;
//			//original byte array of input string	
//			byte[] oldByte = str.getBytes(enc);
//
//			
//			int diffInEncoding = StringUtil.getCharByte(enc) - 1;
////System.err.println("enc="+enc+" diffInEncoding="+diffInEncoding);
//			int tempEndInd = endInd + diffInEncoding;
//			/*
//				NO chinese character for the last byte
//			*/
//			if ((endInd >= length) || (oldByte[endInd-diffInEncoding] > 0)) {
//				tempEndInd = endInd;
//			}
//			
//			//the byte array that the caller program specified
//			byte[] newByte = new byte[tempEndInd-beginInd+1];
//			//the left byte array that from the end index to the tail of the input string
//			byte[] leftByte = new byte[length-tempEndInd];
//
//			for (int i=beginInd; i<tempEndInd; i++){
//				newByte[count] = oldByte[i];
//				count++;
//			}
//			count = 0;
//			for (int i=tempEndInd; i<length; i++){
//				leftByte[count] = oldByte[i];
//				count++;
//			}
//
//			String[] strArray = {new String(newByte, enc), new String(leftByte, enc)};
//			return strArray;
//		}
//		catch (UnsupportedEncodingException e){
//			throw new StringUtilException("Unsupported Encoding in substring : "+enc, e);
//		}		
//	}

	/**
	 * The input string is splitted into multiple lines according to the input db field length
	 * returns a string array contains the splitted lines
	 * chinese character has been checked
	 * @param encoding			The name of a supported character encoding
	 * @param inStr				input string
	 * @param dbfieldsLen		the length of the db field 
	 * @return String[]			
	 * @throws StringUtilException
	 */	
	public static String[] split(String encoding, String inStr, int dbfieldsLen)
	throws StringUtilException {
		
		String[] outStrArr = null;
		
		if (StringUtil.isEmpty(inStr)) {
			throw new StringUtilException("NULL Input in substring()");
		}
		
		int inStrLen = StringUtil.getDbLength(inStr, encoding);
		
		List result = new Vector();
		
		if (inStrLen <= dbfieldsLen) {
			// if the length of input string is less then db field length, then single allocation is enough
			outStrArr = new String[1];
			outStrArr[0] = inStr;
		} else {
			// if the input string is too long, then split it into multiple lines
			String tmpResult = "";
			int lenTmpStr = 0;
			
			for (int i=0; i<inStr.length(); i++) {
				// get each character in the input string one by one
				String tmpStr = inStr.substring(i,i+1);
				
				// get the db length for each character (eg, Eng is one, Chin is two),
				// then sum the length to lenTmpStr
				lenTmpStr += StringUtil.getDbLength(tmpStr, encoding);
				
				if (lenTmpStr <= dbfieldsLen) {
					// if the accumulated length is still within dbfieldsLen,
					// then concat the character to the tmp string, tmpResult
					tmpResult = tmpResult.concat(tmpStr);
					
				} else {
					// if the accumulated tmp string will exceed dbfieldsLen, then store the string
					result.add(tmpResult);
					
					// re-initialize the storage
					tmpResult = tmpStr;
					lenTmpStr = StringUtil.getDbLength(tmpStr, encoding);
				}
				
				if (i == inStr.length()-1) {
					// if it is the last string, then just store to the result
					result.add(tmpResult);
				}
			}
			
			outStrArr = new String[result.size()];
			for (int i=0; i<result.size(); i++) {
				String s = (String)result.get(i);
				outStrArr[i] = s;
			}
		}
		
		//	for (int i=0; i<outStrArr.length; i++) {
		//		System.out.println("s="+outStrArr[i]);
		//	}
		
		return outStrArr;
	}
	
/*	public static void main(String[] args) {
//		BatchUtil.initBatchEnv("");
		try {
			System.out.println(getDbLength("\u767b\u5165", "CP950"));
			System.out.println(getDbLength("\u767b\u5165", "UTF8"));
		}
		catch (Exception e)  {
			e.printStackTrace();
		}
			
	}	*/

	public static List split(String str, String separator, boolean withSpaces) {
		List list = new Vector();
		
		if (StringUtil.isEmpty(str)) {
			return list;
		}
		
		str = str + separator;
		int index = str.indexOf(separator);
		while (index != -1) {
			if (withSpaces) {
				list.add(str.substring(0, index));
			} else {
				list.add(str.substring(0, index).trim());
			}
			str = str.substring(index + 1);
			index = str.indexOf(separator);			
		}
		return list;
	}

	/**
	 * generate the list of tokens from the input string by the input delimiter
	 * @param str
	 * @param delim
	 * @return List 
	 */
/*	public static List getStringTokens(String str, String delim){
		List list = new Vector();
		
		StringTokenizer st = new StringTokenizer(str, delim, true);
		String prevToken = delim;
		
		while(st.hasMoreTokens()){
			String token = st.nextToken();
			if ((token.equals(delim)) && (prevToken.equals(delim)))
				list.add(null);
			else if (prevToken.equals(delim))
				list.add(token);

			prevToken = token;
		}
		
		return list;
		
	}*/
	
	public static List getStringTokens(String str, char delim){
		StringBuffer sb = new StringBuffer(str);
		List list = new Vector();
		int prev = 0;
		for (int i=0; i<sb.length(); i++) {
			if (sb.charAt(i) == delim) {
				String token = sb.substring(prev, i);
				list.add("".equals(token) ? null : token);
				prev = i+1;
			}
		}
		
		String token1 = sb.substring(prev);
		list.add("".equals(token1) ? null : token1);
		
		return list;
		
	}
	
	/**
	 * Returns a new string resulting from replacing all occurrences of
	 * oldSubStr in this string with newSubStr.
	 * @param inStr the input string.
	 * @param oldSubStr
	 * @param newSubStr
	 * @return a string derived from this string by replacing
	 * every occurrence of oldSubStr with newSubStr.
	 */
	public static String oldReplace(String inStr, String oldSubStr, String newSubStr) {
		if (isEmpty(inStr))
			return inStr;

		if (oldSubStr == null)
			return inStr;

		if (isEmpty(newSubStr))
			newSubStr = "";

		int i = 0;
		int pos = 0;
		int oldLen = oldSubStr.length();
		String output = "";
		while (i < inStr.length()) {
			pos = inStr.indexOf(oldSubStr, i);
			if (pos == -1) {
				output += inStr.substring(i);
				break;
			} else {
				output += inStr.substring(i, pos) + newSubStr;
				i = pos + oldLen;
			}
		}
		return output;
   }
   
   
   /**
    * get the byte of each character for different encoding
    * CP950 - 2 and UTF-8 - 3
    * @param encoding
    * @return number of byte
    */
//   public static int getCharByte(String encoding) {
//   		int charByte = 1;
//   		if (encoding.equals("CP950"))
//   			charByte = 2;
//   		else if (encoding.equals("UTF-8"))
//   			charByte = 3;
//   		return charByte;
//   }
   
	
	/**
	 * return the index of the ith occurence of char c (i counts from 1) within start end position (count from 0)
	 * start inclusive
	 * end exclusive
	 * forwards = true search from start
	 * forwards = false search from end
	 * return -1 if not found
	 * returned index counts from 0
	 * 
	 */
	public static int indexOf(StringBuffer sb, char c, int start, int end, int i, boolean forwards) {
		if (sb == null || sb.length() == 0)
			return -1;
		if (i <= 0)
			return -1;
		if (end <= start)
			return -1;
		if (!(0 <= start && start < sb.length())) 
			return -1;
		if (!(0 < end && end <= sb.length())) 
			return -1;
		int hit = 0;
		int incr = 1;
		
		if (!forwards) {
			int temp = start;
			start = end-1;
			end = temp-1;
			incr = -1;
		}
		
		int j=start; 
		while(j!=end) {
			if (c == sb.charAt(j)) {
				hit++;
			}
			if (hit == i) {
				return j;
			}
			j += incr;
		}
		return -1;
	}

/*	public static void main(String[] arg) {
		
		
		String[] xx = {"AA","BB"};	
		System.out.println(addQuote(xx));

		String[] yy = {"AA"};	
		System.out.println(addQuote(yy));

		String[] zz = {};	
		System.out.println(addQuote(zz));

		System.out.println(replace("a","a",null,1));
		System.out.println(oldReplace("a","a",null));
		StringBuffer sb = new StringBuffer("aaa = ? and = ? = ?");
//		int a = indexOf(sb, '?', 0, sb.length(), 1, true);
//		System.out.println(a);
		int b = indexOf(sb, '=', 0, sb.length(), 2, true);
		System.out.println(b);
		b = indexOf(sb, '=', 0, sb.length(), 2, false);
		System.out.println(b);
		b = indexOf(sb, '?', 0, sb.length(), 3, true);
		System.out.println(b);
		b = indexOf(sb, '=', 0, sb.length(), 3, false);
		System.out.println(b+"\n");


		b = indexOf(sb, 'X', 0, sb.length(), 3, false);
		System.out.println(b);
		b = indexOf(sb, 'a', 0, sb.length(), 4, false);
		System.out.println(b);
		b = indexOf(sb, 'a', 0, sb.length(), 3, true);
		System.out.println(b);
		b = indexOf(sb, 'a', 0, sb.length(), 0, false);
		System.out.println(b);
		b = indexOf(sb, 'a', 100, sb.length(), 1, false);
		System.out.println(b);
		b = indexOf(sb, 'a', 0, 100, 1, false);
		System.out.println(b);

	}*/
	
//--> added by passage system	
	public static boolean containDelimiter(String str, char delimiter) {
		boolean contained = false;
		char c[] = str.toCharArray();

		for (int i = 0; i < c.length; i++) {
			if (c[i] == delimiter) {
				contained = true;
				break;
			}
		}
		return contained;
	}
//<-- added by passage system	

	/**
	 * check if the input string contains "%" or "_"
	 * 10/07/2003 - move from UserProfile.isContainWildCard() to StringUtil
	 * 
	 * @param str
	 */
	public static boolean containWildCard(String str) {

		// str cannot be empty
		if ((!StringUtil.isEmpty(str)) &&
			(str.indexOf("%") >= 0 || str.indexOf("_") >= 0)) {
			return true;	
		}	
	
		return false;
	}

	/**
	 * Checks if the specified instr contains any non Basic Latin character
	 * @param instr the string to be checked.
	 * @return true if the specified instr contains any chinese character
	 */
	public static boolean containNonBasicLatinChar(String instr) {
		
		if(instr==null)
			return false;
			
		char[] c = instr.toCharArray();
		for(int i=0;i<c.length;i++)
			if ((int)c[i] > 127) 
				return true;
				
		return false;
	}	

	/**
	 * Checks if the specified c contains any Basic Latin character
	 * @param c the character to be checked.
	 * @return true if the specified c contains any Basic Latin character
	 */
	public static boolean isBasicLatinChar(char c) {
		
		if (Character.isWhitespace(c))
			return false;
			
		if ((int)c < 128 && !String.valueOf(c).equals(" ")) 
			return true;
				
		return false;
	}	
	
	/**
	 * Checks if the specified instr contains any chinese character
	 * @param instr the string to be checked.
	 * @return true if the specified instr contains any chinese character
	 */
//	public static boolean containChineseChar(String instr) {
//		
//		if(instr==null)
//			return false;
//			
//		char[] c = instr.toCharArray();
//		for(int i=0;i<c.length;i++)
//			if ((int)c[i] > 127) 
//				return true;
//				
//		return false;
//	}	

	/**
	 * get the digits of the input string
	 * @param str the string to be covert
	 * @return 
	 */
	public static String getDigits(String str) {
		char c[] = str.toCharArray();
		char r[] = new char[c.length];

		int count = 0;
		for (int i = 0; i < c.length; i++) {
			if (Character.isDigit(c[i])) {
				r[count] = c[i];
				count++;
			}
		}
		return new String(r);
	}
	
	
	/**
	 * rtrim
	 */
	public static String rtrim(String text) {
		if (text == null) {
			return null;
		}
		
		int index = text.length();
		
		while (index > 0 && text.charAt(index - 1) == ' ')
		index--;
		
		if( index == 0 ) return "";
		return text.substring(0, index);
	}

	public static String joinWithSeparator(String[] strArray, String separator) {
		if (strArray == null  ||  separator == null) {  // separator can be empty string
			return null;
		}

		if (strArray.length == 0) {
			return "";
		}

		String result = "";
		for(int i = 0; i < strArray.length; i++){
			result = result + separator + strArray[i];
		}
		return result.substring(separator.length());
	}

	public static String joinWithComma(String[] strArray) {
		return joinWithSeparator(strArray, ", ");
	}

	public static String joinWithSeparator(List strList, String separator) {
		if (strList == null  ||  separator == null) {  // separator can be empty string but not null
			return null;
		}

		if (strList.size() == 0) {
			return "";
		}

		String result = "";
		for(int i = 0; i < strList.size(); i++){
			result = result + separator + ((String) strList.get(i));
		}
		return result.substring(separator.length());
	}

	public static String joinWithComma(List strList) {
		return joinWithSeparator(strList, ", ");
	}
	
	/**
	 * validate if the string specified is acceptable to a typical chinese name (do not support name group)
	 * @param str
	 * @return false if the input string contains any invalid character
	 */
	public static boolean validOfficerNameChin(String str) {
		return coreValidateOfficerNameChin(str, false);
	}

	/**
	 * validate if the string specified is acceptable to a typical chinese name (support name group)
	 * @param str
	 * @return false if the input string contains any invalid character
	 */
	public static boolean validOfficerNameGrpChin(String str) {
		return coreValidateOfficerNameChin(str, true);
	}

	/**
	 * validate if the string specified is acceptable to a typical chinese address field
	 * @param str
	 * @return false if the input string contains any invalid character
	 */
	public static boolean validAddrChin(String str) {
		return !is1754OrExtBOrNull(str);
	}

	/**
	 * validate if the string specified is acceptable to a typical chinese description field
	 * @param str
	 * @return false if the input string contains any invalid character
	 */
	public static boolean validDescChin(String str) {
		return !is1754OrExtBOrNull(str);
	}

	/**
	 * validate if the string specified is acceptable to a typical chinese message field
	 * @param str
	 * @return false if the input string contains any invalid character
	 */
	public static boolean validMsgChin(String str) {
		return !is1754OrExtBOrNull(str);
	}
	
	/**
	 * check if the input string contains any invalid character
	 * @param str
	 * @return true if the input string contains any invalid character or is null
	 */
	public static boolean is1754OrExtBOrNull(String str) {
		
		if (str == null) {
			return true;
		}

		//if the java library unable to handle the string or the string is empty, reject it
		char[] charArray = str.toCharArray();
		if (charArray == null || charArray.length <= 0) {
			return true;
		}		
	
		//if the input string contains any character in the 1754 set, reject it
		if (Big5HKSCSChar.is1754(str)) {
			return true;
		}
		//if the input string contains any character in Ext-B, reject it
		if (Big5HKSCSChar.isExtensionB(str)) {
			return true;
		}
		
		return false;
	}

	
	/**
	 * check if the input string contains any invalid character
	 * @param str
	 * @param allowSpecialChars allow special characters for the handling name group
	 * @return false if the input string contains any invalid character
	 */
	private static boolean coreValidateOfficerNameChin(String str, boolean allowSpecialChars) {
		if (str == null) {
			return false;
		}

		//if the java library unable to handle the string or the string is empty, reject it
		char[] charArray = str.toCharArray();
		if (charArray == null || charArray.length <= 0) {
			return false;
		}

		//if the input string contains any character in the 1754 set, reject it
		if (Big5HKSCSChar.is1754(str)) {
			return false;
		}

		//if the input string contains Basic Latin character, reject it
		//Chinese name of officer (does not support name group) will accept Chinese Characters + Space
		//Chinese name of officer (supports name group) will accept Chinese Characters + Space + symbols for handling name group in MaskingUtil.java
		if (!allowSpecialChars) {
			for (int i=0;i<charArray.length;i++){
				if(
						(Character.UnicodeBlock.of(charArray[i]).equals(Character.UnicodeBlock.BASIC_LATIN) && (charArray[i]=='\u0020'))//u0020 is space
						|| Character.UnicodeBlock.of(charArray[i]).equals(Character.UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS)
						|| Character.UnicodeBlock.of(charArray[i]).equals(Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS)
						|| Character.UnicodeBlock.of(charArray[i]).equals(Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A)
						|| Character.UnicodeBlock.of(charArray[i]).equals(Character.UnicodeBlock.PRIVATE_USE_AREA)
						// ||Character.UnicodeBlock.of(charArray[i]).equals(Character.UnicodeBlock.HIGH_SURROGATES)
						// ||Character.UnicodeBlock.of(charArray[i]).equals(Character.UnicodeBlock.LOW_SURROGATES)						
						){
					//accept
				}else{
					return false;
				}	
			}
		}else{
			for (int i=0;i<charArray.length;i++){
				
				//private static final String NAME_GRP_NAME_DELIMITERS = "@/*&()[]{}\uFF20\uFF0F\uFF0A\uFF06\uFF08\uFF09\u3014\u3015\uFF5B\uFF5D";

				if(
						(Character.UnicodeBlock.of(charArray[i]).equals(Character.UnicodeBlock.BASIC_LATIN)
							&& ((charArray[i]=='\u0020') //u0020 is space 
								|| (charArray[i]=='\u0040') 
								|| (charArray[i]=='\u002F') 
								|| (charArray[i]=='\u002A') 
								|| (charArray[i]=='\u0026') 
								|| (charArray[i]=='\u0028') 
								|| (charArray[i]=='\u0029') 
								|| (charArray[i]=='\u005B') 
								|| (charArray[i]=='\u005D') 
								|| (charArray[i]=='\u007B') 
								|| (charArray[i]=='\u007D')))
						||(Character.UnicodeBlock.of(charArray[i]).equals(Character.UnicodeBlock.CJK_SYMBOLS_AND_PUNCTUATION)
							&& ((charArray[i]=='\u3014')
								|| (charArray[i]=='\u3015')))
						||(Character.UnicodeBlock.of(charArray[i]).equals(Character.UnicodeBlock.HALFWIDTH_AND_FULLWIDTH_FORMS)
							&& ((charArray[i]=='\uFF20')
								|| (charArray[i]=='\uFF0F')
								|| (charArray[i]=='\uFF0A')
								|| (charArray[i]=='\uFF06')
								|| (charArray[i]=='\uFF08')
								|| (charArray[i]=='\uFF09')
								|| (charArray[i]=='\uFF5B')
								|| (charArray[i]=='\uFF5D')))
						|| Character.UnicodeBlock.of(charArray[i]).equals(Character.UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS)
						|| Character.UnicodeBlock.of(charArray[i]).equals(Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS)
						|| Character.UnicodeBlock.of(charArray[i]).equals(Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A)
						|| Character.UnicodeBlock.of(charArray[i]).equals(Character.UnicodeBlock.PRIVATE_USE_AREA)
						// ||Character.UnicodeBlock.of(charArray[i]).equals(Character.UnicodeBlock.HIGH_SURROGATES)
						// ||Character.UnicodeBlock.of(charArray[i]).equals(Character.UnicodeBlock.LOW_SURROGATES)						
						){
					//accept
				}else{
					return false;
				}

			}
		}
		
		return true;
	}

	/**
	 * compare two strings
	 * @return true if equal
	 */
	public static boolean equalsIncludeEmpty(String s1, String s2) {
		if ((StringUtil.isEmpty(s1)) && (StringUtil.isEmpty(s2))) return true;
		if (s1 != null) {
			if (s2 == null) {
				return false;
			} else {
				return s1.equals(s2);
			}
		}
		
		return false;
	}
	
	/**
	 * append the newStrs at the end of input strs and return the new string array 
	 * @param strs
	 * @param newstrs
	 * @return
	 */
	public static String[] append(String[] strs, String[] newStrs){
	    if (strs==null)
	        return newStrs;
	    if (newStrs==null)
	        return strs;
	    
	    String[] retStrs = new String[strs.length+newStrs.length];
	    for (int i = 0; i < strs.length ; i ++) {
	        retStrs[i] = strs[i];
	    }
	    for (int i = 0; i < newStrs.length ; i ++) {
	        retStrs[strs.length+i] = newStrs[i];
	    }
	    return retStrs;
	}
	
	
	/**
	 * Convert to printable string (replace space char with non-printable character
	 * @param instr the string to be converted.
	 * @return String printable string
	 */
	public static String replaceNonPrintableLatinChar(String instr) {
		
		if(instr==null)
			return instr;

		char[] c = instr.toCharArray();
		char r[] = new char[c.length];

		int count = 0;
		for (int i = 0; i < c.length; i++) {
			if (((int)c[i] > 126) || ((int)c[i] < 32) ) {
				r[count] = ' ';
			}else {
				r[count] = c[i];
			}
			count++;
		}		

		return new String(r);
	}	

    /**
     * return the string of HEX code of the input string
     * e.g. "ABC **" -> "414243202a2a" 
     * @param string
     * @return
     */
    public static String stringToHex(String string) {
        StringBuffer buffer = new StringBuffer();
        for (int i = 0; i < string.length(); i++) {
            buffer.append(Integer.toHexString(string.charAt(i)));
        }
        return buffer.toString();
    }

	/**
	 * Convert Hex to ASCII in string format
	 * @param hex
	 * @return
	 */
	public static String hexToString(String hex){
	 	String result = "";
	 	String output;
	 	int decimal;
	 	char c;
		
		for( int i=0; i<hex.length()-1; i+=2 ){
			output = hex.substring(i, (i + 2));			// group the hex in pairs
			decimal = Integer.parseInt(output, 16);		// convert hex to decimal
			c = (char)decimal;							// convert decimal to char
			result = result + Character.toString(c);	// convert char to string
		}
		
		return result;
	}

//obsolete: no reference to these 2 methods
//	
//	/**
//	 * @param input : input sentance without \n
//	 * @param limit : a line limit length
//	 * @return : String contain the newline charactor
//	 * Note: the default seperator is space.
//	 */
//	public static String sepWithLength(String input, int limit){
//		return sepWithLength(input," ",limit,false);
//	}
//	
//	/**
//	 * @param input : input sentence.
//	 * @param seperator : using this word to split the sentence.
//	 * @param limit : a line limit length
//	 * @param sepWord : If there is a word greater than than limit, should it split the word with limit.
//	 * @return : String contain the newline charactor
//	 */
//	public static String sepWithLength(String input, String seperator, int limit, boolean sepWord){
//		StringBuffer strBf = new StringBuffer();
//		if(input != null && seperator != null 
//				&& limit > 0 && seperator.length() <= limit){
//			int counter = 0;
//			char newLine = '\n';
//			String[] strArray = input.split(seperator);
//			for(int i=0;i<strArray.length;i++){
//				String str = strArray[i];
//				
//				if(counter + str.length() > limit){
//					if(strBf.length() > 0){
//						strBf.append(newLine);
//					}
//					counter = 0;
//				}
//				if(sepWord){
//					if(str.length() <= limit){
//						counter = counter + str.length();
//						strBf.append(str);					
//					}else{
//						int length = limit - counter;
//						strBf.append(str.substring(0, length));
//						
//						length = limit;
//						String subString = str.substring(length,str.length());
//						while(subString.length()>0){
//							if(length >= subString.length()){
//								length = subString.length();
//							}
//							strBf.append(newLine);
//							strBf.append(subString.substring(0, length));
//							subString = subString.substring(length,subString.length());
//							counter = length;
//						}
//					}
//				}else{
//					counter = counter + str.length();
//					strBf.append(str);	
//				}
//				
//				
//				//add seperator
//				if(i != strArray.length-1){
//					if(counter + seperator.length() > limit){
//						if(strBf.length() > 0){
//							strBf.append(newLine);
//						}
//						counter = 0;
//					}
//					counter = counter + seperator.length();
//					strBf.append(seperator);
//				}
//			}
//		}else{
//			strBf.append(input);
//		}
//		return strBf.toString();
//	}
	
    /**
	 * Convert HKSCS from "ISO/IEC 10646 Compatibility Point" to ISO/IEC 10646-1:2000 (HKSCS-1999 and HKSCS-2001)
	 * 
     * @param inStr string with characters in compatibility points
     * @return string with characters in actual points
     * @throws UnsupportedEncodingException
     */
    public static String convert_Comp_To_2000(String inStr) throws UnsupportedEncodingException{
    	return Big5HKSCSChar.convert_Comp_To_2000(inStr);
    }

    /**
	 * Convert HKSCS from ISO/IEC 10646-1:2000 (HKSCS-1999 and HKSCS-2001) to "ISO/IEC 10646 Compatibility Point"
	 * 
     * @param inStr string with characters in actual points
     * @return string with characters in compatibility points
     * @throws UnsupportedEncodingException
     */
    public static String convert_2000_To_Comp(String inStr) throws UnsupportedEncodingException{
    	return Big5HKSCSChar.convert_2000_To_Comp(inStr);
    }

	/**
	 * Convert Hex to ASCII in string format
	 * @param s
	 * @return true if the input string contains any CJKV (Chinese, Japanese, Korean and Vietnamese).
	 */
    public static boolean containsHanScript(String s) {
        for (int i = 0; i < s.length(); ) {
            int codepoint = s.codePointAt(i);
            i += Character.charCount(codepoint);
            if (Character.UnicodeScript.of(codepoint) == Character.UnicodeScript.HAN) {
                return true;
            }
        }
        return false;
    }
    
//debug only    
//    public static void main(String args[]){
//    	System.out.println(StringUtil.validOfficerNameChin("���j��"));
//    	System.out.println(StringUtil.validOfficerNameChin("�� �j�� "));
//    	System.out.println(StringUtil.validOfficerNameChin("�� �j��,�v����,"));
//    	System.out.println(StringUtil.validOfficerNameChin("���j��e�v����f�I"));
//    	System.out.println(StringUtil.validOfficerNameGrpChin("�� �j��e�v����f�I"));
//    	System.out.println(StringUtil.validOfficerNameGrpChin("�� �j��a�v����b"));
//    }
}
