/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* @(#) PensUpdatePenProfile.java				20/10/2021 	**/
/*                                              			**/
/* Property of Treasury Information Systems Branch, HKSARG	**/
/* All Right Reserved                           			**/
/*                                              			**/
/* SYSTEM                                       			**/
/*       Pension                                			**/
/*                                              			**/
/* AMENDMENT HISTORY                            			**/
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package treasury.pension.batch;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;

import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;

import treasury.payroll.batchcommon.BatchException;
import treasury.payroll.batchcommon.BatchInitException;
import treasury.payroll.batchcommon.BatchUtil;
import treasury.payroll.batchcommon.Journal;
import treasury.payroll.batchcommon.WriteJournalException;
import treasury.payroll.common.DBNotFoundException;
import treasury.payroll.common.DBObject;
import treasury.payroll.common.DBObjectException;
import treasury.payroll.common.DBSecurityException;
import treasury.payroll.common.PaysConfig;
import treasury.payroll.common.PaysConfigException;
import treasury.payroll.common.PaysErrors;
import treasury.payroll.common.UpdateException;
import treasury.payroll.common.User;
import treasury.payroll.common.ValidationException;
import treasury.payroll.statement.Statement;
import treasury.payroll.tranlog.TranLog;
import treasury.payroll.util.BatchJobUtil;
import treasury.payroll.util.ChainedException;
import treasury.payroll.util.DateUtil;
import treasury.payroll.util.FileUtil;
import treasury.payroll.util.FileUtilException;
import treasury.payroll.util.Log;
import treasury.payroll.util.ReportGeneratorException;
import treasury.payroll.util.StringUtil;
import treasury.pension.automail.PensAutomailUtil;
import treasury.pension.batchcommon.PensCommonBatchJob;
import treasury.pension.control.PensSystemNotice;
import treasury.pension.interfaces.ApplicantJson;
import treasury.pension.interfaces.SubmitJson;
import treasury.pension.pays.SyncPAYS;
import treasury.pension.pendtl.PenDtl;
import treasury.pension.pensioner.ApptDtl;
import treasury.pension.pensioner.PenProfile;
import treasury.pension.report.PEN420_01Obj;
import treasury.pension.report.PEN420_02;
import treasury.pension.statement.EformUpdPenProfileLog;
import treasury.pension.util.CodeMappingUtil;
import treasury.pension.util.PensUtil;
import treasury.pension.util.ZipUtil;

public class PensUpdatePenProfile extends PensCommonBatchJob{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	//TODO BATCH_NAME is not confirmed
	// Required
	public final static String BATCH_NAME = "PensUpdatePenProfile";
	public final static int BATCH_INIT_STATUS = -9999;
	
	// no. of input arguments
	/* For exmaple : 
	 * Case 1 : "C:\rationalsdp_george\workspace\pensdev_rad\WebContent\conf\pensdev_rad.conf" 100 199 20/10/2021 - Daily mode
	 * Case 2 : "C:\rationalsdp_george\workspace\pensdev_rad\WebContent\conf\pensdev_rad.conf" 100 199 20/10/2021 12/2021- Monthly mode (For MM/YYYY)
	 * Case 3 : "C:\rationalsdp_george\workspace\pensdev_rad\WebContent\conf\pensdev_rad.conf" 100 199 20/10/2021 03/12/2021 - Adhoc mode for 1 day (on dd/MM/yyyy)
	 * Case 4 : "C:\rationalsdp_george\workspace\pensdev_rad\WebContent\conf\pensdev_rad.conf" 100 199 20/10/2021 03/12/2021 13/12/2021 - Adhoc mode for day range (from dd/mm/yyyy to dd/mm/yyyy)
	 */
//	public final static int NO_OF_ARGUMENTS = 7;
	
	// define arguments
	private Date runDt;
	private String uploadStartDt, uploadEndDt;
	private String runMode;
	
	private Connection conn, atmsConn;
//	private Connection connCprd;
	
	private User user;
	private TranLog dummy;  
	
	private SyncPAYS syncPays = null; // Sync PAYS Object
	
	//Email
//	private List<PEN420_01Obj> emailList = new ArrayList<>();
//	private List<PEN420_01Obj> saveList = new ArrayList<>();
	private final static BigDecimal DEFAULT_RETENTION_DAYS = new BigDecimal("7");
	private final static String DEFAULT_SECURITY = "0";
	private int noPenProfileCnt = 0;
	
	//DateFormat
//	private final static String DATE_FORMAT1 = "yyyy-MM-dd";
	private final static String DATE_FORMAT2 = "dd/MM/yyyy";
		
	public Date getRunDt() {
		return this.runDt;
	}

	public void setRunDt(Date runDt) {
		this.runDt = runDt;
	}
	
	public String getUploadStartDt() {
		return uploadStartDt;
	}

	public void setUploadStartDt(String uploadStartDt) {
		this.uploadStartDt = uploadStartDt;
	}

	public String getUploadEndDt() {
		return uploadEndDt;
	}

	public void setUploadEndDt(String uploadEndDt) {
		this.uploadEndDt = uploadEndDt;
	}
	
	public String getRunMode() {
		return runMode;
	}

	public void setRunMode(String runMode) {
		this.runMode = runMode;
	}

	/**
	 * The static main method to start the batch job.
	 */

	public static void main(String[] args) {
		PensUpdatePenProfile job = new PensUpdatePenProfile();
		try {
			// check input parameters
			if (!job.prepare(args)) {
				throw new ValidationException("Validation Exception");
			} 
			// include date in jobname if needed
			job.setJobName(job.BATCH_NAME + DateUtil.date2Str(DateUtil.parse(args[3]), JOURNAL_DATE_FORMAT));

			// init batch job
			job.initPens();

			// run
			job.run();

		} catch (ValidationException e) {
			showUsage();
			Journal.outJournal(Journal.ERROR, e.getStackString());
		} catch (BatchInitException e) {
			Journal.outJournal(DEFAULT_ERROR, e.getStackString());
		} catch (BatchException e) {
			Journal.outJournal(DEFAULT_ERROR, e.getStackString());
		} catch (Throwable e) {
			ChainedException ce = new ChainedException("Unexpected Exception ", e);
			Journal.outJournal(Journal.ERROR, ce.getStackString());
		} finally {
			System.exit(job.getJobStatus());
		}
	}

	public boolean prepare(String[] args) throws BatchInitException {
		boolean pass = true;

		if (!(args.length>3&&args.length<7)) {
			return false;
		}

		pass = pensPrepareCommonParam(args);

		if (!DateUtil.validate(args[3])) {
			Journal.outJournal(Journal.ERROR, "Invalid Run Date: " + args[3]);
			pass = false;
		}
		
		if (args.length==4&&pass) {
			setRunDt(DateUtil.parse(args[3]));
			setUploadStartDt(args[3]);
			setUploadEndDt(args[3]);
			setRunMode("D");
		}
		if (args.length==5&&pass) {
			String str = args[4];
			//Monthly mode
			if(str.length()==7) {
				if(!"/".equals(str.substring(2, 3))) {
					Journal.outJournal(Journal.ERROR, "Invalid format in month mode input.");
					pass = false;
				}
				try {
					setRunDt(DateUtil.parse(args[3]));
					int month = Integer.parseInt(str.substring(0, 2));
					if(!(month>0&&month<13)) {
						Journal.outJournal(Journal.ERROR, "Invalid format in month mode input.");
						pass = false;
					}else {
						int year = Integer.parseInt(str.substring(3, 7));
						setUploadStartDt(getMonthStartDt(month,year));
						setUploadEndDt(getMonthEndDt(month,year));
						setRunMode("M");
					}
				}catch(Exception e) {
					Journal.outJournal(Journal.ERROR, "Invalid format in month mode input.");
					pass = false;
				}				
			}
			//Adhoc mode only one date input
			if(str.length()==10) {
				try {
					setRunDt(DateUtil.parse(args[3]));
					if (!DateUtil.validate(args[4])) {
						Journal.outJournal(Journal.ERROR, "Invalid Date format : " + args[4]);
						pass = false;
					}else {
						setRunDt(DateUtil.parse(args[3]));
						setUploadStartDt(args[4]);
						setUploadEndDt(args[4]);
						setRunMode("A");
					}
				}catch(Exception e) {
					Journal.outJournal(Journal.ERROR, "Invalid format in Adhoc mode input.");
					pass = false;
				}				
			}	
		}
		//Adhoc mode
		if (args.length==6&&pass) {
			if (!DateUtil.validate(args[4])) {
				Journal.outJournal(Journal.ERROR, "Invalid Date format : " + args[4]);
				pass = false;
			}
			if (!DateUtil.validate(args[5])) {
				Journal.outJournal(Journal.ERROR, "Invalid Date format : " + args[5]);
				pass = false;
			}
			if(pass) {
				setRunDt(DateUtil.parse(args[3]));
				setUploadStartDt(args[4]);
				setUploadEndDt(args[5]);
				setRunMode("A");
			}
		}

		return pass;
	}
	
	
//	public boolean prepare(String[] args) throws BatchInitException {
//		boolean pass = true;
//
//		if (args.length != NO_OF_ARGUMENTS) {
//			return false;
//		}
//
//		pass = pensPrepareCommonParam(args);
//
//		if (!DateUtil.validate(args[3])) {
//			Journal.outJournal(Journal.ERROR, "Invalid Run Date: " + args[3]);
//			pass = false;
//		}
//		if (!DateUtil.validate(args[4])) {
//			Journal.outJournal(Journal.ERROR, "Invalid Uploaded Start Date : " + args[4]);
//			pass = false;
//		}
//		if (!DateUtil.validate(args[5])) {
//			Journal.outJournal(Journal.ERROR, "Invalid Uploaded End Date: " + args[5]);
//			pass = false;
//		}
//		if(!("A".equals(args[6])||"D".equals(args[6])||"M".equals(args[6]))) {
//			Journal.outJournal(Journal.ERROR, "Invalid Run Mode: " + args[6]);
//			pass = false;
//		}
//
//		if(pass) {
//			setRunDt(DateUtil.parse(args[3]));
//			setUploadStartDt(args[4]);
//			setUploadEndDt(args[5]);
//			setRunMode(args[6]);
//		}
//		
//		return pass;
//	}
	
	/**
	 * shows usage info
	 * @param level
	 */
	public static void showUsage() {
		//Daily mode
		Journal.outJournal(Journal.ERROR,
				"Daily mode Usage: [config_file] [start step] [end step] [run date]");
		Journal.outJournal(Journal.ERROR,
				"Parameter rules: Config file (/abc.conf) Start step (10) End step (20) run date (dd/mm/yyyy)") ;
		Journal.outJournal(Journal.ERROR,
				"e.g.: java PensUpdatePenProfile /tmp/pens.conf 10 20 03/05/2019");
		//Monthly mode
		Journal.outJournal(Journal.ERROR,
				"Monthly mode Usage: [config_file] [start step] [end step] [run date] [report target month] ");
		Journal.outJournal(Journal.ERROR,
				"Parameter rules: Start step (10) End step (20) run date (dd/mm/yyyy) report target month (mm/yyyy)") ;
		Journal.outJournal(Journal.ERROR,
				"e.g.: java PensUpdatePenProfile /tmp/pens.conf 10 20 03/05/2019 05/2019");
		//Adhoc mode - report on the specify date
		Journal.outJournal(Journal.ERROR,
				"Adhoc mode (report on the specify date) Usage: [config_file] [start step] [end step] [run date] [report target date]");
		Journal.outJournal(Journal.ERROR,
				"Parameter rules: Start step (10) End step (20) run date (dd/mm/yyyy) report target date (dd/mm/yyyy) ") ;
		Journal.outJournal(Journal.ERROR,
				"e.g.: java PensUpdatePenProfile /tmp/pens.conf 10 20 03/05/2019 02/05/2019");
		//Adhoc mode - report on the specify date range
		Journal.outJournal(Journal.ERROR,
				"Usage: [config_file] [start step] [end step] [run date] [report target date start] [report target date end] ");
		Journal.outJournal(Journal.ERROR,
				"Parameter rules: Start step (10) End step (20) run date (dd/mm/yyyy) report target date start (dd/mm/yyyy) report target date end (dd/mm/yyyy) ") ;
		Journal.outJournal(Journal.ERROR,
				"e.g.: java PensUpdatePenProfile /tmp/pens.conf 10 20 03/05/2019 01/05/2019 15/05/2019 ");
	}	
	
	/**
	 * @see PensCommonBatchJob#pensPrintActionParam()
	 */
	public void pensPrintActionParam() throws BatchException, WriteJournalException {
		writeJournal(Journal.INFO, "      Run Date : " + getRunDt());
	}
	
	public void pensBatchMain() throws BatchException, WriteJournalException{
		setJobStatus(BATCH_INIT_STATUS);
	
		try {
			prepareResources();
			
			
			if("D".equals(getRunMode())) {
				// JobStep 10
				if (BatchJobUtil.writeStartJobStep(this, 10, getSjs(), getEjs())) {
					writeJournal(Journal.INFO, "");
					writeJournal(Journal.INFO, "Move uploaded E-form file");
					
					runStep10();
					
					writeJournal(Journal.INFO, "");
					writeJournal(Journal.INFO, "Finish Move uploaded E-form file");

					BatchJobUtil.writeEndJobStep(this, 10, getSjs());
				}
					
				
				/*
				 * Step 20
				 */
				if (BatchJobUtil.writeStartJobStep(this, 20, getSjs(), getEjs())) {
					writeJournal(Journal.INFO, "");
					writeJournal(Journal.INFO, "Extract zip file to json and data validation");
					
					runStep20(conn,user);
					
					writeJournal(Journal.INFO, "");
					writeJournal(Journal.INFO, "Finish extract zip file to json and data validation");
					
					BatchJobUtil.writeEndJobStep(this, 20, getSjs());
				}
			}
			
			if("M".equals(getRunMode())||"A".equals(getRunMode())) {
				/*
				 * Step 30
				 */
				if (BatchJobUtil.writeStartJobStep(this, 30, getSjs(), getEjs())) {
					writeJournal(Journal.INFO, "");
					writeJournal(Journal.INFO, "Generating report...");
					
					runStep30(conn);
					
					writeJournal(Journal.INFO, "");
					writeJournal(Journal.INFO, "End of generating report");
					
					BatchJobUtil.writeEndJobStep(this, 30, getSjs());
				}
			}
			if (getJobStatus() == BATCH_INIT_STATUS ) {
				setJobStatus(JOB_STT_OK);
			}
			
		} catch (NullPointerException e) {
			handleException(e);
			throw new BatchException("Null pointer Exception", e);
		} catch (BatchException be) {
			handleException(be);
			throw be;
		} catch (PaysConfigException pe) {
			showUsage();
			Journal.outJournal(Journal.ERROR, pe.getStackString());
		} catch (SQLException e) {
			handleException(e);
			Journal.outJournal(Journal.ERROR, e.getMessage());
		} 
		finally {
			PensUtil.removeLock(this, conn, user);
		}
	}
	
	private void prepareResources() throws BatchException, WriteJournalException ,PaysConfigException{
		try {
			conn = getConnForPens();
			atmsConn = BatchUtil.getConn(this, DBObject.DB_ATMS);
			user = getUser();
			dummy = new TranLog(user);
			dummy.setEnableLog(false);

		} catch (DBObjectException e) {
			setJobStatus(JOB_STT_ERROR);
			writeJournal(Journal.ERROR, ">>>> Job Error Message : DBObjectException" + e.getMessage());
			e.setFatal(true);
			throw new BatchException("DBObjectException", e);
		}
	}
	
	
	private void handleException(Throwable t) throws WriteJournalException {
		setJobStatus(JOB_STT_ERROR);
		try {
			conn.rollback();
		} catch (SQLException sqle) {
			writeExceptionJournal(sqle, false);
		}
		writeExceptionJournal(t, false);
	}

	
	/**
	 * Move TFTS file to in file directory
	 */
	private void runStep10() throws BatchException, WriteJournalException {
		try {
			// move the file from upload folder to job working folder
			File fromDir = new File(PaysConfig.getProperty(DBObject.DB_PENS, "_tfts_upload_fileinput_eform"));
			String toDir = PaysConfig.getProperty(DBObject.DB_PENS, "_eform_working")+FileUtil.PATH_SEPARATOR;
	
			//create the processing directory
			File dir = new File(toDir);
			if (!dir.isDirectory()) {
				dir.mkdirs();
			}

			int moveCnt = moveZipFiles(fromDir, toDir, "move");
			
			writeJournal(Journal.INFO, moveCnt+ " File(s) Moved From  " + fromDir);
			writeJournal(Journal.INFO, "              To  " + toDir);
			
		} 
		catch (FileUtilException e) {
			writeJournal(Journal.INFO, "");
			writeJournal(Journal.INFO, e.getMessage());
		}
		catch (ParseException pe) {
			writeJournal(Journal.INFO, "");
			writeJournal(Journal.INFO, "Invalid zip file name convention");
		}
		catch (Exception e) {
			writeJournal(Journal.INFO, "");
			writeJournal(Journal.INFO, ">>>> Job : runStep10()");
			writeJournal(Journal.INFO, ">>>> Job Message : " + e.getMessage());
		}
	}

	public void runStep20(Connection conn,User user) throws WriteJournalException {
		
		try{
			String workingDir = PaysConfig.getProperty(DBObject.DB_PENS, "_eform_working");
			File[] fileArray = new File(workingDir).listFiles();
						
			if (fileArray == null || fileArray.length == 0) {
				writeJournal(Journal.INFO, "runStep20: E-form zip files Not Found" );			 
			} else {
				/*
				 * Assume 
				 * 1. each zip contains only one json file
				 * 2. more than one zip file in the directory
				 * 
				 */
				writeJournal(Journal.INFO, "");
				writeJournal(Journal.INFO, "Extract zip file to json...");
				writeJournal(Journal.INFO, "");
				List<File> fileList = Arrays.asList(fileArray);
				Collections.sort(fileList);
	
				for(int i=0; i<fileList.size(); i++) {
					PEN420_01Obj obj = handleZipToJson(fileList.get(i));
					removeWorkingFile(fileList.get(i));
					updateDb(obj, conn , user);
					archiveFile(fileList.get(i));
				}
				
				//Debug Code
//				for(PEN420_01Obj o :saveList) {
//					writeJournal(Journal.INFO, o.toString());
//				}
			}
			genEmail();
		} 
		catch (Exception e) { 
			e.printStackTrace();
			writeJournal(Journal.INFO, ">>>> Job : runStep20()");
			writeJournal(Journal.INFO, ">>>> Job Message : " + e.getMessage());
		}
	}
	
	private void archiveFile(File file) throws WriteJournalException, FileUtilException, ParseException {
		String toDir = PaysConfig.getProperty(DBObject.DB_PENS, "_eform_backup")+FileUtil.PATH_SEPARATOR+DateUtil.date2Str(runDt,"yyyyMMdd")+FileUtil.PATH_SEPARATOR;

		File theDir = new File(toDir);
		if (!theDir.exists()){
		    theDir.mkdirs();
		}
		
		String fileName = file.getName();
		
		moveFile(file, toDir, fileName, "move");
				
		writeJournal(Journal.INFO, "archive ["+fileName+"] completed");
	}
	
	private void removeWorkingFile(File file) throws WriteJournalException, FileUtilException, ParseException {
		File fromDir = new File(PaysConfig.getProperty(DBObject.DB_PENS, "_eform_working"));

		String extractDirectory = fromDir + FileUtil.PATH_SEPARATOR + file.getName().replaceAll(".zip", "");
				
		boolean result = deleteDirectory(new File(extractDirectory));
		
		if(result)
			writeJournal(Journal.INFO, "Remove temp directory ["+extractDirectory+"] completed");
	}
	

	public void runStep30(Connection conn) throws WriteJournalException, SQLException {
		try{
				if("A".equals(runMode)) {
					if(uploadStartDt.equals(uploadEndDt)) {
						genRpt("ON "+uploadStartDt);
					}else {
						genRpt("FROM "+uploadStartDt +" TO "+uploadEndDt);	
					}
				}else if("M".equals(runMode)) {
					genRpt("FOR " + uploadStartDt.substring(3,10));
				}
				
		} 
		catch (Exception e) { 
			conn.rollback();
			writeJournal(Journal.INFO, ">>>> Job : runStep30()");
			writeJournal(Journal.INFO, ">>>> Job Message : " + e.getMessage());
		}
	}
		
	private void updateDb(PEN420_01Obj jsonObject, Connection conn ,User user) throws WriteJournalException, BatchException, UpdateException, SQLException, ParseException  {
		try {
			Timestamp currentTs = DateUtil.getSystemNow();
				
				//Bypass the object failed the validation
				if("Failed".equals(jsonObject.getUploadStatus())) {
					noPenProfileCnt++;
					writeJournal(Journal.WARN, ">>>> Job Warning : Record rejected : "+jsonObject.toString());
					return;
				}
				
				PenProfile tempPenProfile = new PenProfile();
				try {
					String hkic = jsonObject.getHkic().length()<9?" "+jsonObject.getHkic():jsonObject.getHkic();
					tempPenProfile.defineCriteriaOnHkic(hkic);
					tempPenProfile.loadForUpdate(conn, user);
					
					syncPays = new SyncPAYS(tempPenProfile);
					syncPays.setPenProfileSourceInd(SyncPAYS.CPRD_PN_SOURCE);
					syncPays.sync("Y", "Y", "N", "N", syncPays.isExistInPens(), conn, user);
					syncPays.lock(conn, user);

					tempPenProfile = syncPays.getPenProfile();
					
					List apptDtls = syncPays.getApptDtls(syncPays.ASC_ORDER);
					ApptDtl appDtl = apptDtls.size()==0?null:apptDtls.size()==1?(ApptDtl) apptDtls.get(0):latestSdtApptDtl(apptDtls);
					
					if(appDtl == null) {
						jsonObject.setUploadStatus("Failed");
						noPenProfileCnt++;
						writeJournal(Journal.WARN, ">>>> Job Warning : This ApptDtl record cannot be retrieved.");
						writeJournal(Journal.WARN, ">>>> Job Warning : Record rejected : "+jsonObject.toString());	
						return;
					}
					
					if(appDtl.getEdt()==null) {
						jsonObject.setUploadStatus("Failed");
						noPenProfileCnt++;
						writeJournal(Journal.WARN, ">>>> Job Warning : This ApptDtl End Date is null.");
						writeJournal(Journal.WARN, ">>>> Job Warning : Record rejected : "+jsonObject.toString());	
						return;
					}
					
					if(edtPlusOneAfterRunDt(appDtl.getEdt(),runDt)) {
						jsonObject.setUploadStatus("Failed");
						noPenProfileCnt++;
						writeJournal(Journal.WARN, ">>>> Job Warning : This ApptDtl End Date is greater than program run date.");
						writeJournal(Journal.WARN, ">>>> Job Warning : Record rejected : "+jsonObject.toString());	
						return;
					}
					
					
					
				} catch (DBNotFoundException e) {
					jsonObject.setUploadStatus("Failed");
					noPenProfileCnt++;
					writeJournal(Journal.WARN, ">>>> Job Warning : Record rejected : "+jsonObject.toString());
					return;
				}

				EformUpdPenProfileLog rptObj = new EformUpdPenProfileLog(tempPenProfile,jsonObject,currentTs);
				
				if((tempPenProfile.getPostalZone()!=null&&"09".equals(tempPenProfile.getPostalZone()))||
						(tempPenProfile.getCorrPostalZone()!=null&&"09".equals(tempPenProfile.getCorrPostalZone()))) {					

					int updateCount = rptObj.insert(conn, user);

					if (updateCount != 1) {
						throw new DBObjectException("PEN420_01 Report object store error in PensUpdatePenProfile.updateDb()");
					}
					return;
				}

				tempPenProfile = mergeAttribute(jsonObject,tempPenProfile);
					
	    		PaysErrors ppErrors = syncPays.storeSyncAll(null, tempPenProfile, null, null, null, null, conn, dummy);

				if ( ppErrors.hasErrors()|| ppErrors.hasWarnings() ) {
					Log.writeLog("updateDb", Log.DEBUG, "Store Error");
					jsonObject.setUploadStatus("Failed");
					return;
//	   				throw new UpdateException("DBException");
				}else {
					int updateCount = rptObj.insert(conn, user);

					if (updateCount != 1) {
						throw new DBObjectException("PEN420_01 Report object store error in PensUpdatePenProfile.updateDb()");
					}
				}
				
				writeJournal(Journal.INFO, "updateDb() process completed.");
		}
		catch (DBObjectException e) {
			writeJournal(Journal.ERROR, ">>>> Job Error : DBObjectException in updateDb()");
			writeJournal(Journal.ERROR, ">>>> Job Error Message : " + e.getMessage());
			throw new BatchException("DBObjectException in updateDb()", e);
		}
		catch (DBSecurityException e) {
			writeJournal(Journal.ERROR, ">>>> Job Error : DBSecurityException in updateDb()");
			writeJournal(Journal.ERROR, ">>>> Job Error Message : " + e.getMessage());
			throw new BatchException("DBSecurityException in updateDb()", e);
		}
	
	}
	private ApptDtl latestSdtApptDtl(List apptDtls) {
		ApptDtl apptDtl = (ApptDtl)apptDtls.get(0); 
		for(int i=0;i<apptDtls.size();i++) {
			ApptDtl tmp = (ApptDtl)apptDtls.get(i);
			if(DateUtil.after(tmp.getSdt(), apptDtl.getSdt())) {
				apptDtl = tmp; 
		    }
		}
		return apptDtl;
	}
	
	private PEN420_01Obj handleZipToJson(File file) throws WriteJournalException, DBSecurityException, DBObjectException {
		PEN420_01Obj rpt = null;
		String workingDir = PaysConfig.getProperty(DBObject.DB_PENS, "_eform_working");
		String inFile = workingDir+FileUtil.PATH_SEPARATOR + file.getName();//full name of the zip file
		String extractPath = inFile.replaceAll(".zip", "");
		String jsonPath1 = extractPath + FileUtil.PATH_SEPARATOR + "data"+ FileUtil.PATH_SEPARATOR + "applicant.json";
		String jsonPath2 = extractPath + FileUtil.PATH_SEPARATOR + "data"+ FileUtil.PATH_SEPARATOR + "submit.json";
		try{
			if(ZipUtil.unzip(inFile, extractPath)) {
				writeJournal(Journal.INFO, "");
				writeJournal(Journal.INFO, inFile+" unzipped successfully.");
				
				//Read json file
				Gson gson = new Gson(); 
			    InputStreamReader isr1 = new InputStreamReader(new FileInputStream(jsonPath1), StandardCharsets.UTF_8);
			    InputStreamReader isr2 = new InputStreamReader(new FileInputStream(jsonPath2), StandardCharsets.UTF_8);

		        ApplicantJson applicantJson = gson.fromJson(isr1, ApplicantJson.class);
			    SubmitJson submitJson = gson.fromJson(isr2, SubmitJson.class);
			    			    
			    String hkic = applicantJson.getHkid().getId()+applicantJson.getHkid().getCheckDigit(); 
			    hkic = hkic.length()<9?" "+hkic:hkic;
//			    List<?> penDtl = PenDtl.loadListDistPenType(hkic, conn, user);
			    List<?> penDtl = PenDtl.loadListDistPenTypeWithCancelInputDtIsNull(hkic, conn, user);

				 StringBuilder sb = new StringBuilder();
				 for(int p=0;p<penDtl.size();p++) {
						sb.append(((PenDtl) penDtl.get(p)).getPenType());
						if(p<penDtl.size()-1){
							sb.append(";");
			            }	
				 }

			    rpt = new PEN420_01Obj(applicantJson,submitJson,sb.toString());
			    if(!validateJson(applicantJson)){						    	
			    	rpt.setUploadStatus("Failed");
			    }

			    isr1.close();
			    isr2.close();
			    
			}else {
				writeJournal(Journal.ERROR, "["+inFile+ "] cannot be extracted. Please move the file to somewhere else then rerun this step.");
			}						
		}catch (IOException e) {
			writeJournal(Journal.ERROR, ">> File cannot be unzipped. Please check the disk capacity and report to related person: " + e.getClass().getSimpleName());
		}catch (JsonSyntaxException je) {
			writeJournal(Journal.ERROR, ">> Json Syntax error: " + je.getClass().getSimpleName());
		}catch (JsonIOException je) {
			writeJournal(Journal.ERROR, ">> Json IO error: " + je.getClass().getSimpleName());
		}
		return rpt;

	}
	
	private void genRpt(String rptTitleYear) throws WriteJournalException, BatchException, ReportGeneratorException, SQLException, DBObjectException, DBSecurityException, ParseException {
//		writeJournal(Journal.INFO, "Generating report PEN420-01 report...");
//		writeJournal(Journal.INFO, "");
//		PEN420_01.writeReport(saveList,DateUtil.getToday(),this, conn, user);
//		writeJournal(Journal.INFO, "End of Generating report PEN420-01 report");
//		writeJournal(Journal.INFO, "");
		
		if("A".equals(getRunMode())||"M".equals(getRunMode())) {
//			writeJournal(Journal.INFO, "Generating report PEN420-01 report...");
//			writeJournal(Journal.INFO, "");
//			
//			PEN420_02.writeReport(noPenProfileCnt, uploadStartDt, uploadEndDt,rptTitleYear, DateUtil.getToday(),"M".equals(getRunMode())?true:false, this, conn, user);
//			
//			writeJournal(Journal.INFO, "End of Generating report PEN420-01 report");
//			writeJournal(Journal.INFO, "");	
			writeJournal(Journal.INFO, "Generating report PEN420-01 report...");
			writeJournal(Journal.INFO, "");
			
			PEN420_02.writeReport(noPenProfileCnt, uploadStartDt, uploadEndDt,rptTitleYear, runDt,"M".equals(getRunMode())?true:false, this, conn, user);
			
			writeJournal(Journal.INFO, "End of Generating report PEN420-01 report");
			writeJournal(Journal.INFO, "");
		}
				
	}

	private String getMonthStartDt(int mm,int yyyy) {
        int dd =  15;
        mm--;

        Calendar cale = Calendar.getInstance();
//        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT2);
        cale = Calendar.getInstance();
        cale.set(yyyy, mm, dd);
        cale.add(Calendar.MONTH, 0);
        cale.set(Calendar.DAY_OF_MONTH, 1);
        return format.format(cale.getTime());
	}
	
	private String getMonthEndDt(int mm,int yyyy) {
        int dd =  15;
        mm--;

        Calendar cale = Calendar.getInstance();
        SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT2);
        cale = Calendar.getInstance();
        cale.set(yyyy, mm, dd);
        cale.add(Calendar.MONTH, 1);
        cale.set(Calendar.DAY_OF_MONTH, 0);
        return format.format(cale.getTime());
	}
	
    private boolean edtPlusOneAfterRunDt(Date eDt, Date runDt) {
//        Calendar c = Calendar.getInstance();
//        c.setTime(eDt);
//        c.add(Calendar.DATE, 1);
//        Date eDtPlusOne = new Date(c.getTimeInMillis());
//
//        return eDtPlusOne.after(runDt);
    	Date eDtPlusOne = DateUtil.addDate(eDt, 0, 1);
    	return DateUtil.after(eDtPlusOne, runDt);
    }
	
	//Logic copied from validPenProfile(PenProfile pp)
	private boolean validateJson (ApplicantJson json) {
		boolean isOk = true;
		
		///Email validation
		if(json.getEmail()!=null&&!validEmailAddress(json.getEmail())) {
			isOk = false;
		}
		
		//phone number validation
		if(json.getPhone1()!=null&&!validPhoneNum(json.getPhone1())) {
			isOk = false;
		}
		if(json.getPhone2()!=null&&!validPhoneNum(json.getPhone2())) {
			isOk = false;
		}
		if(json.getFax()!=null&&!validPhoneNum(json.getFax())) {
			isOk = false;
		}
		//Country code validation		
		if(json.getCorrCountryRegion()!=null&&!validCountryCode(json.getCorrCountryRegion())){
			isOk=false;
		}
		if(json.getResCountryRegion()!=null&&!validCountryCode(json.getResCountryRegion())){
			isOk=false;
		}

		//Address validation 
		if(json.getEngResAddrLine1()!=null&&!validAddress(json.getEngResAddrLine1(),json.getEngResAddrLine2(),json.getEngResAddrLine3())) {
			isOk=false;
		}
		if(json.getEngCorrAddrLine1()!=null&&!validAddress(json.getEngCorrAddrLine1(),json.getEngCorrAddrLine2(),json.getEngCorrAddrLine3())) {
			isOk=false;
		}
		if(json.getChiResAddrLine1()!=null&&!validAddress(json.getChiResAddrLine1(),json.getChiResAddrLine2(),json.getChiResAddrLine3())) {
			isOk=false;
		}
		if(json.getChiCorrAddrLine1()!=null&&!validAddress(json.getChiCorrAddrLine1(),json.getChiCorrAddrLine2(),json.getChiCorrAddrLine3())) {
			isOk=false;
		}

		return isOk;
	}

	
	private boolean validEmailAddress(String emailAddress) {
		String regexPattern = "^(?=.{1,64}@)[A-Za-z0-9_-]+(\\.[A-Za-z0-9_-]+)*@" 
		        + "[^-][A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$";
		return Pattern.compile(regexPattern)
			      .matcher(emailAddress)
			      .matches();
	}
	
	private boolean validPhoneNum(String phoneNum) {
	    String specialCharacters=" ()-0123456789";
	    String str2[]=phoneNum.split("");

	    if(phoneNum.length()>20) {
	    	return false;
	    }
	    for (int i=0;i<str2.length;i++){
	    	if (!specialCharacters.contains(str2[i])){
	    		return false;
		    }		    
		}
	    return true;
	}
	
	private boolean validCountryCode(String countryCode) {
		if("".equals(CodeMappingUtil.conutryCodetoPostalCode(countryCode)))
			return false;
		return true;
	}
	
	private boolean validAddress(String line1,String line2, String line3) {
		if(StringUtil.isEmpty(line1)&&StringUtil.isEmpty(line2)){
			return false;
		}
		
		boolean isHanStr = treasury.pension.util.StringUtil.containsHanScript(line1+line2+line3);
		if(isHanStr) {
			if(line1.length()>20||line2.length()>20||(line3!=null&&line3.length()>20)) {
		    	return false;
		    }
		}else {
			if(line1.length()>40||line2.length()>40||(line3!=null&&line3.length()>40)) {
		    	return false;
		    }
		}
		return true;
	}
	
	private static java.sql.Date strToDate(String strDate) throws ParseException { 
		java.util.Date d = new SimpleDateFormat("dd/MM/yyyy").parse(strDate); 
		java.sql.Date date = new java.sql.Date(d.getTime()); 
		return date; 
	}
	
	private void genEmail() throws WriteJournalException, BatchException, ParseException {
		try {

			List <EformUpdPenProfileLog> postal09List= EformUpdPenProfileLog.loadList(true, strToDate(uploadStartDt), strToDate(uploadEndDt), conn ,user);
			
			if(postal09List.size()<1) {
				conn.commit();
				atmsConn.commit();
				writeJournal(Journal.INFO,	"");
				writeJournal(Journal.INFO,	"No email needs to generate");
				return;
			}
			
			//Email Related Variables
			StringBuilder subject= new StringBuilder();
			              subject.append("Notification of Personal Particulars Update from a Pensioner from Postal Zone 09");
			              
			//Template need to register to PensSystemNotice.java. However, it is not confirmed by user.			           
			String emailTemp = getEmailTemplate("EF1", runDt, conn, user);
			
			//Almost a restricted structure of retrieve running batchnum for email sending cron job
			//Retrieve the Batch Number from TJ4ATMS_BATCH_NUM for ALL Departments' Emails 
			String batchNum = AtmsBatchNum.getBatchNo("PENS", user, conn).toString();
//			
			
			//Inert Automail Records to database for sending Auto Reminder to B/Ds Coordinators
			StringBuilder sb = new StringBuilder();
			int cnt = 0;
			int mailCnt = 1;
			for(int i=0;i<postal09List.size();i++) {
				EformUpdPenProfileLog record = (EformUpdPenProfileLog) postal09List.get(i);
				if(cnt<20) {
					sb.append(record.getIamSmartNoRefNo()+"\t"+record.getFormSubmitDt()+"\t"+record.getFormSubmitTime()+"\n");
					cnt++;
				}else {
					cnt = 0;					
					insertEmailDetailProcess( emailTemp,  sb, batchNum, mailCnt, subject.toString() , runDt,  conn,  atmsConn,  user);

					sb = new StringBuilder();
					mailCnt++;
					sb.append(record.getIamSmartNoRefNo()+"\t"+record.getFormSubmitDt()+"\t"+record.getFormSubmitTime()+"\n");
					cnt++;
				}
			}
			if(!StringUtils.isEmpty(sb.toString())) {
				insertEmailDetailProcess( emailTemp,  sb, batchNum, mailCnt, subject.toString() , runDt,  conn,  atmsConn,  user);
				TranLog tranLog = new TranLog(user);
				tranLog.setEnableLog(false);
				
				//Generate Automail Control (TJ3) for All Email Details
				insertEmailControl(batchNum, mailCnt , runDt, conn, atmsConn, user);
				conn.commit();
				atmsConn.commit();
				writeJournal(Journal.INFO,	"");
				writeJournal(Journal.INFO,	"Batch No. [" + batchNum + "] with Successful Records [" + mailCnt + "]");
			}
		} catch (DBObjectException | DBSecurityException | SQLException e) {
			e.printStackTrace();
			writeJournal(Journal.ERROR,	">>>> Job Error Message : " + e.getClass().getSimpleName() + " " + e.getMessage());
			throw new BatchException("Exception ", e);
		}
	}
	
	private void insertEmailDetailProcess(String emailTemp, StringBuilder contentSb,String batchNum, 
			int mailCnt,String subject ,Date runDt, Connection conn, Connection atmsConn, User user) throws WriteJournalException, BatchException, SQLException {
		
		String replaceEmailContent = StringUtil.replace(emailTemp, "FORMAT_DATA_LIST", contentSb.toString()); 
		String receivedAddr = PaysConfig.getProperty("pens_eform_receiver_address");
		boolean isInsert = insertEmailDetail(batchNum, runDt, receivedAddr, subject, replaceEmailContent, mailCnt, conn, atmsConn, user);
		if(!isInsert){
			setJobStatus(JOB_STT_WARN);
			Journal.outJournal(Journal.INFO, "");
			Journal.outJournal(Journal.WARN, "All transactions are rolled back.");
			Journal.outJournal(Journal.WARN, "Please contact User to check the data; Re-run/submit the job if neccessary.");
			conn.rollback();
			atmsConn.rollback();			
		}
		
	}
	
	private static String getEmailTemplate(String category, Date stmtDt, Connection pensConn, User user) throws BatchException{
		List<PensSystemNotice> rsltList = PensSystemNotice.getPensSystemNoticeList(category, PensSystemNotice.LANG_OPT_E, stmtDt, pensConn, user);
		if(rsltList==null || rsltList.size()==0){
			throw new BatchException(" - NO Email Template Found for Category [" + category + "] on " + stmtDt);
		}else if(rsltList.size() > 1){
			throw new BatchException(" - More than 1 Email Template Found for Category [" + category + "] on " + stmtDt);
		}
		return rsltList.get(0).getNoticeMsg();
	}
	
	
	
//	private List<PEN420_01Obj> mockPEN420_01ObjList(){
//		List<PEN420_01Obj> list = new ArrayList<>();
//		PEN420_01Obj obj = new PEN420_01Obj();
//		for(int i=0;i<42;i++) {
//			String generatedString = RandomStringUtils.randomAlphabetic(10);
//			obj.setIamSmartRefNo(generatedString);
//			obj.setSubmissionDate(generatedString);
//			obj.setSubmissionTime(generatedString);
//			list.add(obj);
//		}
//		return list;
//	}
	
	private boolean insertEmailDetail(String batchNum, Date runDt, String receiverAddr, String subject, String emailContent, int rcrdNum, Connection connPens, Connection connAtms, User user){
		try{
			String status = AtmsBatchLog.STT_QUEUED;	//Must set to Queue. Otherwise, exceptions throw from the Common Function
			
			int attachCnt = 0;
			Date stmtDt = runDt;
			String[] stmtNums = new String[]{""};
			String[] stmtTypes = new String[]{""};
			String[] attachmentNames = new String[]{""};
			String[] attachmentExt = new String[]{""};
			InputStream[] attachments = null;
			
			boolean isSaved = false;
			//Insert Records into Automail Detail for Departmental Coordinators 
			isSaved = PensAutomailUtil.storeRecordLog(
					this, DBObject.DB_PENS, batchNum, rcrdNum, 
					null, null, receiverAddr, subject, emailContent, 
					null, stmtDt, new BigDecimal(attachCnt), stmtNums, stmtTypes, 
					DEFAULT_SECURITY, status, new BigDecimal(attachCnt), attachmentNames, attachmentExt, attachments, false, user, connPens, connAtms);
			if(!isSaved){
				Journal.outJournal(Journal.INFO, "(Fail) Problem: Sending e-form confimation (Automail Detail) To Email Records [" + receiverAddr + "]");
				return false;
			}
			Journal.outJournal(Journal.INFO, "( OK )        : Genenerated e-form confimation (Automail Detail) To Email Records [" + receiverAddr + "]");
			return true;
			
		}catch(Exception e){
			Journal.outJournal(Journal.INFO,	"(Fail) Problem: Other Issue - " + e.getMessage());
			return false;
		}
		
	}
	
	private void insertEmailControl(String batchNum, int rcrdNum, Date runDt, Connection pensConn, Connection atmsConn, User user) throws WriteJournalException, BatchException{
		try{
			
			Date stmtDt = runDt;
			String stmtType = AtmsBatchLog.STMT_TYPE_RUN_OPT_MONTHLY;
			String batchStatus = StringUtil.equalsIgnoreCase(PaysConfig.getEnv(), PaysConfig.DEV) ? AtmsBatchLog.STT_HOLD : AtmsBatchLog.STT_QUEUED;
			String sendAddr = PaysConfig.getProperty("pens_sender_address");
					
			PensAutomailUtil.storeBatchLog(this, DBObject.DB_PENS, batchNum, rcrdNum, 
					stmtDt, stmtType, batchStatus, Statement.SENDER_NAME, sendAddr, 
					DEFAULT_RETENTION_DAYS, false, user, pensConn, atmsConn);
			
		}catch(Exception e){
			writeJournal(Journal.ERROR,	">>>> Job Error Message : " + e.getClass().getSimpleName() + " " + e.getMessage());
			throw new BatchException("Exception ", e);
		}
		
	}

	//** Standard Methods Copied from Pnpp05Process
	/**
	 * Updates database object to the database.
	 * @param result the <code>PaysResult</code> object. 
	 * @param conn the <code>Connection</code> object.
	 * @param user the <code>User</code> object.
	 * @throws UpdateException
	 * @throws SQLException 
	 * @throws ParseException 
	 */
//	public void updateDb(PaysResult result, Connection conn, User user) throws UpdateException {
//		int updateCount = 0;		
//		Log.writeLog("Process", Log.DEBUG, "Update Database");
//		
//		try{			
//    		boolean deleteInd = false;
//    		if ( penProfile.isDeleted() ) {
//    			deleteInd = true;
//    		}
//    		
//			if ( penProfile.getDBImage() != null ) {
//				PenProfile tempPenProfile = (PenProfile)penProfile.getDBImage();
//				if ( !StringUtil.equals(penProfile.getMaritalStt(), tempPenProfile.getMaritalStt() ) ) {
//					penProfile.setMaritalSttUdt(DateUtil.getToday());
//				}
//				if ( !penProfile.getLangOpt().equals(tempPenProfile.getLangOpt()) ) {
//					penProfile.setLangOptUdt(DateUtil.getToday());
//				}
//				if ( !penProfile.getEmailOpt().equals(tempPenProfile.getEmailOpt()) ) {
//					penProfile.setEmailOptUdt(DateUtil.getToday());
//				}
//			} else {
//				if ( !StringUtil.isEmpty(penProfile.getMaritalStt()) ) {
//					penProfile.setMaritalSttUdt(DateUtil.getToday());
//				}
//			}
//			
//			// Auto move the telNum2 to telNum1 if telNum1 is null and telNum2 is not null
//			if (StringUtil.isEmpty(penProfile.getTelNum1()) && !StringUtil.isEmpty(penProfile.getTelNum2())) {
//				penProfile.setTelNum1(penProfile.getTelNum2());
//				penProfile.setTelNum2("");
//			}
//			
//    		//updateCount = penProfile.store(conn, result.getTranLog());
////	    		PaysErrors ppErrors = syncPays.storeSync(null, penProfile, null, null, null, null, conn, result.getTranLog());
//    		PaysErrors ppErrors = syncPays.storeSyncAll(null, penProfile, null, null, null, null, conn, result.getTranLog());
//    		if (ppErrors.hasErrors() || ppErrors.hasWarnings()) {
//	    		result.addErrors(ppErrors);
//    		}
//
////				if (updateCount != 1) {
//			if ( ppErrors.hasErrors() ) {
//				Log.writeLog("updateDb", Log.DEBUG, "Store Error");
//				Log.writeLog("updateDb", Log.DEBUG, "Update Count = " + updateCount);
//   				throw new UpdateException("DBException");
//			}
//			
//			for (int i = penProfile.getPenProfileDtls().size() - 1; i >= 0; i--) {
//				if ( !(deleteInd) || penProfile.getPenProfileDtl(i).getDBImage() != null ) {
//					updateCount = penProfile.getPenProfileDtl(i).store(conn, result.getTranLog());
//					
//					if (updateCount != 1) {
//						Log.writeLog("updateDb", Log.DEBUG, "Store Error");
//						Log.writeLog("updateDb", Log.DEBUG, "Update Count = " + updateCount);
//   						throw new UpdateException("DBException");
//					}
//				}
//			}
//		} catch(DBObjectException dbe){
//			Log.writeLog("updateDb", Log.DEBUG, dbe.getMessage());
//   			throw new UpdateException("DBObjectException", dbe);
//    	} catch(DBSecurityException dbse){
//    		Log.writeLog("updateDb", Log.DEBUG, dbse.getMessage());
//    		throw new UpdateException("DBSecurityException", dbse);
//    	} catch(Exception e){
//			Log.writeLog("updateDb",Log.DEBUG,e.getMessage());
//    		throw new UpdateException("Exception in updateDB", e);
//    	}
//		
//    	Log.writeLog("Process", Log.DEBUG, "Finish Update");
//	}

	public PenProfile mergeAttribute(PEN420_01Obj json,PenProfile dbRecord) {
		if(json.getPhoneNo1()!=null) {
			dbRecord.setTelNum1(json.getPhoneNo1());
			dbRecord.setTelNum2(json.getPhoneNo2()!=null?json.getPhoneNo2():"");
		}else if(json.getPhoneNo1()==null&&json.getPhoneNo2()!=null) {
			dbRecord.setTelNum1(json.getPhoneNo2());
			dbRecord.setTelNum2("");
		}

		if(json.getFaxNo()!=null)dbRecord.setFaxNum(json.getFaxNo());
		
		if(json.getResCountryCode()!=null) {
			dbRecord.setCountryCode(json.getResCountryCode());
			dbRecord.setPostalZone(CodeMappingUtil.conutryCodetoPostalCode(json.getResCountryCode()));
			if("y".equals(json.getSameAsRes())) {
				dbRecord.setCorrCountryCode(json.getResCountryCode());
				dbRecord.setCorrPostalZone(CodeMappingUtil.conutryCodetoPostalCode(json.getResCountryCode()));
			}
		}
		
		
		if(json.getResAddress1()!=null) {
//			String str = json.getResAddress1() +json.getResAddress2()!=null?json.getResAddress2():""+json.getResAddress3()!=null?json.getResAddress3():"";
			
			StringBuilder sb = new StringBuilder();
			sb.append(json.getResAddress1()!=null?json.getResAddress1():"");
			sb.append(json.getResAddress2()!=null?json.getResAddress2():"");
			sb.append(json.getResAddress3()!=null?json.getResAddress3():"");
									
			String str = sb.toString();
			
			if(treasury.pension.util.StringUtil.containsHanScript(str)) {
				dbRecord.setAddr1Chin(json.getResAddress1());
				dbRecord.setAddr2Chin(json.getResAddress2());
				dbRecord.setAddr3Chin(json.getResAddress3());
				dbRecord.setAddr1("");
				dbRecord.setAddr2("");
				dbRecord.setAddr3("");
				if("y".equals(json.getSameAsRes())) {
					dbRecord.setCorrAddr1Chin(json.getResAddress1());
					dbRecord.setCorrAddr2Chin(json.getResAddress2());
					dbRecord.setCorrAddr3Chin(json.getResAddress3());
					dbRecord.setCorrAddr1("");
					dbRecord.setCorrAddr2("");
					dbRecord.setCorrAddr3("");
				}
			}else {
				dbRecord.setAddr1(json.getResAddress1());
				dbRecord.setAddr2(json.getResAddress2());
				dbRecord.setAddr3(json.getResAddress3());
				dbRecord.setAddr1Chin("");
				dbRecord.setAddr2Chin("");
				dbRecord.setAddr3Chin("");
				if("y".equals(json.getSameAsRes())) {
					dbRecord.setCorrAddr1(json.getResAddress1());
					dbRecord.setCorrAddr2(json.getResAddress2());
					dbRecord.setCorrAddr3(json.getResAddress3());
					dbRecord.setCorrAddr1Chin("");
					dbRecord.setCorrAddr2Chin("");
					dbRecord.setCorrAddr3Chin("");
				}
			}			
		}
				
		if(json.getCorAddress1()!=null) {
//			String str = json.getCorAddress1() +json.getCorAddress2()!=null?json.getCorAddress2():""+json.getCorAddress3()!=null?json.getCorAddress3():"";
			StringBuilder sb = new StringBuilder();
			sb.append(json.getCorAddress1()!=null?json.getCorAddress1():"");
			sb.append(json.getCorAddress2()!=null?json.getCorAddress2():"");
			sb.append(json.getCorAddress3()!=null?json.getCorAddress3():"");
						
			String str = sb.toString();
			if(treasury.pension.util.StringUtil.containsHanScript(str)) {
				dbRecord.setCorrAddr1Chin(json.getCorAddress1());
				dbRecord.setCorrAddr2Chin(json.getCorAddress2());
				dbRecord.setCorrAddr3Chin(json.getCorAddress3());
				dbRecord.setCorrAddr1("");
				dbRecord.setCorrAddr2("");
				dbRecord.setCorrAddr3("");
			}else {
				dbRecord.setCorrAddr1(json.getCorAddress1());
				dbRecord.setCorrAddr2(json.getCorAddress2());
				dbRecord.setCorrAddr3(json.getCorAddress3());
				dbRecord.setCorrAddr1Chin("");
				dbRecord.setCorrAddr2Chin("");
				dbRecord.setCorrAddr3Chin("");
			}
		}
		if(json.getCorCountryCode()!=null) {
			dbRecord.setCorrCountryCode(json.getCorCountryCode());
			dbRecord.setCorrPostalZone(CodeMappingUtil.conutryCodetoPostalCode(json.getCorCountryCode()));
		}
		
		// Auto move the telNum2 to telNum1 if telNum1 is null and telNum2 is not null
//		if (StringUtil.isEmpty(dbRecord.getTelNum1()) && !StringUtil.isEmpty(dbRecord.getTelNum2())) {
//			dbRecord.setTelNum1(dbRecord.getTelNum2());
//			dbRecord.setTelNum2("");
//		}
		
		if(json.getEmailAddress()!=null&&!StringUtil.isEmpty(json.getEmailAddress())) {
			dbRecord.setEmailAddr(json.getEmailAddress());
			dbRecord.setEmailOpt("Y");
			dbRecord.setEmailOptUdt(DateUtil.getToday());
		}
		
		return dbRecord;
	        	            		
	}

	private boolean deleteDirectory(File directoryToBeDeleted) {
	    File[] allContents = directoryToBeDeleted.listFiles();
	    if (allContents != null) {
	        for (File file : allContents) {
	            deleteDirectory(file);
	        }
	    }
	    return directoryToBeDeleted.delete();
	}

	
	private int moveZipFiles(File inPath, String outPath, String mode) throws FileUtilException, ParseException {		
		File[] dataList = inPath.listFiles();
				
		if (dataList == null || dataList.length == 0) {
			throw new FileUtilException("moveZipFiles: Data File Not Found");
		}
		
		int moveCnt = 0;
		
		for(int i=0; i<dataList.length; i++) {
			String fileName = dataList[i].getName();
			if (!moveFile(dataList[i], outPath, fileName, mode)) {
				throw new FileUtilException("moveZipFiles: Move File FAILED");
			}else {
				moveCnt++;
			}
		}
		return moveCnt;
	}
	
//	private int moveZipFiles(File inPath, String outPath, String uploadStartDt, String uploadEndDt, String mode) throws FileUtilException, ParseException {		
//		File[] dataList = inPath.listFiles();
//		java.util.Date min = new SimpleDateFormat(DATE_FORMAT2).parse(uploadStartDt); 
//		java.util.Date max = new SimpleDateFormat(DATE_FORMAT2).parse(uploadEndDt);
//		
//		if (dataList == null || dataList.length == 0) {
//			throw new FileUtilException("moveZipFiles: Data File Not Found");
//		}
//		
//		int moveCnt = 0;
//		
//		for(int i=0; i<dataList.length; i++) {
//			String fileName = dataList[i].getName();
//			String fileTimestampStr = fileName.substring(0,10);
//			 
//			java.util.Date fileTimeStamp = new SimpleDateFormat(DATE_FORMAT1).parse(fileTimestampStr);
//			
//			if(min.compareTo(fileTimeStamp) * fileTimeStamp.compareTo(max) >= 0) {
//				if (!moveFile(dataList[i], outPath, fileName, mode)) {
//					throw new FileUtilException("moveZipFiles: Move File FAILED");
//				}else {
//					moveCnt++;
//				}
//			}
//		}
//		return moveCnt;
//	}
	
	public boolean moveFile(File file, String outDir, String fileName,String mode){
	 
		try {
			File outFile = new File(outDir + fileName);
			// move the input file to the assigned directory
			if("copy".equals(mode))
				FileUtil.copy(file, outFile, true);
			else if("move".equals(mode))
				FileUtil.move(file, outFile, true);
			else
				throw new Exception("Move mode undefined exception");
		
			return true;
		}
		catch(FileUtilException e) {
			return false;
		}
		catch(Exception e) {
			return false;
		}
	}

	

	
}
