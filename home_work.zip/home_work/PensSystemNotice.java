/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* @(#) PensSystemNotice.java           		20/11/2014  **/
/*                                              			**/
/* Property of Treasury Computer Branch, HKSARG 			**/
/* All Right Reserved                           			**/
/*                                              			**/
/* SYSTEM                                       			**/
/*        Payroll                               			**/
/*                                              			**/
/* AMENDMENT HISTORY                            			**/
/*	Patrick Lau	14/07/2005 - Modify to support PENS			**/
/*	Agnes Chow 20/11/2014 - Modify to support GF539 reminder **/
/*	Agnes Chow 02/11/2016 - Modify to support TRY448 reminder **/
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package treasury.pension.control;

import java.sql.Connection;
import java.util.Date;
import java.util.List;

import treasury.payroll.common.DBObjectException;
import treasury.payroll.common.DBSecurityException;
import treasury.payroll.common.User;
import treasury.payroll.control.SystemNotice;
import treasury.payroll.control.SystemNoticeInterface;
import treasury.payroll.util.SqlRunner;



/**
 * Class declaration
 *
 * @author  Team 1
 * @version 1.0
 */
public class PensSystemNotice extends SystemNotice implements SystemNoticeInterface {

	/**
	 * constant serial version UID make sure always the same
	 */
	public static final String UID 				= DB_PENS+new PensSystemNotice().getDBTableName();
	public static final long serialVersionUID 	= UID.hashCode();

	public static final String NOTICE_CAT_DEF 	= "DEF"; //Statement Message - Deferred Pension
	public static final String NOTICE_CAT_RMD 	= "RMD"; //Email Notification - Reminder Email to User for Signing Pension Notification
	public static final String NOTICE_CAT_PEN 	= "PEN"; //Send PenPaper notice message.
	public static final String NOTICE_CAT_WOSC 	= "WOC"; //Send WOSC notice message.
	public static final String NOTICE_CAT_SAF 	= "SAF"; //Statement Message - Payment Advice (FULL)
	//20141120AC start
	public static final String NOTICE_CAT_GC1 	= "GC1"; //Email Notification - GF539 Email Reminder (to working level of B/D)
	public static final String NOTICE_CAT_GC2 	= "GC2"; //Email Notification - GF539 Email Reminder (to DS/officer with CEO rank or above of B/D) (Senior Level)
	//20141120 end
	// TC20151126 - start
	public static final String NOTICE_CAT_AP2 	= "AP2"; //Email Notification to B/D - Benefits Statement (Normal)
	public static final String NOTICE_CAT_AP3 	= "AP3"; //Email Notification to B/D - Benefits Statement (SR/PLS)
	public static final String NOTICE_CAT_AP4 	= "AP4"; //Online Message - Benefits Statement via EPAY - Notice 1
	public static final String NOTICE_CAT_AP5 	= "AP5"; //Online Message - Benefits Statement via EPAY - Notice 2
	
	//AC20161102 start
	public static final String NOTICE_CAT_AP6 = "AP6"; //Email Notification to Pensioner - Benefits Statement (Normal) in EPAY
	public static final String NOTICE_CAT_AP7 = "AP7"; //Email Notification to Pensioner - Benefits Statement (SR/PLS) in EPAY
	//AC20161102 end
	
	// TC20151126 - end

	public static final String NOTICE_CAT_SR1 = "SR1"; //Email Notification - Sampling (Reminder 1)
	public static final String NOTICE_CAT_SR2 = "SR2"; //Email Notification - Sampling (Reminder 2)
	
	public static final String NOTICE_CAT_PAM = "PAM"; //PN01 = Email Content - Payment Advice (Monthly)
	public static final String NOTICE_CAT_PAD = "PAD"; //PN03 = Email Content - Payment Advice (OCP)
	public static final String NOTICE_CAT_TRE = "TRE"; //PN04 = Email Content - IR56C
	public static final String NOTICE_CAT_DFE = "DFE"; //PN06 = Email Content - Deferred Pension
	public static final String NOTICE_CAT_DR1 = "DR1"; //PN07R1 = Email Notification - Annual Declaration (Reminder 1)
	public static final String NOTICE_CAT_DR2 = "DR2"; //PN07R2 = Email Notification - Annual Declaration (Reminder 2)
	
	public static final String NOTICE_CAT_PR1 = "PR1"; //Email Notification - Post Retirement Contract Service (Annual Call Return)
	public static final String NOTICE_CAT_PR2 = "PR2"; //Email Notification - Post Retirement Contract Service (Retrospective)
	public static final String NOTICE_CAT_PR3 = "PR3"; //Email Auto Reminder - Post Retirement Contract Service (Annual Call Return Reminder)
	public static final String NOTICE_CAT_PR4 = "PR4"; //Email Notification - Post Retirement Contract Service (Review and Update of Re-appointment End Date)
	
	public static final String NOTICE_CAT_PR5 = "PR5";
	
	public static final String NOTICE_CAT_UBL = "UBL";// PensUncheckedBingoCaseNotificationEmailJob

	public static final String NOTICE_CAT_SEL = "SEL"; //Email for Summary of Enquiry Log
	public static final String NOTICE_CAT_EF1 = "EF1"; //Email content - eForm Update Postal Zone 09
	
	/**
	 * for 
	 * 1. DDL on xxxxsn02.jsp page
	 * 2. 1st system notice on system notice form
	 */
	private final static String[] SN02_NOTICE_CAT 	= {
			NOTICE_CAT_DFE, NOTICE_CAT_TRE,
			NOTICE_CAT_PAM, NOTICE_CAT_PAD,
			NOTICE_CAT_DR1, NOTICE_CAT_DR2,
			NOTICE_CAT_GC2, NOTICE_CAT_GC1,
			NOTICE_CAT_RMD,  
			NOTICE_CAT_SR1, NOTICE_CAT_SR2,
			NOTICE_CAT_AP2, NOTICE_CAT_AP3,
			NOTICE_CAT_AP6, NOTICE_CAT_AP7,
			NOTICE_CAT_AP4, NOTICE_CAT_AP5,
			NOTICE_CAT_DEF, NOTICE_CAT_56C,
			NOTICE_CAT_SAL, NOTICE_CAT_SAF,
			NOTICE_CAT_UBL, NOTICE_CAT_PR1,
			NOTICE_CAT_PR2, NOTICE_CAT_PR3,
			NOTICE_CAT_PR4, NOTICE_CAT_PR5,
			NOTICE_CAT_SEL, NOTICE_CAT_EF1
			
	};

	/**
	 * @see SystemNoticeInterface#getSn02NoticeCatBySystemAbbr(String)
	 */
	public String[] getSn02NoticeCatBySystemAbbr() {
		return SN02_NOTICE_CAT;
	}
	
	public void defineCriteria4DeferredStmt(String noticeCat, Date stmtDt) {
		SqlRunner sqlRunner = new SqlRunner();
		sqlRunner.append("c98notice_cat = ?");
		sqlRunner.append(" AND c98sdt <= ? AND (c98edt is NULL OR c98edt >= ?)");

		sqlRunner.addParam(noticeCat);
		sqlRunner.addParam(stmtDt);
		sqlRunner.addParam(stmtDt);
		storeCriteria(sqlRunner);
	}
	
	public void defineCriteriaOnCategory(String noticeCat, String langOpt) {
		SqlRunner sqlRunner = new SqlRunner();
		sqlRunner.append("c98notice_cat = ?").append(" AND c98lang_opt = ? ");
		sqlRunner.addParam(noticeCat).addParam(langOpt);
		storeCriteria(sqlRunner);
	}

	public void defineCriteriaOnCategoryDt(String noticeCat, String langOpt, Date stmtDt) {
		SqlRunner sqlRunner = new SqlRunner();
		sqlRunner.append("c98notice_cat = ?");
		sqlRunner.append(" AND c98lang_opt = ?");
		sqlRunner.append(" AND c98sdt <= ? AND (c98edt is NULL OR c98edt >= ?)");

		sqlRunner.addParam(noticeCat);
		sqlRunner.addParam(langOpt);
		sqlRunner.addParam(stmtDt);
		sqlRunner.addParam(stmtDt);
		storeCriteria(sqlRunner);
	}
	
	public static List<PensSystemNotice> getPensSystemNoticeList(String category, String langOpt, Date stmtDt, Connection conn, User user){
		try {
			PensSystemNotice sysNotice = new PensSystemNotice();
			sysNotice.defineCriteriaOnCategoryDt(category, langOpt, stmtDt);
			return sysNotice.loadList(conn, user);
		} catch (DBObjectException | DBSecurityException e) {
			return null;
		} 
	}
	
}

/*--- formatting done in "Treasury Payroll Convention" style on 02-21-2002 ---*/