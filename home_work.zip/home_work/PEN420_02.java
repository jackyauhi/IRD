/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* @(#) PEN321_01.java        				   07/02/2007 	**/
/*                                              			**/
/* Property of Treasury Computer Branch, HKSARG 			**/
/* All Right Reserved                           			**/
/*                                              			**/
/* SYSTEM                                       			**/
/*       PENSION                                			**/
/*                                              			**/
/* AMENDMENT HISTORY                            			**/
/*	Patrick Chan	  07/02/2007 - creation				    **/
/*                 											**/
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package treasury.pension.report;

import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Vector;

import org.apache.commons.lang.StringUtils;

import treasury.payroll.batchcommon.CommonBatchJob;
import treasury.payroll.batchcommon.Journal;
import treasury.payroll.batchcommon.WriteJournalException;
import treasury.payroll.common.DBObject;
import treasury.payroll.common.DBObjectException;
import treasury.payroll.common.DBSecurityException;
import treasury.payroll.common.PaysResult;
import treasury.payroll.common.ReportWriter;
import treasury.payroll.common.User;
import treasury.payroll.report.Report;
import treasury.payroll.report.ReportUtil;
import treasury.payroll.report.RptRegistry;
import treasury.payroll.tranlog.TranLog;
import treasury.payroll.util.DateUtil;
import treasury.payroll.util.PaysLocale;
import treasury.payroll.util.ReportGenerator;
import treasury.payroll.util.ReportGeneratorException;
import treasury.payroll.util.ReportLine;
import treasury.payroll.util.StringUtil;
import treasury.pension.statement.EformUpdPenProfileLog;
import treasury.pension.statement.FullStmtLog;
import treasury.pension.util.CodeMappingUtil;
import treasury.pension.util.CsvReportGenerator;

/**
 * Class for generation for SUMMARY FOR REQUEST OF CHANGE OF PENSIONER'S PERSONAL 
 * PARTICULARS VIA IAM SMART+ FOR MM/YYYY
 *
 * @author  Team 4
 * @version 1.0
 */

public class PEN420_02 extends ReportWriter {

	public static final String REPORT_ID = "PEN420-01";
	private static String REPORT_TITLE = "";
	private final static String PART1_TITLE[] = { "PART 1: POSTAL ZONE 09","Existing record in PENS","Request(s) submitted by pensioners (Note 2)"};
	private final static String PART2_TITLE[] = {"PART 2: OTHER THAN POSTAL ZONE 09","Original record in PENS","Request(s) submitted by pensioners (Note 3)"};
	private final static String NO_RECORD_LINE = "No submitted cases";
	public final static String DEFAULT_ERROR = Journal.FATAL;
	private final static String NOTES_CONTENTS[] = {
			"Submission(s) with HKIC that was/were not found in PENS was/were not shown in this report.",
			"These columns show the data submitted by pensioners via iAM Smart+ with original address from postal zone 09 but NOT processed by PENS. Please use \"Input Payee\" ",
			"function of PENS to update the personal particulars of the pensioners where necessary."
			};
	

	private int[] tabs;
	private int[] align;

	/**
	 * constructor
	 */
	public PEN420_02() {

	}


	public static void writeReport(int noPenProfileCnt, String uploadStartDt, String uploadEndDt,
			String pymtYear, Date procDt, boolean isMonthlyReport, CommonBatchJob job, Connection conn, User user) 
					throws DBObjectException, DBSecurityException, ReportGeneratorException, WriteJournalException, SQLException, ParseException {
		try {
			
			RptRegistry rptRegistry = RptRegistry.load(REPORT_ID, conn, user);
			if(rptRegistry==null) {
				job.writeJournal(Journal.INFO, "PEN420_01 cannot be retrieve in rptRegisty.");
				throw new ReportGeneratorException("PEN420_01 cannot be retrieve in rptRegisty.");
			}
			
			Report report = new Report();
			PEN420_02 centralRpt420_02 = new PEN420_02();			
			Timestamp processTime = DateUtil.getSystemNow();
			Timestamp complTime = DateUtil.getSystemNow();
			String rptDest = ReportUtil.genCentralRptFileName(REPORT_ID, processTime, "PNRB01", "4E") + ".csv";
			
			REPORT_TITLE = ReportUtil.getRptEngDesc(conn, user, REPORT_ID, null);		
			if (REPORT_TITLE == null){
				throw new DBObjectException("No report title from report registry for "+ REPORT_ID);			
			}
			REPORT_TITLE = StringUtil.replace(REPORT_TITLE, "MM/YYYY", pymtYear, -1);

			//reading result result from DB and divided into part I list and part II list
			List <EformUpdPenProfileLog> part1List= EformUpdPenProfileLog.loadList(true, strToDate(uploadStartDt), strToDate(uploadEndDt), conn ,user);
			List <EformUpdPenProfileLog> part2List= EformUpdPenProfileLog.loadList(false, strToDate(uploadStartDt), strToDate(uploadEndDt), conn ,user);
			
			
			centralRpt420_02.prepare(REPORT_TITLE, rptDest, CsvReportGenerator.GENERATORTYPE_CSV, user);
			centralRpt420_02.writeReportGeneralInformation(REPORT_TITLE, procDt, user, job);
			centralRpt420_02.writeReportContent(PART1_TITLE, part1List, user, job);
			centralRpt420_02.writeReportContent(PART2_TITLE, part2List, user, job);
			centralRpt420_02.writeNotes(noPenProfileCnt, user);
			if(isMonthlyReport) {
				centralRpt420_02.writeEORLine(user);
			}
			centralRpt420_02.finish(conn, user);
			centralRpt420_02.setReport(report, null, REPORT_ID, processTime, complTime);
			report.insert(conn, new TranLog(user));
			conn.commit();
			
//			job.writeJournal(Journal.INFO, "End of Writing Differences Report.");
			
		} catch (ReportGeneratorException | DBObjectException | DBSecurityException e) {
			job.writeJournal(Journal.INFO, ">>>> Job : " + e.getClass().getSimpleName());
			job.writeJournal(Journal.INFO, ">>>> Job Message : " + e.getMessage());
		}
	}
	
	private static java.sql.Date strToDate(String strDate) throws ParseException { 
		java.util.Date d = new SimpleDateFormat("dd/MM/yyyy").parse(strDate); 
		java.sql.Date date = new java.sql.Date(d.getTime()); 
		return date; 
	}
	
	public void setReport(Report report, String deptCode, String reportId, Timestamp processTime, Timestamp complTime) {
		report.setSystemAbbr(DBObject.DB_PENS);
		report.setRptId(reportId);
		report.setRunDt(DateUtil.getSystemToday());
		report.setRunId("");
		if (deptCode == null) {
			report.setFuncCode("PNRB01");
			report.setSubFuncCode("4E");
			report.setDeptCode("**");
			report.setRptCat(Report.RPT_CAT_CENTRAL);
			report.setFileName(ReportUtil.genCentralRptFileName(reportId, processTime, "PNRB01", "4E"));
		} else {
			report.setFuncCode("******");
			report.setSubFuncCode("**");
			report.setDeptCode(deptCode);
			report.setRptCat(Report.RPT_CAT_DEPT);
			report.setFileName(ReportUtil.genDeptRptFileName(reportId, processTime, deptCode));
		}
		report.setRptExt(Report.RPT_EXT_CSV);
		report.setProcessTime(processTime);
		report.setComplTime(complTime);
		report.setRptStt(Report.RPT_STT_P);
	}
	
	public void prepare(String rptTitle, String outputFileName, String generatorType, User user) throws ReportGeneratorException {
		rptGenerator = new CsvReportGenerator(1800);
		rptGenerator.setEnc("UTF-8");
		rptGenerator.getInstance(REPORT_ID, rptTitle, ReportUtil.rptId2SystemName(REPORT_ID), ReportGenerator.EMPTY_PASSWORD, outputFileName, ReportGenerator.OVERWRITE, user);
		rptGenerator.setMAX_LINE_NO(Integer.MAX_VALUE);
	}
	
	private void writeReportGeneralInformation(String rptTitle, Date runDt, User user, CommonBatchJob job) throws ReportGeneratorException {
		// Report General Information (e.g. Restricted, System Name, Report Name, Run Date)
		ReportLine rptLine = new ReportLine();
		List<String> cols = new Vector<String>();

		// Line: Restricted
		cols.add(0, FullStmtLog.RESTRICTED_ENG_UPPER);
		rptLine.setValues(cols);
		rptGenerator.writeln(rptLine, user);

		// Line: Pension Management System
		cols = new Vector<String>();
		cols.add(0, PaysLocale.getMessage(PaysLocale.LOCALE_ENG, "pn.project.title").toUpperCase());
		rptLine.setValues(cols);
		rptGenerator.writeln(rptLine, user);

		// Line: Run Date in dd/MM/yyyy
		cols = new Vector<String>();
		cols.add(0, "DATE: " + DateUtil.date2Str(runDt));
		rptLine.setValues(cols);
		rptGenerator.writeln(rptLine, user);

		// Line: Report ID
		cols = new Vector<String>();
		cols.add(0, PaysLocale.getMessage(PaysLocale.LOCALE_ENG, "label.rptId").toUpperCase() + ": " + REPORT_ID);
		rptLine.setValues(cols);
		rptGenerator.writeln(rptLine, user);

		// Line: Report Title
		cols = new Vector<String>();
		cols.add(0, rptTitle);
		rptLine.setValues(cols);
		rptGenerator.writeln(rptLine, user);

		// Line: Blank Line
		this.writeBlankLine(user);
	}
	
	private void writeBlankLine(User user) throws ReportGeneratorException {
		ReportLine rptLine = new ReportLine();
		List<String> cols = new Vector<String>();

		cols = new Vector<String>();
		cols.add(0, "");
		rptLine.setValues(cols);
		rptGenerator.writeln(rptLine, user);
	}
	
	private void writeNotes(int noPenProfileCnt, User user) throws ReportGeneratorException {
		
		// Line: Blank Line
		for(int i=0;i<3;i++) {
			this.writeBlankLine(user);
		}
		ReportLine rptLine = new ReportLine();
		List<String> cols = new Vector<String>();

		cols = new Vector<String>();
		cols.add(0, "Notes:");
		rptLine.setValues(cols);
		rptGenerator.writeln(rptLine, user);

		int idx = 1;
		for(String note:NOTES_CONTENTS) {
			cols = new Vector<String>();
			cols.add(0, String.valueOf(idx++));
			cols.add(1, note);
			rptLine.setValues(cols);
			rptGenerator.writeln(rptLine, user);
		}
		
//		Revised on 17/01/2022, By George Lam
//		cols = new Vector<String>();
////		cols.add(0, String.valueOf(noPenProfileCnt));
//		cols.add(0, "1");
//		cols.add(1, "Submission(s) with HKIC that was/were not found in PENS was/were not shown in this report.");
//		rptLine.setValues(cols);
//		rptGenerator.writeln(rptLine, user);
		
	}
	
	private void writeEORLine(User user) throws ReportGeneratorException {
		// Line: Blank Line
		for(int i=0;i<5;i++) {
			this.writeBlankLine(user);
		}
		ReportLine rptLine = new ReportLine();
		List<String> cols = new Vector<String>();

		cols = new Vector<String>();
		for(int idx = 0;idx<30;idx ++) {
			if(idx == 0) {
				cols.add(idx, "To be completed by Treasury:");
			}else {
				cols.add(idx, "");
			}
		}
		rptLine.setValues(cols);
		rptGenerator.writeln(rptLine, user);
		
		cols = new Vector<String>();
		for(int idx = 0;idx<30;idx ++) {
			if(idx == 0) {
				cols.add(idx, "Follow-up by:");
			}else if(idx == 4){
				cols.add(idx, "Reviewed by:");  
			}else {
				cols.add(idx, "");
			}
		}
		rptLine.setValues(cols);
		rptGenerator.writeln(rptLine, user);
		
		for(int i=0;i<5;i++) {
			this.writeBlankLine(user);
		}
		
		cols = new Vector<String>();
		for(int idx = 0;idx<30;idx ++) {
			if(idx == 0) {
				cols.add(idx, "------------------");
			}else if(idx == 4){
				cols.add(idx, "------------------");  
			}else {
				cols.add(idx, "");
			}
		}
		rptLine.setValues(cols);
		rptGenerator.writeln(rptLine, user);
		
		cols = new Vector<String>();
		for(int idx = 0;idx<30;idx ++) {
			if(idx == 0) {
				cols.add(idx, "(Rank equivalent to ACO/CO or above)");
			}else if(idx == 4){
				cols.add(idx, "(Rank equivalent to SCO/AO or above)  ");  
			}else {
				cols.add(idx, "");
			}
		}
		rptLine.setValues(cols);
		rptGenerator.writeln(rptLine, user);
		
	}
	
	private void writeReportContent(String[] partTitle, List<EformUpdPenProfileLog> rptList, 
			User user, CommonBatchJob job) throws ReportGeneratorException {
		ReportLine rptLine = new ReportLine();
		List<String> cols = new Vector<String>();

		// Table Header 
		cols = new Vector<String>();
		for(int idx = 0;idx<36;idx ++) {
			if(idx == 0) {
				cols.add(idx, partTitle[0]);
			}else if(idx == 9) {
				cols.add(idx, partTitle[1]);
			}else if(idx == 29) {
				cols.add(idx, partTitle[2]);
			}else {
				cols.add(idx, "");
			}
		}
		rptLine.setValues(cols);
		rptGenerator.writeln(rptLine, user);

		// Column Header 
		cols = genColHeader();
		rptLine.setValues(cols);
		rptGenerator.writeln(rptLine, user);
		
		// Result 
		for (EformUpdPenProfileLog row : rptList) {
			writeResults(row, user);
		}
		//Empty report handling
		if(rptList.size()==0) {
			cols = new Vector<String>();
			cols.add(0, NO_RECORD_LINE);
			rptLine.setValues(cols);
			rptGenerator.writeln(rptLine, user);
		}
		this.writeBlankLine(user);
		this.writeBlankLine(user);
		
	}
	
	public List<String> genColHeader() {
		int index = 0;
		List<String> cols = new Vector<String>();		
		cols.add(index++, "iAM Smart+ Ref No.");
		cols.add(index++, "Email account registed in iAM Smart");
		cols.add(index++, "HKIC of iAM Smart + certificate");
		cols.add(index++, "English Name of iAM Smart+ certificate");
		cols.add(index++, "Chinese Name of iAM Smart+ certificate");
		cols.add(index++, "Submission Date");
		cols.add(index++, "Submission Time");
		cols.add(index++, "HKIC");
		cols.add(index++, "Pension Type");
		cols.add(index++, "Residential Address 1");
		cols.add(index++, "Residential Address 2");
		cols.add(index++, "Residential Address 3");
		cols.add(index++, "Residential Address Chinese 1");
		cols.add(index++, "Residential Address Chinese 2");
		cols.add(index++, "Residential Address Chinese 3");
		cols.add(index++, "Residential Conutry Code");
		cols.add(index++, "Residential Postal Zone");
//		cols.add(index++, "Correspondence Address = Residential Address");
		cols.add(index++, "Correspondence Address 1");
		cols.add(index++, "Correspondence Address 2");
		cols.add(index++, "Correspondence Address 3");
		cols.add(index++, "Correspondence Address Chinese 1");
		cols.add(index++, "Correspondence Address Chinese 2");
		cols.add(index++, "Correspondence Address Chinese 3");
		cols.add(index++, "Correspondence Conutry Code");
		cols.add(index++, "Correspondence Postal Zone");
		cols.add(index++, "Phone No.1");
		cols.add(index++, "Phone No.2");
		cols.add(index++, "Fax No.");
		cols.add(index++, "Email address");
		cols.add(index++, "Residential Address 1");
		cols.add(index++, "Residential Address 2");
		cols.add(index++, "Residential Address 3");
		cols.add(index++, "Residential Address Chinese 1");
		cols.add(index++, "Residential Address Chinese 2");
		cols.add(index++, "Residential Address Chinese 3");
		cols.add(index++, "Residential Conutry Code");
		cols.add(index++, "Residential Postal Zone");
		cols.add(index++, "Correspondence Address = Residential Address");
		cols.add(index++, "Correspondence Address 1");
		cols.add(index++, "Correspondence Address 2");
		cols.add(index++, "Correspondence Address 3");
		cols.add(index++, "Correspondence Address Chinese 1");
		cols.add(index++, "Correspondence Address Chinese 2");
		cols.add(index++, "Correspondence Address Chinese 3");
		cols.add(index++, "Correspondence Conutry Code");
		cols.add(index++, "Correspondence Postal Zone");
		cols.add(index++, "Phone No.1");
		cols.add(index++, "Phone No.2");
		cols.add(index++, "Fax No.");
		cols.add(index++, "Email address");

		return cols;
	}

	
	public void writeResults(EformUpdPenProfileLog pen420_02Obj, User user) throws ReportGeneratorException {

		ReportLine rptline = new ReportLine();
		List values =  new Vector();
		int idx = 0;
		values.add(idx++, pen420_02Obj.getIamSmartNoRefNo());
		values.add(idx++, pen420_02Obj.getIamSmartEmailAddr());
		values.add(idx++, pen420_02Obj.getHkic());
		values.add(idx++, commaHandling(pen420_02Obj.getEngName()));
		values.add(idx++, pen420_02Obj.getChiName());
		values.add(idx++, DateUtil.date2Str(pen420_02Obj.getFormSubmitDt()));
		values.add(idx++, pen420_02Obj.getFormSubmitTime());
		values.add(idx++, pen420_02Obj.getHkic());
		values.add(idx++, pen420_02Obj.getPenType());
		values.add(idx++, commaHandling(pen420_02Obj.getAddr1Before()));
		values.add(idx++, commaHandling(pen420_02Obj.getAddr2Before()));
		values.add(idx++, commaHandling(pen420_02Obj.getAddr3Before()));
		values.add(idx++, commaHandling(pen420_02Obj.getAddr1ChinBefore()));
		values.add(idx++, commaHandling(pen420_02Obj.getAddr2ChinBefore()));
		values.add(idx++, commaHandling(pen420_02Obj.getAddr3ChinBefore()));
		values.add(idx++, pen420_02Obj.getCountryCodeBefore());		
		values.add(idx++, pen420_02Obj.getPostalZoneBefore());		
//		values.add(idx++, pen420_02Obj.getSameResaddrCoraddrBefore());
		values.add(idx++, commaHandling(pen420_02Obj.getCorrAddr1Before()));			
		values.add(idx++, commaHandling(pen420_02Obj.getCorrAddr2Before()));			
		values.add(idx++, commaHandling(pen420_02Obj.getCorrAddr3Before()));			
		values.add(idx++, commaHandling(pen420_02Obj.getCorrAddr1ChinBefore()));				
		values.add(idx++, commaHandling(pen420_02Obj.getCorrAddr2ChinBefore()));				
		values.add(idx++, commaHandling(pen420_02Obj.getCorrAddr3ChinBefore()));				
		values.add(idx++, pen420_02Obj.getCorrCountryCodeBefore());
		values.add(idx++, pen420_02Obj.getCorrPostalZoneBefore());
		values.add(idx++, pen420_02Obj.getTelNum1Before());			
		values.add(idx++, pen420_02Obj.getTelNum2Before());			
		values.add(idx++, pen420_02Obj.getFaxNumBefore());			
		values.add(idx++, pen420_02Obj.getEmailAddrBefore());
		
		if(!StringUtils.isEmpty(pen420_02Obj.getAddr1())) {
			StringBuilder sb = new StringBuilder();
			sb.append(pen420_02Obj.getAddr1()!=null?pen420_02Obj.getAddr1():"");
			sb.append(pen420_02Obj.getAddr2()!=null?pen420_02Obj.getAddr2():"");
			sb.append(pen420_02Obj.getAddr3()!=null?pen420_02Obj.getAddr3():"");
									
			String str = sb.toString();
			if(treasury.pension.util.StringUtil.containsHanScript(str)) {
				values.add(idx++, "");					
				values.add(idx++, "");				
				values.add(idx++, "");			
				values.add(idx++, commaHandling(pen420_02Obj.getAddr1()));					
				values.add(idx++, commaHandling(pen420_02Obj.getAddr2()));				
				values.add(idx++, commaHandling(pen420_02Obj.getAddr3()));	
			}else {		
				values.add(idx++, commaHandling(pen420_02Obj.getAddr1()));					
				values.add(idx++, commaHandling(pen420_02Obj.getAddr2()));				
				values.add(idx++, commaHandling(pen420_02Obj.getAddr3()));
				values.add(idx++, "");					
				values.add(idx++, "");				
				values.add(idx++, "");	
			}
		}else {
			values.add(idx++, "");					
			values.add(idx++, "");				
			values.add(idx++, "");			
			values.add(idx++, "");					
			values.add(idx++, "");				
			values.add(idx++, "");	
		}
		values.add(idx++, pen420_02Obj.getCountryCode());
		if(pen420_02Obj.getCountryCode()!=null&&!StringUtils.isEmpty(pen420_02Obj.getCountryCode())) {
			values.add(idx++, CodeMappingUtil.conutryCodetoPostalCode(pen420_02Obj.getCountryCode()));	
		}else {
			values.add(idx++, "");	
		}
		values.add(idx++, pen420_02Obj.getSameResaddrCoraddr());
		if(!StringUtils.isEmpty(pen420_02Obj.getCorrAddr1())) {
			StringBuilder sb = new StringBuilder();
			sb.append(pen420_02Obj.getCorrAddr1()!=null?pen420_02Obj.getCorrAddr1():"");
			sb.append(pen420_02Obj.getCorrAddr2()!=null?pen420_02Obj.getCorrAddr2():"");
			sb.append(pen420_02Obj.getCorrAddr3()!=null?pen420_02Obj.getCorrAddr3():"");
									
			String str = sb.toString();
			if(treasury.pension.util.StringUtil.containsHanScript(str)) {
				values.add(idx++, "");					
				values.add(idx++, "");				
				values.add(idx++, "");			
				values.add(idx++, commaHandling(pen420_02Obj.getCorrAddr1()));			
				values.add(idx++, commaHandling(pen420_02Obj.getCorrAddr2()));			
				values.add(idx++, commaHandling(pen420_02Obj.getCorrAddr3()));	
			}else {		
				values.add(idx++, commaHandling(pen420_02Obj.getCorrAddr1()));					
				values.add(idx++, commaHandling(pen420_02Obj.getCorrAddr2()));				
				values.add(idx++, commaHandling(pen420_02Obj.getCorrAddr3()));
				values.add(idx++, "");					
				values.add(idx++, "");				
				values.add(idx++, "");	
			}
		}else {
			values.add(idx++, "");					
			values.add(idx++, "");				
			values.add(idx++, "");
			values.add(idx++, "");					
			values.add(idx++, "");				
			values.add(idx++, "");
		}
		values.add(idx++, pen420_02Obj.getCorrCountryCode());
		if(pen420_02Obj.getCorrCountryCode()!=null&&!StringUtils.isEmpty(pen420_02Obj.getCorrCountryCode())) {
			values.add(idx++, CodeMappingUtil.conutryCodetoPostalCode(pen420_02Obj.getCorrCountryCode()));	
		}else {
			values.add(idx++, "");	
		}
		
		values.add(idx++, pen420_02Obj.getTelNum1());			
		values.add(idx++, pen420_02Obj.getTelNum2());			
		values.add(idx++, pen420_02Obj.getFaxNum());
		values.add(idx++, pen420_02Obj.getEmailAddr());	

		rptline.setValues(values);
		rptline.setTabs(tabs);
		rptline.setAlign(align);
		rptGenerator.writeln(rptline, user);

	}

	@Override
	public void writeResults(TranLog tlog, PaysResult paysresult, User user) throws ReportGeneratorException {
		// TODO Auto-generated method stub
		
	}
	
	public String commaHandling(String orgStr) {
//		return StringUtils.isEmpty(orgStr)?"":"\'"+orgStr+"\'";
		return StringUtils.isEmpty(orgStr)?"":StringUtils.replace(orgStr, "\"", "\"\"");
	}


}