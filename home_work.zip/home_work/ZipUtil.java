/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* @(#) ZipUtil.java      		                    		**/
/*                                              			**/
/* Property of Treasury Computer Branch, HKSARG 			**/
/* All Right Reserved                           			**/
/*                                              			**/
/* SYSTEM                                       			**/
/*       PENS                             			        **/
/*                                              			**/
/* AMENDMENT HISTORY                            			**/

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
package treasury.pension.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import treasury.payroll.common.PaysConfig;
import treasury.payroll.util.FileUtil;
import treasury.payroll.util.StringUtil;


//import treasury.pension.common.ApplnConfig;

/**
 * This class defines three methods which 
 * 1. combines all the user-selected files into a zip-format file
 * 2. un-zips the specified zip file
 * 3. also counts the entries of files in that zip file
 * 
 * The implementation of these zipping and un-zipping operations is based upon 
 * the ZipOutputStream and ZipInputStream classes in the library java.util.zip.
 * 
 * @author  Team 1
 * @version 1.0
 */
public class ZipUtil {
	
	/* Bytesize to perform zipping */     
	private static final int ByteSize = 1024;
	
	/* zip file name extendion */
	public static final String ZIP_EXT = ".zip";
	
	/* default zip file name */
	public static final String DEF_ZIP_NAME = "cpssZip";
	
  	

 	/**
 	 * This function is based on 7-Zip utility installed in AIX server (or local Windows platform, if applicable).
	 * Given a file (inFilePath) to be zipped, this function helps to produce a zipped file at zippedFilePath.
	 * @param inFilePath
	 * @param zippedFilePath
	 * @return Return true when zip is successful; false when zip is failed.
	 * @throws InterruptedException
	 * @throws IOException
	 */
	public static boolean sevenZip(String inFilePath, String zippedFilePath, String password)
		throws InterruptedException, IOException {

		String command = null;
		
		if (PaysConfig.getProperty("env").equals("dev")) {
			// for unit test purpose in LOCAL machine
			// Windows platform (may need to be customized individually for testing purpose)
						
			// basic zip command
			if(StringUtil.isEmpty(password))
				command = "C:/Program Files/7-Zip/7z a -mem=aes256 " + zippedFilePath + " " + inFilePath;
			else
				command = "C:/Program Files/7-Zip/7z a -mem=aes256 -p" + password + " " + zippedFilePath + " " + inFilePath;			
		} else {
			// AIX platform (ST / UAT)
			
			// basic zip command
			if(StringUtil.isEmpty(password))
				command = "/opt/freeware/bin/7za a -mem=aes256 " + zippedFilePath + " " + inFilePath;
			else
				command = "/opt/freeware/bin/7za a -mem=aes256 -p" + password + " " + zippedFilePath + " " + inFilePath;
		}
		
		Process process = Runtime.getRuntime().exec(command);
		int returnCode = process.waitFor();
		
		if (returnCode == 0) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * This function is based on 7-Zip utility installed in AIX server (or local Windows platform, if applicable).
	 * Given a zipped file (zippedFilePath), this function helps to unzip the file to the target (outFilePath).
	 * @param zippedFilePath
	 * @param outFilePath
	 * @return Return true when unzip is successful; false when unzip is failed.
	 * @throws InterruptedException
	 * @throws IOException
	 */
	public static boolean sevenUnzip(String zippedFilePath, String outFilePath)
		throws InterruptedException, IOException {
		
		String command = null;

		if (PaysConfig.getProperty("env").equals("dev")) {
			// for unit test purpose in LOCAL machine
			// Windows platform (may need to be customized individually for testing purpose)
						
			// basic zip command
			command = "C:/Program Files/7-Zip/7z x " + zippedFilePath + " -o" + outFilePath;			
		} else {
			// AIX platform (ST / UAT)
			
			// basic zip command
			command = "/opt/freeware/bin/7za x " + zippedFilePath + " -o" + outFilePath;
		}			
			
		Process process = Runtime.getRuntime().exec(command);
		int returnCode = process.waitFor();
		
		if (returnCode == 0) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * This method is used to extract the zip file to a destination directory
	 * 
	 * @param zippedFilePath of type {@link File} indicating the source zip file
	 * @param outFilePath of type {@link File} indicating the destination directory where the zip file will be extracted.
	 * @return Return fileName when unzip is successful; null when unzip is failed.
	 * @throws IOException
	 */
	public static boolean unzip(String zippedFilePath, String outFilePath) throws IOException {
 		ZipInputStream zipIn = null;
//		String fileName = null;
		boolean unzipok = true;
		try {
			zipIn = new ZipInputStream(new FileInputStream(new File(zippedFilePath)));
			ZipEntry entry = null;
			while ((entry = zipIn.getNextEntry()) != null) {
				String outFilename = entry.getName();
				if (!new File(outFilePath, outFilename).getParentFile().exists())
					new File(outFilePath, outFilename).getParentFile().mkdirs();

				if (!entry.isDirectory()) {
//					fileName = outFilePath +FileUtil.PATH_SEPARATOR + outFilename;
					OutputStream outStream = new FileOutputStream(new File(outFilePath, outFilename));
					byte[] buff = new byte[1024];
					int len;
					while ((len = zipIn.read(buff)) > 0) {
						outStream.write(buff, 0, len);
					}
					outStream.close();
				}
			}
			return unzipok;
//			System.out.println("Zip file extracted successfully...");
		} catch (Exception e) {
			e.printStackTrace();
			return unzipok = false;
			
		} finally {
			if (zipIn != null) {
				zipIn.close();
			}
		}
	}
}