package ird.taas2.tools.converter;

import java.io.File;

import ird.taas2.tools.CloudConverterMain;

public class RemovingTypeConverter implements DefaultCloudConverter{

	@Override
	public String convert(String fileContent, File inputFile) throws Exception {

// remove this to let the Type exist!!!
//		if (fileContent.contains("BaseDaoIbatisImpl<")) {
//			String replace = fileContent.substring(fileContent.indexOf("BaseDaoIbatisImpl<"));
//			replace = replace.substring(0, replace.indexOf(">")+1);
//			fileContent = fileContent.replaceAll(replace, "BaseDaoIbatisImpl");
//			CloudConverterMain.myBatis2To3Converter.javaChange=true;
//		}
//		if (fileContent.contains("BaseDao<")) {
//			String replace = fileContent.substring(fileContent.indexOf("BaseDao<"));
//			replace = replace.substring(0, replace.indexOf(">")+1);
//			fileContent = fileContent.replaceAll(replace, "BaseDao"
//					+ "");
//			CloudConverterMain.myBatis2To3Converter.javaChange=true;
//		}
//		System.out.println("CloudConverterMain.myBatis2To3Converter.javaChange ="+CloudConverterMain.myBatis2To3Converter.javaChange);
		return fileContent;
	}

}
