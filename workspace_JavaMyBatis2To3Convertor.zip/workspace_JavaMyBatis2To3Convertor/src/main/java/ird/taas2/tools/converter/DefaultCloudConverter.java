/**
 * 
 */
package ird.taas2.tools.converter;

import java.io.File;

/**
 * @author mliu
 *
 */
public interface DefaultCloudConverter {
	public String convert(String fileContent, File inputFile) throws Exception;
}
