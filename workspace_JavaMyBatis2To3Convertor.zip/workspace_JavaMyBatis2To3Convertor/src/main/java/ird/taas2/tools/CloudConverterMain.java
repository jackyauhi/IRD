//Use for Auto Convertor  !!!
/**
 * 
 */
package ird.taas2.tools;

import ird.taas2.tools.converter.DefaultCloudConverter;
import ird.taas2.tools.converter.MyBatis2To3Converter;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.io.FilenameUtils;

/**
 * @author mliu
 * @author jackyau
 */
public class CloudConverterMain {
	private static String ENABLE_JAVA_CONVETERS[] = { 
		"ird.taas2.tools.converter.MyBatis2To3Converter",
		"ird.taas2.tools.converter.MissingSqlMapClientDefinitionConverter",
		"ird.taas2.tools.converter.RemovingTypeConverter"
	};
	
	/**
	 * @param args
	 * @throws Exception 
	 */
	public static ArrayList<String> errorInputList = new ArrayList<String>();
	public static boolean errorHappen=false;
	public static String fileErrorPath="";
	public static int countError;
	public static ArrayList<String> latestFileList = new ArrayList<String>();
	public static boolean haveModelName=false;
	public static MyBatis2To3Converter myBatis2To3Converter=new MyBatis2To3Converter();
	public static String openingPath = new String();
	public static String startFolder;
	public static void main(String[] args) throws Exception {
		countError=0;
		openingPath=args[0];
		String destDirStr = args[1];
		String convertorFilePath=args[2];
		String requireCsvFile =convertorFilePath+"\\outputRequiredFileMain.csv";
		String[] inputSplit = openingPath.split(Pattern.quote("\\"));
		startFolder=inputSplit[inputSplit.length-1];
		try {
			BufferedReader fileReader = new BufferedReader(new FileReader(requireCsvFile));
			String line=null;
		    try {
				while ((line = fileReader.readLine()) != null)
				{	
					String[] dataStore = line.split(",");
					latestFileList.add(dataStore[1]);
			
				}
				fileReader.close();
			} 
		    catch (IOException e1) {
				e1.printStackTrace();
			}
			} 
	   	catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}

		String outputConvertPath =convertorFilePath+"\\outputConvert.txt";
		String errorInputPath =convertorFilePath+"\\errorInput.txt";
		String tempTextFile=convertorFilePath+"\\tempTextFile.txt";
		File fileToDelete;
		fileToDelete=new File(outputConvertPath);
	    if (fileToDelete.exists()) {
	     	fileToDelete.delete();
	    	}
		fileToDelete=new File(errorInputPath);
	    if (fileToDelete.exists()) {
	     	fileToDelete.delete();
	    	}
		int countFile=0;
		ArrayList<String> outputPathList = new ArrayList<String>(); 


		File destDir = null;
		File destDirParent = null;

		
		List<DefaultCloudConverter> cloudConverterList = null;
		try {
			
			cloudConverterList = constructCloudConverters(ENABLE_JAVA_CONVETERS);
			
		} catch (Exception e) {
			errorHappen=true;
			errorInputList.add(fileErrorPath);
			errorInputList.add(e.toString());
			fileErrorPath="";
			throw e;
		}
		

		System.out.println("Cloud Migration programs conversion started ...");
		System.out.println();
		
		Instant start = Instant.now();
		
		try {
			for (int i = 0; i < latestFileList.size(); i++) {
	   			String classifyFile=latestFileList.get(i).toString();
	   			String[] javaFilePath = classifyFile.split(",");
	   			
	   			String[] prdApplicationFolderPath = latestFileList.get(i).toString().split(Pattern.quote(startFolder),2);

				destDir = new File(destDirStr+"\\"+startFolder+prdApplicationFolderPath[1]);
				destDirParent=new File(destDir.getParent());
				if (!destDirParent.exists()) {
					destDirParent.mkdirs();
				}
				File javaFileObj = new File(javaFilePath[0]);
				String fileName =javaFileObj.getName();
				if (fileName.toLowerCase().endsWith(".java")) {
				haveModelName=false;
				String fileContent="";
				BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(javaFilePath[0]),"UTF-8"));
	            String bufferedReaderline;
	            while ((bufferedReaderline = br.readLine()) != null) {
	            	fileContent=fileContent+bufferedReaderline+System.lineSeparator();
	            	if(bufferedReaderline.contains("import")) {
	            		if(bufferedReaderline.contains(".model.")) {
	            			if(fileName.contains("Dao")) {
			            		String [] splitRealModelName =fileName.split("Dao",2);
			            		String [] splitImportModelName =bufferedReaderline.split(".model.",2);
			            		String [] splitRealImportModelName = splitImportModelName[1].split(";");
			            		String realImportModelName ="";
			            		realImportModelName=splitRealImportModelName[0];
			            		if(splitRealImportModelName[0].contains(".")) {
			            			String [] importModelName1 =splitRealImportModelName[0].split("[.]");
			            			realImportModelName=importModelName1[importModelName1.length-1];		
			            		}
			            		if(splitRealModelName[0].equals(realImportModelName)) {
			            			haveModelName=true;
			            		}
	            			}
	            			else if(fileName.contains("DAO")) {
			            		String [] splitRealModelName =fileName.split("DAO",2);
			            		String [] splitImportModelName =bufferedReaderline.split(".model.",2);
			            		String [] splitRealImportModelName = splitImportModelName[1].split(";");
			            		String realImportModelName ="";
			            		realImportModelName=splitRealImportModelName[0];
			            		if(splitRealImportModelName[0].contains(".")) {
			            			String [] importModelName1 =splitRealImportModelName[0].split("[.]");
			            			realImportModelName=importModelName1[importModelName1.length-1];		
			            		}
			            		if(splitRealModelName[0].equals(realImportModelName)) {
			            			haveModelName=true;
			            		}
	            			}
	            		}
	            	}
	            }
				boolean javaChange = false;

				fileErrorPath =javaFileObj.getAbsolutePath();

				for(DefaultCloudConverter cloudConverter : cloudConverterList){
					System.out.println("cloudConverterList.size() = " + cloudConverterList.size());
					System.out.println("cloudConverter = " + cloudConverter);

					fileContent = cloudConverter.convert(fileContent, javaFileObj);
				}
				javaChange=myBatis2To3Converter.javaChange;
				if(javaChange==true) {
					if (!destDir.exists()) {
						destDir.delete();
					}
					
				BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(destDir), StandardCharsets.UTF_8));
			    writer.write(fileContent);
			    writer.close();
			    System.out.println("Processing " + javaFileObj.getAbsolutePath());
			    System.out.println("Updated: " + destDir.getAbsolutePath());
			    System.out.println();
			    outputPathList.add(destDir.getAbsolutePath());
			    countFile++;
				}
			}
		}
		} catch (IOException e) {
			errorHappen=true;
			errorInputList.add(fileErrorPath);
			errorInputList.add(e.toString());
			fileErrorPath="";
			countError++;
			throw e;
		}
		
		Instant finish = Instant.now();
		long timeElapsed = Duration.between(start, finish).toMillis();
		
		System.out.println("Java files conversion completed");
		System.out.println();
		int totalCount = countError+outputPathList.size();
		try {       
       		FileWriter fileWriter = new FileWriter(tempTextFile);
       		fileWriter.write(System.lineSeparator());
       		fileWriter.write("Java Files Count :"+totalCount+System.lineSeparator());
       		fileWriter.write("Convert Java Files Count :"+outputPathList.size()+System.lineSeparator());
       		fileWriter.write("The java files convert list is put in ("+outputConvertPath+")"+System.lineSeparator());
        	if(errorHappen==true) {
        		fileWriter.write("The Error Input List is put in ("+errorInputPath+")");
        	}
       		fileWriter.close();
       	}catch (IOException iox) {
       		iox.printStackTrace();
       		System.out.println("File can not save any data in tempTextFile");
			errorHappen=true;
			errorInputList.add(fileErrorPath);
			errorInputList.add(iox.toString());
			fileErrorPath="";
			countError++;
       	}
		try {       
       		FileWriter fileWriter = new FileWriter(outputConvertPath);
	    	for(int i=0; i<outputPathList.size();i++) {
       		fileWriter.write(outputPathList.get(i).toString()+System.lineSeparator());
	    	}
       		fileWriter.close();
       	}catch (IOException iox) {
       		iox.printStackTrace();
       		System.out.println("File can not save any data in outputPathList");
			errorHappen=true;
			errorInputList.add(fileErrorPath);
			errorInputList.add(iox.toString());
			fileErrorPath="";
			countError++;
       	}
    	if(errorHappen==true) {
    	try {       
       		FileWriter fileWriter = new FileWriter(errorInputPath);
	    	for(int i=0; i<errorInputList.size();i++) {
       		fileWriter.write(errorInputList.get(i).toString()+System.lineSeparator());
	    	}
       		fileWriter.close();
       	}catch (IOException iox) {
       		iox.printStackTrace();
       		System.out.println("File can not save any data in errorInputList");
       	}		        	
    	}

	}

	private static File constructDestPath(File destPath, String javaFilePath) throws Exception{
		try{
			File dest = new File(FilenameUtils.concat(destPath.getAbsolutePath(), FilenameUtils.getPath(javaFilePath)));
			if(!dest.exists()){
				dest.mkdirs();
			}
			
			return dest;
		}catch(Exception e){
			errorHappen=true;
			errorInputList.add(fileErrorPath);
			errorInputList.add(e.toString());
			fileErrorPath="";
			countError++;
			throw e;
		}
	}
	
	private static List<DefaultCloudConverter> constructCloudConverters(String []enabledConverters) throws Exception{
		List<DefaultCloudConverter> cloudConverterList = new ArrayList<DefaultCloudConverter>();
		for(String converter : enabledConverters){
			cloudConverterList.add(constructCloudConverter(converter));
		}
		
		return cloudConverterList;
	}
	private static DefaultCloudConverter constructCloudConverter(String fullQualName) throws Exception{
		return (DefaultCloudConverter)Class.forName(fullQualName).newInstance();
	}
}
