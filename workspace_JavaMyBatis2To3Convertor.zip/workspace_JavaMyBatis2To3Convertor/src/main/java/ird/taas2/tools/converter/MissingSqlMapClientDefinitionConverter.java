package ird.taas2.tools.converter;

import java.io.File;

import ird.taas2.tools.CloudConverterMain;

public class MissingSqlMapClientDefinitionConverter implements DefaultCloudConverter{

	@Override
	public String convert(String fileContent, File inputFile) throws Exception {

		/*bcfsham: check MissingSqlMapClientDefinitionConverterTester for the TEST result*/
		if(fileContent.contains("sqlMapClient\\s*[.]")) {
			CloudConverterMain.myBatis2To3Converter.javaChange=true;
		}
		System.out.println("CloudConverterMain.myBatis2To3Converter.javaChange ="+CloudConverterMain.myBatis2To3Converter.javaChange);
		return fileContent.replaceAll("sqlMapClient\\s*[.]", "getSqlMapClient().");
		
	}

}
