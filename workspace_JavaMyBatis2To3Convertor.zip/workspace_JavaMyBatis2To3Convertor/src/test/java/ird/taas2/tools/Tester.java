package ird.taas2.tools;

import org.junit.Test;

import ird.taas2.tools.converter.MissingSqlMapClientDefinitionConverter;
import ird.taas2.tools.converter.SqlMapClientTemplateInsertCastConverter;

public class Tester {
	

	@Test
	public void testSqlMapClientTemplateInsertCastConverter() {
		SqlMapClientTemplateInsertCastConverter mscdc = new SqlMapClientTemplateInsertCastConverter();
		
		String[] contents = new String[]{
				"(Integer)getSqlMapClientTemplate().insert",
				" (Integer)getSqlMapClientTemplate().insert",
				"(Integer)getSqlMapClientTemplate().insert ",
				" (Integer)getSqlMapClientTemplate().insert ",
				

				"(Integer) getSqlMapClientTemplate().insert",
				" (Integer) getSqlMapClientTemplate().insert",
				"(Integer) getSqlMapClientTemplate().insert ",
				" (Integer) getSqlMapClientTemplate().insert ",
				

				"(Integer)	getSqlMapClientTemplate().insert",
				" (Integer)	getSqlMapClientTemplate().insert",
				"(Integer)	getSqlMapClientTemplate().insert ",
				" (Integer)	getSqlMapClientTemplate().insert ",
				

				"(Integer)\ngetSqlMapClientTemplate().insert",
				" (Integer)\ngetSqlMapClientTemplate().insert",
				"(Integer)\ngetSqlMapClientTemplate().insert ",
				" (Integer)\ngetSqlMapClientTemplate().insert ",
				
				"return (Integer)getSqlMapClientTemplate().insert(\"CtfptpadZmPtwaa1.insertRecord\", ctfptpadZmPtwaa1);"
		};
		
		for (String content : contents) {
			try {
				System.out.println();
				System.out.println("**********BEFORE***********");
				System.out.println(content);
				System.out.println("**********AFTER************");
				System.out.println(mscdc.convert(content, null));
				System.out.println("***********END*************");
				System.out.println();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}
	
//	@Test
	public void testMissingSqlMapClientDefinitionConverter() {
		MissingSqlMapClientDefinitionConverter mscdc = new MissingSqlMapClientDefinitionConverter();
		
		String[] contents = new String[]{
			"sqlMapClient.abc()",
			"sqlMapClient .abc()",
			"sqlMapClient. abc()",
			"sqlMapClient	.abc()",
			"sqlMapClient.	abc()",
			"sqlMapClient	\n.abc()",
			"sqlMapClient.	\nabc()",
			"sqlMapClient\n	.abc()",
			"sqlMapClient\n.	abc()",
			"sqlMapClient	.\nabc()",
			"sqlMapClient.\n	abc()",
			/**/
			" sqlMapClient.abc()",
			" sqlMapClient .abc()",
			" sqlMapClient. abc()",
			" sqlMapClient	.abc()",
			" sqlMapClient.	abc()",
			" sqlMapClient	\n.abc()",
			" sqlMapClient.	\nabc()",
			" sqlMapClient\n	.abc()",
			" sqlMapClient\n.	abc()",
			" sqlMapClient	.\nabc()",
			" sqlMapClient.\n	abc()",
			/**/
			"sqlMapClient.abc() ",
			"sqlMapClient .abc() ",
			"sqlMapClient. abc() ",
			"sqlMapClient	.abc() ",
			"sqlMapClient.	abc() ",
			"sqlMapClient	\n.abc() ",
			"sqlMapClient.	\nabc() ",
			"sqlMapClient\n	.abc() ",
			"sqlMapClient\n.	abc() ",
			"sqlMapClient	.\nabc() ",
			"sqlMapClient.\n	abc() ",
			/**/
			" sqlMapClient.abc() ",
			" sqlMapClient .abc() ",
			" sqlMapClient. abc() ",
			" sqlMapClient	.abc() ",
			" sqlMapClient.	abc() ",
			" sqlMapClient	\n.abc() ",
			" sqlMapClient.	\nabc() ",
			" sqlMapClient\n	.abc() ",
			" sqlMapClient\n.	abc() ",
			" sqlMapClient	.\nabc() ",
			" sqlMapClient.\n	abc() ",
			/**/
			"	sqlMapClient.abc()",
			"	sqlMapClient .abc()",
			"	sqlMapClient. abc()",
			"	sqlMapClient	.abc()",
			"	sqlMapClient.	abc()",
			"	sqlMapClient	\n.abc()",
			"	sqlMapClient.	\nabc()",
			"	sqlMapClient\n	.abc()",
			"	sqlMapClient\n.	abc()",
			"	sqlMapClient	.\nabc()",
			"	sqlMapClient.\n	abc()",
			/**/
			"sqlMapClient.abc()	",
			"sqlMapClient .abc()	",
			"sqlMapClient. abc()	",
			"sqlMapClient	.abc()	",
			"sqlMapClient.	abc()	",
			"sqlMapClient	\n.abc()	",
			"sqlMapClient.	\nabc()	",
			"sqlMapClient\n	.abc()	",
			"sqlMapClient\n.	abc()	",
			"sqlMapClient	.\nabc()	",
			"sqlMapClient.\n	abc()	",
			/**/
			"	sqlMapClient.abc()	",
			"	sqlMapClient .abc()	",
			"	sqlMapClient. abc()	",
			"	sqlMapClient	.abc()	",
			"	sqlMapClient.	abc()	",
			"	sqlMapClient	\n.abc()	",
			"	sqlMapClient.	\nabc()	",
			"	sqlMapClient\n	.abc()	",
			"	sqlMapClient\n.	abc()	",
			"	sqlMapClient	.\nabc()	",
			"	sqlMapClient.\n	abc()	",
		};
		
		for (String content : contents) {
			try {
				System.out.println();
				System.out.println("**********BEFORE***********");
				System.out.println(content);
				System.out.println("**********AFTER************");
				System.out.println(mscdc.convert(content, null));
				System.out.println("***********END*************");
				System.out.println();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}
}
