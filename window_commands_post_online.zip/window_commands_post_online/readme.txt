Step1:

open post online.bat, setup the paths of WinSCP, dbeaver and 7z in the bat script

Step2:

ensure below tadblname in the script is correct, in this case the name set as "dtabats1 - SIT"

%dbpath% -con "driver=db2|host=10.31.90.23|port=50010|database=tadb|name=dtabats1 - SIT|openConsole=true" -nl en

Step3:

run the bat file > input the previous working date with YYYYMMDD format

Step4:

wait for the script run until dbeaver open

Step5:

export TASYS.TBL_HANDSHAKE manually to D:\Round_3_Auto\temp\db dump\temp\TSIT0410_DB_DUMP

export 
TSIT0383.TBL_CTQMQMHNC
TSIT0383.TBL_CTQMQMHNT
TSIT0383.TBL_CTQMQMHOO
TSIT0383.TBL_CTQMQMSNC
TSIT0383.TBL_CTQMQMSNT manually to 
D:\Round_3_Auto\temp\db dump\temp\TSIT0383_DB_DUMP

Step6:

close all folder of D:\Round_3_Auto\temp\(7zip won't work when explorer viewing the files!) > close dbeaver

Step7:

the script will zip the folders and output the job run status at the end of running.
(you can also check it in post_online_script\result.txt)

Step8:

move folders from D:\Round_3_Auto\date to round3 manually

Step9:

open WinSCP and remove old csv data from 
/uat.bk/scripts/tsit0410/db_restore/csv_data
/uat.bk/scripts/tsit0383/db_restore/csv_data